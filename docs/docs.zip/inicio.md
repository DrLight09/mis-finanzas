# Módulo Inicio (Dashboard)

Documenta la pantalla `#screen-inicio` y su código en `js/modules/inicio.js`. A diferencia del resto de los módulos documentados (`cuentas.md`, `mesada.md`, `spotify.md`, `prestado.md`, `encargos.md`, `personas.md`), Inicio **no tiene sheets propios** — es una pantalla de solo lectura que resume el estado de los demás módulos. Por eso este documento no sigue el inventario de [`guia-estilo-sheets.md`](./guia-estilo-sheets.md); esa guía sigue siendo la referencia si Inicio llegara a necesitar un sheet en el futuro.

> Los cambios puntuales de la sesión en que se migró este módulo no viven acá — ver [`CHANGELOG.md`](./CHANGELOG.md#inicio) y [`auditoria-tecnica.md`](./auditoria-tecnica.md) (nota del 2026-07-22).

---

## 1. Qué es

Inicio es la pantalla que se ve al abrir la app: un resumen agregado de patrimonio, disponibilidad por cuenta, gastos del mes, salud financiera, proyección y alertas ("Necesita atención"). No registra movimientos ni abre sheets — solo lee y muestra datos que otros módulos ya calcularon o guardaron en `S`.

## 2. Elementos de la pantalla (`#screen-inicio`)

| Elemento (id) | Contenido |
|---|---|
| `#heroTotal` | Patrimonio total visible (excluye la alcancía oculta, ver `guia-estilo-sheets.md#alcancía`). Sale de `calcPatrimonioDesglose().visible` (`js/core/patrimonio.js`), la misma cuenta del historial, la Proyección y Salud: resta tarjetas, «Yo debo» y plata ajena | El color y el mensaje de abajo cambian con la situación (ver `#hero-estado`).
| `#hero-formula` | Texto bajo el monto: «Cuentas + CDTs + Prestado» y, solo si existen, « − Deuda TC − Yo debo − Plata ajena» (`patrimonioFormulaTexto()`) |
| `#hero-patrimonio-label` | "Patrimonio total" o "Patrimonio visible" (cambia si hay alcancía activa) |
| `#hero-alcancia-indicator` | Pill ámbar "+$?? en alcancía oculta" — visible solo si `S.alcancia.saldoRegistrado > 0` |
| `#hero-estado` | Una línea de contexto bajo el monto, y el color de `#heroTotal`: **rojo** si el patrimonio es negativo («Debes más de lo que tienes: $X»), **neutro** si es exactamente 0, **ámbar** si hay patrimonio pero la liquidez neta es negativa («Tienes valor, pero tus deudas superan tu plata disponible en $X»), y neutro con «Sin contar lo que te deben: $X» cuando lo prestado pesa ≥ 25 % del patrimonio (`UMBRALES.hero`). Vacío (colapsado) en el caso sano. Lo calcula `calcEstadoHero()` y lo pinta `renderHeroEstado()` (`inicio.js`), que `refresh()` llama |
| `#hero-change-indicator` | Aviso de gasto del mes: «Gastos altos» (ámbar) si ya gastaste ≥ 80 % del ingreso de referencia del mes, «Gastas más de lo que ingresas» (rojo) si lo superaste; sin ingresos registrados, «Sin plata disponible» solo si ya no te queda |
| `#s-disp`, `#s-nu`, `#s-ef`, `#s-nequi`, `#s-prest`, `#s-cdt` | Grid de saldos por cuenta |
| `#s-disp-neto-tc` | Línea completa, chica, debajo del `grid3` de Disponible/Nu libre/Efectivo (fuera de las celdas `.stat`, para no afectar su altura — 2026-09-20) — "Neto de TC" (disponible menos la deuda TOTAL de TC, sin descontar lo ajeno). Vacía si no hay nada que restar; no reemplaza a `#s-disp` |
| `#s-gf`, `#s-gv`, `#s-gtotal` | Gastos del mes: fijos, variables, total |
| `#tc-deuda-card` | Card de deuda TC (oculto si no hay tarjetas) |
| `#health-score-card` | Anillo + tips de salud financiera |
| `#proyeccion-card` | Tendencia mensual + proyección a 3/6/12 meses. Sin patrimonio registrado, muestra un empty-state propio ("Sin datos suficientes") en vez del contenido normal |
| `#s-attn-section` / `#s-attn-list` | Sección colapsable "Necesita atención" |

Ninguno de estos elementos tiene `onclick` inline — son de solo lectura, salvo el toggle de la sección "Necesita atención" (ver punto 4) y los tooltips de Proyección (ya usaban `addEventListener`, no requirieron migración).

## 3. Funciones (`js/modules/inicio.js`)

**`renderAttencion()`** — arma la lista de alertas ("Necesita atención") a partir de: deudores con saldo pendiente, mesadas con pago parcial, tarjetas con cupo casi agotado o agotado, cobros de Spotify vencidos, y CDTs por vencer o vencidos. Controla también el estado abierto/cerrado de la sección (persistido en `sessionStorage`, con detección de items nuevos vía fingerprint). Además, al principio, la **situación financiera** con las mismas reglas que la Salud (`_itemsSituacion`): liquidez neta negativa (rojo), runway crítico (< 1 mes de gasto, ámbar) y racha de déficit (2 meses ámbar, 3 rojo). También lo que **tú debes** a personas («Yo debo») y las tarjetas **no activas con deuda**. Los **ingresos fijos con día esperado** que ya pasó sin ningún cobro registrado ese mes (`_itemsIngresosFijos`, ámbar). Los **gastos fijos con día de vencimiento** (`_itemsGastosFijos`): «vence en N días» / «vence hoy» (ámbar), «venció hace N días y no está pagado» (rojo) y la **brecha de caja**: el primer día de los próximos 30 en que tu plata disponible quedaría en negativo con lo ya programado (`calcCalendarioCaja`, rojo: «El 5 de nov tu plata disponible quedaría en −$X (vence Arriendo: $Y)»). Los límites (85 % de cupo, 7 días de CDT, 3 días de aviso) vienen de `UMBRALES.atencion` y el horizonte de `UMBRALES.caja`.

**`calcHealthScore()`** — calcula el puntaje de salud financiera (0-100) a partir de: fondo de emergencia (liquidez vs gastos mensuales), ratio de deuda TC vs ingresos, plata prestada a otros vs liquidez, ratio gastos/ingresos, CDTs activos, gastos fijos configurados, y diversidad de categorías de gasto. Devuelve `{ score, tips, ingresosMes, rendimientoCDTMes }`; `rendimientoCDTMes` (informativo, no entra en `ingresosMes`) trae desde 2026-10-09 los rendimientos del mes de cajitas + CDT (`Periodo.rendimientosDelMes`). Los gastos del mes incluyen los retiros manuales ("Restar dinero") y los ingresos incluyen los extras guardados en cajitas, ambos vía `Periodo`.

**`renderHealthScore()`** — pinta el anillo SVG y los tips de `calcHealthScore()` en `#health-score-card`. El círculo de progreso usa `transform="rotate(-90 38 38)"` para que el relleno empiece arriba (a las 12) y avance en sentido horario, en vez de arrancar en el punto por defecto de un `<circle>` SVG (a las 3) — ver `CHANGELOG.md#inicio` (2026-08-30) por qué no se usa `stroke-dashoffset` para esto.

**`renderProyeccion()`** — calcula la tendencia mensual de patrimonio (trimmed mean sobre los últimos 90 días de `S.patrimonioHistorial`, con mínimo de 30 días reales para no extrapolar de un solo movimiento grande; con menos muestra «Tendencia en construcción: llevas N de 30 días») y proyecta a 3/6/12 meses en `#proyeccion-card`. Incluye tooltips táctiles con el detalle de cada proyección.

**`_checkGastoAlto()`** — compara el gasto del mes contra el **ingreso de referencia** (el mayor entre lo ingresado este mes y el ingreso típico; el mismo de la Salud), no contra lo disponible (que ya descuenta ese gasto y con disponible ≤ 0 no avisaba nada). `UMBRALES.gastoAlto.fraccionDelIngreso` = 0,8. Se engancha a `refresh()` mediante `hookGlobal`. Usa clases (`ix-hero-alerta-*`), no estilos inline.

**`_renderDispNetoTC()`** — pinta `#s-disp-neto-tc` con `window._dispActualHoy` (el mismo `disp` que `refresh()`, en `js/core/refresh.js`, acaba de usar para pintar `#s-disp` — no se recalcula acá, ver `CHANGELOG.md#inicio` 2026-09-20) menos la deuda TOTAL de las tarjetas de crédito (con piso en 0 por tarjeta, para que un saldo a favor no reste del total), sin descontar lo confirmado como ajeno — la app no puede saber si esa parte ajena ya te la devolvieron por fuera de un pago a la tarjeta, así que asume el peor caso. Vacía el texto si no hay nada que restar. Se engancha a `refresh()` en el mismo monkey-patch que `_checkGastoAlto()`, DESPUÉS de que `refresh()` original corra (para que `window._dispActualHoy` ya esté actualizado).

**IIFE de reposicionamiento** — mueve `#s-attn-section` justo debajo del `.hero` de Inicio al cargar el módulo (antes vivía más abajo en el DOM estático).

## 4. Qué NO vive en `inicio.js` (a propósito)

| Código | Por qué se quedó en `index.html` |
|---|---|
| `refresh()` | Orquestador central compartido por las 13 pantallas — no es lógica de Inicio, aunque escribe varios de sus elementos (`#heroTotal`, `#s-disp`, etc.) |
| `_renderMejoras()` / `_hookRefreshMejoras()` | Además de llamar a `renderHealthScore()`/`renderProyeccion()`, dispara `renderPresupuestos()` (módulo de Análisis) — infraestructura compartida entre dos módulos |
| Selectores de cuenta (`#nuTotalDisp`, `#sel-nequi-saldo`, etc.) | Se actualizan dentro de `refresh()` junto con los de Inicio porque comparten las mismas variables calculadas (`nu`, `nequi`, `ef`), pero pertenecen a la pantalla Cuentas, no a Inicio |
| `window._dispActualHoy` | Variable global que `refresh()` (`js/core/refresh.js`) expone con el mismo `disp` que pinta en `#s-disp`, para que `_renderDispNetoTC()` la reste en vez de recalcular "disponible" por su cuenta (ver `CHANGELOG.md#inicio`, 2026-09-20) |

## 5. Seguridad — hallazgos de esta migración

- **`onclick` inline:** ninguno. `screen-inicio` es de solo lectura.
- **`.innerHTML` sin escapar:** un caso — `spNombreDe(p)` (nombre de persona en Spotify) se interpolaba sin `escHtml()` en `renderAttencion()`. Corregido. Es la sexta vez que aparece este mismo patrón (texto libre envuelto en una función auxiliar) desde que empezó la auditoría — ver `auditoria-tecnica.md#2`.
- El resto de `renderAttencion()`, `renderHealthScore()` y `renderProyeccion()` se revisó a mano contra el mismo patrón: solo interpolan números calculados, strings fijos, o valores que ya pasaban por `escHtml()`/`fmt()`.

## 6. Dependencias de carga

`js/modules/inicio.js` debe cargarse **después** de: `js/core/events.js`, `mesada.js`, `spotify.js`, `prestado.js` y `tarjetas_credito.js` — `renderAttencion()` usa `getMesadaData()`, `spNombreDe()`, `spPersonaPagadaVigente()` y `tcCupoUsadoPct()`, definidas en esos módulos. Por eso su `<script src>` va al final de `index.html`, después de `alcancia.js`.
