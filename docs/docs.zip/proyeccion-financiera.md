# Proyección financiera

Documenta la sección **Proyección financiera** de `mis-finanzas` (vive en Inicio, no en `screen-analisis`, pero se alimenta de los mismos snapshots que Análisis financiero). Qué la alimenta, qué la afecta, qué no la afecta, y por qué.

Relacionado: [`analisis-financiero.md`](./analisis-financiero.md) documenta `renderAnalisis()` y comparte con este módulo el historial de patrimonio (`S.patrimonioHistorial`) y `calcPatrimonioTotal()`.

---

## 1. Objetivo

Estima cuánto va a crecer (o decrecer) el patrimonio total en 3/6/12 meses, a partir de la tendencia real de los últimos días — sin pedirle al usuario que proyecte nada a mano.

---

## 2. Cómo funciona (mecanismo central)

La proyección **no** usa ingresos ni gastos registrados directamente. Su única fuente de verdad es el **historial de patrimonio** (`S.patrimonioHistorial`): un snapshot del patrimonio total guardado cada vez que el usuario guarda datos (`save()`), y también automáticamente al abrir la app.

### El pipeline completo

```
Cualquier acción del usuario
        ↓
     save()
        ↓
snapshotPatrimonio()          ← guarda { fecha, valor, montoBase? }
        ↓
calcPatrimonioTotal()         ← calcula el patrimonio real en ese instante
        ↓
S.patrimonioHistorial[]       ← array de hasta 365 snapshots diarios
        ↓
renderProyeccion()            ← lee los últimos 120 puntos (UMBRALES.proyeccion.puntosHistorial) y calcula tendencia
```

### Cómo se calcula la tendencia mensual

`renderProyeccion()` (en `js/modules/inicio.js`) toma los últimos 120 snapshots (≈ 4 meses; con 90 la ventana nunca llegaba a los 90 días que pide «estable») y recorre pares consecutivos sumando dos totales: el cambio neto de patrimonio y los días reales transcurridos entre el primer y el último punto.

```
cambioDelDía = (valorVisible[i] - valorVisible[i-1]) - montoBase[i]
cambioNetoTotal = Σ cambioDelDía          (sobre todos los pares consecutivos)
díasReales      = Σ días_entre_i_y_(i-1)
tendenciaMensual = (cambioNetoTotal / díasReales) * 30
```

`valorVisible` (patrimonio sin la alcancía) se usa en vez de `valor` crudo, con `.valor` como fallback para puntos guardados antes de que existiera ese campo — mismo criterio que la gráfica de Análisis financiero (§5). El `montoBase` se resta para descontar **saldos iniciales y ajustes de apertura** — plata que no es ingreso real sino corrección de datos.

**No es un promedio de tasas por intervalo, ni aplica ningún recorte de outliers (trimmed mean).** Es la suma del cambio neto total dividida entre los días totales — un promedio ponderado por días, no un promedio de promedios. La razón, según el propio comentario del código: el ingreso real (mesada, pagos) llega en pocos días grandes, no repartido parejo día a día; una mediana o un trimmed-mean de tasas por-intervalo terminaría descartando casi siempre un día de ingreso real por "outlier" y subestimando la tendencia. Sumar el cambio neto y dividir por los días totales sí refleja el ingreso real proporcionalmente, y de paso una caída de un día que se revierte al siguiente se autocancela casi sola en la suma, sin necesitar filtrar nada a mano.

### Niveles de confianza

| Días de historial | Qué se muestra |
|---|---|
| < 30 | Sin cifras a 3/6/12 meses: «Tendencia en construcción: llevas N de 30 días de historial» (`UMBRALES.proyeccion.diasMinimos`) |
| 30–89 | Tendencia y proyecciones con la marca «estimación» |
| 90+ y ritmo consistente | Marca ESTABLE (verde). «Consistente» = el ritmo mensual de cada uno de los tres **tercios** del historial (`_ritmosPorTercio`) va en la misma dirección que la tendencia total (tolerancia del 10 %) |
| 90+ pero ritmo irregular | «estimación» y una línea con el rango («Tu ritmo cambió mucho entre períodos (de −$X a +$Y al mes)»): una compra grande en un solo tercio ya no se extrapola como ritmo mensual ni se llama «estable» |

### Calendario de caja a 30 días (lo ya programado)

La proyección de 3/6/12 meses extrapola el **pasado**. El calendario de caja mira lo que ya se **sabe** del futuro y responde «¿se me acaba la plata antes del día 30, y cuándo?». No depende de la tendencia: se muestra también sin historial. Lo calcula `calcCalendarioCaja()` (`inicio.js`) con la función pura `Periodo.saldoProyectado(saldoInicial, eventos, hoy, dias)`, partiendo de la **liquidez neta** de hoy (`calcLiquidez().neta`, que ya descuenta lo que debes: por eso no hay evento de tarjeta, pagarla no la cambia).

| Evento | Qué hace | Detalle |
|---|---|---|
| Gasto fijo con día, sin pagar | **Sale** en su fecha | El vencido sin pagar sale hoy (es lo primero que saldrá). Recurre el mes siguiente si cae dentro del horizonte |
| Ingreso fijo con día, sin cobrar | **Entra** en su fecha | Solo si su día **no** ha pasado: uno atrasado no se da por hecho (igual que «lo que te deben» no cuenta hasta que llega) |
| CDT que vence | **Entra** (capital + rendimiento) | Desde el día siguiente al vencimiento (`cdtVencido`) |

- **Se evalúa al cierre de cada día:** las entradas y salidas del mismo día se **netean** (no se sabe en qué orden pasan: un «déficit» de media mañana por el orden sería una falsa alarma; sueldo y arriendo el mismo día no alertan).
- **Resultado:** `puntos` (saldo tras cada día con eventos), `minimo` (el día más bajo) y `primerDeficit` (el primer día en negativo y qué lo causó: la mayor salida de ese día). `primerDeficit` solo existe si hoy no estás ya en negativo (eso ya lo dicen el hero, la Salud y Atención).
- **En la tarjeta:** «Próximos 30 días, con lo ya programado (gastos e ingresos fijos, CDT que vencen): tu plata disponible pasaría de $X a $Y. Lo más bajo: $Z el 12 de nov. El 5 de nov quedaría en −$W (vence Arriendo)». **En Atención** (rojo): «El 5 de nov tu plata disponible quedaría en −$W (vence Arriendo: $900.000)».
- Solo ve lo que registraste con día: un gasto o ingreso fijo sin día no aparece. Horizonte en `UMBRALES.caja.horizonteDias`.

### Compras grandes (una moto)

Las compras marcadas como «compra grande» (`gv.grande`, ver `docs/gastos.md`) bajaron el patrimonio, y ese golpe **ya está** en el valor de hoy (el punto de partida de la proyección). Lo que no es, es un ritmo: para la pendiente, en cada intervalo del historial se suma de vuelta lo que cayó por una compra grande de esa fecha (`Periodo.comprasGrandesEntre`). Sin esto, una moto de 15 M se extrapolaba como −15 M cada mes, o la tendencia quedaba en «estimación» para siempre. La tarjeta lo dice sin esconderlo: «Sin contar tu compra grande (Moto: $15.000.000), tu ritmo es +$300.000 al mes. Ya está descontada de tu patrimonio de hoy; la proyección no la repite». La compra no tiene que estar marcada: si el usuario no ha decidido, se detecta sola cuando supera su gasto mensual normal (`Periodo.compraGrandeEstado`, ver `docs/gastos.md`); y si dijo que **no** es una compra grande, se respeta y cuenta como ritmo. Con menos de 2 meses de historia no se detecta nada sola (la proyección se limita a mostrar «estimación» y el rango cuando el ritmo no fue parejo).

### Valores negativos y patrimonio en cero

- Las tarjetas de 3/6/12 meses muestran el valor **con signo** (antes `Math.max(0, valor)` los mostraba como `$0`, justo cuando la proyección era peor: −$1.100.000 aparecía como «$0»).
- El **porcentaje** solo se calcula sobre una base positiva; con patrimonio ≤ 0 se omite y la nota dice «Pasarías a números rojos», «Seguirías en números rojos» o «Saldrías de números rojos».
- «Sin datos» solo si no hay **ningún** activo visible ni deuda (la alcancía no cuenta: está oculta). Un patrimonio exactamente 0 con cuentas y deudas es un dato real y sí se proyecta.
- Fechas del historial leídas con `_fechaSafe` (una «2026-9-26» sin cero no produce `NaN`).
- **«A este ritmo, tu plata disponible duraría unos N meses»:** solo con tendencia negativa y liquidez neta positiva (`calcLiquidez().neta ÷ |tendencia|`, máximo `UMBRALES.proyeccion.maxMesesRunway`). Es una extrapolación del ritmo del patrimonio, no el runway de gastos de la tarjeta de Salud.
- **Texto de deuda de tarjeta:** «Deuda TC: $total (propia $x) ya descontada del patrimonio» — el patrimonio resta la deuda TOTAL (incluida la de encargos y préstamos), así que se muestra el total y cuánto es propio.


Con menos de un mes un solo movimiento grande domina el promedio y se extrapola como si se repitiera todo el año (una mesada de $80.000 dentro de una ventana de 9 días daba +$267.000 al mes, unos $3,2 millones a 12 meses). Hasta 2026-10-27 el mínimo era 7 días y existía una marca PRELIMINAR (7–29 días) que mostraba la cifra de todos modos; se retiraron las dos (ver `CHANGELOG.md`).

---

## 3. `calcPatrimonioTotal()` — qué suma y qué resta

Esta función es el corazón del módulo. La proyección hereda todo lo que ella incluye o excluye. Desde 2026-10-29 el cálculo vive en `calcPatrimonioDesglose()` (`calcPatrimonioTotal()` es su envoltorio) y la card usa `calcPatrimonioVisible()` en vez de restar la alcancía por su cuenta; ver `analisis-financiero.md` §10.

### Suma (activos)

| Componente | Fuente en `S` |
|---|---|
| Cajitas Nu (capital + intereses acumulados) | `S.cajitas` → `calcC(c).val` |
| CDTs en cajitas (capital + rendimiento proyectado) | `S.cajitas[].cdts` → `calcCDT(cdt).val` |
| Saldo Nequi | `S.cuentas` (cuenta `nequi`, vía `getSaldoFuente('nequi')`) |
| Saldo Efectivo | `S.cuentas` (cuenta `efectivo`, vía `getSaldoFuente('efectivo')`) |
| Saldo deudores (lo que me deben, positivo únicamente) | `S.deudores` → `getDeudorSaldoPatrimonio(d)` |
| Cuentas personalizadas (todas, sin filtro) | `S.cuentas` con `tipo: 'custom'` (`cuentasCustom()`) → suma de `saldo` |
| Alcancía oculta (saldo registrado mientras está activa) | `S.alcancia.saldoRegistrado` |

### Resta (pasivos)

| Componente | Fuente en `S` | Motivo |
|---|---|---|
| Deuda total de tarjetas de crédito | `S.tarjetasCredito[].deuda` | Es plata que debo |
| Lo que yo le debo a otras personas | `S.misDeudas` → `totalMisDeudasPendiente()` | Físicamente en mis cuentas pero no es mía |
| Plata comprometida ajena en cuentas propias | `_saldoCPAjeno()` | Plata de otra persona que administro y aún no pagué |

> **`calcC()`/`calcCDT()` y `Deudas`:** `calcC`, `calcCDT` viven en `js/core/nu-calc.js` y `Deudas` en `js/core/calc-helpers.js` (núcleo, carga de entrada), así que `calcPatrimonioTotal()` —que corre en cada `save()`— los llama directo (ya no hay envoltorios `_calcCSafe`/`_calcCDTSafe`). Aun así, `snapshotPatrimonio()` no guarda ningún punto si alguno todavía no cargó (`_patrimonioDependenciasListas()`: `calcC`, `calcCDT` y `Deudas` definidos): sin ese guard, un snapshot tomado antes de que carguen grabaría un patrimonio artificialmente bajo de forma permanente en el historial.

> **Nota sobre `_saldoCPAjeno()`:** solo resta los destinos de plata comprometida que ya llegaron (`item.recibido = true`), son de tipo `gasto` con `gastoOrigen` cajita o TC, y todavía no se pagaron (`yaPague !== true`). Cuando se marca `yaPague`, la plata ya salió de la cuenta y deja de restarse.

---

## 4. Qué afecta la proyección (y cómo)

La proyección cambia cuando `calcPatrimonioTotal()` devuelve un valor diferente al snapshot anterior.

### Spotify

Cobrar cuotas **sí afecta** la proyección: el cobro entra a una cuenta real (`sumarFuente`) → el patrimonio sube. Pagar el plan sale de una cuenta (`descontarFuente`) → el patrimonio baja. El **neto del mes** queda capturado automáticamente en el cambio de patrimonio; no hay registro separado en `S.movimientos` — el efecto llega indirectamente por el cambio de saldo de la cuenta.

### Mesadas

Registrar el pago **sí afecta** la proyección porque la plata entra a una cuenta real. `S.mesadas` se usa solo para proyectar cuánto se *espera* recibir; el impacto en la tendencia real llega por el cambio de saldo al momento del pago.

### Tarjetas de crédito

Afectan la proyección de dos maneras:

- **Una compra:** aumenta `tc.deuda` → patrimonio baja.
- **Un pago:** disminuye `tc.deuda` y descuenta la cuenta de pago → neto cero (ya se había restado al comprar).

> La deuda TC que corresponde a encargos (`cargo_encargo`), plata comprometida (`_desdeCP`) y préstamos TC (`cargo_prestamo`) **no se resta del patrimonio** porque es ajena — `calcDeudaTcPropia()` la excluye.

### Encargos

No son patrimonio propio, así que el saldo de un encargo nunca entra en `calcPatrimonioTotal()`. Si el usuario saca un margen/diferencial que entra a una cuenta propia, **eso sí afecta** el patrimonio. Si pone plata propia para cubrir un encargo y luego se la recuperan, el efecto neto es cero.

### Plata comprometida

La ajena que ya llegó y no se ha pagado se resta vía `_saldoCPAjeno()`; al pagarse, sale de la cuenta y deja de restarse (neto cero). La propia no tiene efecto especial: ya está en la cuenta y se refleja normalmente.

### Alcancía oculta

Sí afecta la proyección real aunque esté oculta en el hero de Inicio: `calcPatrimonioTotal()` suma `S.alcancia.saldoRegistrado` mientras está activa. Un depósito externo (regalo, mandado, efectivo sin cuenta) genera ingreso real → sube. Un depósito desde cuenta propia es traslado → no cambia. Al destapar, `saldoRegistrado` se resetea a `0` **antes** de sumar a la cuenta destino, para evitar doble conteo.

### Gastos variables y fijos

Cada gasto descuenta una cuenta real → el patrimonio baja, capturado automáticamente. Excepciones que no afectan el análisis de gastos en pantalla (pero sí el patrimonio al salir de la cuenta): `_esAlcancia`, `esPagoGastoFijo`, `_esPagoTC`.

### Restar dinero

Baja el saldo de una cuenta real → el patrimonio baja, capturado automáticamente. Desde 2026-10-09 además cuenta como gasto del mes (`clase: 'gasto'`, categoría `Ajuste`) en Análisis, Inicio y Wrapped; la proyección no cambia porque ya salía del patrimonio.

### Ingresos a cualquier cuenta / intereses

Cualquier flujo que suba el saldo de Nequi, Efectivo, cajita o cuenta personalizada mejora la tendencia. Los intereses de cajitas/CDTs se capturan automáticamente vía `calcC()`/`calcCDT()`, sin acción del usuario.

---

## 5. Qué NO afecta la proyección

- **Transferencias entre cuentas propias:** la suma de activos no cambia.
- **Préstamos a terceros con fuente especificada:** neto cero (una cuenta baja, el saldo deudor sube). **Sin fuente especificada:** `descontarFuente('')` no hace nada, así que el saldo deudor sube pero ninguna cuenta baja → el patrimonio sube sin que haya ingreso. Es un uso legítimo (se sabe que existe la deuda pero no de qué cuenta salió), y desde 2026-10-10 se trata como **ajuste de base**: `montoBase` del día lo descuenta, igual que una apertura, así que **no cuenta como crecimiento** en la tendencia ni en la proyección (`_movsDeudaSinCuenta()`, `recalcularMontoBaseHistorial()` en `core-state.js`). Antes un solo préstamo de $500.000 sin cuenta llevó la proyección a 12 meses de +$1,2 M a +$6,7 M. Lo mismo vale para un abono/pago recibido sin cuenta destino (−) y para "Yo debo" (recibido sin cuenta −, pago sin cuenta +). Si ese préstamo en realidad es plata nueva (p. ej. un regalo), el movimiento lleva `clase: 'ingreso'` y cuenta como ingreso del mes en vez de ajuste.
- **Que alguien me preste plata (con cuenta especificada):** neto cero (la cuenta sube, `misDeudas` sube y se resta). **Excepción sin cuenta especificada:** `_aplicarMovMiDeuda(p)` llama `sumarFuente(cuenta, monto, …)` solo por cada cuenta indicada en `p.cuentas`; con la lista vacía no toca ninguna cuenta, así que `misDeudas` sube sin que suba ningún activo.
- **Saldos iniciales / aperturas:** descontados del cálculo vía `montoBase`.
- **Pagos de TC:** neto cero (baja la cuenta de pago, baja la deuda en igual medida).
- **Gastos de encargos sin diferencial:** el gasto queda registrado en el encargo, no en el patrimonio propio. Solo un margen que entra a cuenta propia cambia el patrimonio.

---

## 6. Resumen por módulo

| Módulo / acción | ¿Afecta proyección? | Mecanismo |
|---|---|---|
| Mesada recibida | ✅ Sí — sube | Entra a una cuenta real |
| Spotify — cobrar cuota | ✅ Sí — sube | `sumarFuente` en la cuenta destino |
| Spotify — pagar plan | ✅ Sí — baja | `descontarFuente` en la cuenta origen |
| Compra con TC propia | ✅ Sí — baja | Aumenta `tc.deuda`, restado del patrimonio |
| Pago de TC | ❌ Neto cero | Baja cuenta de pago + baja deuda TC en igual monto |
| Compra con TC de encargo / plata comprometida | ❌ No | `calcDeudaTcPropia()` excluye esa deuda |
| Encargo — depósito | ❌ No | El saldo del encargo no es patrimonio propio |
| Encargo — margen/diferencial a cuenta propia | ✅ Sí — sube | El diferencial entra a una cuenta real |
| Plata comprometida ajena — recibida y no pagada | ✅ Sí — resta | `_saldoCPAjeno()` la descuenta |
| Plata comprometida ajena — pagada | ❌ Neto cero | Sale de la cuenta, deja de restarse |
| Alcancía — depósito desde cuenta | ❌ Neto cero | Traslado: la cuenta baja, `saldoRegistrado` sube |
| Alcancía — depósito externo (regalo, efectivo) | ✅ Sí — sube | Ingreso real: `S.movimientos` tipo `'entrada'` |
| Alcancía — destapar | ✅ Si hay diferencia positiva | "Dinero extra" es ingreso nuevo tipo `'entrada'` |
| Gasto variable | ✅ Sí — baja | Sale de una cuenta real |
| Gasto fijo pagado | ✅ Sí — baja | Sale de una cuenta real |
| Restar dinero | ✅ Sí — baja | Sale de una cuenta real (además cuenta como gasto `Ajuste`) |
| Ingreso a cualquier cuenta | ✅ Sí — sube | Aumenta saldo de la cuenta |
| Intereses de cajita / CDT | ✅ Sí — sube | `calcC()` y `calcCDT()` los incluyen en el activo (por mes: `Periodo.rendimientosDelMes`, aparte del ingreso operativo) |
| Transferencia entre cuentas propias | ❌ Neto cero | Un activo sube, otro baja en igual monto |
| Préstamo a tercero (fuente especificada) | ❌ Neto cero | La cuenta baja, el saldo deudor sube |
| Préstamo a tercero (sin especificar fuente) | ❌ Excluido (ajuste de base) | Ninguna cuenta baja, el deudor sube: `montoBase` lo descuenta (salvo `clase: 'ingreso'`) |
| Alguien me prestó (con cuenta destino) | ❌ Neto cero | La cuenta sube, `misDeudas` sube y se resta |
| Saldo inicial / apertura | ❌ Excluido | `montoBase` lo descuenta del cálculo de tendencia |
| Abono de un deudor | ✅ Sí — depende | Entra a una cuenta real (sube) y el deudor baja |
