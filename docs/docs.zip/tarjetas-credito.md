# Tarjetas de crédito

## 1. Objetivo

Llevar el registro de las tarjetas de crédito propias: cuánto cupo tiene cada una, cuánto se ha gastado, cuánto se debe hoy y si la plata guardada en una cajita alcanza para pagarle al banco. No intenta simular el funcionamiento real de un banco — no hay fecha de corte, no hay extracto, no hay pago mínimo. Solo responde tres preguntas: ¿cuánto debo?, ¿cuánto cupo me queda? y ¿me alcanza lo que tengo guardado para cubrirlo?

## 2. Conceptos importantes

- **Deuda (`tc.deuda`)** — lo que se debe hoy en total, sin importar de quién sea "moralmente" esa plata. Es un saldo neto, no un acumulado histórico: sube con compras y cargos, baja con pagos.
- **Deuda propia vs. deuda ajena** — una tarjeta puede tener cargos que en realidad son de un encargo, un préstamo o "plata comprometida" (alguien más te va a devolver esa plata, o ya la tenías apartada para otra cosa). La **deuda ajena** es la suma de esos cargos menos los pagos ya hechos sobre ellos; la **deuda propia** es lo que queda de la deuda total al restarle la ajena. Esta separación solo importa para calcular patrimonio y salud financiera — **el banco cobra el 100% de la deuda total sin importar esta distinción**, así que cualquier widget que responda "¿me alcanza para pagar?" debe usar la deuda total, nunca la propia.
- **Cupo disponible** — no se guarda como campo; siempre se calcula como `cupo total − deuda actual`. Si la tarjeta no tiene cupo configurado (`tc.cupo` en 0 o vacío), se trata como sin restricción.
- **Compra vs. pago vs. "cargo"** — una *compra* se registra desde este módulo (o desde el gasto genérico, ver §5). Un *pago* reduce la deuda y sale de una cuenta real. Un *cargo* (`tipo: 'cargo_encargo'` o `'cargo_prestamo'`) es un tercer tipo de movimiento que **no crea este módulo** — lo generan Encargos o Préstamos cuando usan la tarjeta como método de pago, y vive en `S.tcMovimientos`, no en `tc.compras`. Tarjetas de crédito solo los *lee* (para sumarlos a la deuda y al historial), nunca los crea ni los borra.
- **Cobertura** — si una tarjeta tiene una cajita vinculada (`tc.cajitaId`), se muestra si el saldo de esa cajita alcanza para cubrir la deuda total de todas las tarjetas vinculadas a ella (puede haber más de una tarjeta por cajita).
- **Cargo especial (`_esCargoEspecial`)** — un tercer tipo de "compra" pensado para cuando el banco impone un cargo (interés por cupo al tope, comisión, corrección de cierre) que **no fue una decisión de gasto del usuario**. Vive dentro de `tc.compras` con el flag `_esCargoEspecial:true` y un `_motivoCargo` (`'interes' | 'comision' | 'otro'`), y se crea/borra por el mismo camino que una compra normal (`tcCrearCompra`/`tcEliminarCompraInterna`) — la única diferencia real es que su sheet de registro (`confirmarCargoEspecialTC`) **no valida cupo disponible**, a propósito (ver §3 y §7).

## 3. Reglas que nunca deben romperse

- **`tc.deuda` nunca se edita a mano fuera de `tcRecalcular`.** Cualquier función que necesite cambiar la deuda debe hacerlo agregando/marcando un registro (compra, pago, saldo inicial) y llamando a `tcRecalcular(tc)` — nunca sumando o restando directo sobre `tc.deuda`. Como red de seguridad, `refresh()` recalcula la deuda de todas las tarjetas desde cero en cada ciclo (`tcNormalizarTarjetas` → `tcRecalcular`), así que cualquier mutación manual que quede suelta en otra parte del código queda pisada de inmediato — no rompe nada, pero es código muerto y confunde a quien lea después.
- **Ningún registro se borra físicamente.** Compras y pagos se marcan `eliminado:true` y se excluyen de los cálculos — nunca se hace `.splice()` ni se filtra el array. Esto preserva el historial completo y permite que `tcBuscarCompraPorIdOMatch` siga encontrando compras viejas por descripción+monto cuando no hay un id vinculado (datos de antes de este refactor).
- **Un mismo camino para crear una compra, sin importar la pantalla de origen.** Tanto el botón "+ Compra" de este módulo como el flujo genérico de "Gasto variable" pasan por `tcCrearCompra()` — la misma validación de cupo debe aplicar en ambos lugares. Si se agrega una tercera forma de crear una compra en TC en el futuro, también debe pasar por `tcCrearCompra()` y repetir la validación de cupo, no reinventar el flujo.
- **La tarjeta nunca es un destino de dinero que entra.** Los selectores de "fuente" que representan de dónde *sale* la plata sí incluyen tarjetas (`incluirTC=true` en `poblarFuente`); los que representan a dónde *entra* la plata (`getFuentesSinTC`) las excluyen siempre. Registrar dinero "hacia" una tarjeta no tiene sentido en este modelo — lo que existe es pagar (reducir deuda) o comprar (aumentarla). En Encargos (traspaso «Me lo regalaron», reubicación y destino de «Compra con TC») la regla vive en `FuentesFiltro.puedeRecibir()` / `receptoras()` y se aplica también al confirmar.
- **Un pago cancela en este orden: primero el saldo inicial pendiente, luego la deuda ajena, y lo que sobra cancela la propia** (`calcSaldoInicialPendiente` → `calcDeudaAjenaDeTarjeta` → `calcDeudaTcPropiaDeTarjeta`). Esto evita que la deuda ajena o el saldo inicial calculados superen alguna vez a la deuda total.
- **Eliminar una compra o un pago de TC, sea desde el detalle de la tarjeta o desde el feed general de movimientos, siempre pasa por `tcEliminarCompraInterna`/`tcEliminarPagoInterna`.** Nunca se reimplementa la reversión a mano en el punto de entrada — ambos casos existen (ver `abrirDetalleTCSheet` y el feed general en `eliminarMovimiento`) y deben terminar en la misma función interna para no desincronizar la deuda.
- **Un pago de TC (`_esPagoTC`) nunca cuenta como gasto real del mes; una compra de TC (`_esCompraTC`) sí.** El gasto real ya se contó cuando se hizo la compra — el pago solo mueve plata de una cuenta a saldar la deuda, no es un gasto nuevo. Esta exclusión vive centralizada en `_esGastoVarNoReal()`; un flag de exclusión nuevo se agrega ahí, no repetido pantalla por pantalla.
- **La tarjeta no simula un banco real.** No se agregan fechas de corte, extractos ni pago mínimo — es una decisión de diseño explícita (ver §7), no un hueco por completar.
- **Una compra siempre valida cupo disponible; un cargo especial nunca lo valida, a propósito.** Toda compra real (`confirmarCompraTC`, o el "Préstamo con TC" de Préstamos — ver más abajo) debe rechazarse si supera el cupo disponible de la tarjeta. El único camino que se salta esa validación deliberadamente es "Cargo especial" (`confirmarCargoEspecialTC`), porque ahí el monto no lo elige el usuario — lo impone el banco (interés, comisión) y por definición puede superar el cupo configurado. Si se agrega un cuarto camino para crear una "compra" en el futuro, hay que decidir explícitamente a cuál de los dos grupos pertenece — no asumir ninguno de los dos por defecto.
- **"Préstamo con TC" (módulo Préstamos, `prestado.js`) es una compra real a efectos de cupo, no un cargo especial.** Aunque técnicamente se registra como un `tcMovimientos` tipo `'cargo_prestamo'` (igual que "Compra con TC" de Encargos, que tampoco valida cupo — ver `encargos.md`), acá sí importa la decisión de gasto del usuario: eligió comprar algo con su propia tarjeta para prestárselo a alguien. `confirmarPrestamoTC` valida `tc.cupo && tcCupoDisponible(tc) < montoTC` antes de guardar — usando `montoTC` (el valor real que carga la tarjeta si hay diferencial activo), no el monto que se le dijo al deudor. Corregido 2026-09-04 tras un bug real reportado por el usuario: la función nunca validaba cupo, ni con el monto normal ni con el "valor real" del diferencial (ver `CHANGELOG.md#prestado`).

## 4. Modelo de datos

Cada tarjeta vive en `S.tarjetasCredito[]`:

```js
{
  id, nombre, banco, franquicia, color,
  cupo,               // 0 = sin límite configurado, sin restricción de cupo
  deuda,              // SIEMPRE derivado — nunca se edita a mano, ver §3
  estado,             // 'activa' | 'bloqueada' | 'cancelada' | 'vencida'
  cajitaId,           // cajita vinculada para pagar esta tarjeta, o null
  saldoInicial: {id, monto, fecha, nota, eliminado} | null,  // deuda que ya existía antes de usar la app
  compras: [{
    id, desc, cat, fecha, monto, nota, eliminado,
    _esFavor, _desdeCP,      // opcionales: marca que esta compra es deuda ajena
    _esCargoEspecial, _motivoCargo   // opcionales: cargo del banco (interés/comisión), no validó cupo — ver §2/§3
  }],
  pagos: [{id, monto, fecha, fuente, nota, eliminado}],
  creadoEn
}
```

Aparte, `S.tcMovimientos[]` (compartido con Encargos y Préstamos, no exclusivo de este módulo) guarda los "cargos" que otros módulos generan al usar una tarjeta como método de pago:

```js
{ id, tcId, tipo, monto, fecha, desc, nota, deudorId, eliminado }
// tipo: 'cargo_encargo' | 'cargo_prestamo' | 'corte_aviso' (legado, se limpia en cada refresh)
```

`tcMovimientos` es leído por este módulo (para sumar a la deuda y mostrarlo en el historial de la tarjeta) pero **no** es creado ni eliminado por él — esa responsabilidad es de Encargos/Préstamos.

### Clase de los movimientos (2026-10-09)

Desde 2026-10-09 todo movimiento de ingreso/gasto lleva `clase` (`ingreso` · `gasto` · `neutro` · `ajuste`), escrita al crearlo, y los totales del mes (`Periodo`) la leen en vez de deducirla de etiquetas. Ver `libro-de-movimientos.md` (el libro no clasifica: lo hace `clase`) y `CHANGELOG.md#infraestructura--seguridad`.

- Compra con TC (`_esCompraTC`, en `S.gastosVar`): `clase: 'gasto'`.
- Pago de la tarjeta (`_esPagoTC`): `clase: 'neutro'` — cancela deuda, no es un gasto nuevo.

## 5. Flujo

**Registrar una compra (desde este módulo):**
`abrirCompraTC(tcId)` → validar descripción/monto/cupo → `tcCrearCompra(tc, datos)` (agrega a `tc.compras`, llama `tcRecalcular`) → se crea un gasto espejo en `S.gastosVar` marcado `_esCompraTC` → `refresh()` → `renderTCScreen()`.

**Registrar una compra (desde "Gasto variable", fuente `tc:<id>`):**
Mismo destino final — `addGastoVar()` detecta `fuente.startsWith('tc:')`, valida cupo, y llama al mismo `tcCrearCompra()`. El gasto en `S.gastosVar` se crea una sola vez (no hay doble registro); la diferencia con el camino anterior es solo la pantalla de origen.

**Pagar una tarjeta:**
`abrirPagarTC(tcId)` → validar monto/fuente/saldo disponible en la cuenta de origen → `descontarFuente(fuente, monto)` (saca la plata real de la cuenta) → `tcCrearPago(tc, datos)` (agrega a `tc.pagos`, recalcula deuda) → gasto espejo marcado `_esPagoTC` → `refresh()`.

**Eliminar una compra:**
`eliminarCompraTC(tcId, compraId)` (o la ruta equivalente del feed general) → confirmación → `tcEliminarCompraInterna` (marca `eliminado`, recalcula) → se filtra el gasto espejo de `S.gastosVar` → `refresh()`.

**Eliminar un pago:**
`eliminarPagoTC(tcId, pagoId)` → confirmación → `tcEliminarPagoInterna` (marca `eliminado`, recalcula — la deuda sube de vuelta) → `sumarFuente(fuente, monto)` (la plata vuelve a la cuenta de origen) → se filtra el gasto espejo → `refresh()`.

**Registrar un cargo especial (interés, comisión, corrección del banco):**
Botón "+ Cargo especial" dentro del detalle de la tarjeta (`abrirDetalleTCSheet`) → `abrirCargoEspecialTC(tcId)` → completar descripción/monto/motivo → `confirmarCargoEspecialTC()`: si el monto supera el cupo disponible, se avisa explícitamente en el diálogo de confirmación (no se bloquea — ver §3) → `tcCrearCompra(tc, {..., _esCargoEspecial:true, _motivoCargo})` (misma capa de datos que una compra, `tcRecalcular` incluido) → gasto espejo en `S.gastosVar` marcado `_esCompraTC` (sí cuenta como gasto real del mes, igual que una compra — el interés/comisión ya fue un costo real) → `refresh()` → vuelve a abrir el detalle de la tarjeta. Se elimina exactamente igual que cualquier compra (`eliminarCompraTC` → `tcEliminarCompraInterna`), sin código de borrado propio.

## 6. Casos especiales

- **Cajita vinculada eliminada:** si `tc.cajitaId` apunta a una cajita que ya no existe, el widget de cobertura no se muestra en el dashboard general (se ignora en silencio); en el detalle de la tarjeta sí se avisa explícitamente, invitando a vincular una nueva desde "Editar tarjeta".
- **Varias tarjetas comparten la misma cajita:** la cobertura se calcula agrupando todas las tarjetas con el mismo `cajitaId` y comparando el saldo de la cajita contra la suma de sus deudas — no contra la deuda de una sola tarjeta a la vez.
- **Tarjeta sin cupo configurado (`tc.cupo` en 0):** no se valida ningún límite al registrar una compra; se trata como cupo infinito.
- **Compra o cargo sin id vinculado (datos de antes de este refactor):** `tcBuscarCompraPorIdOMatch` cae de vuelta a un match por descripción + monto en vez de fallar silenciosamente.
- **Eliminar la tarjeta completa:** solo procede tras confirmación explícita; si tiene `tcMovimientos` vinculados (cargos de encargos/préstamos), se avisa que esas referencias se perderán. Al eliminar, se limpian también los gastos espejo (`S.gastosVar`) y los `tcMovimientos` que apuntaban a esa tarjeta — no quedan huérfanos apuntando a un id inexistente.

## 7. Decisiones de diseño

- **No simular un banco real (sin corte, sin extracto, sin pago mínimo):** el objetivo del módulo es saber cuánto se debe y si alcanza para pagarlo, no replicar el ciclo de facturación de un banco — eso agregaría complejidad (fechas de corte, intereses, pago mínimo) sin aportar a las preguntas que este módulo existe para responder.
- **Widgets de cobertura usan deuda total, no deuda propia:** decisión corregida explícitamente (ver `CHANGELOG.md`) tras confundir "¿me alcanza para pagar?" (pregunta que el banco hace sobre el 100% de la deuda) con "¿cuánta plata es realmente mía?" (pregunta de patrimonio, donde sí importa separar lo propio de lo ajeno).
- **`tcMovimientos` (cargos de Encargos/Préstamos) vive fuera de `tc.compras`:** en vez de forzar a Encargos/Préstamos a empujar registros directo al array de compras de la tarjeta (acoplando su formato interno a otro módulo), se creó un tipo de registro aparte que Tarjetas de crédito solo consume para calcular deuda ajena e historial. Mantiene la frontera clara: quien genera el cargo es dueño de esa entrada.
- **"Cargo especial" reutiliza `tc.compras` en vez de un array propio (`tc.ajustes` o similar):** se consideró un array separado, pero el 90% de la infraestructura necesaria (historial unificado en `abrirDetalleTCSheet`, borrado con protección por antigüedad, gasto espejo, `tcRecalcular`) ya existe para compras — duplicarla para una variante que solo cambia "¿valida cupo?" y "¿qué badge muestra?" hubiera sido código repetido sin necesidad. Se prefirió un flag (`_esCargoEspecial`) sobre el mismo modelo, mismo criterio que ya usa `_esFavor`/`_desdeCP` para "esta compra es deuda ajena".
## 8. Referencia de implementación

**Nota:** `getTCById`, `tcCupoUsadoPct` y `tcCupoDisponible` se sacaron de este archivo a `js/core/calc-helpers.js` (Inicio las necesita sin cargar el módulo completo); `calcDeudaAjenaDeTarjeta` y `calcDeudaTcPropia` viven en `js/core/patrimonio.js`. Ambos siguen siendo globales que este módulo consume, no define.

| Función | Qué hace |
|---|---|
| `getTCById(id)` / `tcCupoUsadoPct(tc)` / `tcCupoDisponible(tc)` (en `js/core/calc-helpers.js`, no acá — ver nota abajo) | Buscar una tarjeta por id / % de cupo usado / cupo restante |
| `tcDeudaTotal()` | Suma la deuda de todas las tarjetas |
| `calcDeudaAjenaDeTarjeta(tc)` / `calcDeudaTcPropiaDeTarjeta(tc)` / `calcDeudaTcPropia()` (los tres en `js/core/patrimonio.js`, no acá) | Deuda ajena y propia de una tarjeta puntual, y propia agregada de todas — la agregada la usan Inicio, Préstamos y Wrapped |
| `calcSaldoInicialPendiente(tc)` (en `js/core/patrimonio.js`) | Cuánto queda del saldo inicial sin pagar todavía — un pago cancela primero esto, luego lo ajeno, luego lo propio (ver §3) |
| `tcEstadoInfo(estado)` | Info de badge/label para `TC_ESTADOS` |
| `tcRecalcular(tc)` | Única función que escribe `tc.deuda`, desde saldo inicial + compras + cargos − pagos |
| `tcNormalizarTarjetas()` | Migración/auto-sanación, se llama en cada `refresh()`; recalcula deuda de todas las tarjetas |
| `tcCrearCompra(tc, datos)` / `tcEliminarCompraInterna(tc, id)` | Capa de datos de compras (incluye cargos especiales, ver abajo) |
| `abrirCargoEspecialTC(tcId)` / `confirmarCargoEspecialTC()` | Sheet "Cargo especial a la tarjeta" (interés/comisión/otro) — no valida cupo, ver §3/§7 |
| `TC_MOTIVOS_CARGO` | Labels de motivo para cargos especiales (`interes`/`comision`/`otro`) |
| `tcBuscarCompraPorIdOMatch` | Fallback de búsqueda para datos legado sin id vinculado |
| `tcCrearPago(tc, datos)` / `tcEliminarPagoInterna(tc, id)` | Capa de datos de pagos |
| `abrirNuevaTarjeta` / `abrirEditarTC` / `guardarTC` / `eliminarTC` | CRUD de la tarjeta en sí |
| `renderTCScreen` / `renderTCDashboard` | Pantalla completa de Tarjetas / resumen en Inicio |
| `abrirCompraTC` / `confirmarCompraTC` | Sheet "Registrar compra en TC" (valida cupo, ver `CHANGELOG.md`) |
| `abrirPagarTC` / `confirmarPagarTC` | Sheet "Pagar tarjeta" |
| `abrirDetalleTCSheet` | Sheet de detalle: cobertura + historial completo (saldo inicial, compras, cargos, pagos) |
| `eliminarCompraTC` / `eliminarPagoTC` | Eliminar desde el detalle de la tarjeta (con confirmación) |
| `getFuentesSinTC` vs. `poblarFuente(..., incluirTC)` | Listas de cuentas destino (sin TC) vs. origen (con TC), ver regla en §3 |
| `getSaldoFuente` / `descontarFuente` / `sumarFuente` | Genéricas de todo el proyecto; su rama `tc:` es la interfaz que usa el resto de la app para tratar una tarjeta como "cuenta" de origen |

**Puntos de integración externa (no documentados acá, viven en sus propios módulos):** Encargos y Préstamos generan entradas en `S.tcMovimientos` (`cargo_encargo`/`cargo_prestamo`) cuando pagan algo con una tarjeta — ver `encargos.md`/`prestado.md` para ese flujo. Este documento solo cubre el lado que Tarjetas de crédito posee: cómo esos cargos se leen, sí se sacan de cupo/deuda y sí de deuda ajena, sin volver a explicar cómo se crean.
