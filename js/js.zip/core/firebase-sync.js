// Sync con Firestore: setSyncStatus, _fbSaveToCloud (guardado con debounce),
// _fbLoadData, onSnapshot, registro de Events('authgate',...) + habilitación
// del botón de login — extraído de index.html (era <script type="module">
// inline). Ver auditoria-tecnica.md #2 y CHANGELOG.md#infraestructura--seguridad.
//
// import de waitFor (js/core/wait-for-module.js — versión ES module
// independiente de js/core/wait-for.js, ver ese archivo para el porqué):
// reemplaza los dos reintentos manuales con setInterval/setTimeout que
// tenía este archivo (_runWhenEventListenersReady y el registro de
// Events('authgate',...), más abajo). Se usa `import` en vez de asumir un
// global porque este archivo carga como `type="module" async`, sin
// garantía de orden frente a ningún <script defer>. Ver
// CHANGELOG.md#infraestructura--seguridad.
import { waitFor } from './wait-for-module.js';
import { codificarPayload, decodificarPayload } from './payload-codec.js';

  // ── Helpers de estado de sync ──────────────────────────────────────────────
  function setSyncStatus(state, text) {
    const dot = document.getElementById('fb-sync-dot');
    const txt = document.getElementById('fb-sync-text');
    if(dot) { dot.className = 'fb-sync-dot' + (state !== 'ok' ? ' '+state : ''); }
    if(txt) txt.textContent = text;
  }

  // ── Guardar en Firestore con debounce ─────────────────────────────────────
  // FIX (2026-08-17): el autosave de bootstrap.js (cada 60s) y el snapshot
  // diario de patrimonio en _finishFirstLoad() llamaban a esto sin chequear
  // si algo había cambiado de verdad. Resultado real reportado por el
  // usuario: una pestaña olvidada abierta (en otro dispositivo, o una
  // segunda pestaña del mismo) seguía "guardando" cada 60s para siempre,
  // pisando `updatedAt` con la hora actual aunque el payload fuera idéntico
  // — y eso disparaba el toast "Datos actualizados desde otro dispositivo"
  // en la pestaña activa (más abajo, ver `remoteTs > localTs + 5000`) sin
  // que hubiera cambiado un solo dato. `window._lastSavedPayload` guarda el
  // JSON del último guardado real; si el nuevo payload es idéntico, se
  // aborta antes del `setDoc` — no se gasta escritura de Firestore ni se
  // dispara el toast en otras pestañas/dispositivos.
  let _saveTimer = null;
  // _savePromise/_saveResolve: FIX (2026-09-05) — _fbSaveToCloud() era
  // "fire and forget": no había forma de saber, desde afuera, si el
  // guardado con debounce realmente terminó en un setDoc() exitoso, en
  // un "no hacía falta escribir nada" (payload idéntico), o si nunca
  // llegó a intentarlo (guards de _dataLoaded/_fbUser/_fb). Eso permitía
  // que llamadores como leerArchivoImport() (configuracion.js) mostraran
  // "Datos importados correctamente" y recargaran la página sin haber
  // guardado nada de verdad si _fbSaveToCloud() se llamaba antes de que
  // _dataLoaded fuera true (ver auditoria-tecnica.md).
  // Ahora _fbSaveToCloud() siempre devuelve una Promise que resuelve con
  // {ok:boolean, reason:string}. Como varias llamadas seguidas comparten
  // el mismo debounce (clearTimeout de la anterior), todas comparten
  // también la misma promesa pendiente — así ninguna llamada se queda
  // esperando una promesa que el clearTimeout canceló.
  let _savePromise = null;
  let _saveResolve = null;
  const PAYLOAD_AVISO_BYTES = 800000, PAYLOAD_LIMITE_BYTES = 1000000; // el documento de Firestore admite 1 MiB
  window._payloadLimites = { aviso: PAYLOAD_AVISO_BYTES, limite: PAYLOAD_LIMITE_BYTES }; // los lee js/core/cierre.js (medidor de tamaño)
  // Cada guardado toma su número al empezar. Comprimir es asíncrono: si mientras tanto arrancó un guardado más nuevo, este
  // ya quedó viejo y no debe escribir después (pisaría datos más recientes en la nube).
  let _saveSeq = 0;
  // Cuerpo del guardado con debounce, extraído tal cual del setTimeout para
  // poder ejecutarlo también de inmediato (ver _fbFlushSave más abajo).
  async function _ejecutarGuardado() {
      const resolve = _saveResolve;
      _savePromise = null; _saveResolve = null;
      if(!window._fbUser || !window._fb){ resolve({ok:false, reason:'no-auth'}); return; }
      try {
        const {db, doc, setDoc} = window._fb;
        if(!window.S){setSyncStatus("error","Error: datos no inicializados");resolve({ok:false, reason:'no-data'});return;}
        // Se serializa UNA sola vez. Antes se clonaba con JSON.parse(JSON.stringify(S)) para «limpiar los undefined» y se volvía a
        // serializar: el clon costaba ~3/4 del tiempo de este paso y la cadena es idéntica (JSON.stringify ya descarta los undefined, y
        // lo que va a Firestore es una cadena, no un objeto). Una prueba de sync.test.js fija esa igualdad.
        const payloadStr = JSON.stringify(window.S);
        const miSeq = ++_saveSeq; // antes del chequeo "¿cambió algo?": un guardado sin cambios también deja viejo a uno en vuelo
        // Nada cambió desde el último guardado real (ni local ni el que
        // acabamos de recibir de la nube) — no hay razón para escribir.
        if(payloadStr === window._lastSavedPayload) {
          setSyncStatus('ok', window._lastSavedAt
            ? 'Guardado en la nube · ' + new Date(window._lastSavedAt).toLocaleTimeString('es-CO',{hour:'2-digit',minute:'2-digit'})
            : 'Sin cambios');
          resolve({ok:true, reason:'no-changes'});
          return;
        }
        // Tope de tamaño (2026-10-13): todo el estado va en UN documento de Firestore (límite 1 MiB). Si se pasa, `setDoc`
        // falla y el catch de abajo diría "revisa conexión" mientras la nube se queda para siempre en el último guardado
        // bueno. Se mide antes de escribir: aviso a los 800 KB (una vez por sesión) y se detiene a 1.000.000 bytes con un
        // mensaje que dice la causa real.
        const payloadNube = await codificarPayload(payloadStr);
        if(miSeq !== _saveSeq) { resolve({ok:true, reason:'superseded'}); return; }
        const bytes = payloadNube.length; // base64 o JSON plano: todo ASCII salvo tildes del plano (≈ 1 byte por carácter)
        window._payloadBytes = bytes;
        if(bytes > PAYLOAD_LIMITE_BYTES) {
          setSyncStatus('error', 'Datos demasiado grandes para la nube (' + Math.round(bytes/1024) + ' KB de 1.000 KB)');
          if(typeof toast === 'function') toast('Tus datos ya no caben en la nube (' + Math.round(bytes/1024) + ' KB de 1.000 KB) y no se están guardando. Exporta un backup y avisa para archivar meses antiguos.', 'err', 10000);
          resolve({ok:false, reason:'too-large', bytes});
          return;
        }
        if(bytes > PAYLOAD_AVISO_BYTES && !window._avisoTamanoMostrado) {
          window._avisoTamanoMostrado = true;
          if(typeof toast === 'function') toast('Tus datos ocupan ' + Math.round(bytes/1024) + ' KB de 1.000 KB en la nube. Conviene archivar meses antiguos pronto.', 'warn', 8000);
        }
        const savedAt = Date.now();
        // FIX (2026-08-17, hallazgo #2 — el toast falso pasaba INCLUSO sin
        // ninguna otra pestaña/dispositivo real): `window._lastSavedAt` se
        // actualizaba acá abajo, DESPUÉS de que `await setDoc()` resolviera.
        // Pero `onSnapshot` (más abajo, con `includeMetadataChanges:true`)
        // dispara DOS VECES por cada escritura propia: una optimista
        // (`hasPendingWrites:true`, sí filtrada por el guard de esa función)
        // y otra cuando el servidor confirma (`hasPendingWrites:false` —
        // esa NO la filtra nada, cae directo a la rama `remoteTs > localTs +
        // 5000`). Esa segunda notificación y la resolución de este mismo
        // `await` los dispara el mismo viaje de red, pero no hay garantía
        // de en qué orden llegan a la cola de eventos de JS — carrera real.
        // Si la notificación de `onSnapshot` procesa primero, `localTs`
        // todavía tiene el valor del guardado ANTERIOR, y la confirmación
        // del guardado que la propia pestaña acaba de hacer se lee como
        // "actualización de otro dispositivo". Se soluciona fijando
        // `_lastSavedAt` ANTES de la escritura, no después: para cuando
        // llegue la confirmación de `onSnapshot` (venga en el orden que
        // venga), `remoteTs` va a ser exactamente igual a `localTs` — nunca
        // "más nuevo" — así que esta rama nunca dispara para el guardado
        // propio, sea cual sea el orden de las dos resoluciones async.
        window._lastSavedAt = savedAt;
        try { localStorage.setItem('mf_lastSavedAt', String(savedAt)); } catch(_){}
        await setDoc(
          doc(db, 'usuarios', window._fbUser.uid, 'data', 'finanzas'),
          { payload: payloadNube, updatedAt: savedAt }
        );
        window._lastSavedPayload = payloadStr;
        setSyncStatus('ok', 'Guardado en la nube · ' + new Date().toLocaleTimeString('es-CO',{hour:'2-digit',minute:'2-digit'}));
        resolve({ok:true});
      } catch(e) {
        console.error('Firebase save error:', e);
        setSyncStatus('error', 'Error al guardar — revisa conexión');
        resolve({ok:false, reason:'error', error:e});
      }
  }

  window._fbSaveToCloud = function() {
    // Estado aislado (conEstadoAislado, core-state.js): un estado de prueba jamás se escribe en la nube.
    if(window._estadoAislado) return Promise.resolve({ok:false, reason:'isolated'});
    // PROTECCIÓN CRÍTICA: nunca guardar si los datos no se han cargado
    // desde Firestore. Evita sobreescribir la nube con datos vacíos
    // si la app se reinicia abruptamente antes de terminar de cargar.
    if(!window._dataLoaded) return Promise.resolve({ok:false, reason:'not-loaded'});
    clearTimeout(_saveTimer);
    setSyncStatus('syncing', 'Guardando…');
    if(!_savePromise){
      _savePromise = new Promise((resolve) => { _saveResolve = resolve; });
    }
    _saveTimer = window._fbSaveTimer = setTimeout(_ejecutarGuardado, 1500);
    return _savePromise;
  };

  // FIX (2026-09-19): guardado inmediato al salir de la app. Un cambio esperaba
  // hasta ~0,8 s (debounceSave, core-state.js) + 1,5 s (el debounce de acá)
  // antes de empezar a escribir; el único guardado de emergencia era
  // `beforeunload` (core-state.js), que en celulares casi nunca se dispara al
  // cambiar de app o cerrarla. `visibilitychange` (pasa a 'hidden') y
  // `pagehide` sí son confiables. Solo acelera un guardado que YA iba a
  // ocurrir: no escribe nada si este dispositivo no modificó nada, y respeta
  // _dataLoaded (modo lectura) igual que el resto.
  window._fbFlushSave = function() {
    if(!window._dataLoaded || !_savePromise) return Promise.resolve({ok:true, reason:'nothing-pending'});
    clearTimeout(_saveTimer);
    const pendiente = _savePromise;
    _ejecutarGuardado(); // toma _saveResolve y resuelve la misma promesa compartida
    return pendiente;
  };

  let _ultimoFlushOculto = 0;
  function _guardarAlOcultar() {
    if(!window._dataLoaded || !window._fbUser) return;
    const ahora = Date.now();
    if(ahora - _ultimoFlushOculto < 1000) return; // visibilitychange + pagehide suelen llegar juntos
    _ultimoFlushOculto = ahora;
    // Si el usuario tocó algo en este dispositivo, asegurar que save() ya corrió
    // (puede que el debounce de 0,8 s todavía no haya disparado). Igual que el
    // guardado de beforeunload, no se fuerza nada si solo se abrió a leer.
    if(window._locallyModified && typeof save === 'function') { try { save(); } catch(_){} }
    if(_savePromise) console.log('[Sync] Página oculta — guardando de inmediato.');
    window._fbFlushSave();
  }
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'hidden') _guardarAlOcultar(); });
  window.addEventListener('pagehide', _guardarAlOcultar);

  // ── Inicializar la app una sola vez tras la primera carga ─────────────────
  function _initAppUI() {
    load();
    (function(){
      const el=document.getElementById('nuTasaGlobal');
      if(el&&nuTasaConfigurada())el.value=nuTasaATexto(window.S.nuRate);
      if(el){
        // La tasa es UNA para todas las cajitas (S.nuRate): solo números con coma o punto decimal, y no se puede dejar en
        // blanco ni en 0. Mientras se escribe solo se quita lo que no sirve (letras, signos): NO se guarda ni se anota nada
        // a medias (antes cada tecla válida —«1» camino a «10,5»— guardaba una tasa de paso y la anotaba en el historial).
        // El cambio se aplica al confirmar (salir del campo o Enter) y solo si el valor realmente cambió; un valor
        // incompleto o inválido se descarta y se restaura la tasa anterior. Cambiarla NO recalcula nada hacia atrás: el
        // historial interno de tasas (S.historialTasasNu) la aplica desde hoy y los intereses ya sellados no se reabren.
        // Para contrastar con la app de Nu está el Chequeo rápido de cajitas.
        el.addEventListener('input',function(){
          const limpio=nuTasaSanear(this.value);
          if(limpio!==this.value)this.value=limpio;
        });
        el.addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); this.blur(); } });
        el.addEventListener('change',function(){
          const r=nuAplicarTasaEscrita(this.value);
          if(r==='invalida')return; // el blur restaura la tasa anterior
          this.value=nuTasaATexto(window.S.nuRate);
          if(r==='cambio'){save();refresh();}
        });
        el.addEventListener('blur',function(){
          if(nuTasaDesdeTexto(this.value)==null) this.value=nuTasaConfigurada()?nuTasaATexto(window.S.nuRate):'';
        });
      }
    })();
    // Materializar intereses de todas las cajitas al arrancar la app.
    // Así la fecha base nunca queda muy atrás y los redondeos acumulados
    // respecto a Nu son mínimos (máx. 1 día de diferencia).
    (S.cajitas||[]).forEach(c=>{ if(typeof materializarIntereses==='function') materializarIntereses(c); });
    refresh(); if(window.applyModulos) applyModulos();
    poblarCatSelect('gv_cat',getCatsVar());
    poblarCatSelect('gf_c',getCatsFijo());
    // FIX (2026-08-28): _initEventListeners vive en otro <script defer>
    // (fuera de este archivo). firebase-sync.js carga como `type="module"
    // async` a propósito (ver index.html, comentario junto al <script> —
    // deja correr _fbLoadData/onSnapshot en paralelo con el parseo del
    // documento en vez de esperar a que termine). `async` no da NINGUNA
    // garantía de orden frente a los <script defer>. Normalmente igual
    // funciona porque Firestore tarda más en responder que en terminar
    // de ejecutarse los defer — pero onSnapshot(...,{includeMetadataChanges:
    // true}) dispara primero desde el caché local de IndexedDB
    // (persistentLocalCache), que con sesión ya "caliente" puede resolver
    // en milisegundos — bastante rápido para ganarle la carrera a la cola
    // de defer, incluido el script donde vive _initEventListeners. Cuando
    // eso pasa: ReferenceError acá, que interrumpe _initAppUI a la mitad
    // (nunca llega a _injectErrorSpans/verificarVencimientosCDT) → pantalla
    // en negro. Reportado por el usuario: PC suspendido con la pestaña
    // abierta, al reanudar la sesión/caché de Firestore ya estaban
    // calientes y ganaron la carrera.
    // Ya nos habíamos protegido contra llamar esto DOS VECES (ver
    // comentario en _finishFirstLoad más arriba) pero no contra llamarlo
    // ANTES DE TIEMPO. En vez de apostarle a un orden de <script> que no
    // está garantizado por el navegador, se espera activamente a que la
    // función exista — mismo patrón (poll con setInterval) que ya usa
    // mejoras-adicionales.js para envolver openSheet.
    _runWhenEventListenersReady();
  }

  // Antes era un setTimeout recursivo propio, cada 20ms, sin tope de
  // intentos (ver CHANGELOG.md#infraestructura--seguridad, entrada de
  // consolidación de este patrón). Mismo intervalo de 20ms preservado —
  // se eligió corto a propósito para minimizar el retraso antes de pintar
  // tras resolver auth.
  function _runWhenEventListenersReady() {
    waitFor(() => typeof _initEventListeners === 'function', () => {
      _initEventListeners();
      _injectErrorSpans();
      // FIX 2026-08-13: verificarVencimientosCDT (cuentas.js, grupo lazy) sin
      // guard — mismo problema que _renderTasaHistorialTag arreglado antes:
      // corre en cada arranque de la app, no solo al visitar Cuentas.
      if(typeof verificarVencimientosCDT==='function') verificarVencimientosCDT();
    }, { intervalMs: 20 });
  }

  // ── Diagnóstico: consultar el log de errores de conexión de Firestore ─────
  // Uso desde la consola del navegador: _verSyncErrors()
  // Devuelve los últimos errores de onSnapshot (ver handler de error arriba),
  // con timestamp, código de error de Firestore y mensaje. Útil para
  // confirmar si volvió el problema de conexión sin tener que reproducirlo
  // en vivo con la consola abierta.
  window._verSyncErrors = function() {
    try {
      const log = JSON.parse(localStorage.getItem('mf_syncErrors') || '[]');
      return log.map(e => ({ cuando: new Date(e.t).toLocaleString('es-CO'), code: e.code, msg: e.msg }));
    } catch(_) { return []; }
  };

  // ── Cargar datos desde Firestore con escucha en tiempo real ───────────────
  // Usamos onSnapshot en lugar de getDoc para que cualquier cambio desde otro
  // dispositivo o pestaña se refleje automáticamente sin recargar la página.
  let _unsubscribeSnapshot = null; // Para poder cancelar el listener si hace falta

  window._fbLoadData = function() {
    if(!window._fbUser || !window._fb) return;
    const {db, doc, onSnapshot} = window._fb;
    const docRef = doc(db, 'usuarios', window._fbUser.uid, 'data', 'finanzas');

    // Cancelar listener anterior si existía (ej: re-login)
    if(_unsubscribeSnapshot) { _unsubscribeSnapshot(); _unsubscribeSnapshot = null; }

    // Restaurar _lastSavedAt desde localStorage para sobrevivir recargas.
    // Esto evita que al recargar la página, un snapshot del servidor con
    // timestamp reciente sobreescriba datos que nosotros mismos acabamos de guardar.
    if(!window._lastSavedAt) {
      try {
        const saved = localStorage.getItem('mf_lastSavedAt');
        if(saved) window._lastSavedAt = parseInt(saved, 10);
      } catch(_){}
    }

    // (docs/auditoria-tecnica.md #4 — reestructuración del arranque, sesión
    // posterior). Antes: si la primera entrega venía del caché local
    // (fromCache=true), NO se pintaba nada — se esperaba hasta 8s la
    // confirmación del servidor "para no mostrar datos obsoletos" (ver
    // CHANGELOG.md#arranque). En la práctica esos 8s eran casi siempre
    // puro spinner: el caché de persistentLocalCache() es el mismo
    // dispositivo releyendo su propio último guardado (setDoc), así que
    // casi nunca es "obsoleto" — y aunque lo fuera, un snapshot del
    // servidor con datos más nuevos sigue llegando después y se reconcilia
    // igual que ya reconciliábamos actualizaciones en tiempo real de otro
    // dispositivo (misma rama `remoteTs > localTs + 5000` de abajo).
    //
    // _firstLoad: true hasta que cerramos la "primera carga" con datos
    // confirmados del servidor (o con error/sin conexión).
    // _firstPaintDone: true en cuanto mostramos la app por primera vez —
    // separado de _firstLoad porque ahora pueden llegar DOS eventos
    // "primera carga" (caché, después servidor): el primero pinta y llama
    // _finishFirstLoad() (inicializa listeners, UNA sola vez); si llega un
    // segundo con datos del servidor, solo debe reconciliar sin volver a
    // inicializar nada — mismo tipo de bug que ya se vio antes con
    // _initEventListeners() duplicando listeners si se llama dos veces.
    let _firstLoad = true;
    let _firstPaintDone = false;
    // `updatedAt` de la última versión de la nube que ya se aplicó (carga inicial o actualización en vivo). `_lastSavedAt` solo cambia
    // al guardar desde ESTE dispositivo, así que sin esto el mismo dato (caché → servidor → cambio de metadatos) seguía pareciendo
    // «más nuevo que lo local» y se re-aplicaba avisando «Datos actualizados desde otro dispositivo» sin que nada hubiera cambiado.
    let _remotoAplicadoTs = 0;

    _unsubscribeSnapshot = onSnapshot(docRef,
      { includeMetadataChanges: true },
      (snapCrudo) => { _colaSnapshots = _colaSnapshots.then(() => _decodificarSnap(snapCrudo)).then((snap) => {
        const fromCache = snap.metadata.fromCache;
        const hasPendingWrites = snap.metadata.hasPendingWrites;
        // Diagnóstico: qué tipo de evento llegó (caché o servidor) y en qué
        // estado está la carga. Permite ver en consola si la confirmación del
        // servidor llegó o no (fromCache=false) — clave para entender por qué
        // la app queda en modo lectura.
        console.log('[Sync] snapshot: fromCache=' + fromCache + ' exists=' + snap.exists() + ' pendingWrites=' + hasPendingWrites + ' firstLoad=' + _firstLoad + ' dataLoaded=' + !!window._dataLoaded);

        // Si tenemos escrituras locales pendientes Y la app ya está corriendo,
        // es un eco de nuestro propio guardado → ignorar para no hacer refresh
        // innecesario y no crear bucle.
        // CRÍTICO: durante _firstLoad NO ignorar — el celular que nunca abrió la app
        // no tiene caché local. Si el servidor manda el snapshot con hasPendingWrites
        // (porque otro dispositivo acaba de guardar) y lo ignoramos, el celular se
        // queda sin datos y muestra todo en cero.
        if(hasPendingWrites && !_firstLoad) return;
        // Si hay una importación en curso, ignorar snapshots de Firestore
        // para evitar que los datos viejos de la nube pisen los recién importados.
        if(window._importing && !_firstLoad) return;

        if(_firstLoad) {
          const estadoCarga = _applyCloudData(snap);
          if(snap.exists()) _remotoAplicadoTs = Math.max(_remotoAplicadoTs, (snap.data() || {}).updatedAt || 0);
          const confiable = _cargaConfiable(estadoCarga);
          console.log('[Sync] carga: estado=' + estadoCarga + ' confiable=' + confiable);
          // "Sin documento" / "payload vacío" no se cree tal cual (ver
          // _cargaConfiable): se verifica contra el servidor.
          if(!window._dataLoaded && !_verificandoSinDoc && (estadoCarga === 'nodoc' || estadoCarga === 'empty')) {
            _verificandoSinDoc = true;
            _verificarSinDocumento().finally(() => { _verificandoSinDoc = false; });
          }
          if(!_firstPaintDone) {
            // Primer pintado real — con lo que haya llegado primero (caché
            // o servidor). Esto es lo que baja el LCP: ya no se espera.
            _firstPaintDone = true;
            _finishFirstLoad(confiable);
          } else if(!fromCache) {
            // Si el primer pintado fue en modo lectura, recién ahora que
            // llegó un payload leído bien se habilita el guardado.
            if(confiable) { window._dataLoaded = true; clearTimeout(window._syncConfirmTimer); }
            // Ya pintamos con caché; esto es la confirmación del servidor
            // llegando después. Si trajo algo distinto ya se aplicó arriba
            // (_applyCloudData) — solo falta reflejarlo sin re-inicializar
            // listeners (_initAppUI ya corrió una vez, en el pintado de arriba).
            (window.S&&window.S.cajitas||[]).forEach(c=>{ if(typeof materializarIntereses==='function') materializarIntereses(c); });
            if(window._dataLoaded) {
              load(); refresh();
              if(window.applyModulos) applyModulos();
              setSyncStatus('ok', 'Sincronizado con Firebase');
            }
          }
          // Solo cerramos "primera carga" con datos confirmados del servidor
          // (fromCache=false) — si lo que acabamos de pintar fue caché,
          // seguimos esperando esa confirmación en la próxima entrega.
          if(!fromCache) _firstLoad = false;
        } else {
          // Actualización en tiempo real desde otro dispositivo/pestaña.
          // Solo aplicar si los datos de la nube son más nuevos que los locales.
          // Esto evita que un dispositivo lento pise cambios recientes de otro.
          if(!snap.exists()) return;
          const remoteData = snap.data();
          const remoteTs = remoteData.updatedAt || 0;
          const localTs = window._lastSavedAt || 0;

          // Si los datos remotos son más nuevos que lo que guardamos por última
          // vez (con margen de 5s para latencia de red y desfase de relojes), aplicar la actualización.
          if(remoteTs > localTs + 5000 && remoteTs > _remotoAplicadoTs) {
            _remotoAplicadoTs = remoteTs;
            console.log('[Sync] Datos más nuevos del servidor — aplicando actualización en tiempo real.');
            _applyCloudData(snap);
            // Materializar intereses antes de renderizar para minimizar diferencia con Nu
            (window.S&&window.S.cajitas||[]).forEach(c=>{ if(typeof materializarIntereses==='function') materializarIntereses(c); });
            // Re-renderizar la UI sin reinicializar event listeners
            if(window._dataLoaded) {
              load();
              refresh();
              if(window.applyModulos) applyModulos();
              setSyncStatus('ok', 'Sincronizado · ' + new Date().toLocaleTimeString('es-CO',{hour:'2-digit',minute:'2-digit'}));
              if(window.toast) window.toast('Datos actualizados desde otro dispositivo', 'info', 3000);
            }
          }
        }
      }).catch(e => console.error('[Sync] Error procesando snapshot:', e)); },
      (error) => { _colaSnapshots = _colaSnapshots.then(() => {
        console.error('[Sync] Error en onSnapshot:', error);
        setSyncStatus('error', 'Error de conexión — reintentando…');
        // Registro persistente en localStorage (sobrevive a cerrar la consola
        // y a recargar la página) — para poder confirmar más tarde si el
        // problema de conexión de Firestore reapareció (ver
        // auditoria-tecnica.md, cambio a experimentalAutoDetectLongPolling)
        // sin depender de tener la consola abierta justo en el momento en
        // que pasa. Clave con prefijo 'mf_' a propósito: así queda incluida
        // en la limpieza de _limpiarStorageLocal() si el usuario borra su
        // cuenta. Se guardan solo los últimos 20 para no crecer sin límite.
        try {
          const log = JSON.parse(localStorage.getItem('mf_syncErrors') || '[]');
          log.push({ t: Date.now(), code: error.code || null, msg: error.message || String(error) });
          while (log.length > 20) log.shift();
          localStorage.setItem('mf_syncErrors', JSON.stringify(log));
        } catch(_){}
        // Si ni el caché ni el servidor entregaron nada todavía, no dejar a
        // la persona colgada en el spinner — arrancar igual con S por defecto.
        if(!_firstPaintDone) { _firstPaintDone = true; _finishFirstLoad(false); }
        clearTimeout(window._syncConfirmTimer);
        _avisarSinConfirmar();
        _firstLoad = false;
      }).catch(e => console.error('[Sync] Error manejando el error del listener:', e)); }
    );
  };

  // Devuelve un snapshot equivalente con el `payload` ya descomprimido, para que _applyCloudData y el listener sigan siendo
  // síncronos y trabajen siempre con JSON plano. Si no hay payload o no se pudo descomprimir, lo devuelve sin cambios.
  async function _decodificarSnap(snap) {
    try {
      if(!snap || !snap.exists()) return snap;
      const datos = snap.data();
      if(!datos || typeof datos.payload !== 'string') return snap;
      const plano = await decodificarPayload(datos.payload);
      if(plano === datos.payload) return snap;
      return { exists: () => true, data: () => Object.assign({}, datos, { payload: plano }), metadata: snap.metadata };
    } catch(e) {
      console.error('[Sync] _decodificarSnap:', e);
      return snap;
    }
  }
  // Los snapshots (y el error del listener) se procesan de a uno y en el orden en que llegaron, aunque descomprimir sea asíncrono.
  let _colaSnapshots = Promise.resolve();

  // Aplica datos de un snapshot de Firestore a window.S
  // Devuelve qué pasó, para que el llamador decida si S es confiable:
  //   'applied'     — había payload con datos y se aplicó a S
  //   'empty'       — había payload pero sin ninguna clave (S queda por defecto)
  //   'nodoc'       — el documento no existe o no trae payload
  //   'parse-error' — había payload pero no se pudo leer
  function _applyCloudData(snap) {
    if(snap.exists() && snap.data().payload) {
      try {
        let estado = 'applied';
        const cloudData = JSON.parse(snap.data().payload);
        console.log('[Sync] _applyCloudData: keys=' + Object.keys(cloudData).length + ' updatedAt=' + snap.data().updatedAt);
        if(Object.keys(cloudData).length === 0) {
          // Nube vacía — no pisar S con objeto vacío, dejar los valores por defecto de S intactos.
          console.warn('[Sync] Nube vacía (sin payload real) — manteniendo estado por defecto.');
          estado = 'empty';
        } else {
          Object.assign(window.S, cloudData);
          // La migración y auto-sanación de tarjetas de crédito ahora vive en
          // tcNormalizarTarjetas(), que se ejecuta en cada refresh() — no hace
          // falta un parche puntual aquí.
        }
        // FIX (2026-08-17, ver window._fbSaveToCloud más arriba): fijar acá
        // la base de comparación del chequeo "¿cambió algo de verdad?" — se
        // recalcula con JSON.stringify(window.S) (no con el payload crudo
        // de la nube) para que compare exactamente igual que el próximo
        // save(), sin falsos positivos por orden de claves distinto entre
        // el objeto por defecto de S y el JSON que vino de la nube.
        window._lastSavedPayload = JSON.stringify(window.S);
        return estado;
      } catch(e) {
        console.error('[Sync] Error al parsear datos de la nube:', e);
        return 'parse-error';
      }
    } else {
      console.warn('[Sync] _applyCloudData: snap.exists()=' + snap.exists() + ' — sin datos en nube.');
      return 'nodoc';
    }
  }

  // FIX (2026-09-19) — la nube se pisaba con el estado por defecto tras
  // borrar el storage del navegador (DevTools > Application). Causa: con la
  // caché de Firestore vacía o inconsistente, el listener puede decir "no hay
  // documento" — y _finishFirstLoad() lo tomaba como una carga válida:
  // marcaba _dataLoaded=true con S todavía por defecto y guardaba encima. Ese
  // setDoc no usa merge, así que reemplaza el documento completo, y una vez
  // encolado en el SDK no se cancela.
  // Ojo: NO alcanza con exigir que el evento venga del servidor
  // (fromCache=false). Se vio en consola un evento fromCache=false con
  // exists()=false para un documento que SÍ existía en Firestore (caché local
  // inconsistente tras "Clear site data"). Por eso "sin documento" nunca se
  // cree tal cual: se verifica con una lectura directa al servidor
  // (_verificarSinDocumento) antes de permitir guardar.
  // Único veredicto confiable por sí solo: un payload leído bien.
  function _cargaConfiable(estado) {
    return estado === 'applied';
  }

  // Lectura autoritativa del documento: una transacción de solo lectura hace
  // un BatchGetDocuments directo al servidor — no pasa por la caché local ni
  // por el "target" del listener (que es lo que puede estar inconsistente).
  async function _leerDocEnServidor() {
    const {db, doc, runTransaction} = window._fb || {};
    if(typeof runTransaction !== 'function') {
      return {ok:false, error:'runTransaction no está expuesto (actualizar firebase-init.js)'};
    }
    if(!window._fbUser) return {ok:false, error:'sin usuario'};
    try {
      const ref = doc(db, 'usuarios', window._fbUser.uid, 'data', 'finanzas');
      const snap = await runTransaction(db, tx => tx.get(ref));
      return {ok:true, snap: await _decodificarSnap(snap)};
    } catch(e) {
      return {ok:false, error:e};
    }
  }

  // Se llama cuando el listener dice "sin documento" / "payload vacío".
  // Solo se habilita el guardado con lo que diga el servidor de verdad:
  //  · existe  → se aplica lo que trae (aunque el listener dijera lo contrario)
  //  · no existe → usuario realmente nuevo: se puede guardar
  //  · no se pudo verificar (offline, error) → sigue en modo lectura
  let _verificandoSinDoc = false;
  async function _verificarSinDocumento() {
    const res = await _leerDocEnServidor();
    if(window._dataLoaded) return; // mientras tanto llegó una carga confiable
    if(!res.ok) {
      console.warn('[Sync] No se pudo verificar el documento en el servidor — sigue en modo lectura:', res.error);
      return;
    }
    if(res.snap.exists()) {
      console.log('[Sync] Verificación: el documento SÍ existe en el servidor — aplicando sus datos.');
      const estado = _applyCloudData(res.snap);
      if(estado === 'parse-error') return; // payload ilegible: nunca guardar encima
    } else {
      console.log('[Sync] Verificación: el servidor confirma que no hay documento (usuario nuevo).');
    }
    window._dataLoaded = true;
    clearTimeout(window._syncConfirmTimer);
    (window.S&&window.S.cajitas||[]).forEach(c=>{ if(typeof materializarIntereses==='function') materializarIntereses(c); });
    load(); refresh();
    if(window.applyModulos) applyModulos();
    setSyncStatus('ok', 'Sincronizado con Firebase');
  }

  // Aviso de "modo lectura": solo si de verdad no llegó la confirmación.
  function _avisarSinConfirmar() {
    if(window._dataLoaded) return; // ya se confirmó: nada que avisar
    setSyncStatus('error', 'Sin confirmar con la nube — no se guarda nada por ahora');
    if(typeof toast === 'function') toast('No se pudo confirmar tus datos con la nube. Los cambios no se guardarán hasta reconectar (si sigue así, recarga la página).', 'err', 8000);
  }

  // Finaliza la primera carga: muestra la app e inicializa la UI
  // `confiable=false` pinta la app en modo lectura: S puede seguir en sus
  // valores por defecto, así que nada se guarda hasta que el servidor confirme
  // (ver _cargaConfiable). Si el listener murió por error, hay que recargar.
  function _finishFirstLoad(confiable) {
    document.getElementById('fb-loading-screen').style.display = 'none';
    // PROTECCIÓN: marcar que los datos ya se cargaron correctamente.
    // _fbSaveToCloud no guardará nada hasta que esta bandera esté activa.
    window._dataLoaded = !!confiable;
    _initAppUI();
    // Snapshot diario: guardar patrimonio del día aunque no haya otros cambios.
    // Esto llena la gráfica de patrimonio sin que el usuario tenga que hacer nada.
    if(confiable && typeof snapshotPatrimonio === 'function'){
      snapshotPatrimonio();
      if(typeof window._fbSaveToCloud === 'function') window._fbSaveToCloud();
    }
    // Resumen de cierre de mes: detectar si cambió el mes desde la última apertura
    _checkCierreMes();
    if(confiable) {
      setSyncStatus('ok', 'Sincronizado con Firebase');
    } else {
      // Con la caché vacía el PRIMER evento siempre es de caché y sin datos;
      // lo normal es que el servidor confirme en menos de un segundo. Solo si
      // pasa mucho tiempo sin confirmación se avisa (ver _avisarSinConfirmar).
      setSyncStatus('syncing', 'Conectando con la nube…');
      clearTimeout(window._syncConfirmTimer);
      window._syncConfirmTimer = setTimeout(_avisarSinConfirmar, 8000);
    }
    // Notificar a módulos inline que los datos están listos.
    // Los scripts inline no pueden sobrescribir window._fbLoadData de forma confiable
    // porque este módulo (type="module") se ejecuta DESPUÉS que ellos, sobreescribiendo
    // cualquier wrapper que hayan puesto. El evento 'appDataLoaded' es el canal correcto.
    window.dispatchEvent(new CustomEvent('appDataLoaded'));
  }

  // ── Resumen de cierre de mes ─────────────────────────────────────────────
  function _checkCierreMes(){
    if(!window.S || !window._dataLoaded) return;
    const mesHoy = typeof mesActual === 'function' ? mesActual() : '';
    if(!mesHoy) return;
    const ultimoMesVisto = window.S._ultimoMesVisto || '';
    // Guardar el mes actual para la próxima apertura
    window.S._ultimoMesVisto = mesHoy;
    // Solo mostrar resumen si había un mes anterior registrado y es diferente al actual
    if(!ultimoMesVisto || ultimoMesVisto === mesHoy) return;
    // Calcular datos del mes que acaba de cerrar
    const fmt = window.fmt; // núcleo (core-state.js): si hay window.S, fmt ya existe
    const S = window.S;
    const mesK = ultimoMesVisto;
    const totalGastos = Periodo.gastosDelMes(mesK).total;
    // Patrimonio al cierre (último registro del mes anterior en el historial)
    const hist = S.patrimonioHistorial || [];
    const snapMes = [...hist].filter(h=>(h.fecha||'').startsWith(mesK)).pop();
    const patrimonioMes = snapMes ? snapMes.valor : null;
    const [anioM, mesM] = mesK.split('-').map(Number);
    const nombreMes = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'][mesM-1];
    // Construir mensaje
    let lineas = [`<b>Resumen de ${nombreMes} ${anioM}</b>`];
    if(patrimonioMes != null) lineas.push(`Patrimonio al cierre: <b>${fmt(patrimonioMes)}</b>`);
    if(totalGastos > 0) lineas.push(`Total gastado: <b>${fmt(totalGastos)}</b>`);
    else lineas.push('Sin gastos registrados ese mes.');
    if(typeof toast === 'function') toast(lineas.join('<br>'), 'info', 7000);
  }

  // ── Login con Google ──────────────────────────────────────────────────────
  // Guard de doble ejecución (2026-09-27): el doble popup por doble clic/
  // doble tap mientras el primero seguía abierto ya lo cubre el bloqueo
  // genérico de Events.dispatch (js/core/events.js) — cualquier handler
  // async queda bloqueado en su propio elemento hasta que su promesa
  // resuelve, así que no hace falta repetir esa lógica acá.
  // Lo que Events NO puede saber es esto: si la pantalla #fb-login-screen
  // alcanza a quedar visible un instante después de un login exitoso
  // (onAuthStateChanged/DOM aún resolviendo) con el botón ya habilitado de
  // antes, un clic ahí repetiría el signIn aunque ya hubiera una sesión
  // activa — por eso el corte por `window._fbUser` sigue siendo local.
  window._fbSignIn = async function() {
    if(!window._fb) return;
    if(window._fbUser) return; // ya hay sesión — ignora clics durante el parpadeo de la pantalla de login
    const {auth, provider, signInWithPopup, popupResolver} = window._fb;
    try {
      // popupResolver explícito: si esta carga arrancó sin resolver (ver
      // firebase-init.js, mf_auth_hint), es lo que carga el iframe recién acá.
      await signInWithPopup(auth, provider, popupResolver);
      // onAuthStateChanged se encarga del resto
    } catch(e) {
      if(e.code !== 'auth/popup-closed-by-user') {
        console.error('Error al iniciar sesión:', e.code, e.message);
        // Mensaje claro para el usuario según el tipo de error — el mensaje crudo de
        // Firebase (ej. "Firebase: Error (auth/internal-error).") no dice nada útil.
        const MENSAJES_AUTH = {
          'auth/popup-blocked': 'El navegador bloqueó la ventana de inicio de sesión. Revisa que no esté bloqueando pop-ups para este sitio e intenta de nuevo.',
          'auth/cancelled-popup-request': 'Se abrió más de una ventana de inicio de sesión a la vez. Intenta de nuevo.',
          'auth/network-request-failed': 'No hay conexión a internet. Revisa tu red e intenta de nuevo.',
          'auth/internal-error': 'No se pudo completar el inicio de sesión con Google. Intenta de nuevo en unos segundos.',
          'auth/unauthorized-domain': 'Este dominio no está autorizado para iniciar sesión. Contacta al administrador.',
        };
        const msg = MENSAJES_AUTH[e.code] || 'No se pudo iniciar sesión. Intenta de nuevo en unos segundos.';
        if(typeof toast === 'function') toast(msg, 'err', 5000);
      }
    }
  };

  // ── Cerrar sesión ─────────────────────────────────────────────────────────
  // FIX (2026-09-27): entre confirmar y el location.reload() final había un
  // guardado a Firestore + el propio signOut(), todo async — nada bloqueaba
  // la app en esa ventana, así que se podía seguir navegando/editando datos
  // mientras tanto (efecto observado: "me puedo seguir moviendo unos
  // segundos"). Se reutiliza #fb-loading-screen (overlay de pantalla
  // completa que ya usa el arranque de la app, ver index.html) para
  // bloquear cualquier interacción hasta que la sesión termine de cerrarse.
  window._fbSignOut = async function() {
    const ok = await dialogo('Cerrar sesión', '¿Seguro que quieres salir? Tus datos quedan guardados en la nube.', 'Cerrar sesión', true);
    if(!ok) return;
    if(!window._fb) return;
    const _overlay = document.getElementById('fb-loading-screen');
    if(_overlay) _overlay.style.display = 'flex';
    // Cancelar cualquier guardado pendiente antes de salir para evitar
    // que un timer de debounce guarde datos vacíos o corruptos post-signout.
    // Ambos timers se exponen en window para que este módulo pueda cancelarlos.
    clearTimeout(window._debounceTimer);     // timer de debounceSave (script global)
    clearTimeout(window._fbSaveTimer);       // timer de _fbSaveToCloud (módulo Firebase)
    // Guardar una última vez de forma inmediata si hay datos válidos
    if(window._fbUser && window.S && window._dataLoaded) {
      try {
        const {db, doc, setDoc} = window._fb;
        const signOutTs = Date.now();
        try { localStorage.setItem('mf_lastSavedAt', String(signOutTs)); } catch(_){}
        await setDoc(
          doc(db, 'usuarios', window._fbUser.uid, 'data', 'finanzas'),
          { payload: await codificarPayload(JSON.stringify(window.S)), updatedAt: signOutTs }
        );
      } catch(e) {
        console.warn('Error en guardado final antes de cerrar sesión:', e);
        // No seguir con el cierre de sesión: si este guardado no llegó a Firestore,
        // cerrar sesión igual arriesga perder en silencio el último cambio financiero.
        if(_overlay) _overlay.style.display = 'none'; // no dejar la app bloqueada: no habrá reload en este camino
        if(typeof toast === 'function') toast('No se pudo guardar el último cambio en la nube. Revisa tu conexión e intenta cerrar sesión de nuevo.', 'err', 6000);
        return;
      }
    }
    // Cancelar el listener de tiempo real para evitar actualizaciones fantasma tras logout
    if(typeof _unsubscribeSnapshot === 'function') {
      _unsubscribeSnapshot();
      _unsubscribeSnapshot = null;
    }
    // window._fbCacheFallbackTimer ya no se crea en ningún lado (ver
    // _fbLoadData, docs/auditoria-tecnica.md #4) — esta línea queda
    // inofensiva a propósito (el `if` nunca entra) en vez de borrarla, para
    // no tocar código de limpieza de sesión sin necesidad real.
    if(window._fbCacheFallbackTimer) { clearTimeout(window._fbCacheFallbackTimer); window._fbCacheFallbackTimer = null; }
    // Bloquear futuros guardados limpiando el usuario ANTES del signOut
    window._dataLoaded = false;
    window._lastSavedAt = 0;
    window._fbUser = null;
    const {auth, signOut} = window._fb;
    await signOut(auth);
    location.reload();
  };

  // ── Eliminar cuenta (borra todos los datos y cierra sesión) ────────────────
  window._abrirEliminarCuenta = function() {
    const input = document.getElementById('del-account-input');
    const btn = document.getElementById('del-account-confirm');
    input.value = '';
    btn.disabled = true;
    document.getElementById('del-account-overlay').classList.add('open');
    setTimeout(() => input.focus(), 50);
  };
  window._cerrarEliminarCuenta = function() {
    // FIX (2026-09-27): mientras _fbDeleteAccount está en curso, esta misma
    // función se dispara al tocar "Cancelar" o al hacer clic fuera del
    // overlay (ver _wireDeleteAccountOverlay) — cerraba el overlay y dejaba
    // seguir navegando mientras el borrado seguía en Firestore en segundo
    // plano. El botón "Confirmar" ya se autobloquea vía Events.dispatch
    // (js/core/events.js) por ser un handler async, pero eso no cubre otros
    // elementos como este.
    if(window._fbDeleteAccountEnCurso) return;
    document.getElementById('del-account-overlay').classList.remove('open');
  };

  // Wiring del overlay "Eliminar cuenta" (docs/auditoria-tecnica.md #4,
  // paso 2 de la reestructuración de arranque). Este bloque corría a nivel
  // superior del módulo, tocando el DOM sin null-checks (`document.
  // getElementById('del-account-overlay').addEventListener(...)` directo).
  // Con este archivo cargando <script type="module"> sin `async`, eso era
  // seguro porque el navegador no lo ejecuta hasta terminar de parsear todo
  // el documento. Al pasar a `async` (mismo cambio ya hecho en
  // firebase-init.js) esa garantía desaparece: si el módulo llega a
  // ejecutar antes de que el parser llegue a estos elementos, cualquiera
  // de esos `getElementById(...)` devuelve `null` y el `.addEventListener`
  // encadenado tira un TypeError — que corta la ejecución del resto del
  // archivo completo, incluyendo el registro de Events('authgate',...) de
  // más abajo. Se envuelve con el mismo guard de document.readyState que
  // ya usa firebase-init.js, más null-checks por las dudas.
  function _wireDeleteAccountOverlay() {
    const overlay = document.getElementById('del-account-overlay');
    const input   = document.getElementById('del-account-input');
    const confirm = document.getElementById('del-account-confirm');
    if (overlay) {
      overlay.addEventListener('click', function(e){
        if(e.target === this) window._cerrarEliminarCuenta();
      });
    }
    if (input) {
      input.addEventListener('input', function(){
        if (confirm) confirm.disabled = (this.value.trim() !== 'ELIMINAR');
      });
      input.addEventListener('keydown', function(e){
        if(e.key === 'Enter' && this.value.trim() === 'ELIMINAR') window._fbDeleteAccount();
      });
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _wireDeleteAccountOverlay, { once: true });
  } else {
    _wireDeleteAccountOverlay();
  }

  // Limpia todo el almacenamiento local propio de la app (claves 'mf_*')
  function _limpiarStorageLocal() {
    try {
      const keys = [];
      for(let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if(k && k.startsWith('mf_')) keys.push(k);
      }
      keys.forEach(k => localStorage.removeItem(k));
    } catch(_){}
    try { sessionStorage.clear(); } catch(_){}
  }

  window._fbDeleteAccount = async function() {
    const input = document.getElementById('del-account-input');
    if(input.value.trim() !== 'ELIMINAR') return;
    if(!window._fb || !window._fbUser) return;
    // Con PIN activo, se vuelve a pedir antes de borrar la cuenta (mejora 13). Si se cancela no se toca nada.
    if(typeof window.pedirPinAntesDe === 'function' && !(await window.pedirPinAntesDe('Para eliminar tu cuenta y todos tus datos'))) return;

    // FIX (2026-09-27): antes se podía cancelar el overlay (botón "Cancelar"
    // o clic afuera) mientras el borrado seguía en curso en segundo plano —
    // ver el guard equivalente en _cerrarEliminarCuenta más arriba.
    window._fbDeleteAccountEnCurso = true;

    const btn = document.getElementById('del-account-confirm');
    const textoOriginal = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Eliminando…';

    const {auth, db, doc, deleteDoc, deleteUser, reauthenticateWithPopup, provider, popupResolver, signOut} = window._fb;
    const uid = window._fbUser.uid;

    // Cancelar guardados/listeners pendientes para que nada reescriba datos a mitad de la eliminación
    clearTimeout(window._debounceTimer);
    clearTimeout(window._fbSaveTimer);
    if(typeof _unsubscribeSnapshot === 'function') {
      _unsubscribeSnapshot();
      _unsubscribeSnapshot = null;
    }
    // Ver nota equivalente en _fbSignOut — código de limpieza inofensivo,
    // dejado a propósito.
    if(window._fbCacheFallbackTimer) { clearTimeout(window._fbCacheFallbackTimer); window._fbCacheFallbackTimer = null; }
    window._dataLoaded = false;

    try {
      // 1) Borrar el documento de datos en Firestore
      await deleteDoc(doc(db, 'usuarios', uid, 'data', 'finanzas'));
      // 2) Borrar el usuario de Firebase Auth
      await deleteUser(auth.currentUser);
    } catch(e) {
      // Si Firebase exige un login reciente para borrar la cuenta, se re-autentica y se reintenta
      if(e && e.code === 'auth/requires-recent-login') {
        try {
          await reauthenticateWithPopup(auth.currentUser, provider, popupResolver);
          await deleteDoc(doc(db, 'usuarios', uid, 'data', 'finanzas'));
          await deleteUser(auth.currentUser);
        } catch(e2) {
          window._fbDeleteAccountEnCurso = false;
          btn.disabled = false;
          btn.textContent = textoOriginal;
          if(typeof toast === 'function') toast('No se pudo eliminar la cuenta: ' + (e2.message || e2), 'err');
          return;
        }
      } else {
        window._fbDeleteAccountEnCurso = false;
        btn.disabled = false;
        btn.textContent = textoOriginal;
        if(typeof toast === 'function') toast('No se pudo eliminar la cuenta: ' + (e.message || e), 'err');
        return;
      }
    }

    // 3) Limpiar todo rastro local y cerrar sesión
    window._lastSavedAt = 0;
    window._fbUser = null;
    _limpiarStorageLocal();
    try { await signOut(auth); } catch(_){}
    location.reload();
  };

  // Registro bajo Events (docs/auditoria-tecnica.md #1): estas tres funciones
  // son núcleo de sesión (compartidas más allá de una sola pantalla), pero los
  // botones que las disparan sí son exclusivos de esta pantalla de login/
  // eliminar-cuenta — mismo criterio ya usado con config:signOut, que también
  // envuelve una función de auth compartida bajo el namespace del botón que
  // la llama, no de dónde vive la función.
  //
  // Con reintento (docs/auditoria-tecnica.md #4, paso 2): `Events` lo define
  // js/core/events.js, un <script> clásico. El guard `typeof Events !==
  // 'undefined'` ya existía porque en algún momento este archivo podía
  // ejecutar antes de que events.js cargara — pero antes, sin `async`, el
  // navegador garantizaba que TODO el JS clásico (incluyendo events.js) ya
  // había corrido antes de que este módulo arrancara, así que el guard
  // nunca fallaba en la práctica. Con `async`, esa garantía ya no existe: si
  // falla el guard, antes simplemente no se registraba nada y quedaba así
  // para siempre (el botón de login se habilitaba solo por el timeout de
  // 8s de firebase-init.js, pero sin listener real detrás — clickearlo no
  // hacía nada). Mismo patrón de reintento que ya usa este mismo archivo
  // para el overlay de eliminar cuenta, y que ya usa pin-bio.js para su
  // propio hook de refresh().
  function _registrarEventosAuthgate() {
    if(typeof Events === 'undefined' || typeof Events.registerAll !== 'function') return false;
    Events.registerAll('authgate', {
      signIn: window._fbSignIn,
      cerrarEliminarCuenta: window._cerrarEliminarCuenta,
      eliminarCuenta: window._fbDeleteAccount,
    });
    // Confirmado: ya se puede usar el botón de login (ver el timeout de
    // seguridad en el bloque de arriba, junto a onAuthStateChanged).
    window._authgateReady = true;
    clearTimeout(window._authgateReadyTimeout);
    document.querySelectorAll('[data-action^="authgate:"]').forEach(function(b){ b.disabled = false; });
    return true;
  }
  // Antes era un setInterval propio (ver CHANGELOG.md#infraestructura--
  // seguridad, entrada de consolidación de este patrón). _registrarEventosAuthgate
  // ya hace el registro Y devuelve si tuvo éxito, así que sirve directo como
  // checkFn — waitFor solo lo vuelve a llamar hasta que dé true.
  if (!_registrarEventosAuthgate()) {
    waitFor(_registrarEventosAuthgate, () => {});
  }
