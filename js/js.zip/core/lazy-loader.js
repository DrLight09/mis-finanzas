/* ═══════════════════════════════════════════════════════════════
   js/core/lazy-loader.js

   Motor genérico de carga bajo demanda por pantalla — fase 1 de la
   modularización (docs/auditoria-tecnica.md #4). Reemplaza, para las
   pantallas registradas en GROUPS, la carga de entrada (<script defer>
   en index.html) por una descarga la primera vez que el usuario entra
   a esa pantalla.

   Piloto: "alcancia" y "comprometida" en GROUPS por ahora (ver
   CHANGELOG.md). El resto de las pantallas sigue cargando de entrada
   como siempre — Loader.GROUPS[name] === undefined para ellas, así
   que showScreen() (navegacion.js) ni siquiera pasa por este archivo
   para esos casos.

   ── Por qué en orden y no en paralelo (Promise.all) ──────────────
   Un archivo de un grupo puede usar, al cargar, lo que definió el anterior (p. ej. registrar ganchos de Ui sobre funciones del
   primero). Se cargan uno por vez, en el orden declarado en GROUPS.
   ═══════════════════════════════════════════════════════════════ */

const Loader = (function () {
  // false hasta que ensureAll() (precarga en segundo plano de todos los
  // grupos lazy) termine — ver _iniciarEnsureAll() más abajo. La lee
  // inicio.js (renderAttencion) para no comparar un fingerprint parcial.
  window._appFullyLoaded = false;

  // pantalla → archivos que hay que cargar, EN ESTE ORDEN, la primera
  // vez que se visita. Pantallas que no aparecen acá siguen cargando
  // de entrada (comportamiento actual, sin cambios).
  const GROUPS = {
    alcancia: ['js/modules/alcancia.js'],
    // (docs/auditoria-tecnica.md #4) Segundo grupo lazy. A diferencia de
    // Alcancía, plata_comprometida.js NO tenía su pantalla ni su ítem de
    // menú "Más" como HTML estático — los auto-inyectaba en tiempo de
    // ejecución (_injectScreen()/_injectMasItem(), ambas con guard por
    // id, así que siguen ahí sin cambios y ahora son no-op). Se copió
    // ese HTML tal cual a index.html (#screen-comprometida,
    // #mas-comprometida) para que el ítem de menú exista desde el
    // arranque — si no, no habría nada que el usuario pudiera tocar
    // para disparar la carga lazy en primer lugar. Ver CHANGELOG.md#arranque.
    comprometida: ['js/modules/plata_comprometida.js'],
    // Tercer grupo lazy. Más simple que los dos anteriores: #screen-config
    // y #mas-config YA eran HTML estático desde antes (no hubo que copiar
    // nada), y el único caller externo de una función suya (renderCatsConfig,
    // desde navegacion.js) ya tenía guard `typeof` desde la sesión del
    // piloto de Alcancía. gastos.js quedó afuera a propósito: navegacion.js
    // (núcleo) parchea addGastoVar/addGastoFijo a nivel superior de SU
    // propio archivo — haría lazy-loading imposible sin tocar antes ese
    // núcleo. Ver CHANGELOG.md#arranque.
    //
    // 2026-08-30: era ['js/modules/configuracion.js', 'js/modules/import-validado.js']
    // — import-validado.js (validación de estructura del JSON, MEJORA 5)
    // parcheaba leerArchivoImport a nivel superior de su propio archivo,
    // por eso necesitaba cargar DESPUÉS y el orden del array importaba. Se
    // fusionó dentro de configuracion.js (una sola función real, sin
    // depender del orden de carga entre dos archivos) — ver
    // CHANGELOG.md#configuración. import-validado.js ya no existe.
    config: ['js/modules/configuracion.js'],
    // Cuarto grupo lazy. Entrada única: el botón "Actividad reciente"
    // dentro de Configuración (#cfg-historial-row, data-action=
    // "config:irA" con args ["historial"]) — no hay ítem en el menú
    // "Más" ni en el nav inferior, así que no hizo falta estatizar ni
    // copiar HTML (a diferencia de Plata Comprometida): #screen-historial
    // y el botón que dispara la carga ya son estáticos, y ese botón vive
    // en configuracion.js, que solo es alcanzable si Configuración ya
    // cargó — mismo prerequisito que ya existía antes de esto.
    // Requirió UN cambio real en actividad_reciente.js (no solo sacar el
    // <script>): el módulo se auto-renderizaba por DOMContentLoaded/
    // appDataLoaded/clic, los 3 eventos que con carga lazy ya pasaron
    // para cuando el archivo llega a existir — se agregó un cuarto
    // trigger sin condición de evento al final del archivo. Ver ese
    // archivo y CHANGELOG.md#arranque para el detalle.
    historial: ['js/modules/actividad_reciente.js'],
    // Quinto grupo lazy (2026-08-02). #screen-mesada y #mas-mesada ya eran
    // HTML estático desde antes, así que no hubo que copiar/inyectar nada
    // (mismo caso que Configuración/Actividad Reciente, a diferencia de
    // Plata Comprometida). No requirió ningún cambio dentro de mesada.js:
    // su wiring de botones (btn-anio-prev, btn-confirmar-mesada, etc.) ya
    // corría top-level contra ids del DOM estático sin esperar
    // DOMContentLoaded (mismo patrón seguro que ya usaba alcancia.js), y no
    // monkey-patchea ninguna función ajena. Su único caller externo
    // conocido, inicio.js (getMesadaData/_getCuotaAnio en renderAttencion/
    // calcHealthScore), ya tenía guard typeof desde la sesión anterior —
    // ver auditoria-tecnica.md #4. Sin verificar: si analisis.js (no
    // auditado a este nivel) también llama alguna función de mesada.js sin
    // guard — queda anotado como hallazgo abierto, no investigado acá.
    mesada: ['js/modules/mesada.js'],
    // Sexto grupo lazy (2026-08-02, ronda de resolver de raíz el acoplamiento
    // spotify↔tarjetas_credito). A diferencia de los 5 anteriores, este no
    // partió de "¿cuál es la próxima pantalla candidata?" sino de un bug de
    // acoplamiento ya encontrado: spotify.js llamaba funciones de
    // tarjetas_credito.js (getTCById/tcCupoDisponible/tcRecalcular) asumiendo
    // que ya estaba cargado porque siempre cargaba eager. En vez de solo
    // documentar la decisión de producto, se resolvió de raíz: tarjetas_credito
    // pasa a ser lazy de verdad, y los 3 puntos en spotify.js (más 2 en
    // movimientos.js: tcEliminarCompraInterna/tcEliminarPagoInterna) ya esperan
    // Loader.ensure('tarjetas') antes de usar esas funciones — ver
    // js/modules/spotify.js (_spEnsureTC) y js/core/movimientos.js.
    // #screen-tarjetas y #mas-tarjetas ya eran HTML estático (mismo caso que
    // Mesada/Configuración). Sí requirió 2 cambios reales dentro del propio
    // archivo (ver su header): el wiring de botones que esperaba
    // 'DOMContentLoaded' se corrigió a top-level (mismo fix que
    // actividad_reciente.js), y tcNormalizarTarjetas()/renderTCDashboard()
    // (llamadas desde refresh()/save() en js/core/refresh.js, no desde acá) ya
    // tienen guard typeof — confirmado con el archivo real, ver
    // auditoria-tecnica.md. Su wrapper de abrirDetalleMov (Events.registerAll
    // más abajo en el archivo) ya resolvía el nombre en tiempo de click, no
    // de carga, así que es lazy-safe sin tocarlo. Efecto secundario aceptado,
    // no corregido: el gancho Ui.en("fuente-alerta") al final del
    // archivo (hint "se carga a la TC" al elegir una tarjeta como fuente en
    // Gastos/Encargos/Préstamos) no aplica hasta que el usuario visite
    // Tarjetas por primera vez — el hint simplemente no aparece hasta
    // entonces, no rompe nada.
    tarjetas: ['js/modules/tarjetas_credito.js'],
    // Séptimo a undécimo grupo lazy (ronda de modularización de spotify/
    // prestado/cuentas/analisis/encargos — ver auditoria-tecnica.md). Los 5
    // se auditaron línea por línea contra el mismo criterio de siempre
    // (código de nivel superior sin dependencia real de orden de carga,
    // llamadas cruzadas a otros módulos de dominio con guard typeof) y
    // aparecieron confirmados seguros en todos los casos SALVO dos bugs
    // reales, ya corregidos como parte de esta misma ronda:
    // 1. openSheet() en spotify.js estaba envuelto en un listener
    //    DOMContentLoaded que, con carga lazy, nunca dispara (el evento ya
    //    pasó) — se corrigió a top-level, ver cabecera de ese bloque en
    //    spotify.js.
    // 2. navegacion.js (núcleo, siempre eager) tenía dos referencias sin
    //    guard a globales de estos módulos que corrían en CADA llamada a
    //    showScreen(), no solo al entrar a esas pantallas: el bloque de
    //    reset de Préstamos (deudorActualId/miDeudaActualId/
    //    prestamosTabActiva), que ya tiene guard typeof — ver navegacion.js.
    // #screen-spotify/#screen-prestamos/#screen-cuentas/#screen-encargos ya
    // eran HTML estático desde antes (mismo caso que Mesada/Tarjetas), y
    // #screen-analisis vive dentro de "Más", también estático — ninguno
    // necesitó copiar/inyectar HTML. Se agregaron ramas de re-render en
    // showScreen() (navegacion.js) para spotify y prestamos, replicando el
    // fix que ya se había hecho para tarjetas — cuentas/encargos/analisis ya
    // las tenían desde antes (antes de volverse lazy, esas ramas ya
    // corrían, solo que sobre un módulo cargado de entrada).
    spotify: ['js/modules/spotify.js'],
    prestamos: ['js/modules/prestado.js'],
    // cuentas: REACTIVADO como lazy (2026-08-13, segundo intento). El primer
    // intento se revirtió por 3 ReferenceError encadenados al arrancar
    // (ahorroTotal/getTasaCuenta llamados sin guard
    // desdel núcleo y firebase-sync.js). Se recibieron y auditaron
    // los archivos núcleo (el núcleo, firebase-sync.js, pin-bio.js, gastos-fijos-progress.js, …):
    // los tres puntos del error, más calcC/calcCDT/materializarIntereses/
    // registrarTasaHistorial/verificarVencimientosCDT (todo lo demás que
    // cuentas.js expone y que estos archivos llegan a tocar), ya tienen
    // guard `typeof` — confirmado contra el código real, no por inferencia.
    // pin-bio.js/gastos-fijos-progress.js no llaman ninguna función de cuentas.js.
    // El grupo carga DOS archivos, uno tras otro: nu.js (cajitas, tasa, CDTs, metas, chequeo) y cuentas.js (selector, cuentas
    // simples, historial, agregar/retirar/transferir). Ninguno usa al otro al cargar, solo cuando una función corre, así que el
    // orden no es obligatorio; se deja nu.js primero por convención.
    cuentas: ['js/modules/nu.js', 'js/modules/cuentas.js'],
    analisis: ['js/modules/analisis.js'],
    encargos: ['js/modules/encargos.js'],
    // Duodécimo grupo lazy (2026-09-07, rediseñado a solo-anual 2026-09-08).
    // "Wrapped" — revelación anual animada tipo Spotify Wrapped, pantalla
    // accesible desde "Más". A propósito solo anual, no mensual (ver
    // wrapped.md §7). Caso más simple que los anteriores: no
    // monkey-patchea ninguna función ajena, no lo llama nadie más (a
    // diferencia de Mesada/Tarjetas, que sí tenían callers externos con
    // guard typeof que auditar), y sus únicas dependencias de datos
    // (_esGastoVarNoReal, _esEntradaEspejoNoIngreso) viven en archivos
    // núcleo eager (calc-helpers.js y el núcleo), no en otro módulo
    // lazy — así que no hace falta Loader.ensure() encadenado como sí
    // necesita spotify.js con tarjetas_credito.js. La única lectura
    // cross-módulo (racha de Alcancía) es opcional y con guard typeof —
    // si Alcancía no cargó todavía, esa cifra puntual simplemente no se
    // muestra (ver wrapped.js).
    //
    // 2026-09-15: pasa a tener ventana de disponibilidad (solo enero, año
    // recién cerrado — ver js/core/wrapped-gate.js y wrapped.md §7decies).
    // ensureAll() más abajo ya no lo precarga fuera de esa ventana.
    wrapped: ['js/modules/wrapped.js'],
    // Grupo SOLO bajo demanda (2026-10-31): huella de invariantes y cierre de períodos (~34 KB, ~12 KB comprimidos). Se usa al abrir
    // Configuración (medidor «Tamaño de tus datos») y desde la consola. A diferencia del resto, ensureAll() NO lo precarga (ver
    // SOLO_BAJO_DEMANDA). Orden: huella.js antes que cierre.js. Las sondas de los módulos (tarjetas, encargos, alcancía, Wrapped) llegan
    // antes y esperan en cola (registrarSonda, js/core/persistencia.js); huella.js la vacía al cargarse.
    cierre: ['js/core/huella.js', 'js/core/cierre.js'],
  };

  const loaded = new Set();   // grupos ya cargados (no se vuelven a pedir)
  const loading = new Map();  // grupo → Promise en curso (evita pedidos duplicados)

  function _loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('No se pudo cargar ' + src));
      document.body.appendChild(s);
    });
  }

  function ensure(group) {
    if (loaded.has(group)) return Promise.resolve();
    if (loading.has(group)) return loading.get(group);
    const files = GROUPS[group];
    if (!files) return Promise.resolve(); // grupo desconocido = no es lazy, no hay nada que cargar

    const p = files
      .reduce((chain, src) => chain.then(() => _loadScript(src)), Promise.resolve())
      .then(() => { loaded.add(group); loading.delete(group); })
      .catch(err => { loading.delete(group); throw err; });

    loading.set(group, p);
    return p;
  }

  // Puro a propósito: solo dice si ESE grupo específico ya cargó. La pregunta
  // "¿esta pantalla es lazy?" es responsabilidad de quien llama (showScreen
  // chequea Loader.GROUPS[name] aparte, antes de llamar a esto).
  function isLoaded(group) {
    return loaded.has(group);
  }

  // ── Precarga total en segundo plano ───────────────────────────────────────
  // Por qué existe: dos módulos lazy alimentan cálculos que corren fuera de
  // sus propias pantallas — cuentas.js (calcC, calcCDT, calcRendimientoCDTsMes,
  // ahorroTotal) y prestado.js (getDeudorSaldoPatrimonio, totalMisDeudasPendiente,
  // totalPrestadoPendiente):
  //   - snapshotPatrimonio() (js/core/patrimonio.js, corre en cada save()) no graba el
  //     punto del historial de patrimonio hasta que calcC, calcCDT,
  //     getDeudorSaldoPatrimonio y totalMisDeudasPendiente existan
  //     (_patrimonioDependenciasListas): sin la precarga, una sesión donde el
  //     usuario nunca abre Cuentas ni Préstamos no actualizaría el historial.
  //   - la salud financiera y la alerta de gasto alto de Inicio (inicio.js)
  //     las llaman con guard y, si no cargaron, caen a un valor de respaldo
  //     (saldo guardado sin recalcular, préstamos en 0) — el número queda mal
  //     hasta que el usuario visite esa pantalla a mano.
  // "Necesita atención" en sí NO depende de ningún módulo lazy: las 6
  // funciones que usa (getDeudorSaldo, getMesadaData, _mesNombreDeKey,
  // tcCupoUsadoPct, spNombreDe, spPersonaPagadaVigente) viven en
  // js/core/calc-helpers.js, que carga de entrada.
  // Se decidió explícitamente NO forzar la carga desde dentro de inicio.js
  // (eso reintroduciría el problema que la modularización por pantalla
  // buscaba resolver: bloquear Inicio con el peso de TODOS los módulos). En
  // cambio, se precarga en PARALELO (no uno por uno) recién después de que la
  // app ya pintó y cargó datos reales — así el primer pintado de Inicio sigue
  // tan rápido como con la carga lazy, y el costo de red se paga una sola
  // vez, en segundo plano, sin bloquear nada visible.
  //
  // Dentro de cada grupo los archivos siguen cargando en orden (ver
  // ensure() arriba, sigue aplicando el motivo del header de este
  // archivo); ENTRE grupos no hay dependencia de orden — cada pantalla es
  // independiente — así que sí se piden todas a la vez.
  //
  // Se precargan todos los grupos MENOS los que el usuario no tiene forma de
  // abrir en este momento (bajar código que nadie puede usar es costo puro):
  //   - 'wrapped': fuera de su ventana de enero la fila de menú está oculta
  //     (ver js/core/wrapped-gate.js y wrapped.md §7decies). Guard typeof: si
  //     ese script no cargó, se asume "no disponible" (falla cerrado, mismo
  //     criterio que la fila del menú).
  //   - 'mesada' y 'spotify': si el toggle de Configuración → "Módulos
  //     activos" está apagado (S.modulos.<x> === false) su ítem del menú
  //     "Más" está oculto. Inicio no necesita estos archivos para nada: las
  //     funciones que lee de ambos viven en js/core/calc-helpers.js (carga de
  //     entrada) y inicio.js ya se salta el módulo cuando el toggle está
  //     apagado. Solo se omite con `=== false` explícito: si S.modulos no
  //     existe o la clave falta, se precarga (el comportamiento seguro). `S`
  //     se lee con typeof y no como window.S: no se asume que sea propiedad
  //     de window. Al reactivar el toggle no hace falta ningún paso extra:
  //     showScreen() llama a Loader.ensure() la primera vez que se entra a la
  //     pantalla, como con cualquier grupo lazy.
  // ensureAll() corre tras 'appDataLoaded', así que S.modulos ya es el real.
  const _MODULO_DE_GRUPO = { mesada: 'mesada', spotify: 'spotify' };

  // Grupos que NUNCA se precargan: se piden solo cuando se necesitan (ensure('cierre')).
  const SOLO_BAJO_DEMANDA = new Set(['cierre']);

  function ensureAll() {
    const grupos = Object.keys(GROUPS).filter(g => {
      if (SOLO_BAJO_DEMANDA.has(g)) return false;
      if (g === 'wrapped') {
        return typeof window._wrappedDisponible === 'function' && window._wrappedDisponible();
      }
      const modulo = _MODULO_DE_GRUPO[g];
      if (modulo && typeof S !== 'undefined' && S && S.modulos && S.modulos[modulo] === false) {
        return false;
      }
      return true;
    });
    return Promise.all(grupos.map(g => ensure(g).catch(() => {})));
  }

  // FIX (2026-08-17, confirmado con dos corridas reales de Lighthouse — ver
  // CHANGELOG.md#infraestructura--seguridad): el disparo inmediato de acá
  // abajo SÍ contaba dentro de la ventana que Lighthouse mide como Total
  // Blocking Time. Prueba encontrada en los propios reportes: "Avoid long
  // main-thread tasks" mostraba tareas de cuentas.js/plata_comprometida.js/
  // alcancia.js/import-validado.js corriendo varios segundos después del
  // primer pintado (una de 106ms a los 8.6s de carga), y "Reduce unused
  // JavaScript" marcaba cuentas.js con 76% de su peso sin usar — confirma
  // que ensureAll() se estaba disparando y ejecutando adentro de la ventana
  // auditada, no "de verdad en segundo plano" como asumía el diseño
  // original (comentario de abajo, sin tocar por valor histórico).
  //
  // Se reemplaza el disparo inmediato por requestIdleCallback: es la
  // semántica correcta para "trabajo de fondo que no debe competir con
  // nada" — el navegador lo corre solo cuando el hilo principal está
  // realmente libre, cediendo el paso a cualquier interacción real del
  // usuario que llegue primero (un tap en un nav-item, por ejemplo).
  // timeout:5000 garantiza que igual corra si el hilo nunca queda idle por
  // su cuenta — mismo patrón de "timeout de seguridad" que ya usa el resto
  // de la app (window._pinGateTimeout, window._authgateReadyTimeout en
  // firebase-init.js). Fallback a setTimeout para Safari (sin soporte de
  // requestIdleCallback al momento de escribir esto).
  //
  // Nota honesta, no prometer de más: en la corrida de Lighthouse en sí
  // (una pestaña sola, sin otra interacción real compitiendo) es posible
  // que requestIdleCallback dispare casi enseguida igual, porque ahí no
  // hay ningún otro trabajo esperando el hilo principal — así que el
  // número de TBT podría no bajar mucho en ese entorno sintético
  // específico. El beneficio real es para un usuario de verdad, que sí
  // puede estar tocando algo justo en ese momento.
  function _iniciarEnsureAll() {
    ensureAll().then(() => {
      // Bandera global: marca que la precarga terminó. inicio.js
      // (renderAttencion) la lee para no comparar/guardar el fingerprint de
      // "Necesita atención" antes de ese punto (ver CHANGELOG.md#sheets--ui).
      window._appFullyLoaded = true;
      if (typeof refresh === 'function') refresh();
      if (typeof applyModulos === 'function') applyModulos();
    });
  }

  // Disparo automático, una sola vez por carga de página: apenas termina
  // la primera carga real de datos (evento 'appDataLoaded', ver
  // firebase-sync.js#_finishFirstLoad — se dispara tanto con datos de la
  // nube como en el camino de error/sin conexión, así que cubre ambos
  // casos). Al terminar, un solo refresh()/applyModulos() para que todo lo
  // de Inicio que dependía de un módulo lazy (salud financiera, alerta de
  // gasto alto) se actualice sola, sin que el usuario tenga que tocar nada
  // ni volver a entrar a Inicio.
  // Descartado (2026-08-17, sesión de investigación del punto 12 de
  // auditoria-tecnica.md): se probó acá un guard con MutationObserver sobre
  // #pin-screen.open, bajo la hipótesis de que _iniciarEnsureAll podía
  // disparar mientras el PIN seguía sin desbloquear. Se revirtió al
  // confirmar, con pin-bio.js + firebase-init.js + firebase-sync.js en
  // mano, que la hipótesis es imposible en la arquitectura actual:
  // appDataLoaded solo lo dispara _finishFirstLoad() (firebase-sync.js),
  // que solo corre dentro del onSnapshot de _fbLoadData(), que solo se
  // llama desde _launchApp() (pin-bio.js) — y ahí SIEMPRE después de
  // _hidePin() (que ya sacó la clase 'open'). No hay ningún camino de
  // código en el que este evento pueda disparar con el PIN todavía en
  // pantalla. Ver CHANGELOG.md#infraestructura--seguridad para el detalle
  // completo de la investigación y qué explica el TBT real medido.
  window.addEventListener('appDataLoaded', function () {
    if (typeof requestIdleCallback === 'function') {
      requestIdleCallback(_iniciarEnsureAll, { timeout: 5000 });
    } else {
      setTimeout(_iniciarEnsureAll, 2000);
    }
  }, { once: true });

  return { ensure, ensureAll, isLoaded, GROUPS };
})();
