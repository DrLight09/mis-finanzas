// js/core/mejoras-adicionales.js
//
// Fusión de mejoras.js + mejoras-adicionales.js (2026-09-10): ambos eran
// literalmente la parte 1 y la parte 2 de un mismo bloque original llamado
// "MEJORAS ADICIONALES" (ver el propio encabezado que tenía cada uno antes
// de esta fusión) — no una separación real de responsabilidad, sino el
// corte arbitrario de la sesión de extracción original. Mismo criterio que
// ya se usó para fusionar sheet-swipe.js + sheet-viewport.js en
// sheet-behavior.js: dos archivos con nombres casi idénticos (uno de ellos
// literalmente "mejoras-adicionales", el otro apodado igual en su propio
// comentario) invitaban a confundirlos o a no saber en cuál de los dos
// buscar algo. Ver CHANGELOG.md para el detalle.
//
// No hay ninguna dependencia real de orden de carga ENTRE las dos mitades
// (cada sección depende de cosas ya definidas antes por otros archivos —
// hookGlobal, DOM, S — nunca de una sección de la otra mitad), así que
// fusionarlas fue seguro. Las secciones de abajo conservan su numeración
// original de cada mitad (no se renumeraron a una sola secuencia continua,
// mismo criterio que sheet-behavior.js) — algunas ya son solo un comentario
// apuntando a dónde vive hoy esa funcionalidad, migrada en sesiones
// posteriores a la extracción original.

(function(){
  /* ====================================================
     1. OCULTAR/MOSTRAR SALDOS
  ==================================================== */
  const SALDOS_OCULTOS_KEY = 'mf-saldos-ocultos';
  let _saldosOcultos = localStorage.getItem(SALDOS_OCULTOS_KEY) === '1';
  const MONEY_SELECTORS = [
    '#heroTotal','#hero-estado','#s-disp','#s-nu','#s-ef','#s-nequi','#s-prest','#s-cdt',
    '#s-gf','#s-gv','#s-gtotal','.hero-amount','.stat-value','.row-amount',
    '#det-cuenta-saldo','#nuTotalDisp','.cajita-val','#tc-hero-cupo','.an-bien-monto'
  ];
  // #det-cuenta-saldo: saldo del detalle de Nequi, Efectivo y cuentas personalizadas (una sola
  // pantalla; reemplaza a #det-nequi-saldo, #det-ef-saldo y #det-custom-saldo). Los saldos del
  // selector de Cuentas (#sel-nequi-saldo, #sel-nu-saldo, #sel-ef-saldo, antes elementos fijos) ya
  // no son elementos fijos: renderSelectorCuentas() reescribe todo el contenedor con innerHTML,
  // por eso se tratan como área dinámica (SALDO_DINAMICO_IDS, 'selector-cuentas-lista').

  // Aplica el estado actual de _saldosOcultos al ícono del botón y a los
  // elementos de dinero, sin cambiar el valor de _saldosOcultos. Se usa
  // tanto al hacer click (toggleSaldos) como al restaurar el estado
  // guardado en localStorage al cargar la página.
  function _aplicarEstadoSaldos(){
    const btn = document.getElementById('btn-toggle-saldos');
    if(_saldosOcultos){
      btn.innerHTML = `<svg aria-hidden="true" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
      btn.style.color = 'var(--accent)';
    } else {
      btn.innerHTML = `<svg aria-hidden="true" id="ojo-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
      btn.style.color = 'var(--text2)';
    }
    // Aplicar blur a todos los elementos de dinero
    MONEY_SELECTORS.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        if(_saldosOcultos) el.classList.add('saldo-hidden');
        else el.classList.remove('saldo-hidden');
      });
    });
    // Proyección, "Necesita atención" (deudas de personas y cobros
    // vencidos), tarjetas de crédito, selector de cuentas y las listas
    // de gastos: los montos ya están envueltos en spans .saldo-inline
    // (ver 1b más abajo), acá solo se prende/apaga.
    _aplicarOcultoEnAreas();
  }

  function toggleSaldos(){
    _saldosOcultos = !_saldosOcultos;
    localStorage.setItem(SALDOS_OCULTOS_KEY, _saldosOcultos ? '1' : '0');
    _aplicarEstadoSaldos();
  }

  document.getElementById('btn-toggle-saldos').addEventListener('click', toggleSaldos);

  /* ====================================================
     1b. OCULTAR MONTOS EN ÁREAS DINÁMICAS
         (Tendencia mensual/proyección, "Necesita atención" —
         deudas de personas y cobros vencidos—, tarjetas de
         crédito, el selector de cuentas en "Cuentas" (Nequi, Nu, Efectivo y personalizadas), las
         listas de gastos variables/fijos en "Gastos", los
         listados y el historial de Préstamos (me deben / yo
         debo), la lista y estadísticas de Spotify, la lista
         de tarjetas en la pantalla Tarjetas de crédito, y todo
         el contenido de Análisis financiero: balance del mes,
         comparación con el mes anterior, historial de
         patrimonio, categorías, gráfico de gastos por mes,
         ranking de meses y presupuestos). Estos
         contenedores se re-renderizan completos con innerHTML
         desde otros módulos (inicio.js y los módulos de
         tarjetas/cuentas/gastos), así que en vez de apuntar a
         selectores fijos como en MONEY_SELECTORS, se busca
         cualquier texto con formato "$..." dentro de ellos, se
         envuelve en un <span class="saldo-inline"> y se observa
         el contenedor para repetir el envoltorio cada vez que
         su contenido se vuelve a pintar.

         Nota: esto solo oculta MONTOS. El nombre/descripción de
         cada gasto (ej. "Uber", "Farmacia") sigue visible — no
         se toca ese texto.
  ==================================================== */
  const SALDO_DINAMICO_IDS = ['proyeccion-card','s-attn-list','tc-deuda-card','selector-cuentas-lista','gastosVarList','gastosFijosList',
    // Préstamos (lo que me deben / lo que debo): listas y detalle
    'deudoresList','misDeudasList','ddHistorial','mdHistorial',
    // Spotify: lista de personas, estadísticas (ganancias) e historial de cobros
    'spotifyList','spStats','spHistorial',
    // Tarjetas de crédito: lista de tarjetas (screen-tarjetas)
    'tc-lista',
    // Análisis financiero: balance del mes, comparación con mes
    // anterior, historial de patrimonio, categorías, gráfico de
    // gastos por mes, ranking de meses, presupuestos e ingresos fijos
    'analisis-balance-hero','an-comparacion','an-patrimonio-chart',
    'an-cats-mes','an-grafico-barras','an-grafico-labels',
    'an-ranking-meses','an-presupuestos','an-ingresos-fijos-list'];
  const REGEX_MONTO = /[-+]?\$\s?\d[\d.,]*/g;

  function _envolverMontos(root){
    if(!root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node){
        if(node.parentElement && node.parentElement.classList.contains('saldo-inline')) return NodeFilter.FILTER_REJECT;
        REGEX_MONTO.lastIndex = 0;
        return REGEX_MONTO.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodos = [];
    let n;
    while((n = walker.nextNode())) nodos.push(n);
    nodos.forEach(textNode => {
      REGEX_MONTO.lastIndex = 0;
      const montos = textNode.nodeValue.match(REGEX_MONTO);
      if(!montos) return;
      const partes = textNode.nodeValue.split(REGEX_MONTO);
      const frag = document.createDocumentFragment();
      partes.forEach((parte, i) => {
        if(parte) frag.appendChild(document.createTextNode(parte));
        if(montos[i]){
          const span = document.createElement('span');
          span.className = 'saldo-inline' + (_saldosOcultos ? ' saldo-hidden' : '');
          span.textContent = montos[i];
          frag.appendChild(span);
        }
      });
      textNode.parentNode.replaceChild(frag, textNode);
    });
  }

  function _aplicarOcultoEnAreas(){
    SALDO_DINAMICO_IDS.forEach(id => {
      const el = document.getElementById(id);
      if(!el) return;
      el.querySelectorAll('.saldo-inline').forEach(span => {
        span.classList.toggle('saldo-hidden', _saldosOcultos);
      });
    });
  }

  const _obsAreasSaldo = {};
  function _observarAreaSaldo(id){
    const el = document.getElementById(id);
    if(!el || _obsAreasSaldo[id]) return;
    _envolverMontos(el);
    const obs = new MutationObserver(() => {
      // Desconectar mientras tocamos el DOM nosotros mismos, para no
      // reaccionar a nuestro propio envoltorio (evita loop/recursión).
      obs.disconnect();
      _envolverMontos(el);
      _aplicarOcultoEnAreas();
      obs.observe(el, {childList:true, subtree:true});
    });
    obs.observe(el, {childList:true, subtree:true});
    _obsAreasSaldo[id] = obs;
  }

  // Los contenedores ya existen en el HTML inicial (aunque arranquen
  // vacíos o en display:none), así que se observan de una vez. appDataLoaded
  // vuelve a intentarlo por si alguno se creó después.
  SALDO_DINAMICO_IDS.forEach(_observarAreaSaldo);
  window.addEventListener('appDataLoaded', function(){
    SALDO_DINAMICO_IDS.forEach(_observarAreaSaldo);
  });

  // Restaurar de una vez el estado guardado (botón + montos ya presentes en
  // el HTML inicial). Se hace acá, después de definir SALDO_DINAMICO_IDS y
  // _aplicarOcultoEnAreas (más arriba), porque _aplicarEstadoSaldos() llama
  // a _aplicarOcultoEnAreas() y esta última depende de SALDO_DINAMICO_IDS —
  // llamarla antes de que ese const se inicialice tira
  // "Cannot access 'SALDO_DINAMICO_IDS' before initialization" (TDZ).
  _aplicarEstadoSaldos();

  /* ====================================================
     2. BÚSQUEDA GLOBAL — migrado a js/core/busqueda-global.js
        Ver auditoria-tecnica.md. Sin dependencia real de orden de
        carga, se carga como <script src> aparte, ver el final del
        <body> (junto a los demás módulos de js/core y js/modules).
  ==================================================== */

  /* ====================================================
     3. INDICADOR DE SALUD FINANCIERA — migrado a js/modules/inicio.js
        (calcHealthScore() y renderHealthScore()). Ver auditoria-tecnica.md.
        Quedan como funciones globales; _renderMejoras() (más abajo en
        este mismo archivo) las sigue llamando desde acá porque ese mismo
        hook también dispara renderPresupuestos() (módulo de Análisis, no
        de Inicio).
  ==================================================== */

  /* ====================================================
     4. PROYECCIÓN FINANCIERA — migrado a js/modules/inicio.js
        (renderProyeccion()). Ver auditoria-tecnica.md. _renderMejoras()
        (más abajo en este mismo archivo) la sigue llamando desde acá por
        el mismo motivo que la sección 3.
  ==================================================== */


  /* ==== 6. PRESUPUESTOS: migrado a js/modules/analisis.js (abrirPresupuestos, renderPresupuestos) ==== */

  /* ====================================================
     7. EXPORTAR CSV: migrado a js/modules/configuracion.js
  ==================================================== */

  /* ====================================================
     8. HOOK EN REFRESH para nuevas funciones
  ==================================================== */
  // Renderizar salud y proyección directamente (sin depender del hook de refresh)
  function _renderMejoras() {
    try { renderHealthScore(); } catch(e){}
    try { renderProyeccion(); } catch(e){}
    try { renderPresupuestos(); } catch(e){}
  }

  // Guard: si refresh no existe aún, esperar a que esté disponible —
  // hookGlobal (js/core/hook-global.js) ya encapsula el capturar+envolver+
  // esperar con waitFor(). Antes esto era el mismo bloque de ~10 líneas
  // que también tenían, casi calcado, gastos-fijos-progress.js y
  // pin-bio.js — ver js/core/hook-global.js para el porqué de sacarlo a
  // un solo lugar. Sin tope de intentos, igual que antes: refresh()
  // siempre termina existiendo.
  Refresh.registrar('mejoras-render', _renderMejoras);

  // Llamar directamente cuando Firebase termina de cargar los datos.
  // Necesario porque los módulos type="module" se ejecutan DESPUÉS que los scripts
  // inline, por lo que cuando _initAppUI llama refresh() el hook aún no está instalado.
  window.addEventListener('appDataLoaded', function() {
    setTimeout(_renderMejoras, 300);
  });

  /* ====================================================
     9. VALIDACIÓN MEJORADA DE MONTOS (numéricos grandes)
  ==================================================== */
  document.addEventListener('change', e => {
    const inp = e.target;
    if(!inp.classList.contains('money-input')) return;
    const val = window.parseMoney ? window.parseMoney(inp.value) : 0;
    if(val < 0){
      if(window.toast) window.toast('El monto no puede ser negativo','err');
      inp.value = '';
    }
    if(val > 1e12){
      if(window.toast) window.toast('El monto parece demasiado grande','err');
      inp.value = '';
    }
  });

  /* ====================================================
     10. ANIMACIÓN DE CARGA INICIAL (fade-in del app)
  ==================================================== */
  // Animacion fade-in: se aplica cuando _finishFirstLoad oculta el loader.
  // Ya no envolvemos _fbLoadData porque ahora usa onSnapshot (no es awaitable).
  (function(){
    const app = document.querySelector('.app');
    const loadingEl = document.getElementById('fb-loading-screen');
    if(app && loadingEl){
      app.style.opacity='0'; app.style.transition='opacity .4s';
      const _obs = new MutationObserver(()=>{
        if(loadingEl.style.display==='none'){ requestAnimationFrame(()=>{ app.style.opacity='1'; }); _obs.disconnect(); }
      });
      _obs.observe(loadingEl,{attributes:true,attributeFilter:['style']});
    }
  })();

})();

/* ================================================================
   SERVICE WORKER — PWA offline
   ================================================================ */
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/mis-finanzas/sw.js', { scope: '/mis-finanzas/' })
    .then(() => console.info('[SW] Registrado correctamente'))
    .catch(err => console.info('[SW] No disponible:', err.message));

  // «Hay una versión nueva». El SW nuevo se activa solo (skipWaiting + clients.claim), pero esta pestaña ya tiene cargado el index.html
  // y los .js de la versión anterior: si además abre un módulo lazy, lo baja de la caché NUEVA y se mezclan dos versiones. Recargar
  // lo resuelve, y no se hace solo para no perder lo que el usuario esté escribiendo. `controllerchange` también salta en la primera
  // instalación (no había controlador), y ahí no hay nada que avisar: por eso se compara contra si ya había uno al cargar la página.
  // Ver scripts/sellar-sw.js y docs/CHANGELOG.md (2026-11-05).
  const _teniaControlador = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (_teniaControlador) mostrarAvisoNuevaVersion(); });
} // fin if ('serviceWorker' in navigator)

function mostrarAvisoNuevaVersion() {
  if (document.getElementById('sw-aviso')) return; // ya está visible: varios cambios seguidos no apilan avisos
  const barra = document.createElement('div');
  barra.id = 'sw-aviso';
  barra.className = 'sw-aviso';
  barra.setAttribute('role', 'status');
  const texto = document.createElement('span');
  texto.className = 'sw-aviso-texto';
  texto.textContent = 'Hay una versión nueva de la app.';
  const recargar = document.createElement('button');
  recargar.type = 'button';
  recargar.className = 'sw-aviso-btn';
  recargar.textContent = 'Actualizar';
  recargar.addEventListener('click', () => location.reload());
  const luego = document.createElement('button');
  luego.type = 'button';
  luego.className = 'sw-aviso-cerrar';
  luego.setAttribute('aria-label', 'Cerrar');
  luego.textContent = '×';
  luego.addEventListener('click', () => barra.remove());
  barra.append(texto, recargar, luego);
  document.body.appendChild(barra);
}
window.mostrarAvisoNuevaVersion = mostrarAvisoNuevaVersion;

/* ================================================================
   NAVEGACIÓN POR GESTOS — manejado por makeSwipeable(), en
   js/core/sheet-behavior.js (sección "SWIPE TO CLOSE" de ese archivo,
   no de este) — aclarado acá porque la numeración de secciones de
   arriba (1, 1b, 2, 3, 4, 6, 7, 8, 9, 10) es de este archivo, no la de
   sheet-behavior.js, y podía confundirse con su propia "sección 7".
   ================================================================ */

/* ================================================================
   AUTOFOCUS en formularios al abrirse
   ================================================================ */
(function() {
  // Mapeo de sheet-id → id del primer campo a enfocar
  const focusMap = {
    'gasto-var': 'gv_desc',
    'gasto-fijo': 'gf_n',
    'nueva-persona': 'np_nombre',
    'spotify': 'sp_n',
    'nuevo-encargo': 'enc_nombre',
    'nueva-cuenta': 'nc_nombre',
    'agregar-dinero': 'adDesc',
    'restar-dinero': 'rdDesc',
    // 'mesada-pago' y 'mesada-pend' NO se enfocan a propósito: abren con el monto ya
    // precargado (la cuota del mes / lo pendiente), que casi siempre es el correcto;
    // el teclado saltaría sin necesidad. El campo sigue editable con un toque.
    'transferir': 'tr_monto',
  };

  // Hook a openSheet — ver js/core/hook-global.js. Reemplaza el wrap manual
  // + fallback con waitFor() que tenía este archivo (y de paso se saca un
  // bug latente sin efecto real que tenía esa rama: comparaba
  // `window.openSheet !== arguments.callee` dentro de un arrow function,
  // donde arguments.callee apuntaba al IIFE completo, no a la función
  // interna — la comparación nunca hacía lo que parecía. hookGlobal() no
  // necesita esa comparación: waitFor() ya resuelve "esperar hasta que
  // exista" con su propio checkFn).
  hookGlobal('openSheet', function(id) {
    const focusId = focusMap[id];
    if (focusId) focusSheetField(focusId);   // js/core/sheet-behavior.js: foco en el momento justo, sin timers sueltos
  }, { intervalMs: 100 });
})();

/* ================================================================
   MEJORA SEMÁNTICA — aria-labels y roles
   ================================================================ */
(function() {
  // Añadir role="main" al scroll-area
  const main = document.getElementById('scrollArea');
  if (main && !main.getAttribute('role')) main.setAttribute('role', 'main');

  // Añadir aria-label a las pantallas
  const screenLabels = {
    'screen-inicio': 'Inicio',
    'screen-cuentas': 'Cuentas',
    'screen-gastos': 'Gastos',
    'screen-prestamos': 'Préstamos',
    'screen-analisis': 'Análisis',
    'screen-config': 'Configuración',
    'screen-historial': 'Actividad reciente',
    'screen-personas': 'Personas',
  };
  Object.entries(screenLabels).forEach(([id, label]) => {
    const el = document.getElementById(id);
    if (el) el.setAttribute('aria-label', label);
  });
})();
