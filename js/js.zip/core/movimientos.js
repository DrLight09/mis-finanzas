/* ==========================================================================
   js/core/movimientos.js — Núcleo compartido: detalle y eliminación de movimientos
   ==========================================================================
   No es un módulo de dominio (no pertenece a Cuentas, Préstamos, TC, etc.):
   son las dos funciones que usa TODA la app para mostrar y borrar cualquier
   movimiento desde el feed general de actividad y desde el detalle de cada
   cuenta — por eso vive en js/core/, junto a events.js, y no en js/modules/.

   - abrirDetalleMov(el)   — abre el sheet "detalle de movimiento" (saldo
     antes/después de la fuente involucrada). Reconstruye el saldo histórico
     recorriendo la lista de movimientos de la fuente hasta el índice del
     movimiento clickeado.
   - eliminarMovimiento(btn) — borra un movimiento genérico y revierte su
     efecto en los saldos de todas las cuentas involucradas. Bloquea el
     borrado si el movimiento es "secundario" (generado automáticamente por
     otra sección — encargos, cajitas, cuentas personalizadas, deudores,
     etc.) y redirige al usuario a la sección de origen.

   ¿CUÁNDO UN MOVIMIENTO NUEVO NECESITA `_secundario: true` + `_origenSeccion`?
   (regla fijada 2026-08-05, tras el bug de "Margen de encargo" borrable directo
   — ver CHANGELOG.md § Encargos, misma fecha)

   NO es "¿hay un objeto o dos?" — es "¿el borrado genérico de acá abajo sabe
   deshacer TODO lo que este movimiento implica?". Dos formas de que falle:

   (a) Estructural — el objeto vive en un array que ninguna rama del switch
       de abajo (movTipoEl === ...) sabe limpiar. Ej.: un "espejo" guardado
       en el historial propio de otro módulo — las ramas genéricas solo saben
        tocar S.movimientos (el historial de TODAS
        las cuentas), S.gastosVar y deudores[].movimientos.
       Si el array de destino no está ahí, borrar revierte el saldo pero
       deja el registro zombie parado para siempre.
   (b) Relacional — el objeto SÍ se borra limpio de su propio array, pero
       tiene un campo que lo liga a un "dueño" en otro módulo (_encMovId,
       spId, _viaEncargo, _tcId...) que no se entera del borrado y sigue
       mostrando el evento como vigente.

   Checklist al agregar un movimiento nuevo generado automáticamente:
     1. ¿En qué array vive realmente? (S.movimientos, historial propio del
         módulo, etc.)
     2. ¿Hay una rama en el switch de abajo que busque y haga
        splice()/filter() de ESE array exacto para este movTipoEl? Si no →
        _secundario obligatorio (falla (a)).
     3. ¿Tiene un campo que lo liga a un registro "dueño" en otro módulo? Si
        sí, y ese dueño no se revierte solo cuando se borra este → _secundario
        obligatorio (falla (b)).
     4. Solo si las dos anteriores dan limpio (array propio bien barrido, sin
        dueño externo que sincronizar) es seguro dejarlo borrable directo —
        caso real: "Préstamo dado" (deudores[].movimientos), único registro
        del evento — pero NO lo revierte una rama de acá: eliminarMovimiento()
        delega en eliminarMovDeudor() (prestado.js), la única implementación
        completa (fuentes divididas, vía TC/encargo/Alcancía, grupos).

   Se registran bajo el namespace Events 'core:' (no bajo el de ningún
   módulo) para no dar a entender que un dominio específico es dueño de esta
   lógica — mismo criterio ya usado cuando se migró Cuentas.

   Sin dependencia real de orden de carga: ambas funciones se llaman desde
   data-action="core:..." (click-time), nunca en el momento en que este
   script se parsea — así que basta con que carguen en algún punto antes de
   que Events.on('core:abrirDetalleMov', ...) / Events.on('core:eliminarMovimiento', ...)
   se ejecuten en index.html (que sigue siendo donde se registran, junto al
   resto del wiring de Events).

   Dependen de helpers ya definidos en el núcleo de index.html (S, save,
   refresh, escHtml, fmt, fuenteLabel, fuenteBadgeClass, getSaldoFuente,
   getMovimientosCuenta, sumarFuente, descontarFuente, openSheet, dialogo,
   toast, getMesadaData, mesKey) y de funciones de otros módulos ya migrados
   (tcEliminarCompraInterna/tcEliminarPagoInterna de Tarjetas de Crédito,
   renderDetalleCuenta de Cuentas, getEncargo de Encargos)
   — todos ya cargados antes de este archivo en index.html.
   ========================================================================== */

// ── Libro (js/core/cuentas-fuentes.js) ─────────────────────────────────────────────────────────────────────────────────
// _ogMov(ref, rev): al borrar un movimiento desde el feed o el historial de una cuenta, todo lo que se devuelve queda en el libro como reversión de ese movimiento (ref = id borrado). Con rev=true es una reversión (tipo 'reversion', mismo ref que lo que deshace).
const _ogMov = Libro.origen('movimientos');

/* ---- DETALLE DE MOVIMIENTO (sheet) ---- */
// Abre un sheet con el detalle de un movimiento y el saldo de la cuenta
// (de la fuente involucrada) antes y después de ese movimiento.
// `el` es el .gasto-item / .card clickeado, con data-mov-* attributes.
function abrirDetalleMov(el){
  if(!el) return;
  const movId = el.dataset.movId;
  const movTipo = el.dataset.movTipo || '';
  const fuente = el.dataset.movFuenteReal || el.dataset.movFuente || '';
  const montoAbs = parseFloat(el.dataset.movMonto) || 0;
  const cuentaKey = el.dataset.cuentaKey || '';
  let monto, fecha, desc, saldoAntes, saldoDespues, saldoLabel;

  if(cuentaKey==='deudor' || cuentaKey==='tc' || cuentaKey==='encargo'){
    // Movimiento que afecta una deuda/saldo de terceros (préstamo/abono, compra/pago TC, entrada/salida encargo)
    const aumentaSaldo = (movTipo === 'prestamo' || movTipo === 'compra' || movTipo === 'entrada');
    monto = aumentaSaldo ? montoAbs : -montoAbs;
    fecha = el.dataset.movFecha || '';
    desc = el.dataset.movDesc || (aumentaSaldo ? 'Entrada' : 'Salida');
    saldoAntes = parseFloat(el.dataset.movSaldoAntes) || 0;
    saldoDespues = parseFloat(el.dataset.movSaldoDespues) || 0;
    saldoLabel = el.dataset.movSaldoLabel || 'Saldo';
  } else if(!fuente){
    // Sin fuente identificable — no hay saldo que calcular
    return;
  } else {
  // Reconstruir la lista de movimientos de esta fuente para hallar el saldo histórico
  let lista, idx, signedFn;
  if(esFuenteCuenta(fuente)){
    // Cuenta normal: getMovimientosCuenta incluye todas las fuentes que la afectan
    lista = getMovimientosCuenta(fuente);
    idx = lista.findIndex(m => m._movId === movId);
    if(idx===-1) return;
    signedFn = m => m.monto;
    const m = lista[idx];
    monto = m.monto; fecha = m.fecha; desc = m.desc;
  } else {
    // Cajita: su historial se lista bajo la cuenta de ahorro a la que pertenece — m.monto ya viene con signo correcto
    const cajita = (S.cajitas||[]).find(x=>x.id===fuente.split(':')[1]);
    const tipoCuenta = cajita && cajita.cuentaId ? fuenteDeCuenta(cajita.cuentaId) : fuente;
    lista = getMovimientosCuenta(tipoCuenta).filter(m=>m.fuente===fuente);
    idx = lista.findIndex(m=> movId ? m._movId===movId : (m.fecha===el.dataset.movFecha && Math.abs(m.monto)===montoAbs));
    if(idx===-1) return;
    signedFn = m => m.monto;
    const m = lista[idx];
    monto = m.monto; fecha = m.fecha; desc = m.desc;
  }

  // saldoActual - suma de montos de movimientos más recientes (idx 0..idx-1) = saldo justo después de este mov
  const saldoActual = getSaldoFuente(fuente);
  let sumaPosteriores = 0;
  for(let j=0;j<idx;j++) sumaPosteriores += signedFn(lista[j]);
  saldoDespues = saldoActual - sumaPosteriores;
  saldoAntes = saldoDespues - monto;
  saldoLabel = fuenteLabel(fuente);
  }

  const esPositivo = monto >= 0;
  const claseMonto = esPositivo ? 'mdet-c-accent' : 'mdet-c-red';
  const signo = esPositivo ? '+' : '−';
  const tipoLabel = { gasto:'Gasto', ingreso:'Ingreso', apertura:'Apertura', prestamo:'Préstamo', abono:'Abono', compra:'Compra', mesada:'Mesada', transferencia:'Transferencia', salida_manual:'Retiro' }[movTipo] || movTipo;

  // Sección de origen (módulo donde se registró este movimiento)
  const origenLabel = el.dataset.movOrigen || '';
  const origenHtml = origenLabel ? `
    <div class="mdet-origen">
      <svg aria-hidden="true" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" class="mdet-no-shrink"><path d="M9 18l6-6-6-6"/></svg>
      Registrado desde <span class="mdet-origen-nombre">${escHtml(origenLabel)}</span>
    </div>` : '';

  // Otras cuentas implicadas en este mismo movimiento (transferencias, splits, etc.)
  let otrasCuentas = [];
  try { otrasCuentas = JSON.parse(el.dataset.movOtras || '[]'); } catch(_){ otrasCuentas = []; }
  const otrasHtml = (otrasCuentas && otrasCuentas.length) ? `
    <div class="mdet-caja-saldo">
      <div class="mdet-cap-saldo">Otras cuentas implicadas</div>
      ${otrasCuentas.map(oc=>{
        const ocPos = oc.monto>=0;
        return `<div class="mdet-otra-fila">
          <span class="badge ${fuenteBadgeClass(oc.fuente)} badge-xs">${fuenteHtml(oc.fuente)}</span>
          <span class="mdet-oc-monto ${ocPos?'mdet-c-accent':'mdet-c-red'}">${ocPos?'+':'−'} ${fmt(Math.abs(oc.monto))}</span>
        </div>`;
      }).join('')}
    </div>` : '';

  // ── Buscar el objeto raw del movimiento para mostrar info rica ────────────
  let _rawMov = null;
  try {
    if (movId) {
      if (cuentaKey === 'encargo') {
        // Buscar en todos los encargos (no solo el activo, para cubrir casos donde el usuario navegó)
        const encIdHint = el.dataset.movEncId || null;
        const todosEncs = (S.encargos||[]);
        for (const enc of todosEncs) {
          const found = (enc.movimientos||[]).find(m=>m.id===movId);
          if (found) { _rawMov = found; break; }
        }
        // Fallback al encargo activo
        if (!_rawMov) {
          if (typeof getEncargo==='function') {
            const enc = getEncargo(encargoActualId);
            if (enc) _rawMov = (enc.movimientos||[]).find(m=>m.id===movId) || null;
          }
        }
      } else if (cuentaKey === 'deudor') {
        for (const d of Deudas.lista('favor')) {
          const found = (d.movimientos||[]).find(m=>m.id===movId);
          if (found) { _rawMov = found; break; }
        }
      } else if (cuentaKey === 'tc') {
        for (const tc of (S.tarjetasCredito||[])) {
          _rawMov = (tc.compras||[]).find(m=>m.id===movId)
                 || (tc.pagos||[]).find(m=>m.id===movId)
                 || null;
          if (_rawMov) break;
        }
        if (!_rawMov) _rawMov = (S.tcMovimientos||[]).find(m=>m.id===movId) || null;
      } else {
        // Cuentas estándar/custom: busca en gastosVar, S.movimientos, transferencias, deudores (abonos), mesadas, Spotify
        _rawMov = (S.gastosVar||[]).find(m=>m.id===movId)
               || (S.movimientos||[]).find(m=>m.id===movId)
               || (S.transferencias||[]).find(m=>m.id===movId)
               || null;
        if (!_rawMov) {
          for (const d of Deudas.lista('favor')) {
            const found = (d.movimientos||[]).find(m=>m.id===movId);
            if (found) { _rawMov = found; break; }
          }
        }
      }
    }
  } catch(_){}

  // ── Info rica del movimiento raw en lenguaje claro ──────────────────────
  let richHtml = '';
  if (_rawMov) {
    const rm = _rawMov;
    const richParts = [];

    // Abono de deuda con extra: aunque en la cuenta se ve un solo movimiento (o uno por cuenta), el detalle dice que todo
    // viene del mismo abono, con el importe y la cuenta de cada parte.
    if (rm._abonoId) {
      const partes = (S.movimientos || []).filter(x => x._abonoId === rm._abonoId)
        .sort((a, b) => (a._parteAbono === 'abono' ? 0 : 1) - (b._parteAbono === 'abono' ? 0 : 1));
      if (partes.length > 1 && partes.some(x => x._parteAbono === 'extra')) {
        richParts.push(`
        <div class="mdet-caja-saldo">
          <div class="mdet-cap-saldo">Del mismo abono</div>
          ${partes.map(x => `<div class="mdet-otra-fila">
            <span class="badge ${fuenteBadgeClass(x.fuente)} badge-xs">${fuenteHtml(x.fuente)}</span>
            <span class="mdet-c-text2">${x._parteAbono === 'extra' ? 'Extra' : 'Abono de deuda'}</span>
            <span class="mdet-oc-monto mdet-c-accent">+ ${fmt(+x.monto)}</span>
          </div>`).join('')}
        </div>`);
      }
    }

    // Nota del movimiento (si es distinta a la descripción principal)
    if (rm.nota && rm.nota !== desc && !/automáticamente|contable neutro/i.test(rm.nota)) {
      richParts.push(`
        <div class="mdet-caja-nota">
          <div class="mdet-cap-nota">Nota</div>
          <div class="mdet-txt-lh15">${escHtml(rm.nota)}</div>
        </div>`);
    }

    // ── Sobrante del diferencial de encargo (ingreso generado automáticamente) ─
    if (rm._esDiferencialEncargo) {
      const encMovRef = rm._encMovId ? (() => {
        for (const enc of (S.encargos||[])) {
          const m = (enc.movimientos||[]).find(x=>x.id===rm._encMovId);
          if (m) return { enc, mov: m };
        }
        return null;
      })() : null;
      const dijo  = rm._difDijo  || (encMovRef?.mov?.monto) || 0;
      const real  = rm._difReal  || 0;
      const margenVal = rm._difMargen || (dijo - real) || 0;
      const encNombre = encMovRef?.enc?.nombre || '';
      const tcUsada = encMovRef?.mov?._tcId ? ((S.tarjetasCredito||[]).find(t=>t.id===encMovRef.mov._tcId)||{}).nombre : '';
      const destino = encMovRef?.mov?._destino ? fuenteLabel(encMovRef.mov._destino) : '';

      richParts.push(`
        <div class="mdet-panel-sobrante">
          <div class="mdet-cap-amber">Sobrante del diferencial — generado automáticamente</div>
          <div class="mdet-txt-suave">
            Este ingreso es el margen que quedó a tu favor porque le dijiste al encargo un valor diferente al real cargado a la tarjeta.
          </div>
          ${dijo ? `<div class="mdet-fila"><span class="mdet-c-text2">Le dijiste al encargo</span><span class="mdet-val-text">${fmt(dijo)}</span></div>` : ''}
          ${real ? `<div class="mdet-fila"><span class="mdet-c-text2">Costó realmente (TC)</span><span class="mdet-val-blue">${fmt(real)}</span></div>` : ''}
          ${margenVal ? `<div class="mdet-fila"><span class="mdet-c-amber">Margen a tu favor</span><span class="mdet-val-amber">+ ${fmt(margenVal)}</span></div>` : ''}
          ${tcUsada ? `<div class="mdet-fila"><span class="mdet-c-text2">Tarjeta que se usó</span><span class="mdet-b-blue">${escHtml(tcUsada)}</span></div>` : ''}
          ${encNombre ? `<div class="mdet-fila"><span class="mdet-c-text2">Encargo origen</span><span class="mdet-b-text2">${escHtml(encNombre)}</span></div>` : ''}
          ${destino ? `<div class="mdet-fila"><span class="mdet-c-text2">Fondos para pagar la TC en</span><span class="mdet-b-accent">${escHtml(destino)}</span></div>` : ''}
        </div>`);
    }

    // ── Diferencial / margen ────────────────────────────────────────────────
    if (rm.diferencial) {
      const d = rm.diferencial;
      const benefs = (d.beneficiarios || []).filter(b => b.nombre || b.monto > 0);
      const benefsNorm   = benefs.filter(b => !b.pagadoPorMi);
      const benefsYoPague = benefs.filter(b => b.pagadoPorMi);

      // Cabecera compacta: cuánto fue la ganancia (o pérdida) y de qué a qué, sin explicación.
      const _difPerdida = d.margen < 0;
      richParts.push(`
        <div class="mdet-panel-dif">
          <div class="mdet-dif-cab">
            <span class="mdet-cap-amber">${_difPerdida ? 'Pérdida' : 'Ganancia'} por valor diferente</span>
            <span class="mdet-dif-monto ${_difPerdida ? 'mdet-c-red' : 'mdet-c-amber'}">${_difPerdida ? '− ' : '+ '}${fmt(Math.abs(d.margen))}</span>
          </div>
          <div class="mdet-dif-detalle">Cobrado ${fmt(d.dijo)} · Real ${fmt(d.real)}</div>
          ${d.yoMeQuedo > 0 && d.miCuenta ? `
          <div class="mdet-txt">
            Guardaste <strong class="mdet-c-accent">${fmt(d.yoMeQuedo)}</strong> en <strong>${fuenteHtml(d.miCuenta)}</strong>.
          </div>` : ''}
          ${benefsNorm.length ? `
          <div class="mdet-txt">
            Del margen le diste:
            ${benefsNorm.map(b => `<span class="mdet-chip-amber"><strong>${escHtml(b.nombre)}</strong> <i class="fa-solid fa-arrow-right"></i> ${fmt(b.monto)}</span>`).join(' ')}
          </div>` : ''}
          ${benefsYoPague.length ? `
          <div class="mdet-txt">
            Pagaste de tu bolsillo por:
            ${benefsYoPague.map(b => `<span class="mdet-chip-blue"><strong>${escHtml(b.nombre)}</strong> ${fmt(b.monto)}${b.miCuentaSalida ? ' desde ' + fuenteHtml(b.miCuentaSalida) : ''}${b.miCuentaEntrada ? ' <i class="fa-solid fa-arrow-right"></i> recuperas en ' + fuenteHtml(b.miCuentaEntrada) : ''}</span>`).join(' ')}
            <div class="mdet-nota-pie">Pusiste esa plata de tu cuenta pero se te descuenta del encargo, así que es plata neutra.</div>
          </div>` : ''}
        </div>`);
    }

    // ── Extra del abono (deudores: dónde fue el extra del pago) ───────────
    if (rm._extPartes && rm._extPartes.length) {
      const extraTotal = rm._extPartes.reduce((a,p)=>a+(p.monto||0),0);
      richParts.push(`
        <div class="mdet-panel-extra">
          <div class="mdet-cap-blue">¿A dónde fue el extra del pago? (${fmt(extraTotal)})</div>
          ${rm._extPartes.map(p => {
            if (p.tipo==='guardar')   return `<div class="mdet-txt"><i class="fa-solid fa-arrow-right"></i> Guardaste <strong class="mdet-c-accent">${fmt(p.monto)}</strong> en <strong>${fuenteHtml(p.cuenta)}</strong></div>`;
            if (p.tipo==='gastar')    return `<div class="mdet-txt"><i class="fa-solid fa-arrow-right"></i> Se usó como gasto <strong>${fmt(p.monto)}</strong></div>`;
            if (p.tipo==='regalar')   return `<div class="mdet-txt"><i class="fa-solid fa-arrow-right"></i> Lo regalaste: <strong>${fmt(p.monto)}</strong></div>`;
            if (p.tipo==='pendiente') return `<div class="mdet-txt"><i class="fa-solid fa-arrow-right"></i> Quedó sin asignar: <strong>${fmt(p.monto)}</strong></div>`;
            return '';
          }).filter(Boolean).join('')}
        </div>`);
    }

    // ── Ganancia virtual en préstamo (no salió plata real) ─────────────────
    if (rm._gananciaVirtual) {
      richParts.push(`
        <div class="mdet-panel-ganancia">
          <div class="mdet-cap-accent">Ganancia incluida</div>
          <div class="mdet-txt-lh16">
            De este préstamo, <strong class="mdet-c-accent">${fmt(rm._gananciaVirtual)}</strong> son ganancia tuya que se registró como si los hubieras prestado, pero no salieron de ninguna cuenta.
          </div>
        </div>`);
    }

    // ── Fuentes split del préstamo ──────────────────────────────────────────
    if (rm.fuentes && rm.fuentes.length && !otrasCuentas.length) {
      richParts.push(`
        <div class="mdet-caja">
          <div class="mdet-cap-neutra">Salió de</div>
          ${rm.fuentes.map(f=>`<div class="mdet-txt-fila"><strong>${fuenteHtml(f.fuente)}</strong> <i class="fa-solid fa-arrow-right"></i> ${fmt(f.monto)}</div>`).join('')}
        </div>`);
    }

    // ── Destinos del abono ──────────────────────────────────────────────────
    if (!otrasCuentas.length && (rm.destinos?.length || rm.destino)) {
      const destinos = rm.destinos?.length ? rm.destinos : [{fuente: rm.destino, monto: rm.monto}];
      richParts.push(`
        <div class="mdet-caja">
          <div class="mdet-cap-neutra">Entró a</div>
          ${destinos.map(r=>`<div class="mdet-txt-fila"><strong>${fuenteHtml(r.fuente)}</strong>${r.monto ? ' <i class="fa-solid fa-arrow-right"></i> ' + fmt(r.monto) : ''}</div>`).join('')}
        </div>`);
    }

    // ── Compra de encargo pagada con TC ────────────────────────────────────
    if (rm._esTcEncargo) {
      const tc = (S.tarjetasCredito||[]).find(t=>t.id===rm._tcId);
      const tcNombre = tc ? tc.nombre : (rm._tcId || 'tarjeta desconocida');
      const montoEnc = rm.monto;         // lo que salió del encargo (= lo que se le dijo)
      const montoReal = rm._tcMonto || montoEnc;  // lo que realmente se cargó a la TC
      const hayMargen = montoEnc !== montoReal && Math.abs(montoEnc - montoReal) > 0.5;
      const destinoLabel = rm._destino ? fuenteLabel(rm._destino) : '';

      richParts.push(`
        <div class="mdet-panel-tc">
          <div class="mdet-cap-blue">Compra pagada con tarjeta de crédito</div>
          <div class="mdet-fila-wrap">
            <span class="mdet-txt">Tarjeta usada</span>
            <span class="mdet-tc-blue">${escHtml(tcNombre)}</span>
          </div>
          <div class="mdet-fila-wrap">
            <span class="mdet-txt">Salió del encargo</span>
            <span class="mdet-tc-monto mdet-c-red">− ${fmt(montoEnc)}</span>
          </div>
          <div class="mdet-fila-wrap">
            <span class="mdet-txt">Cargado a la TC</span>
            <span class="mdet-tc-monto mdet-c-blue">+ ${fmt(montoReal)}</span>
          </div>
          ${hayMargen ? `
          <div class="mdet-fila-wrap">
            <span class="mdet-tc-amber">Diferencia (tu margen)</span>
            <span class="mdet-tc-monto mdet-c-amber">+ ${fmt(montoEnc - montoReal)}</span>
          </div>` : ''}
          ${destinoLabel ? `
          <div class="mdet-fila-wrap">
            <span class="mdet-txt">Fondos reservados para pagar la TC</span>
            <span class="mdet-tc-accent">${escHtml(destinoLabel)}</span>
          </div>` : ''}
        </div>`);
    }

    // ── Vía tarjeta de crédito ──────────────────────────────────────────────
    if (rm._viaTC && rm._tcId) {
      const tcName = ((S.tarjetasCredito||[]).find(t=>t.id===rm._tcId)||{}).nombre||'';
      if (tcName) richParts.push(`
        <div class="mdet-aviso-azul">
          <div class="mdet-txt">Compra hecha con la tarjeta <strong>${escHtml(tcName)}</strong> — la deuda la tiene el deudor, no tu tarjeta.</div>
        </div>`);
    }

    // ── Vía encargo ─────────────────────────────────────────────────────────
    if (rm._viaEncargo && rm._encNombre) {
      richParts.push(`
        <div class="mdet-aviso-azul">
          <div class="mdet-txt">Este pago salió del encargo de <strong>${escHtml(rm._encNombre)}</strong>, no de tu bolsillo directamente.</div>
        </div>`);
    }

    // Ingreso ya registrado: se puede marcar (o desmarcar) como extraordinario (aguinaldo, venta, premio). Entonces no cuenta en el ingreso
    // típico ni en el balance recurrente. Solo entradas reales de S.movimientos (no saldos iniciales ni espejos de otros módulos).
    if (rm.id && rm.tipo === 'entrada' && (S.movimientos || []).includes(rm) && entradasIngresoReal().some(x => x.id === rm.id)) {
      richParts.push(`
        <div class="mdet-caja">
          <div class="mdet-cap-neutra">Ingreso extraordinario</div>
          <div class="mdet-txt">${rm.extraordinario ? 'Marcado como extraordinario: no cuenta en tu ingreso típico.' : 'Si no se repite (aguinaldo, venta, premio), márcalo para que no suba tu ingreso típico.'}</div>
          <button type="button" class="btn btn-ghost btn-sm" ${raw(Events.attr('core:toggleExtraordinario', rm.id))}>${rm.extraordinario ? 'Quitar la marca' : 'Marcar como extraordinario'}</button>
        </div>`);
    }

    if (richParts.length) {
      richHtml = `<div class="mdet-rich">${richParts.join('')}</div>`;
    }
  }

  document.getElementById('mvdContent').innerHTML = `
    <div class="mdet-cab">
      <div class="mdet-tipo">${escHtml(tipoLabel)}</div>
      <div class="mdet-monto-grande ${claseMonto}">${signo} ${fmt(Math.abs(monto))}</div>
      <div class="mdet-desc">${escHtml(desc)}</div>
      <div class="mdet-fecha">${escHtml(fecha)}</div>
    </div>
    ${origenHtml}
    <div class="mdet-caja-saldo">
      <div class="mdet-cap-saldo">${(cuentaKey==='deudor'||cuentaKey==='tc'||cuentaKey==='encargo') ? escHtml(saldoLabel) : 'Saldo en ' + escHtml(saldoLabel)}</div>
      <div class="mdet-saldo-fila">
        <div>
          <div class="mdet-etq-saldo">Antes</div>
          <div class="mdet-saldo-antes">${fmt(saldoAntes)}</div>
        </div>
        <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2" stroke-linecap="round" class="mdet-no-shrink"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        <div class="mdet-derecha">
          <div class="mdet-etq-saldo">Después</div>
          <div class="mdet-saldo-desp ${claseMonto}">${fmt(saldoDespues)}</div>
        </div>
      </div>
    </div>
    ${otrasHtml}
    ${richHtml}`;
  openSheet('mov-detalle');
}


// Motor de filtros de movimientos (renderMovsCuenta y compañía) migrado a js/modules/cuentas.js.

/* ---- ELIMINAR MOVIMIENTO (con reversión bidireccional) ---- */
// Cantidad de movimientos manuales (S.movimientos: salida_manual/ingreso/
// apertura/entrada) o transferencias (S.transferencias) posteriores que
// tocaron la misma cuenta — criterio de "operaciones posteriores" de la
// protección por antigüedad (ver js/core/dialogos.js#nivelAntiguedadMovimiento y
// docs/proteccion-antiguedad-movimientos.md §4). No cuenta movimientos de
// módulos con su propio historial (Mesada, Spotify, etc.) ni de Alcancía/
// CDT/Plata Comprometida, que llevan su propio registro aparte.
function _cuentaOpsPosteriores(cuenta, fecha, excludeId) {
  if (!cuenta || !fecha) return 0;
  let count = 0;
  (S.movimientos || []).forEach(m => {
    if (m.id === excludeId || !m.fecha || m.fecha <= fecha) return;
    if (m.fuente === cuenta) count++;
  });
  (S.transferencias || []).forEach(t => {
    if (t.id === excludeId || !t.fecha || t.fecha <= fecha) return;
    if (t.origen === cuenta || t.destino === cuenta) count++;
  });
  return count;
}

// ¿Existe todavía el registro que borra eliminarMovimiento()? true / false, o null si el tipo no se puede comprobar aquí.
function _movExiste(tipo, id) {
  switch (tipo) {
    case 'transferencia': return (S.transferencias || []).some(t => t.id === id);
    case 'salida_manual': case 'ingreso': case 'apertura': case 'entrada':
      return (S.movimientos || []).some(m => m.id === id);
    case 'gasto': return (S.gastosVar || []).some(g => g.id === id);
    default: return null;
  }
}

// Movimientos que se están eliminando ahora mismo: un segundo disparo del mismo clic (o un doble clic) no abre otro diálogo ni
// revierte otra vez. Se libera siempre al terminar, cancele o no el usuario.
const _movEliminando = new Set();
async function eliminarMovimiento(btn) {
  const item = btn && btn.closest && btn.closest('.gasto-item');
  const id = item && item.dataset && item.dataset.movId;
  if (!id) return;
  if (_movEliminando.has(id)) return;
  _movEliminando.add(id);
  try { await _eliminarMovimientoImpl(btn); }
  finally { _movEliminando.delete(id); }
}

async function _eliminarMovimientoImpl(btn) {
  const item = btn.closest('.gasto-item');
  if (!item) return;
  const movId = item.dataset.movId;
  const movTipoEl = item.dataset.movTipo;
  const fuenteOrigen = item.dataset.movFuente;
  const fuenteDestino = item.dataset.movDestino;
  const monto = parseFloat(item.dataset.movMonto) || 0;
  const fechaItem = item.dataset.movFecha || '';

  // Bloquear si es un movimiento secundario (generado automáticamente por otra sección)
  const movObj = (S.movimientos || []).find(x => x.id === movId)
    || (() => { for (const enc of (S.encargos||[])) { const m=(enc.movimientos||[]).find(x=>x.id===movId); if(m) return m; } return null; })()
    || (() => { for (const d of Deudas.lista('favor')) { const m=(d.movimientos||[]).find(x=>x.id===movId); if(m) return m; } return null; })()
    || (S.gastosVar || []).find(x => x.id === movId)
    || (S.spotify.historial || []).find(x => x.id === movId)
    || (() => { for (const h of (S.spotify.historial||[])) { const ab=(h.pendienteHistorial||[]).find(x=>x.id===movId); if(ab) return ab; } return null; })();
  if (movObj && movObj._secundario) {
    const seccion = movObj._origenSeccion || 'la sección de origen';
    await avisarNoSePuede('Movimiento vinculado', `Este movimiento fue generado automáticamente desde ${seccion}. Para eliminarlo, ve a ${seccion} y borra el movimiento principal — eso revertirá todo.`);
    return;
  }

  // Préstamo dado / abono recibido (S.deudores[].movimientos): no se revierte acá.
  // Antes este archivo tenía su propia copia de la reversión (solo `fuente` simple
  // y `destino` simple) que no sabía deshacer préstamos con fuentes divididas
  // (`fuentes`), vía TC (`_viaTC`), abonos con `destinos`/encargo/Alcancía, ni
  // reevaluar los grupos de préstamo — y la protección por antigüedad de esa copia
  // llamaba funciones de prestado.js (grupo lazy) sin guard. Se delega en
  // eliminarMovDeudor(), que trae todo eso; { desdeFeed: true } evita que navegue
  // al detalle del deudor (el usuario se queda en la cuenta desde donde borró).
  if (movTipoEl === 'prestamo' || movTipoEl === 'abono') {
    const deudorDueno = Deudas.lista('favor').find(d => (d.movimientos || []).some(x => x.id === movId));
    if (!deudorDueno) {
      toast('No se encontró este movimiento en Préstamos — puede que ya se haya eliminado', 'err', 4000);
      return;
    }
    if (typeof eliminarMovDeudor !== 'function') {
      try { await Loader.ensure('prestamos'); }
      catch (err) { toast('No se pudo cargar Préstamos. Intenta de nuevo.', 'err', 4000); return; }
    }
    await eliminarMovDeudor(deudorDueno.id, movId, { desdeFeed: true });
    _rerenderCuentaActiva();
    return;
  }

  // Protección por antigüedad — ver docs/proteccion-antiguedad-movimientos.md.
  // Resuelto ANTES de la confirmación genérica de abajo porque el nivel
  // 'viejo'/'bloqueado' usa su propio diálogo en vez del genérico. Cubre
  // todos los tipos que maneja esta función: 'mesada', 'prestamo'/'abono' y
  // TC (dentro de 'gasto') tienen además su propio punto de entrada en su
  // módulo (mesada.js, prestado.js, tarjetas_credito.js respectivamente, que
  // aplican la misma protección por su cuenta); 'transferencia',
  // 'salida_manual', 'ingreso'/'apertura'/'entrada' y el 'gasto' genérico
  // (no-TC) solo se pueden borrar desde acá, así que es su único punto de
  // entrada.
  // Cada tipo declara su protección con Reversibles.registrar() (más abajo en este archivo y en gastos.js).
  let ref = null;
  if (movTipoEl === 'mesada') {
    ['papa', 'mama'].forEach(parent => {
      const data = getMesadaData(parent);
      Object.keys(data).forEach(k => { if (data[k] && data[k]._id === movId) ref = { parent, key: k, info: data[k] }; });
    });
  } else if (movTipoEl === 'gasto') ref = (S.gastosVar || []).find(x => x.id === movId);
  else if (movTipoEl === 'transferencia') ref = (S.transferencias || []).find(t => t.id === movId);
  else if (movTipoEl === 'salida_manual') ref = (S.movimientos || []).find(x => x.id === movId);
  else if (movTipoEl === 'ingreso' || movTipoEl === 'apertura' || movTipoEl === 'entrada') {
    const m = (S.movimientos || []).find(x => x.id === movId);
    ref = { m, fuente: (m && m.fuente) || fuenteOrigen, fecha: (m && m.fecha) || fechaItem, monto: m ? m.monto : monto };
  }
  const prot = await Reversibles.proteger(movTipoEl, ref, { fechaItem });
  if (!prot.ok) return;
  let confirmado = prot.confirmado;

  // Confirmación
  // Seguridad: si el movimiento ya no existe (otro clic, otra pestaña, otro dispositivo) no se pregunta ni se revierte nada:
  // revertir dos veces el mismo movimiento duplica la plata.
  if (_movExiste(movTipoEl, movId) === false) {
    toast('Este movimiento ya se eliminó', 'info', 3000);
    _rerenderCuentaActiva();
    return;
  }
  if (!confirmado) {
    const ok = await confirmarEliminar({ titulo: 'Eliminar movimiento', objeto: 'este movimiento', detalle: 'Se revertirá el efecto en los saldos de todas las cuentas involucradas.', irreversible: false });
    if (!ok) return;
  }
  if (_movExiste(movTipoEl, movId) === false) { _rerenderCuentaActiva(); return; }

  // Lo que cambie el patrimonio al revertir se quita también de las instantáneas del historial (el núcleo).
  const _histAntes = medirPatrimonioParaHistorial();
  const _histItem = movObj || (S.transferencias || []).find(t => t.id === movId) || { id: movId, fecha: fechaItem };
  let _histApertura = null;

  // Revertir según el tipo
  if (movTipoEl === 'transferencia') {
    // Una transferencia afecta dos cuentas: origen pierde, destino gana.
    // Para revertir: origen recupera, destino pierde.
    const tr = (S.transferencias || []).find(t => t.id === movId);
    if (tr) {
      // Se revierte con la misma regla única (los dos lados o ninguno). sinSaldo: revertir nunca se bloquea por saldo, y
      // permitirArchivada: una cuenta archivada igual debe poder deshacer su historial.
      const rev = Plata.transferir(tr.destino, tr.origen, tr.monto, { og: _ogMov(movId, true), sinSaldo: true, permitirArchivada: true });
      if (!rev.ok) { toast('No se pudo revertir la transferencia: ' + rev.motivo, 'err', 4500); _rerenderCuentaActiva(); return; }
      S.transferencias = S.transferencias.filter(t => t.id !== movId);
    }
  } else if (movTipoEl === 'salida_manual') {
    // Fue una salida manual (S.movimientos tipo 'salida_manual')
    const m = (S.movimientos || []).find(x => x.id === movId);
    if (m) {
      sumarFuente(m.fuente, m.monto, _ogMov(movId, true));
      S.movimientos = S.movimientos.filter(x => x.id !== movId);
    }
  } else if (movTipoEl === 'ingreso' || movTipoEl === 'apertura' || movTipoEl === 'entrada') {
    // Fue una entrada manual (S.movimientos tipo 'entrada' o 'apertura'; 'ingreso' es como la vista de Cuentas rotula una entrada)
    const m = (S.movimientos || []).find(x => x.id === movId);
    if (m) {
      const fuente = m.fuente || fuenteOrigen;
      if (fuente) descontarFuente(fuente, m.monto, _ogMov(movId, true));
      else if (monto > 0 && fuenteOrigen) descontarFuente(fuenteOrigen, monto, _ogMov(movId, true));
      if (m.tipo === 'apertura') _histApertura = m;
      S.movimientos = S.movimientos.filter(x => x.id !== movId);
    }
  } else if (movTipoEl === 'gasto') {
    // Gasto variable (S.gastosVar)
    const g = (S.gastosVar || []).find(x => x.id === movId);
    if (g) {
      if (g._esCompraTC && g._tcId) {
        // Compra de TC: marcar como eliminada en tc.compras (nunca se borra
        // físicamente) y recalcular la deuda — NO usar sumarFuente aquí.
        // FIX: tcEliminarCompraInterna es una mutación real (revierte deuda),
        // no un render — si tarjetas_credito.js no está cargado, hay que
        // esperarlo (Loader.ensure) y abortar todo el borrado si falla, en
        // vez de borrar el gasto y dejar la tarjeta con la deuda vieja.
        if (typeof tcEliminarCompraInterna!=='function') {
          try { await Loader.ensure('tarjetas'); }
          catch(err) { toast('No se pudo cargar Tarjetas de Crédito. Intenta de nuevo.', 'err', 4000); return; }
        }
        const tc = (S.tarjetasCredito || []).find(x => x.id === g._tcId);
        if (tc && g._tcCompraId) tcEliminarCompraInterna(tc, g._tcCompraId);
      } else if (g._esPagoTC && g._tcId) {
        // Pago de TC: restaurar la deuda en la tarjeta Y devolver la plata a
        // la cuenta origen (antes solo se hacía lo segundo — la deuda de la
        // TC quedaba mal para siempre).
        if (typeof tcEliminarPagoInterna!=='function') {
          try { await Loader.ensure('tarjetas'); }
          catch(err) { toast('No se pudo cargar Tarjetas de Crédito. Intenta de nuevo.', 'err', 4000); return; }
        }
        const tc = (S.tarjetasCredito || []).find(x => x.id === g._tcId);
        if (tc && g._tcPagoId) tcEliminarPagoInterna(tc, g._tcPagoId);
        if (g.fuente) sumarFuente(g.fuente, g.monto, _ogMov(movId, true));
      } else if (g.fuente) {
        sumarFuente(g.fuente, g.monto, _ogMov(movId, true)); // devolver el dinero
      } else if (g.splits && g.splits.length) {
        // Gasto dividido entre varias cuentas (`fuente` vacío): se devuelve cada parte a su cuenta, igual que deleteGastoVar() en
        // gastos.js. Antes esta rama no las devolvía y la plata se perdía al borrar desde la cuenta o desde el feed.
        g.splits.forEach(sp => { if (sp.fuente) sumarFuente(sp.fuente, sp.monto || 0, _ogMov(movId, true)); });
      }
      // Bug fix: si era pago de gasto fijo, desmarcar como pagado
      if(g.esPagoGastoFijo && g.gastoFijoId){
        const mes = mesKey(g.fecha);
        if(S.pagosGastosFijos) delete S.pagosGastosFijos[g.gastoFijoId+'_'+mes];
      }
      S.gastosVar = S.gastosVar.filter(x => x.id !== movId);
    }
  } else if (movTipoEl === 'mesada') {
    // Mesada
    // FIX: getMesadaData es una mutación real (encuentra y borra el registro
    // original + revierte la plata al destino) — mesada.js ya es un grupo
    // lazy real, así que esto rompía HOY (no solo en un escenario futuro) si
    // se eliminaba un movimiento de mesada desde el feed general sin haber
    // visitado antes la pantalla Mesada.
    if (typeof getMesadaData!=='function') {
      try { await Loader.ensure('mesada'); }
      catch(err) { toast('No se pudo cargar Mesada. Intenta de nuevo.', 'err', 4000); return; }
    }
    let found = false;
    ['papa', 'mama'].forEach(parent => {
      const data = getMesadaData(parent);
      Object.keys(data).forEach(k => {
        const info = data[k];
        if (info && info._id === movId) {
          // Revertir destino(s)
          if (info.splits && info.splits.length) {
            info.splits.forEach(s => { if (s.fuente) descontarFuente(s.fuente, s.monto, _ogMov(movId, true)); });
          } else if (info.destino) {
            descontarFuente(info.destino, info.monto, _ogMov(movId, true));
          }
          delete data[k];
          found = true;
        }
      });
    });
  }

  if (_histApertura) purgarAperturaDelHistorial(_histApertura);
  else purgarEfectoEnHistorial(_histAntes, _histItem);
  save(); refresh();
  _rerenderCuentaActiva();
  toast('Movimiento eliminado y saldos revertidos', 'ok');
}

// Vuelve a pintar la cuenta que está abierta (saldo + movimientos) después de
// borrar un movimiento. Compartido por el final de eliminarMovimiento() y por la
// delegación en eliminarMovDeudor() (préstamo/abono).
function _rerenderCuentaActiva() {
  // cuentaActual vive en cuentas.js (grupo lazy): guard typeof, igual que refresh() en
  // el núcleo. Vale para cualquier cuenta abierta ('cuenta:ID').
  if (typeof renderDetalleCuenta !== 'function') return;
  if (typeof cuentaActual !== 'undefined' && cuentaActual) renderDetalleCuenta(cuentaActual);
}

// Registro bajo el namespace 'core' — ver nota de cabecera de este archivo.
Events.on('core:abrirDetalleMov', abrirDetalleMov);
Events.on('core:eliminarMovimiento', eliminarMovimiento);
// Marca o quita «extraordinario» en una entrada ya registrada (S.movimientos). No mueve plata: solo cambia cómo cuenta en el ingreso típico.
function toggleExtraordinario(id) {
  const m = (S.movimientos || []).find(x => x.id === id);
  if (!m || m.tipo !== 'entrada') return;
  if (m.extraordinario) delete m.extraordinario; else m.extraordinario = true;
  save(); refresh();
  closeSheet('mov-detalle');
  toast(m.extraordinario ? 'Marcado como ingreso extraordinario' : 'Ya cuenta como ingreso normal', 'ok');
}
Events.on('core:toggleExtraordinario', toggleExtraordinario);


/* ---- Reversibles: protección por antigüedad de cada tipo de movimiento (ver js/core/utilidades-ui.js) ---- */
Reversibles.registrar({ tipo: 'mesada', proteccion(t) {
  if (!t || !_mesadaTieneCuentaAfectada(t.info)) return null;
  const fuentes = _mesadaFuentesDe(t.info);
  return { fecha: t.info.fecha, ops: _mesadaOpsPosteriores(t.parent, t.key, t.info), modulo: 'mesada',
    nombre: fuentes.length > 1 ? `${fuentes.length} cuentas` : fuenteLabel(fuentes[0]), monto: t.info.monto || 0, direccion: 'baja' };
} });
Reversibles.registrar({ tipo: 'transferencia', proteccion(tr, c) {
  if (!tr) return null;
  const fecha = tr.fecha || (c && c.fechaItem);
  return { fecha, ops: Math.max(_cuentaOpsPosteriores(tr.origen, fecha, tr.id), _cuentaOpsPosteriores(tr.destino, fecha, tr.id)), modulo: 'cuentas',
    // Dos cuentas en direcciones opuestas: no encaja en el aviso estándar.
    dialogo: () => dialogo('Movimiento antiguo',
      `Esta transferencia ya tiene tiempo y puede estar mezclada con operaciones más recientes. Si la eliminas, "${fuenteLabel(tr.origen)}" recupera ${fmt(tr.monto)} y "${fuenteLabel(tr.destino)}" pierde ${fmt(tr.monto)} ahora mismo — no se recalcula el historial completo. ¿Eliminar de todas formas?`,
      'Eliminar de todas formas', true) };
} });
Reversibles.registrar({ tipo: 'salida_manual', proteccion(m, c) {
  if (!m || !m.fuente) return null;
  const fecha = m.fecha || (c && c.fechaItem);
  return { fecha, ops: _cuentaOpsPosteriores(m.fuente, fecha, m.id), modulo: 'cuentas', nombre: fuenteLabel(m.fuente), monto: m.monto || 0, direccion: 'sube' };
} });
Reversibles.registrar({ tipo: ['ingreso', 'apertura', 'entrada'], proteccion(r) {
  if (!r || !r.fuente) return null;
  return { fecha: r.fecha, ops: _cuentaOpsPosteriores(r.fuente, r.fecha, r.m ? r.m.id : null), modulo: 'cuentas', nombre: fuenteLabel(r.fuente), monto: r.monto || 0, direccion: 'baja' };
} });
Reversibles.registrar({ tipo: 'gasto', proteccion(g) {
  if (!g) return null;
  if ((g._esCompraTC || g._esPagoTC) && g._tcId) {
    const tc = (S.tarjetasCredito || []).find(x => x.id === g._tcId);
    const it = g._esCompraTC ? (tc && (tc.compras || []).find(c => c.id === g._tcCompraId)) : (tc && (tc.pagos || []).find(p => p.id === g._tcPagoId));
    if (!tc || !it) return null;
    return { fecha: it.fecha, ops: _tcOpsPosteriores(tc, it.fecha, it.id), modulo: 'tarjetas', nombre: tc.nombre, monto: it.monto || 0, direccion: g._esCompraTC ? 'baja' : 'sube', campo: 'deuda' };
  }
  if (g.fuente) return { fecha: g.fecha, ops: _cuentaOpsPosteriores(g.fuente, g.fecha, g.id), modulo: 'gastos', nombre: fuenteLabel(g.fuente), monto: g.monto || 0, direccion: 'sube' };
  // Dividido entre cuentas: g.fuente queda vacío (ver addGastoVar).
  const conFuente = (g.splits || []).filter(s => s.fuente);
  if (!conFuente.length) return null;
  return { fecha: g.fecha, ops: Math.max(...conFuente.map(s => _cuentaOpsPosteriores(s.fuente, g.fecha, g.id))), modulo: 'gastos',
    nombre: conFuente.length > 1 ? `${conFuente.length} cuentas` : fuenteLabel(conFuente[0].fuente), monto: g.monto || 0, direccion: 'sube' };
} });

Ui.hoja('registrar-movimiento', () => { poblarFuente('mov_fuente'); poblarFuente('mov_destino'); }, { key: 'movimientos-fuentes' });
