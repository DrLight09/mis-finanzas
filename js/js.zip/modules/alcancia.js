/* ═══════════════════════════════════════════════════════════════
   js/modules/alcancia.js

   Módulo Alcancía oculta — extraído de index.html (ver
   auditoria-tecnica.md, punto 3 "Arquitectura monolítica").

   Depende de `Events` (js/core/events.js) — debe cargarse en
   index.html DESPUÉS de ese script. No tuvo que partirse en dos
   archivos (a diferencia de Spotify/Encargos): su única integración
   es con las cuentas (`getSaldoFuente`, `sumarFuente`,
   `opcionesCuenta`), ya definidas más arriba en index.html
   antes de que este script se cargue — mismo caso que Mesada.

   Todas las funciones y el estado (`window.S.alcancia`) siguen
   viviendo tal cual estaban; lo único que cambia es que los onclick
   inline pasan a ser `data-action="alcancia:..."` despachados por
   Events, y el archivo deja de vivir dentro de index.html.
   ═══════════════════════════════════════════════════════════════ */
(function(){
'use strict';

/* ─── OFUSCACIÓN XOR+BASE64 ────────────────────────────────────────────────
   Clave fija. No es cifrado fuerte — solo esconde el número del JSON plano.  */
const _ALC_KEY = 0x4D;
// Ícono (SVG inline) que reemplaza al texto "••••" cuando el monto de un depósito está oculto.
const _ALC_ICONO_OCULTO = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="6" viewBox="0 0 32 6" fill="currentColor" role="img" aria-label="Monto oculto" class="alc-svg-block"><circle cx="2" cy="3" r="2"/><circle cx="11.3333" cy="3" r="2"/><circle cx="20.6667" cy="3" r="2"/><circle cx="30" cy="3" r="2"/></svg>';
// ── Libro (js/core/cuentas-fuentes.js) ─────────────────────────────────────────────────────────────────────────────────
// _ogAlc(ref, rev): cada sumar/descontarFuente deja en el libro { modulo:'alcancia', ref:<id del depósito> }. Con rev=true es una reversión (tipo 'reversion', mismo ref que lo que deshace).
const _ogAlc = Libro.origen('alcancia');

function _alcEncode(saldo){
  const raw = JSON.stringify({s: saldo});
  const bytes = new TextEncoder().encode(raw);
  const xored = bytes.map(b => b ^ _ALC_KEY);
  return btoa(String.fromCharCode(...xored));
}
function _alcDecode(str){
  try {
    const xored = Uint8Array.from(atob(str), c => c.charCodeAt(0));
    const raw = new TextDecoder().decode(xored.map(b => b ^ _ALC_KEY));
    return JSON.parse(raw).s || 0;
  } catch(e){ return 0; }
}

/* ─── ESTADO INTERNO ────────────────────────────────────────────────────── */
function _getA(){ return window.S.alcancia || null; }
function _initA(){
  if(!window.S.alcancia){
    window.S.alcancia = {
      saldoRegistrado: 0,
      depositos: 0,
      fechaInicio: hoy(),
      movimientos: [],
      historial: []
    };
  }
}
function _saldoRegistrado(){
  const a = _getA(); if(!a) return 0;
  return a.saldoRegistrado || 0;
}
function _setSaldoOfuscado(saldo){
  window.S.alcanciaSaldoOfuscado = _alcEncode(saldo);
}
function _getSaldoOfuscado(){
  const str = window.S.alcanciaSaldoOfuscado;
  if(!str) return _saldoRegistrado();
  return _alcDecode(str);
}

/* ─── TIEMPO ────────────────────────────────────────────────────────────── */
function _diasDesde(fechaStr){
  if(!fechaStr) return 0;
  return Math.max(0, Fecha.diasEntre(fechaStr, hoy()));   // días de calendario (un solo criterio: Fecha.diasEntre)
}
function _fmtTiempo(dias){
  if(dias === 0) return 'Hoy';
  if(dias < 7) return dias + (dias===1?' día':' días');
  if(dias < 30){ const s=Math.round(dias/7); return s+(s===1?' semana':' semanas'); }
  const m=Math.round(dias/30); return m+(m===1?' mes':' meses');
}

/* ─── DESGLOSE DE ORIGEN ─────────────────────────────────────────────────── */
/**
 * Genera el HTML del desglose de origen de los depósitos de una alcancía.
 * @param {Array} movimientos  - Array de movimientos de la alcancía
 * @param {Function} fmtFn     - Función de formateo de moneda
 * @returns {string} HTML del desglose (vacío si no hay movimientos)
 */
function _alcDesgloseHtml(movimientos, fmtFn){
  if(!movimientos || !movimientos.length) return '';
  const f = typeof fmtFn === 'function' ? fmtFn : fmt;

  // Acumular por categoría
  let yo      = 0; // yo-directo + yo-cuenta + tu parte del split + cobro-deuda (es plata tuya)
  let mandado = 0; // tipo === 'mandado'
  let mama    = 0; // regalo de mamá (tipo === 'regalo') + parte de mamá en splits

  movimientos.forEach(m => {
    const tipo = m.tipo || '';
    const monto = m.monto || 0;
    if(tipo === 'yo-directo' || tipo === 'yo-cuenta' || tipo === 'cobro-deuda'){
      yo += monto;
    } else if(tipo === 'mandado'){
      mandado += monto;
    } else if(tipo === 'regalo'){
      mama += monto;
    } else if(tipo === 'multi'){
      (m.partes || []).forEach(pt => {
        if(pt.origen === 'regalo') mama += pt.monto || 0;
        else if(pt.origen === 'mandado') mandado += pt.monto || 0;
        else yo += pt.monto || 0; // cuenta / propio
      });
    }
  });

  // Construir filas sólo con montos > 0
  const iconYo      = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v2m0 8v2M9.5 9.5a2.5 2.5 0 0 1 5 0c0 1.5-2.5 2-2.5 3.5m0 1h.01"/></svg>';
  const iconMandado = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><path d="M10 18H6.5M14 18h3.5M4 10h12l2 5H2l2-5z"/><path d="M10 10V7l4-2"/></svg>';
  const iconMama    = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--purple)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12v10H4V12"/><path d="M22 7H2v5h20V7z"/><path d="M12 22V7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>';

  const filas = [];
  if(yo > 0)      filas.push({ icon: iconYo,      label: 'Ahorrado con mi propio dinero',      monto: yo      });
  if(mandado > 0) filas.push({ icon: iconMandado,  label: 'Mamá me pagó por hacer un mandado', monto: mandado });
  if(mama > 0)    filas.push({ icon: iconMama,     label: 'Me regaló mamá',                    monto: mama    });

  if(!filas.length) return '';

  const filasHtml = filas.map(row => `
    <div class="row alc-desglose-fila">
      <span class="alc-desglose-ico">${row.icon}</span>
      <span class="alc-desglose-label">${row.label}</span>
      <span class="alc-desglose-monto">${f(row.monto)}</span>
    </div>`).join('');

  return `
  <div class="card card-sm alc-aviso-card">
    <div class="alc-aviso-cap"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg> Origen del dinero acumulado</div>
    ${filasHtml}
  </div>`;
}

/* ─── ORÍGENES DEL DEPÓSITO ──────────────────────────────────────────────
   Antes había un selector de "tipo" (yo-directo / yo-cuenta / regalo / mandado /
   split / cobro-deuda). Ahora cada depósito se arma con UNO o VARIOS orígenes:
   una cuenta real (resta saldo), o uno de tres orígenes "sin cuenta" (plata que
   nunca estuvo en ninguna cuenta → ingreso registrado, sin tocar saldos), o el
   cobro de una deuda (solo en modo de un único origen). "Dividir" reparte el
   monto entre varios orígenes con el motor genérico js/core/split.js.
   Con UN solo origen el registro guardado es idéntico al de siempre (tipo
   yo-cuenta / yo-directo / regalo / mandado / cobro-deuda); con varios se guarda
   tipo 'multi' con `partes[]`.  */
const _ALC_VALOR_DEUDA = '@deuda';
const _ALC_ORIGENES_SIN_CUENTA = {
  '@propio':  { origen: 'propio',  tipo: 'yo-directo', label: 'Plata mía (no estaba en ninguna cuenta)', corto: 'Propio',        desc: 'Depósito en alcancía', nota: 'Ingreso registrado al guardar en alcancía (dinero directo)' },
  '@regalo':  { origen: 'regalo',  tipo: 'regalo',     label: 'Regalo de mamá',                          corto: 'Regalo mamá',   desc: 'Regalo de mamá',       nota: 'Ingreso: regalo de mamá guardado en alcancía' },
  '@mandado': { origen: 'mandado', tipo: 'mandado',    label: 'Pago de mamá por un mandado',             corto: 'Mandado mamá',  desc: 'Mandado de mamá',      nota: 'Ingreso: pago de mandado guardado en alcancía' }
};
const _ALC_INFO_ORIGEN = {};
Object.keys(_ALC_ORIGENES_SIN_CUENTA).forEach(k => { _ALC_INFO_ORIGEN[_ALC_ORIGENES_SIN_CUENTA[k].origen] = _ALC_ORIGENES_SIN_CUENTA[k]; });

let _alcSplitMode = false; // true = "Dividir" activo (varios orígenes)

function _alcNombreFuente(f){
  if(!f) return '';
  if(typeof fuenteLabel === 'function'){ try { const l = fuenteLabel(f); if(l) return l; } catch(e){} }
  if(Fuente.esCajita(f)){ const c=(window.S&&window.S.cajitas||[]).find(x=>x.id===f.split(':')[1]); return c?c.nombre:'Cajita'; }
  if(esFuenteCuenta(f)){ const c=getCuentaDeFuente(f); return c?c.nombre:'Cuenta'; }
  return f;
}

// <option>s del selector de origen: cuentas con saldo + orígenes sin cuenta (+ deuda si aplica).
// `conDeuda` solo en modo de un único origen (un cobro de deuda necesita elegir persona/préstamo).
function _alcOrigenOptsHtml(selected, conDeuda){
  // Cuentas con más de $50 (preset ALCANCIA; las tarjetas no se ofrecen) + los orígenes sin cuenta como extra.
  return opcionesCuenta({
    selectedVal: selected,
    sentido: 'sale',
    preset: 'ALCANCIA',
    placeholder: 'Elige de dónde viene',
    sinOpcionesTexto: 'Elige de dónde viene',
    extra: () => {
      let extra = '<optgroup label="Sin cuenta">'
        + Object.keys(_ALC_ORIGENES_SIN_CUENTA).map(v => `<option value="${v}">${_ALC_ORIGENES_SIN_CUENTA[v].label}</option>`).join('')
        + '</optgroup>';
      if(conDeuda && Deudas.lista('favor').some(d => typeof getDeudorSaldo === 'function' && getDeudorSaldo(d) > 0.5)){
        extra += `<optgroup label="Deudas"><option value="${_ALC_VALOR_DEUDA}">Me pagaron una deuda</option></optgroup>`;
      }
      return extra;
    },
  });
}

// valor de un <select> de origen → parte { origen, monto, [fuente] }
function _alcParteDesdeValor(v, monto){
  if(v === _ALC_VALOR_DEUDA) return { origen: 'deuda', monto };
  const info = _ALC_ORIGENES_SIN_CUENTA[v];
  if(info) return { origen: info.origen, monto };
  return { origen: 'cuenta', fuente: v, monto };
}

// Muestra/oculta lo que depende del origen elegido (persona del cobro, saldo disponible, monto editable).
function _alcOrigenActualizar(){
  const sel = document.getElementById('alc_dep_origen');
  const v = sel ? sel.value : '';
  const esDeuda = !_alcSplitMode && v === _ALC_VALOR_DEUDA;
  const deudorWrap = document.getElementById('alc_dep_deudor_wrap');
  if(deudorWrap) deudorWrap.style.display = esDeuda ? '' : 'none';
  if(esDeuda) _alcDeudorSelActualizar();
  const hint = document.getElementById('alc_dep_saldo_hint');
  if(hint){
    if(!_alcSplitMode && v && v.charAt(0) !== '@'){
      const s = (typeof getSaldoFuente === 'function') ? getSaldoFuente(v) : 0;
      hint.textContent = 'Saldo disponible: ' + (typeof fmt === 'function' ? fmt(s) : s);
      hint.style.color = s > 0 ? 'var(--accent)' : 'var(--red)';
    } else {
      hint.textContent = '';
    }
  }
  // En modo dividido el total es la suma de las filas: no se edita a mano.
  const montoInput = document.getElementById('alc_dep_monto');
  if(montoInput){
    montoInput.readOnly = _alcSplitMode;
    montoInput.style.opacity = _alcSplitMode ? '0.6' : '';
  }
}

// onPreview del motor split: recalcula el total a partir de las filas.
function _alcSplitPreview(){
  _alcOrigenActualizar();
  if(!_alcSplitMode) return;
  const filas = (typeof splitGetData === 'function') ? splitGetData('alcancia') : [];
  const total = Math.round(filas.reduce((t, f) => t + f.monto, 0) * 100) / 100;
  const hint = document.getElementById('alc_split_total_hint');
  if(hint){
    hint.textContent = total > 0 ? 'Total: ' + (typeof fmt === 'function' ? fmt(total) : total) : '';
    hint.style.color = 'var(--amber)';
  }
  const montoInput = document.getElementById('alc_dep_monto');
  if(montoInput){
    setMoneyInput(montoInput, total > 0 ? total : 0, { evento: true });
  }
}

window.alcanciaToggleDividir = function(){ if(typeof splitToggle === 'function') splitToggle('alcancia'); };
window.alcanciaAgregarOrigen = function(){ if(typeof splitAgregarRow === 'function') splitAgregarRow('alcancia'); };

/* ─── COBRO DE DEUDA: selector de deudor/grupo dentro de Depositar ───────
   Espejo simplificado de _initMovGrupoSelector (prestado.js): si la
   persona elegida tiene ≥2 préstamos abiertos hay que preguntar a cuál
   corresponde el cobro (nunca se adivina); con 0 o 1 se resuelve solo.
   No hay opción de "préstamo aparte" acá — un cobro nunca abre un grupo
   nuevo, solo puede reducir uno existente. */
function _alcDeudorSelActualizar(){
  const sel = document.getElementById('alc_dep_deudor');
  const grupoWrap = document.getElementById('alc_dep_deudor_grupo_wrap');
  const grupoSel = document.getElementById('alc_dep_deudor_grupo');
  const hint = document.getElementById('alc_dep_deudor_saldo_hint');
  const deudorId = sel ? sel.value : '';
  if(!deudorId){
    if(grupoWrap) grupoWrap.style.display = 'none';
    if(hint) hint.textContent = '';
    return;
  }
  const d = Deudas.lista('favor').find(x => x.id === deudorId);
  if(!d) return;
  const abiertos = (typeof _gruposAbiertos === 'function') ? _gruposAbiertos(d) : [];
  if(abiertos.length >= 2){
    if(grupoWrap) grupoWrap.style.display = '';
    if(grupoSel){
      grupoSel.innerHTML = abiertos.map(g => `<option value="${g.id}">${escHtml(g.nombre)} (${fmt(getGrupoSaldo(d, g.id))})</option>`).join('');
      grupoSel.onchange = _alcDeudorSaldoHintActualizar;
    }
  } else if(grupoWrap){
    grupoWrap.style.display = 'none';
  }
  _alcDeudorSaldoHintActualizar();
}

function _alcDeudorSaldoHintActualizar(){
  const sel = document.getElementById('alc_dep_deudor');
  const grupoWrap = document.getElementById('alc_dep_deudor_grupo_wrap');
  const grupoSel = document.getElementById('alc_dep_deudor_grupo');
  const hint = document.getElementById('alc_dep_deudor_saldo_hint');
  const deudorId = sel ? sel.value : '';
  if(!deudorId) return;
  const d = Deudas.lista('favor').find(x => x.id === deudorId);
  if(!d) return;
  const grupoVisible = grupoWrap && grupoWrap.style.display !== 'none';
  const saldo = (grupoVisible && grupoSel && grupoSel.value) ? getGrupoSaldo(d, grupoSel.value) : getDeudorSaldo(d);
  // El hint quedaría repitiendo un monto que ya se ve en la opción elegida
  // (el select de persona siempre trae el saldo total en el texto, y el de
  // préstamo/grupo trae el saldo de ese grupo) — se deja oculto. `saldo` se
  // sigue calculando porque se usa para precargar el monto más abajo.
  // Ver reglas-visuales.md#selectores-con-saldo.
  if(hint) hint.style.display = 'none';
  // Precarga el monto con el saldo pendiente (editable — puede ser un abono parcial)
  const montoInput = document.getElementById('alc_dep_monto');
  if(montoInput && saldo > 0){
    setMoneyInput(montoInput, saldo, { evento: true });
  }
}

/* ─── INYECTAR SHEETS ───────────────────────────────────────────────────── */
function _inyectarAlcanciaSheets(){
  if(document.getElementById('sheet-alcancia-depositar')) return;

  /* ---------- SHEET: Depositar ---------- */
  const sheetDep = document.createElement('div');
  sheetDep.className = 'overlay';
  sheetDep.id = 'sheet-alcancia-depositar';
  sheetDep.setAttribute('data-sheet-id','alcancia-depositar');
  sheetDep.innerHTML = `
    <div class="sheet">
      <div class="sheet-handle"></div>
      <div class="sheet-title">Guardar en la alcancía</div>
      <div class="ig">
        <div class="alc-origen-cab">
          <label class="il alc-origen-lbl" for="alc_dep_origen">¿De dónde viene este dinero?</label>
          <button type="button" id="alc_split_toggle" ${Events.attr('alcancia:toggleDividir')} class="alc-btn-dividir">Dividir</button>
        </div>
        <div id="alc_origen_simple">
          <div class="select-wrap">
            <select id="alc_dep_origen"></select>
          </div>
          <div id="alc_dep_saldo_hint" class="alc-hint"></div>
        </div>
        <div id="alc_origen_split" style="display:none;">
          <div id="alc_split_rows"></div>
          <button type="button" ${Events.attr('alcancia:agregarOrigen')} class="btn-add-cuenta">+ Agregar otro origen</button>
          <div id="alc_split_total_hint" class="alc-split-total"></div>
        </div>
      </div>
      <div class="ig" id="alc_dep_deudor_wrap" style="display:none;">
        <label class="il" for="alc_dep_deudor">¿Quién te pagó?</label>
        <div class="select-wrap">
          <select id="alc_dep_deudor"><option value="">Seleccionar persona</option></select>
        </div>
        <div class="ig alc-mt8" id="alc_dep_deudor_grupo_wrap" style="display:none;">
          <label class="il" for="alc_dep_deudor_grupo">¿De cuál préstamo?</label>
          <div class="select-wrap"><select id="alc_dep_deudor_grupo"></select></div>
        </div>
        <div id="alc_dep_deudor_saldo_hint" class="alc-hint"></div>
      </div>
      <div class="ig">
        <label class="il" for="alc_dep_monto">Monto total</label>
        <input type="text" inputmode="decimal" class="money-input" id="alc_dep_monto" placeholder="0,00" autocomplete="off">
      </div>
      <div class="ig">
        <label class="il" for="alc_dep_fecha">Fecha</label>
        <input type="date" id="alc_dep_fecha" class="input-fecha">
      </div>
      <div class="ig">
        <label class="il" for="alc_dep_desc">Descripción <span class="alc-opcional">(opcional)</span></label>
        <input type="text" id="alc_dep_desc" placeholder="Ej: ahorro semanal, regalo, vuelto...">
      </div>
      <button type="button" class="btn btn-primary alc-btn-amber" ${Events.attr('alcancia:confirmarDeposito')}>Guardar</button>
      <button type="button" class="btn btn-ghost alc-mt6" data-close-sheet="alcancia-depositar">Cancelar</button>
    </div>`;
  document.body.appendChild(sheetDep);

  /* ---------- SHEET: Destapar paso 1 — resumen ---------- */
  const sheetD1 = document.createElement('div');
  sheetD1.className = 'overlay';
  sheetD1.id = 'sheet-alcancia-destapar';
  sheetD1.setAttribute('data-sheet-id','alcancia-destapar');
  sheetD1.innerHTML = `
    <div class="sheet">
      <div class="sheet-handle"></div>
      <div class="sheet-title">Destapar alcancía</div>
      <div id="alc-destapar-resumen" class="alc-mb18"></div>
      <div class="ig">
        <label class="il" for="alc_real_monto">¿Cuánto dinero encontraste realmente?</label>
        <input type="text" inputmode="decimal" class="money-input" id="alc_real_monto" placeholder="0,00" autocomplete="off">
        <div id="alc_diferencia_hint" class="alc-nota-mono"></div>
      </div>
      <div class="ig">
        <label class="il" for="alc_destino">¿Dónde vas a guardar este dinero?</label>
        <div class="select-wrap">
          <select id="alc_destino"></select>
        </div>
      </div>
      <button type="button" class="btn btn-primary alc-btn-amber" ${Events.attr('alcancia:confirmarDestapar')}>Confirmar y destapar</button>
      <button type="button" class="btn btn-ghost alc-mt6" data-close-sheet="alcancia-destapar">Cancelar</button>
    </div>`;
  document.body.appendChild(sheetD1);

  /* ---------- SHEET: Destapar resultado ---------- */
  const sheetRes = document.createElement('div');
  sheetRes.className = 'overlay';
  sheetRes.id = 'sheet-alcancia-resultado';
  sheetRes.setAttribute('data-sheet-id','alcancia-resultado');
  sheetRes.innerHTML = `
    <div class="sheet">
      <div class="sheet-handle"></div>
      <div class="sheet-title">Resultado</div>
      <div id="alc-resultado-body" class="alc-mb18"></div>
      <button type="button" class="btn btn-primary alc-btn-amber-mb8" ${Events.attr('alcancia:iniciarNueva')}>Iniciar nueva alcancía</button>
      <button type="button" class="btn btn-ghost" data-close-sheet="alcancia-resultado">Cerrar</button>
    </div>`;
  document.body.appendChild(sheetRes);

  /* ---------- Swipe y data-close-sheet para los nuevos sheets ---------- */
  [sheetDep, sheetD1, sheetRes].forEach(sh => {
    const panel = sh.querySelector('.sheet');
    if(panel && typeof makeSwipeable === 'function'){
      const sid = sh.getAttribute('data-sheet-id');
      makeSwipeable(panel, ()=>{ if(typeof closeSheet==='function') closeSwipeSheet(sid, sh); });
    }
    sh.querySelectorAll('[data-close-sheet]').forEach(btn => {
      const sid = btn.getAttribute('data-close-sheet');
      btn.addEventListener('click', ()=>{ if(typeof closeSheet==='function') closeSheet(sid); });
    });
    sh.addEventListener('click', e => {
      if(e.target === sh){
        const sid = sh.getAttribute('data-sheet-id');
        if(typeof closeSheet==='function') closeSheet(sid);
      }
    });
  });

  /* ---------- Motor de "Dividir" (js/core/split.js) ---------- */
  if(typeof crearSplitWidget === 'function'){
    crearSplitWidget('alcancia', {
      simpleId: 'alc_origen_simple', splitId: 'alc_origen_split', toggleId: 'alc_split_toggle', rowsId: 'alc_split_rows',
      getModo: () => _alcSplitMode,
      setModo: v => { _alcSplitMode = !!v; },
      getFuentesFn: sel => _alcOrigenOptsHtml(sel, false),   // en filas no hay "cobro de deuda"
      onPreview: _alcSplitPreview
    });
  }

  /* ---------- Selector de origen (modo un solo origen) ---------- */
  const origenSel = document.getElementById('alc_dep_origen');
  if(origenSel) origenSel.addEventListener('change', _alcOrigenActualizar);

  /* ---------- Cobro de deuda: selector de deudor ---------- */
  const deudorSel = document.getElementById('alc_dep_deudor');
  if(deudorSel){
    deudorSel.addEventListener('change', _alcDeudorSelActualizar);
  }

  /* ---------- Diferencia hint en destapar ---------- */
  const realInput = document.getElementById('alc_real_monto');
  if(realInput){
    realInput.addEventListener('input', _actualizarDiferenciaHint);
  }
}

function closeSwipeSheet(sid, el){
  if(typeof closeSheet==='function') closeSheet(sid);
}

function _getMoneyVal(id){
  const el = document.getElementById(id);
  if(!el) return 0;
  if(typeof parseMoney === 'function') return parseMoney(el.value) || 0;
  return parseFloat((el.value||'').replace(/\./g,'').replace(',','.')) || 0;
}

/* ─── "WRAPPED" DE ALCANCÍA: progreso de ahorro entre ciclos ──────────────
   Todo se calcula en vivo desde S.alcancia.historial — no se guarda ningún
   número nuevo aparte (mismo principio que el resto de la app: los
   movimientos/registros ya guardados son la única fuente de verdad, nunca
   un valor cacheado que pueda desincronizarse). Estas funciones son la
   ÚNICA fuente de esta cifra: tanto la tarjeta persistente en la pantalla
   principal como la sheet de resultado al destapar llaman a las mismas. */

/* Racha: cuántos ciclos consecututivos, contando desde el más reciente hacia
   atrás, ahorraron más que el ciclo inmediatamente anterior. 0 si el último
   ciclo ahorró igual o menos que el anterior. */
function _alcRachaAhorro(hist){
  if(!hist || hist.length < 2) return 0;
  let racha = 0;
  for(let i = hist.length - 1; i > 0; i--){
    if((hist[i].saldoRegistrado||0) > (hist[i-1].saldoRegistrado||0)) racha++;
    else break;
  }
  return racha;
}

/* Mejor ciclo histórico por saldoRegistrado (nunca por saldoReal, para no
   premiar diferencias que en realidad fueron un error de conteo). */
function _alcMejorCiclo(hist){
  if(!hist || !hist.length) return null;
  return hist.reduce((mejor, h) => (h.saldoRegistrado||0) > (mejor.saldoRegistrado||0) ? h : mejor, hist[0]);
}

// Expuestas en window (2026-09-07): el módulo Wrapped general (js/modules/
// wrapped.js) las reutiliza para no duplicar el cálculo de racha/mejor
// ciclo — misma fuente de verdad que la tarjeta de Alcancía. Con guard
// typeof en quien las llama, por si Alcancía todavía no cargó (es un grupo
// lazy independiente).
window._alcRachaAhorro = _alcRachaAhorro;
window._alcMejorCiclo = _alcMejorCiclo;

/* Mini gráfico de barras (SVG inline, sin dependencias) de los últimos hasta
   6 ciclos por saldoRegistrado. Devuelve '' si hay menos de 2 ciclos —no
   tiene sentido "comparar" con un solo punto. */
function _alcWrappedBarrasSvg(hist){
  if(!hist || hist.length < 2) return '';
  const datos = hist.slice(-6);
  const max = Math.max(...datos.map(h => h.saldoRegistrado||0), 1);
  const w = 280, h = 70, gap = 8;
  const barW = (w - gap*(datos.length-1)) / datos.length;
  const bars = datos.map((d,i) => {
    const val = d.saldoRegistrado || 0;
    const barH = Math.max(4, (val/max) * (h-10));
    const x = i * (barW + gap);
    const y = h - barH;
    const esUltimo = i === datos.length - 1;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${barH.toFixed(1)}" rx="3" fill="${esUltimo?'var(--amber)':'var(--accent)'}" opacity="${esUltimo?'1':'0.5'}"/>`;
  }).join('');
  return `<svg aria-hidden="true" viewBox="0 0 ${w} ${h}" width="100%" height="${h}" class="alc-svg-visible">${bars}</svg>`;
}

/* Arma el HTML de la tarjeta persistente de progreso (pantalla principal de
   Alcancía). '' si no hay al menos 2 ciclos destapados para comparar. */
function _alcWrappedProgresoHtml(hist, fmtFn){
  if(!hist || hist.length < 2) return '';
  const fmt2 = fmtFn || fmt;
  const racha = _alcRachaAhorro(hist);
  const mejor = _alcMejorCiclo(hist);
  const ultimo = hist[hist.length-1];
  const esMejorHastaAhora = mejor === ultimo;
  const rachaMsg = racha >= 2
    ? `🔥 Llevas ${racha} alcancías seguidas ahorrando más que la anterior`
    : (racha === 1 ? '📈 Ahorraste más que en tu alcancía anterior' : null);
  return `
    <div class="card alc-prog-card">
      <div class="alc-prog-cap">Tu progreso ahorrando</div>
      ${_alcWrappedBarrasSvg(hist)}
      <div class="alc-mt10">
        ${rachaMsg ? `<div class="alc-racha">${rachaMsg}</div>` : ''}
        <div class="alc-prog-txt">Mejor alcancía hasta ahora: <span class="alc-prog-val">${fmt2(mejor.saldoRegistrado||0)}</span>${esMejorHastaAhora ? ' <span class="alc-c-amber">(tu última)</span>' : ''}</div>
      </div>
    </div>`;
}

function _actualizarDiferenciaHint(){
  const hint = document.getElementById('alc_diferencia_hint');
  if(!hint) return;
  const real = _getMoneyVal('alc_real_monto');
  const reg  = _saldoRegistrado();
  if(!real){ hint.textContent = ''; return; }
  const dif = real - reg;
  if(Math.abs(dif) < 1){
    hint.style.color = 'var(--text3)';
    hint.textContent = 'Todo el dinero estaba registrado.';
  } else if(dif > 0){
    hint.style.color = 'var(--accent)';
    hint.textContent = '+ ' + (typeof fmt==='function'?fmt(dif):dif) + ' encontrados sin registro y se suman al patrimonio.';
  } else {
    hint.style.color = 'var(--red)';
    hint.textContent = '− ' + (typeof fmt==='function'?fmt(Math.abs(dif)):Math.abs(dif)) + ' de diferencia y se restan del patrimonio.';
  }
}

/* ─── OPEN SHEET HOOK ─── ver js/core/ui.js ───────────────────────────── */
Ui.hoja('alcancia-depositar', function(){
  {
    _inyectarAlcanciaSheets();
    setTimeout(()=>{
      const fd = document.getElementById('alc_dep_fecha');
      if(fd) fd.value = hoy();
      const mi = document.getElementById('alc_dep_monto');
      if(mi) mi.value = '';
      const desc = document.getElementById('alc_dep_desc');
      if(desc) desc.value = '';
      // Reset de orígenes: salir del modo dividido, vaciar filas y repoblar el selector
      if(_alcSplitMode && typeof splitToggle === 'function') splitToggle('alcancia');
      const splitRows = document.getElementById('alc_split_rows');
      if(splitRows) splitRows.innerHTML = '';
      const splitHint = document.getElementById('alc_split_total_hint');
      if(splitHint) splitHint.textContent = '';
      const origenSel = document.getElementById('alc_dep_origen');
      if(origenSel){ origenSel.innerHTML = _alcOrigenOptsHtml('', true); origenSel.value = ''; }
      // Cobro de deuda: poblar personas con saldo pendiente y resetear el wrap
      const deudorSelReset = document.getElementById('alc_dep_deudor');
      if(deudorSelReset){
        const deudoresConSaldo = Deudas.lista('favor')
          .filter(d => typeof getDeudorSaldo === 'function' && getDeudorSaldo(d) > 0.5);
        deudorSelReset.innerHTML = '<option value="">Seleccionar persona</option>'
          + deudoresConSaldo.map(d => `<option value="${d.id}">${escHtml(d.nombre)} (${fmt(getDeudorSaldo(d))})</option>`).join('');
      }
      const deudorGrupoWrapReset = document.getElementById('alc_dep_deudor_grupo_wrap');
      if(deudorGrupoWrapReset) deudorGrupoWrapReset.style.display = 'none';
      const deudorHintReset = document.getElementById('alc_dep_deudor_saldo_hint');
      if(deudorHintReset) deudorHintReset.textContent = '';
      _alcOrigenActualizar();
    }, 30);
  }
}, { fase: 'despues', key: 'alcancia-depositar' });
Ui.hoja('alcancia-destapar', function(){
  {
    _inyectarAlcanciaSheets();
    setTimeout(()=>{
      const mi = document.getElementById('alc_real_monto');
      if(mi) mi.value = '';
      const dest = document.getElementById('alc_destino');
      if(dest) dest.innerHTML = opcionesCuenta({placeholder:'Seleccionar cuenta'});
      const hint = document.getElementById('alc_diferencia_hint');
      if(hint) hint.textContent = '';
      // Resumen
      const a = _getA();
      const res = document.getElementById('alc-destapar-resumen');
      if(res && a){
        const dias = _diasDesde(a.fechaInicio);
        res.innerHTML = `
          <div class="card alc-act-card">
            <div class="row alc-fila-mb8">
              <span class="alc-prog-txt">Tiempo activa</span>
              <span class="alc-act-val-amber">${_fmtTiempo(dias)}</span>
            </div>
            <div class="row alc-fila-mb8">
              <span class="alc-prog-txt">Depósitos registrados</span>
              <span class="alc-act-val">${a.depositos || 0}</span>
            </div>
            <div class="row">
              <span class="alc-prog-txt">Saldo esperado (registrado)</span>
              <span class="alc-act-val-mono">${typeof fmt==='function'?fmt(a.saldoRegistrado||0):'$'+a.saldoRegistrado}</span>
            </div>
          </div>`;
      }
    }, 30);
  }
}, { fase: 'despues', key: 'alcancia-destapar' });

/* ─── RENDER PANTALLA ───────────────────────────────────────────────────── */
window.renderAlcancia = function(){
  const a = _getA();
  // Una alcancía destapada pero no reiniciada se trata como "no activa"
  // para que la pantalla principal no muestre una alcancía fantasma vacía.
  const activa = !!(a && !a._destapada && (a.fechaInicio || a.depositos > 0 || a.saldoRegistrado > 0));

  const elNoIniciada = document.getElementById('alcancia-no-iniciada');
  const elActiva     = document.getElementById('alcancia-activa');
  if(elNoIniciada) elNoIniciada.style.display = activa ? 'none' : '';
  if(elActiva)     elActiva.style.display     = activa ? '' : 'none';

  const heroSaldo = document.getElementById('alcancia-hero-saldo');
  if(heroSaldo){
    heroSaldo.textContent = activa ? '$??' : '$0';
    heroSaldo.style.filter = activa ? 'blur(8px)' : 'none';
  }
  const heroSub = document.getElementById('alcancia-hero-sub');
  if(heroSub){
    if(!activa) heroSub.textContent = 'Sin alcancía activa';
    else {
      const dias = _diasDesde(a.fechaInicio);
      heroSub.textContent = 'Activa hace ' + _fmtTiempo(dias);
    }
  }

  if(activa && a){
    const statDep = document.getElementById('alcancia-stat-depositos');
    const statTiempo = document.getElementById('alcancia-stat-tiempo');
    if(statDep) statDep.textContent = a.depositos || 0;
    if(statTiempo) statTiempo.textContent = _fmtTiempo(_diasDesde(a.fechaInicio));

    // ── Movimientos: se ven dentro de Alcancía (detalle por depósito), pero
    // el TOTAL acumulado sigue oculto (heroSaldo con blur) — eso es lo único
    // que debe seguir siendo sorpresa. Sin esta lista no hay forma de
    // corregir un depósito mal anotado, porque cuentas.js también los
    // esconde mientras la alcancía sigue activa.
    const movsTitulo = document.getElementById('alcancia-movs-titulo');
    const movsEl = document.getElementById('alcancia-movimientos-lista');
    if(movsTitulo) movsTitulo.style.display = '';
    if(movsEl){
      movsEl.style.display = '';
      const movs = (a.movimientos || []);
      if(!movs.length){
        movsEl.innerHTML = emptyInline('Aún no hay movimientos en esta alcancía.',{grande:true});
      } else {
        const tipoIcon = { yo: '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><ellipse cx="12" cy="17" rx="8" ry="5"/><path d="M4 17v-4c0-2.76 3.58-5 8-5s8 2.24 8 5v4"/><path d="M4 13c0-2.76 3.58-5 8-5s8 2.24 8 5"/></svg>', regalo: '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>', mandado: '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>', split: '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><path d="M17 11H9l-2-2H3v8h4l2 2h8l4-4v-4h-4z"/><path d="M9 11V7l4-4 4 4v4"/></svg>', 'cobro-deuda': '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><circle cx="12" cy="12" r="10"/><polyline points="8 12 12 16 16 12"/><line x1="12" y1="8" x2="12" y2="16"/></svg>' };
        const tipoColor = { yo: 'alc-c-accent', regalo: 'alc-c-amber', mandado: 'alc-c-amber', split: 'alc-c-amber', 'cobro-deuda': 'alc-c-accent' };
        // Orden por FECHA del depósito (más reciente arriba); si dos tienen la misma fecha, gana el que se
        // registró después (ts). Antes se usaba el orden de registro, así que un depósito olvidado y anotado
        // con fecha pasada quedaba arriba de otros más nuevos.
        const movsOrdenados = [...movs].sort((x, y) => {
          const fx = x.fecha || '', fy = y.fecha || '';
          if(fx !== fy) return fy.localeCompare(fx);
          return (y.ts || 0) - (x.ts || 0);
        });
        movsEl.innerHTML = movsOrdenados.map(m => {
          const icon  = tipoIcon[m.tipo]  || '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alc-ico-v"><ellipse cx="12" cy="17" rx="8" ry="5"/><path d="M4 17v-4c0-2.76 3.58-5 8-5s8 2.24 8 5v4"/><path d="M4 13c0-2.76 3.58-5 8-5s8 2.24 8 5"/></svg>';
          const color = tipoColor[m.tipo] || 'alc-c-accent';
          const label = m.tipoLabel || (m.fuenteOrigen ? 'Propio' : 'Externo');
          const fmtFuente = m.fuenteOrigen
            ? _alcNombreFuente(m.fuenteOrigen) // misma resolución de nombre que el resto del módulo
            : (m.tipo === 'cobro-deuda' && m._prestamoDeudorId
                ? (() => { const dd=Deudas.lista('favor').find(x=>x.id===m._prestamoDeudorId); return dd?dd.nombre:null; })()
                : null);
          return `
          <div class="card card-sm alc-mov-card">
            <div class="alc-mov-ico">${icon}</div>
            <div class="alc-mov-cuerpo">
              <div class="alc-mov-desc">${escHtml(m.desc || 'Depósito')}</div>
              <div class="alc-mov-fecha">${m.fecha}${fmtFuente ? ' · de ' + fmtFuente : ''}</div>
              <div class="alc-mov-tipo ${color}">${label}</div>
            </div>
            <span class="alc-dep-monto alc-mov-monto" data-shown="0" data-mov-id="${m.id}" ${Events.attr('alcancia:toggleMontoDeposito', m.id)} title="Toca para ver el monto">${_ALC_ICONO_OCULTO}</span>
            <button type="button" class="btn-delete-hover alc-no-shrink" data-stop-propagation="true" ${Events.attr('alcancia:eliminarDeposito', m.id)} title="Eliminar este depósito">
              <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
            </button>
          </div>`;
        }).join('');
      }
    }
  }

  // ── Historial de alcancías destapadas (siempre visible, haya o no alcancía activa)
  if(a){
    const listaEl  = document.getElementById('alcancia-historial-lista');
    const tituloEl = document.getElementById('alcancia-historial-titulo');

    // "Wrapped" de progreso: se recalcula en cada render desde a.historial,
    // así que se actualiza solo apenas se destapa una alcancía nueva —
    // ninguna cifra propia que persistir ni sincronizar aparte.
    const wrapEl = document.getElementById('alcancia-wrapped-progreso');
    if(wrapEl){
      const html = _alcWrappedProgresoHtml(a.historial || []);
      wrapEl.style.display = html ? '' : 'none';
      wrapEl.innerHTML = html;
    }

    if(listaEl){
      const hist = a.historial || [];
      // Sin alcancías destapadas no hay historial que mostrar: ni título ni mensaje
      // (el estado vacío o la alcancía activa ya dicen en qué punto está la persona).
      if(tituloEl) tituloEl.style.display = hist.length ? '' : 'none';
      listaEl.style.display = hist.length ? '' : 'none';
      if(!hist.length){
        listaEl.innerHTML = '';
      } else {
        listaEl.innerHTML = [...hist].reverse().map((h,i) => {
          const dif = (h.saldoReal||0) - (h.saldoRegistrado||0);
          const difFmt = Math.abs(dif) < 1 ? 'Exacto'
            : dif > 0 ? '+' + (typeof fmt==='function'?fmt(dif):dif)
            : '−' + (typeof fmt==='function'?fmt(Math.abs(dif)):Math.abs(dif));
          const difColor = Math.abs(dif) < 1 ? 'alc-c-text3' : dif > 0 ? 'alc-c-accent' : 'alc-c-red';
          const histIdx = hist.length - i; // número de alcancía (1-based, más reciente = mayor)
          const desgloseId = 'alc-hist-desglose-' + histIdx;
          const desgloseHtml = _alcDesgloseHtml(h.movimientos || [], fmt);
          return `
          <div class="card card-sm alc-fila-mb8">
            <div class="row alc-fila-mb6">
              <span class="alc-hist-tit">Alcancía #${histIdx}</span>
              <span class="alc-mov-fecha">${h.fechaInicio||''} <i class="fa-solid fa-arrow-right"></i> ${h.fechaFin||''}</span>
            </div>
            <div class="row alc-fila-mb4">
              <span class="alc-mov-fecha">Duración</span>
              <span class="alc-hist-dur">${_fmtTiempo(h.diasDuracion||0)}</span>
            </div>
            <div class="row alc-fila-mb4">
              <span class="alc-mov-fecha">Depósitos</span>
              <span class="alc-hist-dur">${h.depositos||0}</span>
            </div>
            <div class="row alc-fila-mb4">
              <span class="alc-mov-fecha">Registrado</span>
              <span class="alc-hist-saldo-amber">${typeof fmt==='function'?fmt(h.saldoRegistrado||0):'$'+h.saldoRegistrado}</span>
            </div>
            <div class="row alc-fila-mb4">
              <span class="alc-mov-fecha">Real encontrado</span>
              <span class="alc-hist-saldo">${typeof fmt==='function'?fmt(h.saldoReal||0):'$'+h.saldoReal}</span>
            </div>
            <div class="row">
              <span class="alc-mov-fecha">Diferencia</span>
              <span class="alc-hist-dif ${difColor}">${difFmt}</span>
            </div>
            ${desgloseHtml ? `
            <div class="alc-hist-desg-box">
              <button type="button" ${Events.attr('alcancia:toggleDesglose', desgloseId)} class="alc-hist-btn">
                <span class="alc-hist-btn-txt"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg> Ver origen del dinero</span>
                <svg aria-hidden="true" class="alc-hist-chevron alc-hist-chev" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div id="${desgloseId}" class="alc-mt4" style="display:none;">${desgloseHtml}</div>
            </div>` : ''}
          </div>`;
        }).join('');
      }
    }
  }
};

/* ─── ACCIONES ──────────────────────────────────────────────────────────── */

/* Iniciar nueva alcancía (o reiniciar tras destapar) */
window.alcanciaIniciarNueva = function(){
  _initA();
  const a = window.S.alcancia;
  a.saldoRegistrado = 0;
  a.depositos = 0;
  a.fechaInicio = hoy();
  a.movimientos = [];
  if(!a.historial) a.historial = [];
  delete a._destapada;
  _setSaldoOfuscado(0);
  if(typeof save==='function') save();
  if(typeof closeSheet==='function') closeSheet('alcancia-resultado');
  window.renderAlcancia();
  if(typeof showScreen==='function') showScreen('alcancia');
  if(typeof toast==='function') toast('Alcancía iniciada', 'ok');
};

/* Confirmar depósito
   Un depósito = uno o varios ORÍGENES (ver "ORÍGENES DEL DEPÓSITO" arriba).
   Por cada origen se crea su movimiento espejo:
     · cuenta          → gasto interno en S.gastosVar (_esAlcancia) + resta saldo real
     · propio/regalo/mandado → ingreso en S.movimientos (_esAlcanciaIngreso). NO toca ningún
                         saldo: es plata que nunca estuvo en una cuenta. (Antes se sumaba y
                         restaba el mismo monto a Efectivo para "cancelarlo".)
     · deuda           → abono en el deudor (solo con un único origen)
   Un único origen guarda el mismo registro de siempre (tipo yo-cuenta/yo-directo/...);
   varios orígenes guardan tipo 'multi' con partes[]. */
window.alcanciaConfirmarDeposito = function(){
  const fecha  = (document.getElementById('alc_dep_fecha')||{}).value  || (typeof hoy==='function'?hoy():'');
  const descEl = document.getElementById('alc_dep_desc');
  const descVal = (descEl ? descEl.value.trim() : '') || '';
  const err = m => { if(typeof toast==='function') toast(m, 'err'); };

  /* ── 1. Armar las partes ── */
  let partes = [];
  if(_alcSplitMode){
    const filas = (typeof splitGetData === 'function') ? splitGetData('alcancia') : [];
    if(!filas.length){ err('Ingresa cuánto viene de cada origen'); return; }
    if(filas.some(f => !f.fuente)){ err('Elige el origen de cada monto'); return; }
    partes = filas.map(f => _alcParteDesdeValor(f.fuente, f.monto));
  } else {
    const v = (document.getElementById('alc_dep_origen')||{}).value || '';
    if(!v){ err('Elige de dónde viene el dinero'); return; }
    const m = _getMoneyVal('alc_dep_monto');
    if(!m || m <= 0){ err('Ingresa un monto válido'); return; }
    partes = [_alcParteDesdeValor(v, m)];
  }
  const monto = Math.round(partes.reduce((t, p) => t + p.monto, 0) * 100) / 100;
  if(!(monto > 0)){ err('Ingresa un monto válido'); return; }
  const unica = partes.length === 1;

  /* ── 2. Validar ── */
  const vSal = Plata.validarSalidas(partes.filter(p => p.origen === 'cuenta')); // suma por cuenta (núcleo)
  if(!vSal.ok){ err(vSal.motivo); return; }

  // Cobro de deuda: persona + (si aplica) préstamo, y que el monto no supere lo que todavía debe.
  let cobroDeudorId = '', cobroGrupoId = '', cobroDeudorNombre = '';
  const esCobro = unica && partes[0].origen === 'deuda';
  if(esCobro){
    cobroDeudorId = (document.getElementById('alc_dep_deudor')||{}).value || '';
    if(!cobroDeudorId){ err('Selecciona quién te pagó'); return; }
    const dCheck = Deudas.lista('favor').find(x => x.id === cobroDeudorId);
    if(!dCheck){ err('Esa persona ya no existe'); return; }
    cobroDeudorNombre = dCheck.nombre;
    const grupoWrapCheck = document.getElementById('alc_dep_deudor_grupo_wrap');
    if(grupoWrapCheck && grupoWrapCheck.style.display !== 'none'){
      cobroGrupoId = (document.getElementById('alc_dep_deudor_grupo')||{}).value || '';
      if(!cobroGrupoId){ err('Selecciona a cuál préstamo corresponde'); return; }
    }
    const saldoDisp = cobroGrupoId ? getGrupoSaldo(dCheck, cobroGrupoId) : getDeudorSaldo(dCheck);
    if(monto > saldoDisp + 0.5){
      err(`${dCheck.nombre} solo debe ${typeof fmt==='function'?fmt(saldoDisp):saldoDisp}`); return;
    }
  }

  /* ── 3. Crear los movimientos espejo ── */
  _initA();
  const a = window.S.alcancia;
  const uidF = () => typeof uid==='function' ? uid() : Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const entryId = uidF();
  partes.forEach((p, i) => { p.movId = i === 0 ? entryId : uidF(); }); // la 1ª parte comparte id con la entrada (como siempre)

  partes.forEach(p => {
    if(p.origen === 'cuenta'){
      // Cambio 2026-09-27: un depósito desde una cuenta real es un TRASLADO, no un
      // gasto — antes vivía en S.gastosVar con _esAlcancia:true, obligando a que
      // _esGastoVarNoReal()/busqueda-global.js/actividad_reciente.js lo excluyeran
      // a mano en cada pantalla. Ahora se registra como transferencia (origen: la
      // cuenta, destino: 'alcancia'), igual que cualquier traslado entre cuentas
      // (ver docs/alcancia.md §4 y CHANGELOG.md#alcancia). El monto sigue oculto en
      // todo lado — eso no cambia, solo cambia dónde vive el registro.
      window.S.transferencias = window.S.transferencias || [];
      window.S.transferencias.push({
        id: p.movId,
        fecha,
        origen: p.fuente,
        destino: 'alcancia',
        monto: p.monto,
        desc: descVal || 'Depósito en alcancía',
        nota: (unica ? 'Guardado en alcancía oculta' : 'Guardado en alcancía oculta (depósito dividido)') + (descVal ? ': ' + descVal : ''),
        _esAlcancia: true,
        _alcTipo: unica ? 'yo-cuenta' : 'multi',
        _secundario: true, _origenSeccion: 'Alcancía',
        ts: Date.now()
      });
      if(typeof descontarFuente === 'function') descontarFuente(p.fuente, p.monto, _ogAlc(p.movId));
    } else if(p.origen !== 'deuda'){
      const info = _ALC_INFO_ORIGEN[p.origen];
      window.S.movimientos = window.S.movimientos || [];
      window.S.movimientos.push({
        id: p.movId,
        tipo: 'entrada',
        // Plata que nunca estuvo en una cuenta: la fuente es la propia alcancía, no una cuenta (el ingreso cuenta en el mes
        // igual: entradasIngresoReal() no mira la fuente). No mueve ningún saldo y ningún historial de cuenta lo lista.
        fuente: 'alcancia',
        monto: p.monto,
        fecha,
        desc: unica ? (descVal || info.desc) : (descVal ? descVal + ' (' + info.corto + ')' : info.desc),
        nota: info.nota,
        clase: 'ingreso', // propio/regalo/mandado: plata que nunca estuvo en una cuenta (ver alcanciaConfirmarDeposito)
        _esAlcanciaIngreso: true,
        _secundario: true, _origenSeccion: 'Alcancía',
        ts: Date.now()
      });
    }
  });

  // Cobro de deuda: abono en la persona (descuenta la deuda). No toca ninguna cuenta ni cuenta como ingreso.
  let cobroAbonoMovId = null;
  if(esCobro){
    const d = Deudas.lista('favor').find(x => x.id === cobroDeudorId);
    if(d){
      if(!d.movimientos) d.movimientos = [];
      const grupoIdFinal = cobroGrupoId || (typeof _autoGrupoIdMov === 'function' ? _autoGrupoIdMov(d, fecha) : undefined);
      cobroAbonoMovId = uidF();
      d.movimientos.push({
        id: cobroAbonoMovId,
        tipo: 'abono',
        monto,
        fecha,
        nota: 'Cobrado y guardado directo en la alcancía' + (descVal ? ': ' + descVal : ''),
        destino: '',
        grupoId: grupoIdFinal,
        _viaAlcancia: true,
        _alcanciaMovId: entryId,
        ts: Date.now()
      });
      if(typeof _autoCerrarGruposEnCero === 'function') _autoCerrarGruposEnCero(d);
      if(typeof logCambio === 'function') logCambio('Abono de ' + escHtml(d.nombre) + ' guardado directo en la alcancía', d.nombre, monto, 'abono');
    }
  }

  /* ── 4. Registro propio de la alcancía ── */
  a.saldoRegistrado = (a.saldoRegistrado || 0) + monto;
  a.depositos = (a.depositos || 0) + 1;
  a.movimientos = a.movimientos || [];
  const movEntry = { id: entryId, monto, fecha, fuenteOrigen: null, ts: Date.now() };
  if(unica){
    const p = partes[0];
    if(p.origen === 'cuenta'){
      movEntry.tipo = 'yo-cuenta'; movEntry.tipoLabel = 'Propio (de cuenta)'; movEntry.fuenteOrigen = p.fuente;
      movEntry.desc = descVal || 'Depósito en alcancía';
    } else if(p.origen === 'deuda'){
      movEntry.tipo = 'cobro-deuda'; movEntry.tipoLabel = 'Cobro de deuda';
      movEntry.desc = descVal || ('Cobro de deuda — ' + cobroDeudorNombre);
      movEntry._prestamoDeudorId = cobroDeudorId;
      movEntry._prestamoMovId = cobroAbonoMovId;
    } else {
      const info = _ALC_INFO_ORIGEN[p.origen];
      movEntry.tipo = info.tipo;
      movEntry.tipoLabel = { propio: 'Propio (directo)', regalo: 'Regalo mamá', mandado: 'Mandado mamá' }[p.origen];
      movEntry.desc = descVal || info.desc;
    }
  } else {
    movEntry.tipo = 'multi';
    movEntry.tipoLabel = partes.map(p => p.origen === 'cuenta' ? _alcNombreFuente(p.fuente) : _ALC_INFO_ORIGEN[p.origen].corto).join(' + ');
    movEntry.desc = descVal || 'Depósito de varias fuentes';
    movEntry.partes = partes.map(p => {
      const o = { origen: p.origen, monto: p.monto, movId: p.movId };
      if(p.fuente) o.fuente = p.fuente;
      return o;
    });
  }
  a.movimientos.push(movEntry);
  _setSaldoOfuscado(a.saldoRegistrado);

  if(typeof save==='function') save();
  if(typeof closeSheet==='function') closeSheet('alcancia-depositar');
  if(typeof refresh==='function') refresh();
  window.renderAlcancia();
  if(typeof toast==='function') toast('Guardado en la alcancía', 'ok');
};

/* Confirmar destapar */
window.alcanciaConfirmarDestapar = function(){
  const saldoReal = _getMoneyVal('alc_real_monto');
  const destino   = (document.getElementById('alc_destino')||{}).value || '';

  if(saldoReal <= 0){
    if(typeof toast==='function') toast('Ingresa el monto real encontrado', 'err'); return;
  }
  if(!destino){
    if(typeof toast==='function') toast('Selecciona una cuenta destino', 'err'); return;
  }

  _initA();
  const a = window.S.alcancia;
  const saldoReg = a.saldoRegistrado || 0;
  const dif = saldoReal - saldoReg;
  const hoyStr = hoy();

  // ── Movimiento 1: transferir saldo registrado desde alcancía → destino
  // Los gastos marcados _esAlcancia ya descontaron el dinero de las cuentas.
  // Ahora lo reponemos en la cuenta destino como ingreso neutral interno.
  if(saldoReg > 0){
    window.S.movimientos = window.S.movimientos || [];
    window.S.movimientos.push({
      id: typeof uid==='function' ? uid() : Date.now().toString(36),
      tipo: 'transferencia',
      fuente: destino,
      monto: saldoReg,
      fecha: hoyStr,
      clase: 'neutro',
      desc: 'Alcancía destapada — saldo registrado',
      nota: 'Transferencia interna desde alcancía',
      _esAlcancia: true,
      _secundario: true, _origenSeccion: 'Alcancía',
      ts: Date.now()
    });
    // Actualizar saldo de la cuenta destino
    _sumarASaldo(destino, saldoReg);
  }

  // ── Movimiento 2: diferencia positiva → ingreso real
  if(dif > 1){
    window.S.movimientos = window.S.movimientos || [];
    window.S.movimientos.push({
      id: typeof uid==='function' ? uid() : Date.now().toString(36),
      tipo: 'entrada',
      fuente: destino,
      monto: dif,
      fecha: hoyStr,
      clase: 'ingreso',
      desc: 'Dinero extra encontrado en alcancía',
      nota: 'Ajuste: dinero físico no registrado previamente',
      _esAlcancia: true,
      _secundario: true, _origenSeccion: 'Alcancía',
      ts: Date.now()
    });
    _sumarASaldo(destino, dif);
  }

  // ── Movimiento 3: diferencia negativa → gasto de ajuste
  if(dif < -1){
    const absDif = Math.abs(dif);
    window.S.gastosVar = window.S.gastosVar || [];
    window.S.gastosVar.push({
      id: typeof uid==='function' ? uid() : Date.now().toString(36),
      clase: 'gasto',
      desc: 'Ajuste alcancía — faltante',
      monto: absDif,
      fecha: hoyStr,
      cat: 'Ajuste',
      fuente: destino,
      nota: 'Diferencia negativa al destapar alcancía',
      _esAlcanciaAjuste: true,
      _secundario: true, _origenSeccion: 'Alcancía',
      ts: Date.now()
    });
    // Restar la diferencia del saldo de la cuenta destino
    _sumarASaldo(destino, -absDif);
  }

  // ── Resetear saldoRegistrado: ya se transfirió arriba a la cuenta destino
  // vía _sumarASaldo(). Si se deja el valor viejo, calcPatrimonioTotal()
  // (el núcleo) lo sigue sumando SIEMPRE (tapada o destapada, por
  // diseño — es plata real), y como la alcancía queda en estado
  // `_destapada` sin reiniciar hasta que el usuario elija "Iniciar nueva
  // alcancía", ese monto queda contado DOS veces (una en la cuenta destino,
  // otra acá) — duplicando patrimonio, tendencia mensual y la proyección
  // 3m/6m/12m. El valor para historial ya quedó capturado arriba en
  // `saldoReg`, así que resetear acá no afecta el registro histórico.
  a.saldoRegistrado = 0;
  _setSaldoOfuscado(0);

  // ── Historial de patrimonio: al destapar, la plata deja de ser oculta también
  // hacia atrás. Cada punto guarda `valor` (con alcancía) y `valorVisible` (sin
  // ella); igualarlos hace que la gráfica de Análisis y la tendencia/proyección
  // reflejen los depósitos en el día en que ocurrieron, en vez de un salto único
  // el día del destape. Todo lo oculto pertenece a esta alcancía o a ciclos ya
  // destapados, así que aplica a todos los puntos.
  (window.S.patrimonioHistorial || []).forEach(function(p){
    if(p && typeof p.valor === 'number' && p.valorVisible != null) p.valorVisible = p.valor;
  });

  // ── Guardar en historial
  const diasDuracion = _diasDesde(a.fechaInicio);
  if(!a.historial) a.historial = [];
  const entradaHist = {
    fechaInicio:      a.fechaInicio,
    fechaFin:         hoyStr,
    diasDuracion,
    depositos:        a.depositos || 0,
    saldoRegistrado:  saldoReg,
    saldoReal,
    diferencia:       dif,
    movimientos:      [...(a.movimientos || [])]
  };
  a.historial.push(entradaHist);

  // ── Preparar resultado para mostrar
  const resBody = document.getElementById('alc-resultado-body');
  if(resBody){
    const fmt2 = fmt;
    const hist = a.historial;
    const prev = hist.length >= 2 ? hist[hist.length - 2] : null;
    let comparHtml = '';
    if(!prev){
      comparHtml = `<div class="alc-primera">Esta es tu primera alcancía. ¡Se inicia tu historial de ahorro!</div>`;
    } else {
      const difMonto  = saldoReg - (prev.saldoRegistrado||0);
      const difDias   = diasDuracion - (prev.diasDuracion||0);
      const racha = _alcRachaAhorro(hist);
      const rachaMsg = racha >= 2 ? `🔥 Racha de ${racha} alcancías seguidas ahorrando más` : '';
      comparHtml = `
        <div class="card alc-cmp-card">
          <div class="alc-cmp-cap">vs. alcancía anterior</div>
          <div class="row alc-fila-mb4">
            <span class="alc-prog-txt">Monto</span>
            <span class="alc-cmp-monto ${difMonto>=0?'alc-c-accent':'alc-c-red'}">${difMonto>=0?'+':''} ${fmt2(difMonto)}</span>
          </div>
          <div class="row${rachaMsg ? ' alc-fila-mb8' : ''}">
            <span class="alc-prog-txt">Duración</span>
            <span class="alc-cmp-dias ${difDias>=0?'alc-c-accent':'alc-c-red'}">${difDias>=0?'+':''} ${difDias} días</span>
          </div>
          ${rachaMsg ? `<div class="alc-cmp-racha">${rachaMsg}</div>` : ''}
        </div>`;
    }
    const difMsgColor = Math.abs(dif)<1 ? 'alc-c-text3' : dif>0 ? 'alc-c-accent' : 'alc-c-red';
    const difMsg = Math.abs(dif)<1
      ? 'El dinero encontrado coincide exactamente con lo registrado.'
      : dif > 0
        ? `Encontraste ${fmt2(dif)} adicionales que no estaban registrados. Se suman al patrimonio.`
        : `Faltan ${fmt2(Math.abs(dif))} respecto a lo registrado. Se ajusta el patrimonio.`;
    resBody.innerHTML = `
      <div class="card alc-res-card">
        <div class="alc-res-saldo">${fmt2(saldoReal)}</div>
        <div class="alc-prog-txt">encontraste en la alcancía</div>
      </div>
      <div class="card card-sm alc-fila-mb8">
        <div class="row alc-fila-mb6">
          <span class="alc-prog-txt">Registrado por la app</span>
          <span class="alc-res-reg-val">${fmt2(saldoReg)}</span>
        </div>
        <div class="row alc-fila-mb6">
          <span class="alc-prog-txt">Real encontrado</span>
          <span class="alc-res-real-val">${fmt2(saldoReal)}</span>
        </div>
        <div class="row">
          <span class="alc-prog-txt">Diferencia</span>
          <span class="alc-res-dif ${difMsgColor}">${Math.abs(dif)<1?'$0':dif>0?'+'+fmt2(dif):'−'+fmt2(Math.abs(dif))}</span>
        </div>
      </div>
      <div class="alc-dif-msg ${Math.abs(dif)<1?'alc-dif-0':dif>0?'alc-dif-pos':'alc-dif-neg'}">${difMsg}</div>
      ${_alcDesgloseHtml(a.movimientos, fmt2)}
      ${comparHtml}`;
  }

  // ── Marcar la alcancía como destapada (sin iniciar una nueva automáticamente)
  // El reset real ocurre solo cuando el usuario elige "Iniciar nueva alcancía".
  // Si pulsa "Cerrar", la alcancía queda en estado _destapada hasta que decida.
  a._destapada = true;

  // ── Sincronizar DOM antes de save() ─────────────────────────────────────
  // Nequi, Efectivo y las personalizadas guardan su saldo en S.cuentas y save() ya no lo relee
  // del DOM: no hay nada que sincronizar. Las cajitas Nu sí siguen espejadas en su input.
  if(typeof fmtInput === 'function'){
    // Si el destino fue una cajita, sincronizar su input de saldo
    if(destino && Fuente.esCajita(destino)){
      const _cajId = destino.split(':')[1];
      const _cajEl = document.getElementById('cs_' + _cajId);
      const _caj = (window.S.cajitas||[]).find(c=>c.id===_cajId);
      if(_cajEl && _caj && !(_caj.cdts && _caj.cdts.length)) _cajEl.value = fmtInput(_caj.saldo || 0);
    }
  }

  if(typeof save==='function') save();
  if(typeof closeSheet==='function') closeSheet('alcancia-destapar');
  setTimeout(()=>{ if(typeof openSheet==='function') openSheet('alcancia-resultado'); }, 200);
  if(typeof refresh==='function') refresh();
  window.renderAlcancia();
};

/* ─── TOGGLE DESGLOSE (historial) ───────────────────────────────────────── */
/**
 * Handler de 'alcancia:toggleDesglose'. Events le pasa el propio elemento
 * clickeado (el botón) como argumento extra al final — lo usamos para
 * encontrar el chevron a rotar sin depender de `this` (como hacía la
 * IIFE inline original armada con onclick="(function(btn){...})(this)").
 */
function _alcanciaToggleDesglose(desgloseId, el){
  const box = document.getElementById(desgloseId);
  if(!box) return;
  const open = box.style.display !== 'none';
  box.style.display = open ? 'none' : '';
  const chevron = el && el.querySelector('.alc-hist-chevron');
  if(chevron) chevron.style.transform = open ? '' : 'rotate(180deg)';
}

/* ─── SUMAR A SALDO DE CUENTA ───────────────────────────────────────────── */
function _sumarASaldo(fuente, monto){
  if(!fuente || !monto) return;
  // Solo sube/baja el saldo (y deja la entrada en el libro). En cuentas personalizadas NO se escribe nada en
  // c.movimientos: las filas del destape ya viven en S.movimientos (transferencia y "Dinero extra…") y S.gastosVar
  // (faltante), y el historial de la cuenta las lee de ahí. Antes se duplicaban acá como 'ingreso'/'egreso'
  // (2026-09-29), y ese 'ingreso' de "Alcancía destapada" (plata que ya era tuya) contaba como ingreso del mes.
  const cuenta = Fuente.esCajita(fuente)
    ? (window.S.cajitas||[]).find(x=>x.id===fuente.split(':')[1])
    : getCuentaDeFuente(fuente);
  if(cuenta) ajustarSaldoCuenta(fuente, (cuenta.saldo||0) + monto, {tipo:'movimiento', desc:'Alcancía', origen:{modulo:'alcancia'}});
}

/* ─── REVELAR EL MONTO DE UN DEPÓSITO (uno a la vez) ─────────────────────
   Por defecto la lista muestra cuatro puntos (SVG) en vez del monto — mostrarlos todos
   de una permitiría sumarlos a mano y reconstruir el total que heroSaldo
   mantiene oculto ("$??"). El monto real nunca se guarda en el HTML antes
   de que el usuario lo pida: se busca en window.S.alcancia recién al
   tocar, y solo para esa fila. */
window.alcanciaToggleMontoDeposito = function(movId, el){
  if(!el || el.dataset.movId === undefined) return;
  const montoEl = el;
  const shown = montoEl.dataset.shown === '1';
  if(shown){
    montoEl.innerHTML = _ALC_ICONO_OCULTO;
    montoEl.dataset.shown = '0';
    montoEl.style.color = 'var(--text3)';
  } else {
    _initA();
    const a = window.S.alcancia;
    const entry = a && (a.movimientos || []).find(m => m.id === movId);
    montoEl.textContent = entry ? '+' + (typeof fmt==='function'?fmt(entry.monto):entry.monto) : '?';
    montoEl.dataset.shown = '1';
    montoEl.style.color = 'var(--amber)';
  }
};

/* ─── ELIMINAR UN DEPÓSITO ───────────────────────────────────────────────
   Revierte según el tipo del depósito (ver depositAlcancia() arriba):
   - 'yo-directo' / 'regalo' / 'mandado':
     fueron un ingreso neto-cero en S.movimientos (sumarFuente(+) seguido
     de sumarFuente(-)) — no tocan saldo real, así que basta con quitar el
     registro, sin revertir ningún saldo.
   - 'yo-cuenta': fue un traslado a la alcancía en S.transferencias que sí
     descontó saldo — hay que devolver la plata con sumarFuente().
   No usa eliminarMovimiento() de movimientos.js porque esos registros ya
   quedan marcados _secundario (ver arriba), así que esa función los
   bloquea a propósito — este es el único camino real para deshacerlos. */
window.alcanciaEliminarDeposito = async function(movId){
  _initA();
  const a = window.S.alcancia;
  if(!a || !a.movimientos) return;
  const idx = a.movimientos.findIndex(m => m.id === movId);
  if(idx === -1){ if(typeof toast==='function') toast('No se encontró ese depósito', 'err'); return; }
  const entry = a.movimientos[idx];

  // Protección por antigüedad — ver docs/proteccion-antiguedad-movimientos.md.
  // A diferencia de un ingreso neto-cero suelto, acá SIEMPRE hay algo que
  // proteger: a.saldoRegistrado es un total corrido que se ajusta
  // incrementalmente al borrar (igual que enc.movimientos en Encargos o
  // tc.deuda en Tarjetas), así que se mezcla con depósitos/retiros
  // posteriores muevan o no, además, una cuenta externa. "Operaciones
  // posteriores" se cuenta contra la alcancía completa (mismo criterio que
  // se usa en Encargos desde 2026-09-01 — ver CHANGELOG.md#encargos).
  let deudorParaAviso = null;
  if(entry.tipo === 'cobro-deuda' && entry._prestamoDeudorId){
    deudorParaAviso = Deudas.lista('favor').find(x => x.id === entry._prestamoDeudorId) || null;
  }
  if(typeof nivelAntiguedadMovimiento === 'function'){
    const opsPosteriores = entry.fecha ? (a.movimientos||[]).filter(m => m.id!==entry.id && m.fecha && m.fecha>entry.fecha).length : 0;
    const nivel = nivelAntiguedadMovimiento(entry.fecha, opsPosteriores, 'alcancia');
    if(nivel === 'bloqueado'){
      if(typeof avisarMovimientoBloqueado === 'function') await avisarMovimientoBloqueado();
      return;
    }
    if(nivel === 'viejo' && typeof confirmarBorrarMovimientoViejo === 'function'){
      let nombreCuenta, direccion;
      if(entry.tipo === 'yo-cuenta' && entry.fuenteOrigen){ nombreCuenta = fuenteLabel(entry.fuenteOrigen); direccion = 'sube'; }
      else if(entry.tipo === 'multi' && (entry.partes||[]).some(pt => pt.origen === 'cuenta')){ nombreCuenta = entry.partes.filter(pt => pt.origen === 'cuenta').map(pt => _alcNombreFuente(pt.fuente)).join(' y '); direccion = 'sube'; }
      else if(entry.tipo === 'cobro-deuda' && deudorParaAviso){ nombreCuenta = 'la deuda de ' + deudorParaAviso.nombre; direccion = 'sube'; }
      else { nombreCuenta = 'tu alcancía'; direccion = 'baja'; }
      const ok = await confirmarBorrarMovimientoViejo(nombreCuenta, entry.monto || 0, direccion);
      if(!ok) return;

      // Ya se confirmó con el aviso específico de arriba — no repetir con el
      // genérico de abajo, igual que en Spotify (_borrarSpHistorial).
      return _alcanciaEjecutarEliminarDeposito(a, idx, entry);
    }
  }

  const dialogoDetalle = entry.tipo === 'cobro-deuda'
    ? 'Se le volverá a sumar esa plata a la deuda de la persona.'
    : (entry.fuenteOrigen || (entry.tipo === 'multi' && (entry.partes||[]).some(pt => pt.origen === 'cuenta')) ? 'Se devolverá el dinero a la cuenta de origen.' : 'No afecta ningún saldo (fue un ingreso registrado sin mover plata real).');
  const ok = await confirmarEliminar({ titulo: 'Eliminar depósito', objeto: `este depósito de ${fmt(entry.monto)} del ${entry.fecha}`, detalle: dialogoDetalle });
  if(!ok) return;

  return _alcanciaEjecutarEliminarDeposito(a, idx, entry);
};

// Quita el movimiento espejo de un depósito con cuenta de origen (vive en S.transferencias).
function _alcQuitarMirrorCuenta(id){
  if(!id) return;
  window.S.transferencias = (window.S.transferencias || []).filter(x => x.id !== id);
}

async function _alcanciaEjecutarEliminarDeposito(a, idx, entry){
  // Revertir el/los registro(s) reales según el tipo
  if(entry.tipo === 'yo-cuenta'){
    _alcQuitarMirrorCuenta(entry.id);
    if(entry.fuenteOrigen && typeof sumarFuente === 'function') sumarFuente(entry.fuenteOrigen, entry.monto, _ogAlc(entry.id, true));
  } else if(entry.tipo === 'multi'){
    // Varios orígenes: cada parte tiene su propio movimiento espejo (partes[].movId).
    (entry.partes || []).forEach(pt => {
      if(pt.origen === 'cuenta'){
        _alcQuitarMirrorCuenta(pt.movId);
        if(pt.fuente && typeof sumarFuente === 'function') sumarFuente(pt.fuente, pt.monto, _ogAlc(pt.movId || entry.id, true));
      } else {
        window.S.movimientos = (window.S.movimientos || []).filter(x => x.id !== pt.movId);
      }
    });
  } else if(entry.tipo === 'cobro-deuda'){
    // No hay cuenta real ni movimiento en S.movimientos que revertir — el
    // rastro real es el abono en el deudor. Quitarlo de ahí reabre la deuda.
    if(entry._prestamoDeudorId && entry._prestamoMovId){
      const d = Deudas.lista('favor').find(x => x.id === entry._prestamoDeudorId);
      if(d && d.movimientos){
        d.movimientos = d.movimientos.filter(x => x.id !== entry._prestamoMovId);
        if(typeof _autoCerrarGruposEnCero === 'function') _autoCerrarGruposEnCero(d);
      }
    }
  } else {
    // 'yo-directo' / 'regalo' / 'mandado' — ingreso neto-cero
    window.S.movimientos = (window.S.movimientos || []).filter(x => x.id !== entry.id);
  }

  // Revertir el estado propio de la alcancía
  a.movimientos.splice(idx, 1);
  a.saldoRegistrado = Math.max(0, (a.saldoRegistrado || 0) - entry.monto);
  a.depositos = Math.max(0, (a.depositos || 0) - 1);
  _setSaldoOfuscado(a.saldoRegistrado);

  if(typeof save==='function') save();
  if(typeof refresh==='function') refresh();
  window.renderAlcancia();
  if(typeof toast==='function') toast('Depósito eliminado', 'ok');
}

/* Quita SOLO el lado de la alcancía de un depósito 'cobro-deuda', sin tocar
   al deudor — para cuando el borrado se inició desde Préstamos
   (eliminarMovDeudor ya revirtió/confirmó ese lado). Sin diálogo de
   confirmación propio: quien llama ya confirmó una sola vez. */
window._alcanciaQuitarPorCobroDeuda = function(alcMovId){
  _initA();
  const a = window.S.alcancia;
  if(!a || !a.movimientos) return false;
  const idx = a.movimientos.findIndex(m => m.id === alcMovId);
  if(idx === -1) return false;
  const entry = a.movimientos[idx];
  a.movimientos.splice(idx, 1);
  a.saldoRegistrado = Math.max(0, (a.saldoRegistrado || 0) - entry.monto);
  a.depositos = Math.max(0, (a.depositos || 0) - 1);
  _setSaldoOfuscado(a.saldoRegistrado);
  return true;
};

/* ─── REGISTRO EN EVENTS ─────────────────────────────────────────────────
   Los dos primeros (abrirDepositar/abrirDestapar) reemplazan los
   onclick="openSheet('alcancia-...')" que vivían como HTML estático en
   index.html (mismo patrón ya usado en Préstamos/TC: cada acción se
   nombra por lo que hace, no por el nombre genérico de la función que
   invoca por debajo). El resto envuelve las funciones ya expuestas en
   `window` — se mantienen colgadas de window por compatibilidad, Events
   solo agrega la forma de dispararlas desde el HTML sin onclick inline. */
Events.registerAll('alcancia', {
  abrirDepositar:     function(){ if(typeof openSheet === 'function') openSheet('alcancia-depositar'); },
  abrirDestapar:      function(){ if(typeof openSheet === 'function') openSheet('alcancia-destapar'); },
  iniciarNueva:       window.alcanciaIniciarNueva,
  confirmarDeposito:  window.alcanciaConfirmarDeposito,
  confirmarDestapar:  window.alcanciaConfirmarDestapar,
  eliminarDeposito:   window.alcanciaEliminarDeposito,
  toggleMontoDeposito: window.alcanciaToggleMontoDeposito,
  toggleDividir:      window.alcanciaToggleDividir,
  agregarOrigen:      window.alcanciaAgregarOrigen,
  toggleDesglose:     _alcanciaToggleDesglose
});

/* ─── INYECTAR MAS MENU ITEM ─────────────────────────────────────────────── */
// CÓDIGO MUERTO EN LA PRÁCTICA (confirmado, no borrado — ver auditoria-tecnica.md
// "Alcancía: regresión del ítem de menú", cierre 2026-08-18): este era el fix del
// piloto de carga lazy de Alcancía — el ítem "Alcancía" del menú "Más" se generaba
// acá porque el módulo (y su ítem de menú) recién existían tras la primera carga
// lazy. En algún momento posterior #mas-alcancia pasó a vivir como HTML estático
// en index.html (junto a #mas-config, con su mismo data-screen="alcancia") y ya
// lo wirea el handler genérico de js/core/mas-menu.js (querySelectorAll
// ('.mas-item[data-screen]')) — el guard de la línea de abajo (elemento ya
// existe) hace que esta función retorne siempre antes de crear nada. El hook de
// showScreen() más abajo sigue siendo necesario (dispara renderAlcancia() sin
// importar cómo se llegó a la pantalla) — eso no es código muerto.
function _inyectarMasMenuItem(){
  const masMenu = document.getElementById('mas-menu');
  if(!masMenu || document.getElementById('mas-alcancia')) return;
  const configItem = document.getElementById('mas-config');
  const item = document.createElement('div');
  item.className = 'mas-item';
  item.id = 'mas-alcancia';
  item.setAttribute('data-screen','alcancia');
  item.innerHTML = `
    <div class="mas-item-icon alc-mas-ico">
      <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--amber)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 2a4 4 0 0 1 4 4v1h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1V6a4 4 0 0 1 4-4z"/>
        <circle cx="12" cy="14" r="1.5" fill="var(--amber)" stroke="none"/>
      </svg>
    </div>
    <div>
      <div class="mas-item-label">Alcancía oculta</div>
      <div class="mas-item-sub">Ahorro sorpresa — saldo oculto</div>
    </div>`;
  if(configItem) masMenu.insertBefore(item, configItem);
  else masMenu.appendChild(item);

  // Registrar en el sistema de navegación
  item.addEventListener('click', ()=>{
    if(typeof closeMas==='function') closeMas();
    else {
      const ov = document.getElementById('mas-menu-overlay');
      const mn = document.getElementById('mas-menu');
      if(ov) ov.style.display='none'; if(mn) mn.style.display='none';
    }
    if(typeof showScreen==='function'){
      showScreen('alcancia');
      window.renderAlcancia();
    }
  });
}

/* ─── showScreen HOOK — ver js/core/ui.js ──────────────────────── */
Ui.pantalla('alcancia', function(){ window.renderAlcancia(); }, { key: 'alcancia-render' });

/* ─── INTEGRACIÓN CON data-screen en el mas-menu ────────────────────────── */
// El sistema nativo usa data-screen en .mas-item → querySelectorAll detecta el click.
// Pero nuestro item es inyectado dinámicamente, así que usamos addEventListener arriba.
// Aun así hay que registrar el screen en el mapa de nombres si la app los valida.
if(window._screenNames){
  window._screenNames['screen-alcancia'] = 'Alcancía';
}

/* ─── ARRANQUE ──────────────────────────────────────────────────────────── */
function _alcanciaInit(){
  _inyectarMasMenuItem();
  _inyectarAlcanciaSheets();
  // Registrar refresh en el sistema de navegación nativo (mas-item data-screen clicks)
  document.querySelectorAll('.nav-item[data-screen]').forEach(btn => {
    if(btn.getAttribute('data-screen') === 'alcancia'){
      btn.addEventListener('click', ()=> window.renderAlcancia());
    }
  });
}

window.addEventListener('appDataLoaded', function(){
  setTimeout(_alcanciaInit, 700);
});

// Fallback si ya cargó
if(window._dataLoaded){
  setTimeout(_alcanciaInit, 500);
} else if(document.readyState !== 'loading'){
  // Antes era un setInterval propio con contador a mano (ver
  // CHANGELOG.md#infraestructura--seguridad, entrada de consolidación de
  // este patrón — se había cerrado como "cero copias en todo el proyecto"
  // sin haber revisado todavía js/modules/, donde vivía esta 8ª copia).
  // alcancia.js carga vía lazy-loader.js (script clásico inyectado
  // dinámicamente con document.createElement, mucho después de que
  // wait-for.js — <script defer> del HTML inicial — ya terminó de correr),
  // así que puede usar waitFor() como global sin ningún riesgo de carrera
  // (a diferencia de pin-bio.js/firebase-sync.js).
  //
  // onGiveUp (agregado 2026-09-08): antes, si los 40 intentos (~12s) se
  // agotaban sin que window.S/window._dataLoaded aparecieran, la falla era
  // 100% silenciosa — Alcancía simplemente nunca se inicializaba, sin nada
  // en consola. No cambia el camino exitoso, solo le da un rastro
  // diagnosticable al que hoy fallaba sin ninguna pista.
  waitFor(() => window.S && window._dataLoaded, _alcanciaInit, {
    intervalMs: 300,
    maxAttempts: 40,
    onGiveUp: () => console.warn('[alcancia] window.S/_dataLoaded no aparecieron tras 40 intentos (~12s) — Alcancía no se inicializó.')
  });
}

// Sonda de la huella (js/core/huella.js): saldo registrado y su copia ofuscada, depósitos y cada ciclo ya destapado (con la suma de
// los movimientos que guarda). Vive dentro de la IIFE porque _getSaldoOfuscado es privado; corre aislada (lee el S de la copia).
registrarSonda('alcancia',function(st){
  const a=st.alcancia;
  if(!a) return {existe:false,entidades:{}};
  const suma=l=>(l||[]).reduce((x,m)=>x+((m&&m.monto)||0),0);
  return {
    existe:true, entidades:{alcancia:{saldo:a.saldoRegistrado||0}}, destapada:!!a._destapada, saldoRegistrado:a.saldoRegistrado||0, depositos:a.depositos||0,
    ofuscado:st.alcanciaSaldoOfuscado?_getSaldoOfuscado():null, sumaMovimientos:suma(a.movimientos),
    ciclos:(a.historial||[]).map(h=>({fechaFin:h.fechaFin||null,saldoRegistrado:h.saldoRegistrado||0,depositos:h.depositos||0,saldoReal:h.saldoReal==null?null:h.saldoReal,diferencia:h.diferencia==null?null:h.diferencia,sumaMovimientos:suma(h.movimientos)}))
  };
});

})(); // end IIFE
