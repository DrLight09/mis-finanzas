/* ═══════════════════════════════════════════════════════════════
   js/modules/encargos.js

   Módulo Encargos — plata de otras personas que el usuario administra
   (no suma al patrimonio propio). Extraído de index.html como parte
   de la migración de arquitectura descrita en auditoria-tecnica.md
   (§1 onclick→data-action, §3 monolito) — mismo patrón ya usado en
   spotify.js y mesada.js. Ver docs/encargos.md para el detalle
   funcional del módulo (reglas de negocio, modelo de datos, flujos).

   ── Qué NO vive acá ──────────────────────────────────────────────
   - El motor de diferencial/margen (diffRegistrarInstancia, diffToggle,
     diffAddParte, diffResumen, diffAplicar, etc.) y el de split
     (crearSplitWidget, splitToggle, splitAgregarRow, splitGetData)
     siguen en index.html: los usan también Préstamos ("extra",
     "prtc") y otros módulos, no son exclusivos de Encargos. Acá solo
     viven las INSTANCIAS que este módulo registra en esos motores
     (diffRegistrarInstancia('movenc', ...), ('usarParte', ...),
     ('ctc', ...) y crearSplitWidget('movenc', ...), ('usarParte', ...)).
   - iniciales() se queda en bootstrap.js porque también la usa el sistema
     de Personas. getCajitaNombre() vive en js/core/nu-calc.js.
   - _normEncargos(S) (normalización para el feed unificado de movimientos)
     vive en js/modules/actividad_reciente.js, junto a las de los demás módulos.
   - La integración con el Sistema de Personas (selector en "Nuevo encargo",
     hook que exige personaId, botones de perfil en lista/detalle) vive al
     final de este mismo archivo (fusionada el 2026-08-03). Usa getPersona/
     abrirSelPersona/_inyectarPersonaSheets, de personas.js, solo dentro de
     handlers.
   - La integración cruzada con Préstamos ("Pago de una deuda con
     plata de un encargo", dentro del sheet de abono de deudor) no se
     tocó: es código de Deudores que consume datos de Encargos, no al
     revés, y Deudores todavía no se migró (ver plan-migracion-personas.md).

   ── Correcciones de este mismo cambio ────────────────────────────
   Se migraron los onclick="..." inline de este módulo a data-action
   (ver js/core/events.js), y se corrigieron ~18 casos de texto libre
   sin escapar en .innerHTML/toast() — mismo patrón ya visto en
   Spotify (spNombreDe) y Mesada (fuenteLabel): el barrido original de
   escHtml() por nombre de campo no detecta texto libre que llega
   envuelto en una función auxiliar. Acá la función era fuenteLabel()
   (nombre de cajita/cuenta personalizada/tarjeta — todos campos de
   texto libre del usuario) e iniciales(). Detalle completo en
   CHANGELOG.md#encargos.
   ═══════════════════════════════════════════════════════════════ */

// ── Libro (js/core/cuentas-fuentes.js): origen de cada cambio de saldo ────────────────────────────────────────────────
// _ogEnc(ref, rev): cada sumar/descontarFuente deja en el libro { modulo:'encargos', ref:<id del movimiento del encargo> }.
// Con rev=true es una reversión (tipo 'reversion', mismo ref que lo que deshace). `opts.exacto` ya no existe: el saldo
// nunca se recorta en 0 (ver descontarFuente en js/core/cuentas-fuentes.js).
const _ogEnc = Libro.origen('encargos');

function editarEncargoActual() {
  if (!encargoActualId) return;
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  document.getElementById('enc_edit_nombre').value = enc.nombre || '';
  document.getElementById('enc_edit_nota').value = enc.nota || '';
  openSheet('editar-encargo');
}
function guardarEditarEncargo() {
  if (!encargoActualId) return;
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const nombre = document.getElementById('enc_edit_nombre').value.trim();
  if (!nombre) { toast('Ingresa el nombre', 'err'); return; }
  enc.nombre = nombre;
  enc.nota = document.getElementById('enc_edit_nota').value.trim();
  // Sincronizar nombre en S.personas si hay vínculo
  if (enc.personaId) {
    const p = (S.personas || []).find(x => x.id === enc.personaId);
    if (p) p.nombre = nombre;
  }
  save();
  abrirEncargoDetalle(encargoActualId);
  closeSheet('editar-encargo');
  toast(nombre + ' actualizado', 'ok');
}
function renderEncargosEnCuenta(elId, tipoCuenta) {
  const el = document.getElementById(elId);
  if (!el) return;
  const encargos = S.encargos || [];

  // Cuenta de ahorro: construir filas por cajita específica (no agrupado)
  // Para otras cuentas: comportamiento normal
  const cuentaAhorro = getCuentaDeFuente(tipoCuenta);
  if (esCuentaAhorro(cuentaAhorro)) {
    const cajitasPropias = new Set(cajitasDeCuenta(cuentaAhorro.id).map(x => x.id));
    // Estructura: [{enc, cajitaId, saldoEncargo}]
    const filas = [];
    encargos.forEach(enc => {
      const mapRaw = {};
      if (enc.saldoInicial > 0) {
        const k = enc.cuentaInicial || '__sin__';
        mapRaw[k] = (mapRaw[k]||0) + enc.saldoInicial;
      }
      (enc.movimientos||[]).forEach(m => {
        const k = m.cuenta || '__sin__';
        if (m.tipo === 'entrada') mapRaw[k] = (mapRaw[k]||0) + m.monto;
        else mapRaw[k] = (mapRaw[k]||0) - m.monto;
      });
      // Una fila por cajita específica
      Object.entries(mapRaw).forEach(([k, v]) => {
        if (v > 0 && k && Fuente.esCajita(k) && cajitasPropias.has(k.split(':')[1])) {
          filas.push({ enc, cajitaId: k.split(':')[1], saldoEncargo: v });
        }
      });
    });
    if (!filas.length) { el.innerHTML = ''; return; }

    // Calcular intereses por cajita usando interés compuesto proporcional.
    // La porción del encargo crece al mismo ritmo que la cajita entera.
    // Proporción del encargo = saldoEncargo / saldo_base_cajita (el saldo guardado, sin intereses futuros)
    // Valor actual de esa porción = calcC(cajita).val * proporción
    // Interés de HOY de esa porción = valor_actual_porción * tasaDiaria
    // Esto replica exactamente lo que hace el banco: el dinero del encargo genera interés compuesto
    // acumulado desde que se depositó (fecha de la cajita), y el de hoy es sobre la base ya crecida.

    let totalEncargosAhorro = 0;      // saldo nominal (lo que le debes al encargante)
    let totalInteresesMios = 0;   // interés de hoy sobre la porción del encargo (es tuyo)
    let totalValorActual = 0;     // valor actual de la porción (nominal + intereses acumulados = ganancia tuya)
    const filasHtml = filas.map(({enc, cajitaId, saldoEncargo}) => {
      totalEncargosAhorro += saldoEncargo;
      const cajita = (S.cajitas||[]).find(x => x.id === cajitaId);
      const cajitaNombre = cajita ? (cajita.nombre || 'Cajita') : 'Cajita';

      // Calcular valor actual proporcional de la porción del encargo
      let interesMioHoy = 0;
      let valorActualPorcion = saldoEncargo;
      let interesAcumulado = 0;
      if (cajita && cajita.saldo > 0) {
        const k = calcC(cajita);
        const proporcion = saldoEncargo / cajita.saldo; // fracción del saldo base que es del encargo
        valorActualPorcion = k.val * proporcion;        // valor actual de esa fracción (crece con la cajita)
        interesAcumulado = valorActualPorcion - saldoEncargo; // ganancia acumulada tuya hasta ahora
        // Interés de hoy = sobre la base ya crecida (interés compuesto)
        interesMioHoy = valorActualPorcion * k.tasaDiaria;
      } else {
        // Cajita sin fecha o sin saldo: usar tasa global simple
        const tasa = getTasaCuenta(cuentaAhorro.id);
        const tasaDiaria = Math.pow(1 + tasa / 100, 1 / 365) - 1;
        interesMioHoy = saldoEncargo * tasaDiaria;
      }
      totalInteresesMios += interesMioHoy;
      totalValorActual += valorActualPorcion;

      // Mostrar interés acumulado sólo si es significativo
      const acumuladoTag = interesAcumulado > 0.5
        ? `<span class="enc-int-acum">+${fmt(interesAcumulado)} acumulado tuyo</span>`
        : '';

      return html`
        <div class="enc-nu-caja" data-encargo-id="${enc.id}" ${raw(Events.attr('encargos:abrirDesdeCuenta', enc.id))}>
          <div class="enc-nu-cab">
            <div class="avatar enc-av-azul-26">${iniciales(enc.nombre)}</div>
            <div class="enc-flex1-min0">
              <div class="enc-nombre-ell">${enc.nombre}</div>
              ${enc.nota?html`<div class="enc-nota">${enc.nota}</div>`:''}
            </div>
            <div class="enc-der">
              <div class="enc-saldo-azul">${fmt(saldoEncargo)}</div>
              <div class="enc-de-total">de ${fmt(encargoSaldo(enc))} total</div>
            </div>
          </div>
          <div class="enc-nu-pie">
            <span class="enc-nu-tag">
              <svg aria-hidden="true" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
              ${cajitaNombre}
            </span>
            <div class="enc-nu-der">
              ${interesMioHoy >= 0.01 ? html`<span class="enc-nu-int">+${fmt(interesMioHoy)}/día <span class="enc-nu-tuyo">(tuyo)</span></span>` : ''}
              ${raw(acumuladoTag)}
            </div>
          </div>
        </div>`;
    });

    const totalAcumulado = totalValorActual - totalEncargosAhorro; // ganancia acumulada total tuya
    el.innerHTML = html`
      <div class="sec-title">Encargos en ${cuentaAhorro.nombre}</div>
      <div class="enc-cap-caja">
        <div class="enc-cap-txt">Plata que administras de otras personas, guardada en tus cajitas — los intereses que genera son tuyos</div>
        ${filasHtml}
        <div class="enc-tot-fila">
          <div>
            <div class="enc-nota">Total encargos en ${cuentaAhorro.nombre}</div>
            ${totalInteresesMios >= 0.01 ? html`<div class="enc-tot-int-dia">+${fmt(totalInteresesMios)}/día que ganas tú</div>` : ''}
            ${totalAcumulado > 0.5 ? html`<div class="enc-tot-acum">+${fmt(totalAcumulado)} ganados hasta hoy</div>` : ''}
          </div>
          <span class="enc-tot-val">${fmt(totalEncargosAhorro)}</span>
        </div>
      </div>`;
    return;
  }

  // ── Comportamiento normal para las demás cuentas ──
  const filas = [];
  encargos.forEach(enc => {
    const mapRaw = {};
    if (enc.saldoInicial > 0) {
      const k = enc.cuentaInicial || '__sin__';
      mapRaw[k] = (mapRaw[k]||0) + enc.saldoInicial;
    }
    (enc.movimientos||[]).forEach(m => {
      const k = m.cuenta || '__sin__';
      if (m.tipo === 'entrada') mapRaw[k] = (mapRaw[k]||0) + m.monto;
      else mapRaw[k] = (mapRaw[k]||0) - m.monto;
    });
    let saldoEnCuenta = 0;
    Object.entries(mapRaw).forEach(([k, v]) => {
      if (k === tipoCuenta) saldoEnCuenta += v;
    });
    if (saldoEnCuenta > 0) {
      filas.push({ enc, saldo: saldoEnCuenta });
    }
  });
  if (!filas.length) { el.innerHTML = ''; return; }
  // Color de la cuenta: el que eligió el usuario (azul si la cuenta ya no existe).
  const cuentaTipo = getCuentaDeFuente(tipoCuenta);
  const color = cuentaTipo ? colorCuenta(cuentaTipo) : 'var(--blue)';
  el.innerHTML = html`
    <div class="sec-title">Encargos en esta cuenta</div>
    <div class="enc-cap-caja">
      <div class="enc-lista-cap">Plata que administras de otras personas guardada aquí</div>
      ${filas.map(({enc, saldo}) => html`
        <div class="enc-lista-fila" data-encargo-id="${enc.id}" ${raw(Events.attr('encargos:abrirDesdeCuenta', enc.id))}>
          <div class="enc-lista-pers" ${raw(Events.attr('encargos:abrirDesdeCuenta', enc.id))}>
            <div class="avatar enc-av-azul-28">${iniciales(enc.nombre)}</div>
            <div class="enc-lista-nombre">
              <div class="enc-nombre-ell">${enc.nombre}</div>
              ${enc.nota?html`<div class="enc-nota">${enc.nota}</div>`:''}
            </div>
          </div>
          <div class="enc-lista-der">
            <div class="enc-saldo-azul">${fmt(saldo)}</div>
            <div class="enc-de-total">de ${fmt(encargoSaldo(enc))} total</div>
          </div>
        </div>
      `)}
      <div class="enc-lista-pie">
        <span class="enc-nota">Total encargos aquí</span>
        <span class="enc-tot-val">${fmt(filas.reduce((a,f)=>a+f.saldo,0))}</span>
      </div>
    </div>`;
}

function abrirEncargoDesdeCuenta(id) {
  // Navigate to encargos screen and open the detail
  showScreen('encargos');
  setTimeout(() => abrirEncargoDetalle(id), 80);
}

/* ================================================================
   ENCARGOS — plata de otros que administras (NO suma al patrimonio)
   ================================================================ */

let encargoActualId = null;
let movEncargoTipo = 'entrada'; // 'entrada' | 'salida'

function getEncargo(id) {
  return (S.encargos||[]).find(e=>e.id===id);
}

function encargoSaldo(enc) {
  return (enc.movimientos||[]).reduce((a,m)=>{
    return a + (m.tipo==='entrada'?m.monto:-m.monto);
  }, enc.saldoInicial||0);
}

// Cuánto del saldo ya tiene destino asignado vía partes comprometidas (sin usar todavía).
function encargoComprometido(enc) {
  return (enc.partes||[]).filter(p=>!p.usada).reduce((a,p)=>a+(p.monto||0), 0);
}

// Lo que realmente se puede sacar del encargo ahora mismo: saldo total menos lo ya
// comprometido. Nunca negativo — si el comprometido superó el saldo (p.ej. porque
// una salida por fuera de "usar parte" lo redujo), no hay nada libre para sacar.
function encargoLibre(enc) {
  return Math.max(0, encargoSaldo(enc) - encargoComprometido(enc));
}

// Sonda de la huella (js/core/huella.js): saldo, comprometido, libre y reparto por cuenta de cada encargo. Un encargo es su
// propia bolsa (enc.movimientos), fuera de S.movimientos y del libro: un cambio de almacenamiento no puede alterar nada de esto.
registrarSonda('encargos', st => {
  const entidades = {};
  (st.encargos || []).forEach(enc => {
    const porCuenta = {};
    _getEncargoSaldoPorCuenta(enc).forEach(c => { porCuenta[c.cuenta] = c.saldo; });
    entidades[enc.id] = { saldo: encargoSaldo(enc), comprometido: encargoComprometido(enc), libre: encargoLibre(enc), sinCuenta: _getEncargoSaldoSinCuenta(enc), porCuenta };
  });
  return { entidades };
});

function renderEncargosList() {
  _pintarEncargosList();
}
function _pintarEncargosList() {
  const el = document.getElementById('encargosList');
  const encargos = S.encargos||[];
  // El estado vacío ya trae «Crear encargo»: el botón de pie solo aparece con encargos.
  mostrarSi(document.getElementById('btn-nuevo-encargo'), encargos.length > 0);
  if (!encargos.length) {
    el.innerHTML = emptyState(
      '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.8" stroke-linecap="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-4 0v2"/><line x1="12" y1="12" x2="12" y2="17"/><line x1="9.5" y1="14.5" x2="14.5" y2="14.5"/></svg>',
      'Sin encargos',
      'Cuando administres plata de alguien, crea un encargo para llevar el registro.',
      'Crear encargo',
      { action: 'encargos:nuevo' }
    );
    return;
  }
  el.innerHTML = html`${encargos.map(enc => {
    const saldo = encargoSaldo(enc);
    const comprometido = encargoComprometido(enc);
    const libre = encargoLibre(enc);
    const ini = iniciales(enc.nombre);
    const per = enc.personaId ? getPersona(enc.personaId) : null;
    // Avatar con el color de la persona y clic al perfil: todo en el HTML de la fila (antes se parchaba el DOM después de pintar).
    const colorPer = per && /^#[0-9a-fA-F]{6}$/.test(per.color || '') ? per.color : '#60b0f0';
    const avatar = per
      ? html`<div class="avatar enc-av-det enc-av-perfil" title="Ver perfil" ${raw(Events.attr('personas:abrirPerfil', per.id))} style="color:${colorPer};background:${colorPer}1a;border-color:${colorPer}33;">${ini}</div>`
      : html`<div class="avatar enc-av-det">${ini}</div>`;
    return html`<div class="card card-sm enc-card-click" data-encargo-id="${enc.id}" ${raw(Events.attr('encargos:abrirDetalle', enc.id))}>
      <div class="row">
        <div class="enc-pers-cab">
          ${avatar}
          <div>
            <div class="row-name">${enc.nombre}</div>
            <div class="row-sub">${(enc.movimientos||[]).length} movimiento${(enc.movimientos||[]).length!==1?'s':''} · ${enc.nota||'Encargo'}</div>
          </div>
        </div>
        <div class="enc-txt-der">
          <div class="row-amount c-blue">${fmt(libre)}</div>
          ${comprometido > 0 ? html`<div class="enc-de-total">de ${fmt(saldo)}, ${fmt(comprometido)} comprometido</div>` : ''}
          <span class="badge bg-blue enc-fs9">No es tuyo</span>
        </div>
      </div>
    </div>`;
  })}`;
}

function abrirEncargoDetalle(id) {
  _pintarEncargoDetalle(id);
  const enc = getEncargo(id);
  if (!enc) return;
  _encDetallePartes(enc);      // partes del encargo + preview de monto
  _encDetallePersona(enc);     // color de la persona + chip «Ver perfil» (sección Personas, más abajo)
}
function _pintarEncargoDetalle(id) {
  encargoActualId = id;
  const enc = getEncargo(id);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  const comprometido = encargoComprometido(enc);
  const libre = encargoLibre(enc);
  const entradas = (enc.movimientos||[]).filter(m=>m.tipo==='entrada').reduce((a,m)=>a+m.monto,0)+(enc.saldoInicial||0);
  const salidas = (enc.movimientos||[]).filter(m=>m.tipo==='salida').reduce((a,m)=>a+m.monto,0);

  document.getElementById('encargosListView').style.display = 'none';
  document.getElementById('encargoDetalle').style.display = '';
  document.getElementById('encargoAvatar').textContent = iniciales(enc.nombre);
  document.getElementById('encargoNombreDet').textContent = enc.nombre;
  document.getElementById('encargoSaldoLabel').textContent = enc.nota||'';
  document.getElementById('encargoSaldoHero').textContent = fmt(libre);
  const compHint = document.getElementById('encargoComprometidoHint');
  if (compHint) {
    compHint.textContent = comprometido > 0
      ? `de ${fmt(saldo)} total · ${fmt(comprometido)} ya comprometido en partes`
      : '';
  }
  document.getElementById('encargoTotalEntradas').textContent = fmt(entradas);
  document.getElementById('encargoTotalSalidas').textContent = fmt(salidas);

  // Desglose por cuenta
  const desgEl = document.getElementById('encargoDesgloseCuentas');
  if (desgEl) {
    const cuentas = _getEncargoSaldoPorCuenta(enc);
    // También incluir sin especificar si hay plata ahí
    const mapRaw = {};
    if (enc.saldoInicial > 0) {
      const k = enc.cuentaInicial || '__sin__';
      mapRaw[k] = (mapRaw[k]||0) + enc.saldoInicial;
    }
    (enc.movimientos||[]).forEach(m => {
      const k = m.cuenta || '__sin__';
      if (m.tipo === 'entrada') mapRaw[k] = (mapRaw[k]||0) + m.monto;
      else mapRaw[k] = (mapRaw[k]||0) - m.monto;
    });
    const hayMultiple = Object.keys(mapRaw).filter(k => (mapRaw[k]||0) > 0).length > 0;
    if (hayMultiple && saldo > 0) {
      // La tasa depende de la cuenta de ahorro a la que pertenece cada cajita.
      const tasaDiariaDe = k => {
        const caj = (S.cajitas || []).find(x => x.id === k.split(':')[1]);
        return Math.pow(1 + getTasaCuenta(caj && caj.cuentaId) / 100, 1 / 365) - 1;
      };
      const filas = Object.entries(mapRaw)
        .filter(([k,v]) => v > 0)
        .sort((a,b) => b[1]-a[1])
        .map(([k,v]) => {
          const lbl = k === '__sin__' ? 'Sin especificar' : fuenteLabel(k);
          const pct = saldo > 0 ? Math.round(v/saldo*100) : 0;
          // Si está en una cajita de ahorro, calcular interés diario que genera (es mío)
          const esCajita = k && Fuente.esCajita(k);
          const interesMio = esCajita ? v * tasaDiariaDe(k) : 0;
          return html`<div class="enc-int-cab">
            <div>
              <span class="enc-int-lbl">${lbl}</span>
              ${interesMio >= 0.01 ? html`<div class="enc-int-tuyo">+${fmt(interesMio)}/día tuyo</div>` : ''}
            </div>
            <span class="enc-int-val">${fmt(v)} <span class="enc-fs9-op6">${pct}%</span></span>
          </div>`;
        });
      desgEl.innerHTML = html`<div class="enc-filas">${filas}</div>`;
    } else {
      desgEl.innerHTML = '';
    }
  }

  // Historial — mezclar saldo inicial con movimientos y ordenar todo por fecha desc
  const histEl = document.getElementById('encargoHistorial');
  // Construir lista unificada
  const todosMovs = [...(enc.movimientos||[]).map(m=>({...m, _esSaldoInicial:false}))];
  if (enc.saldoInicial > 0) {
    todosMovs.push({
      id: '__saldo_ini__',
      _esSaldoInicial: true,
      fecha: enc.fechaCreacion || '0000-00-00',
      tipo: 'entrada',
      monto: enc.saldoInicial,
      cuenta: enc.cuentaInicial || '',
      desc: 'Saldo inicial',
      nota: ''
    });
  }
  todosMovs.sort((a,b) => {
    const fechaDiff = b.fecha.localeCompare(a.fecha);
    if (fechaDiff !== 0) return fechaDiff;
    return (b.ts || 0) - (a.ts || 0);
  });

  // Precalcular saldo del encargo (antes/después) para cada movimiento
  const _encSaldoPorId = new Map();
  {
    let _saldoCorriente = saldo;
    todosMovs.forEach(m=>{
      const efecto = m.tipo==='entrada' ? +m.monto : -m.monto;
      const despues = _saldoCorriente;
      const antes = _saldoCorriente - efecto;
      _encSaldoPorId.set(m.id, {antes, despues});
      _saldoCorriente = antes;
    });
  }
  if (!todosMovs.length) {
    histEl.innerHTML = emptyInline('Sin movimientos aún. Registra entradas y salidas.', { centro: true });
  } else {
    // Helper: construye atributos data-mov-* para abrir el sheet de detalle (saldo = saldo del encargo)
    // Ya escapa a mano (escHtml) porque arma una lista de atributos, no un solo valor —
    // se interpola siempre envuelto en raw() en los sitios de abajo.
    const _encAttrs=(m, origenLbl)=>{
      const sd=m._sd||_encSaldoPorId.get(m.id);
      if(!sd) return '';
      return `data-mov-id="${m.id}" data-mov-tipo="${m.tipo}" data-mov-monto="${Math.abs(m.monto)}" data-cuenta-key="encargo" data-mov-origen="${escHtml(origenLbl)}" data-mov-saldo-antes="${sd.antes}" data-mov-saldo-despues="${sd.despues}" data-mov-saldo-label="Saldo de ${escHtml(enc.nombre)}" data-mov-desc="${escHtml(m.desc||'')}" data-mov-fecha="${escHtml(m.fecha)}" style="cursor:pointer;" data-action="core:abrirDetalleMov"`;
    };
    // Salidas divididas → una sola fila (ver _encGrupoSplit)
    const _gruposVistos = new Set();
    const movsRender = [];
    todosMovs.forEach(m => {
      const partes = m._esSaldoInicial ? null : _encGrupoSplit(enc, m);
      if (!partes) { movsRender.push(m); return; }
      const k = _encSplitKey(m);
      if (_gruposVistos.has(k)) return;
      _gruposVistos.add(k);
      const sds = partes.map(x => _encSaldoPorId.get(x.id)).filter(Boolean);
      movsRender.push({
        ..._encSplitCarrier(partes),
        monto: partes.reduce((a, x) => a + x.monto, 0),
        _grupo: partes,
        _sd: sds.length ? { antes: Math.max(...sds.map(x => x.antes)), despues: Math.min(...sds.map(x => x.despues)) } : undefined
      });
    });
    const contenido = movsRender.map((m,i) => {
      if (m._esSaldoInicial) {
        const lblCuentaIni = m.cuenta ? fuenteLabel(m.cuenta) : '';
        return filaMovimiento({
          clase: 'enc-item-ent',
          attrs: _encAttrs(m,'Encargos · '+enc.nombre),
          nombre: 'Saldo inicial',
          sub: `${m.fecha!=='0000-00-00'?m.fecha:''}${lblCuentaIni?' · '+lblCuentaIni:''}`,
          monto: fmt(m.monto),
          montoClase: 'c-blue',
          acciones: botonEliminarFila('encargos:deleteMov', [enc.id, m.id], 'Eliminar saldo inicial'+(lblCuentaIni?' (también se descuenta de '+lblCuentaIni+')':'')),
          meta: html`<span class="badge bg-blue enc-fs9">Inicio</span>${lblCuentaIni?html`<span class="badge ${fuenteBadgeClass(m.cuenta)} enc-fs9">${lblCuentaIni}</span>`:''}`
        });
      }
      const esEntrada = m.tipo === 'entrada';
      const lblCuenta = m._grupo ? m._grupo.map(x => (x.cuenta ? fuenteLabel(x.cuenta) : 'Sin especificar') + ' ' + fmt(x.monto)).join(' + ') : (m.cuenta ? fuenteLabel(m.cuenta) : '');
      const esAbonoPrestamo = !esEntrada && m._esAbonoDeudor;
      const esTcEncargo = !esEntrada && m._esTcEncargo;
      const esMia = !esEntrada && !!m._miaCuentaSale;
      const tcNombreLbl = esTcEncargo && m._tcId ? ((S.tarjetasCredito||[]).find(t=>t.id===m._tcId)||{}).nombre||'' : '';
      const _miaLbl = arr => (arr||[]).map(r=>fuenteLabel(r.cuenta)+' '+fmt(r.monto)).join(' + ');
      const miaSaleLbl  = esMia ? ((m._miaCuentas && m._miaCuentas.sale.length>1) ? _miaLbl(m._miaCuentas.sale) : fuenteLabel(m._miaCuentaSale)+(m._miaMonto?' '+fmt(m._miaMonto):'')) : '';
      const miaEntraLbl = esMia && m._miaCuentaEntra ? ((m._miaCuentas && m._miaCuentas.entra.length>1) ? _miaLbl(m._miaCuentas.entra) : fuenteLabel(m._miaCuentaEntra)+(m._miaMonto?' '+fmt(m._miaMonto):'')) : '';
      const origenEnc = esAbonoPrestamo ? ('Préstamos · ' + ((Deudas.lista('favor').find(x=>x.id===m._deudorId)||{}).nombre||'')) : ('Encargos · '+enc.nombre);
      return filaMovimiento({
        clase: 'enc-item ' + (esEntrada?'enc-item-b-ent':esAbonoPrestamo?'enc-item-b-abono':esTcEncargo?'enc-item-b-tc':'enc-item-b-sal'),
        attrs: _encAttrs(m,origenEnc),
        nombre: m.desc,
        sub: `${m.fecha}${lblCuenta?' · '+lblCuenta:''}${tcNombreLbl?' · '+tcNombreLbl:''}${esMia?' · Yo puse la plata':''}`,
        monto: `${esEntrada?'+':'−'}${fmt(m.monto)}`,
        montoClase: esEntrada?'c-blue':esAbonoPrestamo?'c-amber':'c-red',
        acciones: botonEliminarFila('encargos:deleteMov', [enc.id, m.id], 'Eliminar (también elimina movimientos secundarios en tus cuentas)'),
        antesMeta: html`${m.nota&&!esTcEncargo&&!esMia?html`<div class="gasto-item-meta"><span class="enc-nota">${m.nota}</span></div>`:''}${esMia?html`<div class="gasto-item-meta enc-meta-mt3"><span class="enc-meta-txt"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="enc-meta-ico"><path fill-rule="evenodd" d="M1 11.5a.5.5 0 0 0 .5.5h11.793l-3.147 3.146a.5.5 0 0 0 .708.708l4-4a.5.5 0 0 0 0-.708l-4-4a.5.5 0 0 0-.708.708L13.293 11H1.5a.5.5 0 0 0-.5.5zm14-7a.5.5 0 0 1-.5.5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H14.5a.5.5 0 0 1 .5.5z"/></svg>Salió de <strong class="enc-c-text2">${miaSaleLbl}</strong>${miaEntraLbl?html` · Entró a <strong class="enc-c-text2">${miaEntraLbl}</strong>`:''}</span></div>`:''}`,
        meta: html`
          <span class="badge ${esEntrada?'bg-blue':esAbonoPrestamo?'bg-amber':esTcEncargo?'bg-blue':'bg-red'} enc-fs9">${esEntrada?'Entrada':esAbonoPrestamo?'Pago préstamo':esTcEncargo?'Pagado con TC':'Salida'}</span>
          ${esMia?html`<span class="badge enc-badge-yo">Yo puse la plata</span>`:''}
          ${m._grupo?raw(m._grupo.filter(x=>x.cuenta).map(x=>`<span class="badge ${fuenteBadgeClass(x.cuenta)} enc-fs9">${escHtml(fuenteLabel(x.cuenta))}</span>`).join('')):(lblCuenta?html`<span class="badge ${fuenteBadgeClass(m.cuenta)} enc-fs9">${lblCuenta}</span>`:'')}
          ${tcNombreLbl?html`<span class="badge bg-blue enc-fs9">${tcNombreLbl}</span>`:''}`,
        despues: raw(m && m.diferencial ? diffRenderHistorial(m.diferencial) : '')
      });
    });
    histEl.innerHTML = html`${contenido}`;
  }
}

/* ── PARTES COMPROMETIDAS DEL ENCARGO ─────────────────────────────────── */
let _parteEditId = null;

function renderEncargoParts(enc) {
  const el = document.getElementById('encargo-partes-lista');
  if (!el) return;
  const partes = (enc.partes || []).filter(p => !p.usada);
  const usadas = (enc.partes || []).filter(p => p.usada);
  const saldo = encargoSaldo(enc);
  const totalComp = encargoComprometido(enc);
  const libre = encargoLibre(enc);

  if (!partes.length && !usadas.length) {
    el.innerHTML = html`<div class="enc-sin-asignar">
      Toda la plata está sin asignar — <b class="enc-c-text2">tuyo para usar: ${fmt(saldo)}</b>.
      <br>Agrega partes para saber cuánto de este encargo ya tiene destino.
    </div>`;
    return;
  }

  // Resumen rápido
  const contenido = [];
  if (partes.length) {
    contenido.push(html`<div class="enc-comp-caja">
      <div>
        <div class="enc-comp-cap">Comprometido</div>
        <div class="enc-comp-rojo">-${fmt(totalComp)}</div>
      </div>
      <div class="enc-txt-der">
        <div class="enc-comp-cap">Libre (de él)</div>
        <div class="enc-comp-verde">+${fmt(libre)}</div>
      </div>
    </div>`);
  }

  // Lista activas
  contenido.push(partes.map(p => {
    const hoyStr = hoy();
    let fechaInfo = '';
    if (p.fecha) {
      const dias = Fecha.diasEntre(hoyStr, p.fecha);
      if (dias < 0) fechaInfo = `<span class="enc-venc-rojo">venció hace ${Math.abs(dias)}d</span>`;
      else if (dias === 0) fechaInfo = `<span class="enc-venc-rojo">hoy</span>`;
      else if (dias === 1) fechaInfo = `<span class="enc-venc-amber">mañana</span>`;
      else if (dias <= 5) fechaInfo = `<span class="enc-venc-amber">en ${dias}d (${p.fecha})</span>`;
      else fechaInfo = `<span class="enc-fecha-uso">uso: ${p.fecha}</span>`;
    }
    return html`<div class="card card-sm enc-part-card">
      <div class="enc-part-fila">
        <div class="enc-flex1-min0">
          <div class="enc-part-desc">${p.desc}</div>
          ${fechaInfo ? raw(`<div class="enc-part-fecha">${fechaInfo}</div>`) : ''}
        </div>
        <div class="enc-part-monto">${fmt(p.monto)}</div>
      </div>
      <div class="enc-part-btns">
        <button type="button" ${raw(Events.attr('encargos:usarParte', enc.id, p.id))} class="enc-btn-usar">
          <i class="fa-solid fa-check enc-ico-r4"></i>Ya la usé
        </button>
        <button type="button" ${raw(Events.attr('encargos:editarParte', enc.id, p.id))} class="enc-btn-edit">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button type="button" ${raw(Events.attr('encargos:eliminarParte', enc.id, p.id))} class="enc-btn-borrar">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>
    </div>`;
  }));

  // Usadas recientes
  if (usadas.length) {
    contenido.push(html`<div class="enc-usadas">
      ${usadas.slice(-3).reverse().map(p => html`<div class="card card-sm enc-usada-card">
      <div class="enc-usada-fila">
        <div class="enc-usada-desc">${p.desc}</div>
        <div class="enc-fila-g6">
          <span class="enc-usada-monto"><s>${fmt(p.monto)}</s></span>
          ${raw(typeof _difRenderHistorialParte === 'function' ? _difRenderHistorialParte(p) : '')}
          <button type="button" ${raw(Events.attr('encargos:eliminarParte', enc.id, p.id))} class="enc-usada-x">&#x2715;</button>
        </div>
      </div>
    </div>`)}
    </div>`);
  }

  el.innerHTML = html`${contenido}`;
}

function abrirNuevaParte() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  _parteEditId = null;
  document.getElementById('parte-sheet-title').textContent = 'Agregar parte';
  document.getElementById('parte-desc').value = '';
  document.getElementById('parte-monto').value = '';
  document.getElementById('parte-fecha').value = '';
  _actualizarPartePreview(enc);
  openSheet('parte-encargo');
  focusSheetField('parte-desc');
}

function editarParte(encId, parteId) {
  const enc = getEncargo(encId);
  if (!enc) return;
  const parte = (enc.partes || []).find(p => p.id === parteId);
  if (!parte) return;
  encargoActualId = encId;
  _parteEditId = parteId;
  document.getElementById('parte-sheet-title').textContent = 'Editar parte';
  document.getElementById('parte-desc').value = parte.desc || '';
  setMoneyInput('parte-monto', parte.monto);
  document.getElementById('parte-fecha').value = parte.fecha || '';
  _actualizarPartePreview(enc);
  openSheet('parte-encargo');
}

function _actualizarPartePreview(enc) {
  const prevEl = document.getElementById('parte-balance-preview');
  if (!prevEl) return;
  const saldo = encargoSaldo(enc);
  const partes = (enc.partes || []).filter(p => !p.usada && p.id !== _parteEditId);
  const yaComp = partes.reduce((a, p) => a + (p.monto || 0), 0);
  const libre = Math.max(0, saldo - yaComp);
  prevEl.textContent = 'Saldo del encargo: ' + fmt(saldo) + ' · Ya comprometido: ' + fmt(yaComp) + ' · Libre: ' + fmt(libre);
}

function cerrarPartSheet() {
  _parteEditId = null;
}

function guardarParte() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const desc = (document.getElementById('parte-desc').value || '').trim();
  if (!desc) { toast('Escribe para qué es', 'err'); return; }
  const montoStr = document.getElementById('parte-monto').value || '';
  const monto = typeof parseMoney === 'function' ? parseMoney(montoStr) : parseFloat(montoStr.replace(/\./g, '').replace(',', '.'));
  if (!monto || monto <= 0) { toast('Ingresa el monto', 'err'); return; }
  const fecha = document.getElementById('parte-fecha').value || '';

  // Validar que no sobrepase el saldo
  const saldo = encargoSaldo(enc);
  const otrasPartes = (enc.partes || []).filter(p => !p.usada && p.id !== _parteEditId).reduce((a, p) => a + (p.monto || 0), 0);
  if (otrasPartes + monto > saldo + 0.01) {
    toast('El total comprometido supera el saldo del encargo (' + fmt(saldo) + ')', 'err'); return;
  }

  if (!enc.partes) enc.partes = [];
  if (_parteEditId) {
    const p = enc.partes.find(x => x.id === _parteEditId);
    if (p) { p.desc = desc; p.monto = monto; p.fecha = fecha; }
    toast('Parte actualizada', 'ok');
  } else {
    enc.partes.push({ id: uid(), desc, monto, fecha, usada: false, creadaEn: hoy() });
    toast('Parte agregada', 'ok');
  }
  save();
  closeSheet('parte-encargo');
  _parteEditId = null;
  abrirEncargoDetalle(encargoActualId);
}

async function usarParte(encId, parteId) {
  // Abre el sheet de "Ya la usé" con opción de diferencial
  abrirUsarParteSheet(encId, parteId);
}

async function eliminarParte(encId, parteId) {
  const enc = getEncargo(encId);
  if (!enc) return;
  const ok = await confirmarEliminar({ titulo: 'Eliminar parte', objeto: 'esta parte del registro', irreversible: false });
  if (!ok) return;
  enc.partes = (enc.partes || []).filter(p => p.id !== parteId);
  save();
  abrirEncargoDetalle(encId);
  toast('Parte eliminada', 'ok');
}

// Partes del encargo: las pinta abrirEncargoDetalle() al terminar de armar el detalle.
function _encDetallePartes(enc) {
  renderEncargoParts(enc);
  // Listener para preview en tiempo real del monto
  const montoInput = document.getElementById('parte-monto');
  if (montoInput && !montoInput._parteListenerAdded) {
    montoInput.addEventListener('input', () => {
      const e = getEncargo(encargoActualId);
      if (e) _actualizarPartePreview(e);
    });
    montoInput._parteListenerAdded = true;
  }
}

function volverEncargosLista() {
  encargoActualId = null;
  document.getElementById('encargoDetalle').style.display = 'none';
  document.getElementById('encargosListView').style.display = '';
  renderEncargosList();
}

function crearEncargo() {
  // personaId es obligatorio: no debe existir un encargo sin persona vinculada (enc_nombre se llena al elegirla).
  const pId = _encPicker().valor;
  if (!pId) { toast('Selecciona una persona', 'err'); return; }
  const persona = getPersona(pId);
  const nombre = persona ? persona.nombre : document.getElementById('enc_nombre').value.trim();
  if (!nombre) { toast('Ingresa el nombre de la persona', 'err'); return; }
  const saldoIni = parseMoney(document.getElementById('enc_saldo').value)||0;
  const cuentaIni = document.getElementById('enc_cuenta_ini').value || '';
  const nota = document.getElementById('enc_nota').value.trim();
  if (!S.encargos) S.encargos = [];
  S.encargos.push({
    id: uid(),
    personaId: pId,
    nombre,
    nota,
    saldoInicial: saldoIni,
    cuentaInicial: cuentaIni,
    fechaCreacion: hoy(),
    movimientos: []
  });
  document.getElementById('enc_nombre').value = '';
  document.getElementById('enc_saldo').value = '';
  document.getElementById('enc_nota').value = '';
  document.getElementById('enc_cuenta_ini').value = '';
  document.getElementById('enc_cuenta_wrap').style.display = 'none';
  _encPicker().limpiar();
  save(); renderEncargosList();
  closeSheet('nuevo-encargo');
  if(window.logCambio) logCambio('Creaste un encargo',nombre,'','editar');
  toast('Encargo creado', 'ok');
}

/* ═══════════════════════════════════════════════════════════════
   INSTANCIA 1 — "Salió plata" de un encargo (movenc-dif)
   ═══════════════════════════════════════════════════════════════ */

// Split (Dividir) del sobrante del margen: true cuando el usuario repartió lo que sobra
// entre varias cuentas suyas en vez de una sola. Ver crearSplitWidget('movencDifMi') abajo.
let _difMiSplitMode = false;

const _dif_movenc = diffRegistrarInstancia('movenc', {
  ids: {
    wrap: 'movenc-dif-wrap', body: 'movenc-dif-body', icon: 'movenc-dif-toggle-icon',
    real: 'movenc_dif_real', partesList: 'movenc-dif-beneficiarios',
    resumen: 'movenc-dif-resumen', miCuentaWrap: 'movenc-dif-mi-cuenta-wrap', miCuenta: 'movenc_dif_mi_cuenta'
  },
  permiteBeneficiarios: true,
  permiteIntercambio: true,
  permiteMiCuenta: true,
  getDijo: () => parseMoney(document.getElementById('movenc_monto')?.value) || 0,
  descMargen: () => 'Margen de encargo — ',
  origenSeccion: 'Encargos', // margen/intercambios protegidos contra borrado suelto (ver diferencial.js)
  getMiCuentaSplit: () => _difMiSplitMode ? splitGetData('movencDifMi') : null,
  onReset: () => splitReset('movencDifMi'),
  onResumen: () => _difMiSplitPreview()
});

const _sp_movencDifMi = crearSplitWidget('movencDifMi', {
  simpleId: 'movenc_dif_mi_simple', splitId: 'movenc_dif_mi_split', toggleId: 'movenc_dif_mi_toggle', rowsId: 'movencDifMiRows',
  getModo: () => _difMiSplitMode, setModo: v => { _difMiSplitMode = v; },
  getFuentesFn: sel => opcionesCuenta({ selectedVal: sel, placeholder: 'Elegir cuenta' }),
  onPreview: () => _difMiSplitPreview()
});

function _difMiSplitPreview() {
  const el = document.getElementById('movenc_dif_mi_preview');
  if (!el) return;
  if (!_difMiSplitMode) { el.textContent = ''; return; }
  const calc = diffCalcular('movenc');
  const sobra = calc ? Math.max(0, calc.sinAsignar) : 0;
  const filas = splitGetData('movencDifMi');
  if (!filas.length) { el.textContent = sobra > 0.5 ? `Repartí ${fmt(sobra)} entre tus cuentas` : ''; el.style.color = 'var(--text3)'; return; }
  const total = filas.reduce((a, r) => a + r.monto, 0);
  const lineas = filas.map(r => `${r.fuente ? fuenteLabel(r.fuente) : '?'}: ${fmt(r.monto)}`).join(' · ');
  const resto = sobra - total;
  if (sobra <= 0.5)      { el.textContent = lineas; el.style.color = 'var(--text2)'; }
  else if (resto > 0.5)  { el.textContent = lineas + ` · Sin asignar: ${fmt(resto)}`; el.style.color = 'var(--amber)'; }
  else if (resto < -0.5) { el.textContent = lineas + ` · Excede: ${fmt(-resto)}`; el.style.color = 'var(--red)'; }
  else                   { el.textContent = lineas + ' \u2713'; el.style.color = 'var(--accent)'; }
}

// Wrappers con los nombres viejos — el HTML del sheet sigue llamándolos igual, cero cambios de markup

/* ─── "Yo puse la plata" — intercambio simple sin diferencial ─────
   Para cuando lo que dijiste = lo real, pero la plata no salió de la
   cuenta del encargo elegida arriba sino de tu bolsillo, y quieres
   recuperar ese monto del encargo en una de tus cuentas.
   Genera el mismo par de transferencias _intercambioSalida/_intercambioEntrada
   que el sistema de "lo pagué yo" del diferencial, pero por el monto total
   del movimiento y sin tocar _difBenefs.
   ═══════════════════════════════════════════════════════════════ */

function _movEncMiaToggle() {
  const body = document.getElementById('movenc-mia-body');
  const icon = document.getElementById('movenc-mia-icon');
  if (!body) return;
  const abierto = body.style.display !== 'none';
  body.style.display = abierto ? 'none' : '';
  if (icon) icon.style.transform = abierto ? '' : 'rotate(180deg)';
  if (!abierto) {
    const saleSel  = document.getElementById('movenc_mia_cuenta_sale');
    const entraSel = document.getElementById('movenc_mia_cuenta_entra');
    if (saleSel)  saleSel.innerHTML  = _diffFuentesOptsHtml(saleSel.value, true);
    if (entraSel) entraSel.innerHTML = _diffFuentesOptsHtml(entraSel.value, false);
    _movEncMiaPreview();
  }
}

/* Split (Dividir) de "Yo puse la plata": el monto total puede haber salido de
   varias cuentas tuyas y/o recuperarse en varias. Cada lado tiene su propio widget. */
let _miaSaleSplitMode  = false;
let _miaEntraSplitMode = false;

const _sp_miaSale = crearSplitWidget('miaSale', {
  simpleId: 'movenc_mia_sale_simple', splitId: 'movenc_mia_sale_split', toggleId: 'movenc_mia_sale_toggle', rowsId: 'miaSaleRows',
  getModo: () => _miaSaleSplitMode, setModo: v => { _miaSaleSplitMode = v; },
  getFuentesFn: sel => _diffFuentesOptsHtml(sel, true),
  onPreview: () => _movEncMiaPreview()
});
const _sp_miaEntra = crearSplitWidget('miaEntra', {
  simpleId: 'movenc_mia_entra_simple', splitId: 'movenc_mia_entra_split', toggleId: 'movenc_mia_entra_toggle', rowsId: 'miaEntraRows',
  getModo: () => _miaEntraSplitMode, setModo: v => { _miaEntraSplitMode = v; },
  getFuentesFn: sel => _diffFuentesOptsHtml(sel, false),
  onPreview: () => _movEncMiaPreview()
});

// Monto que realmente puso el usuario de su bolsillo (2026-09-30): si el bloque
// "El valor real era diferente" está abierto y el real es válido (0 < real < monto),
// "Yo puse la plata" trabaja con el REAL (lo que costó de verdad), no con el monto
// cobrado. La diferencia (margen) la maneja el diferencial como ganancia tuya; si
// acá también se usara el monto total, ese margen se contaría dos veces.
function _miaMontoEfectivo(montoCampo) {
  if (typeof diffEstaAbierto === 'function' && diffEstaAbierto('movenc')) {
    const c = diffCalcular('movenc');
    if (c && c.real > 0 && c.real < montoCampo) return c.real;
  }
  return montoCampo;
}

// Lee las cuentas de cada lado como listas [{fuente, monto}], sea modo simple (una fila
// con el monto total) o dividido (las filas que puso el usuario).
function _miaLeerCuentas(monto) {
  const saleSel  = document.getElementById('movenc_mia_cuenta_sale');
  const entraSel = document.getElementById('movenc_mia_cuenta_entra');
  return {
    sale:  _miaSaleSplitMode  ? splitGetData('miaSale')  : [{ fuente: saleSel  ? saleSel.value  : '', monto }],
    entra: _miaEntraSplitMode ? splitGetData('miaEntra') : [{ fuente: entraSel ? entraSel.value : '', monto }]
  };
}

function _miaResumenLado(filas, monto, dividido) {
  const txt = filas.map(r => `${r.fuente ? fuenteLabel(r.fuente) : '?'} ${fmt(r.monto)}`).join(' + ') || '?';
  if (!dividido || !filas.length) return txt;
  const resto = monto - filas.reduce((a, r) => a + r.monto, 0);
  if (resto > 0.5)  return `${txt} (sin asignar ${fmt(resto)})`;
  if (resto < -0.5) return `${txt} (excede ${fmt(-resto)})`;
  return `${txt} \u2713`;
}

function _movEncMiaPreview() {
  const el = document.getElementById('movenc-mia-preview');
  if (!el) return;
  const monto = _miaMontoEfectivo(parseMoney(document.getElementById('movenc_monto').value) || 0);
  if (!monto) { el.textContent = ''; return; }
  const { sale, entra } = _miaLeerCuentas(monto);
  if (!_miaSaleSplitMode && !_miaEntraSplitMode) {
    const saleTxt  = sale[0].fuente  ? fuenteLabel(sale[0].fuente)  : '?';
    const entraTxt = entra[0].fuente ? fuenteLabel(entra[0].fuente) : '?';
    el.innerHTML = html`Sale ${fmt(monto)} de ${saleTxt} · Recupero ${fmt(monto)} en ${entraTxt}`;
  } else {
    el.innerHTML = html`Sale ${_miaResumenLado(sale, monto, _miaSaleSplitMode)} · Recupero ${_miaResumenLado(entra, monto, _miaEntraSplitMode)}`;
  }
}

function _validarMovEncMia() {
  const body = document.getElementById('movenc-mia-body');
  if (!body || body.style.display === 'none') return null;
  const monto = _miaMontoEfectivo(parseMoney(document.getElementById('movenc_monto').value) || 0);
  if (!monto) return null;
  const { sale, entra } = _miaLeerCuentas(monto);

  if (_miaSaleSplitMode) {
    if (!sale.length) return 'Repartí de qué cuentas tuyas salió la plata';
    if (sale.some(r => !r.fuente)) return 'Elige la cuenta en cada fila de "sale"';
    const total = sale.reduce((a, r) => a + r.monto, 0);
    if (Math.abs(total - monto) > 0.5) return `Lo que sale de tus cuentas (${fmt(total)}) tiene que ser igual al monto (${fmt(monto)})`;
  } else if (!sale[0].fuente) {
    return 'Elige de qué cuenta tuya salió la plata';
  }
  for (const r of sale) {
    const val = Plata.validarSalida(r.fuente, r.monto);
    if (!val.ok) return val.motivo;
  }

  // Recupero: sin filas = "sin especificar" (igual que el modo simple con la opción vacía)
  if (_miaEntraSplitMode && entra.length) {
    if (entra.some(r => !r.fuente)) return 'Elige la cuenta en cada fila de "recupero"';
    const total = entra.reduce((a, r) => a + r.monto, 0);
    if (Math.abs(total - monto) > 0.5) return `Lo que recuperas (${fmt(total)}) tiene que ser igual al monto (${fmt(monto)})`;
  }
  return null;
}

function _procesarMovEncMia(movimiento) {
  const body = document.getElementById('movenc-mia-body');
  if (!body || body.style.display === 'none') return;
  // Monto TOTAL del campo, no movimiento.monto: en una salida dividida entre cuentas
  // del encargo, `movimiento` es solo la primera porción y "Yo puse" cubre el gasto entero.
  const monto = _miaMontoEfectivo(parseMoney(document.getElementById('movenc_monto').value) || movimiento.monto);
  const { sale, entra } = _miaLeerCuentas(monto);
  const salidas  = sale.filter(r => r.fuente && r.monto > 0);
  const entradas = entra.filter(r => r.fuente && r.monto > 0);
  if (!salidas.length) return;
  const fecha = movimiento.fecha || hoy();
  if (!S.movimientos) S.movimientos = [];
  const destinoUnico = entradas.length === 1 ? entradas[0].fuente : '';
  const origenUnico  = salidas.length === 1 ? salidas[0].fuente : '';
  let k = 1;

  // Egresos de mis cuentas propias (lo que puse de mi bolsillo) — uno por cuenta
  salidas.forEach(r => {
    descontarFuente(r.fuente, r.monto, _ogEnc(movimiento.id));
    S.movimientos.push({
      id: uid(),
      tipo: 'transferencia',
      fuente: r.fuente,
      _fuenteDestino: destinoUnico,
      _encMovId: movimiento.id,
      clase: 'neutro',
      _esIntercambioEncargo: true,
      _intercambioSalida: true,
      _secundario: true,
      _origenSeccion: 'Encargos',
      monto: r.monto,
      fecha,
      desc: `Yo puse la plata: ${movimiento.desc || ''}`,
      nota: `Salida de ${fuenteLabel(r.fuente)} — generado automáticamente al registrar "Yo puse la plata" en encargo.`,
      ts: Date.now() + k++
    });
  });

  // Ingresos a mis cuentas destino (lo que recupero del encargo) — uno por cuenta
  entradas.forEach(r => {
    sumarFuente(r.fuente, r.monto, _ogEnc(movimiento.id));
    S.movimientos.push({
      id: uid(),
      tipo: 'transferencia',
      fuente: r.fuente,
      _fuenteDestino: origenUnico,
      _encMovId: movimiento.id,
      clase: 'neutro',
      _esIntercambioEncargo: true,
      _intercambioEntrada: true,
      _secundario: true,
      _origenSeccion: 'Encargos',
      monto: r.monto,
      fecha,
      desc: `Recupero de encargo: ${movimiento.desc || ''}`,
      nota: `Entrada a ${fuenteLabel(r.fuente)} — generado automáticamente al registrar "Yo puse la plata" en encargo.`,
      ts: Date.now() + k++
    });
  });

  movimiento._miaCuentaSale = salidas[0].fuente;
  movimiento._miaMonto = monto; // lo que puse de mi bolsillo (puede ser menor al monto del movimiento si hay diferencial)
  if (entradas.length) movimiento._miaCuentaEntra = entradas[0].fuente;
  if (salidas.length > 1 || entradas.length > 1) {
    movimiento._miaCuentas = {
      sale:  salidas.map(r => ({ cuenta: r.fuente, monto: r.monto })),
      entra: entradas.map(r => ({ cuenta: r.fuente, monto: r.monto }))
    };
  }
}

function _procesarDiferencial(movimiento) {
  diffAplicar('movenc', movimiento, movimiento.id);
}


/* ─── Diferencial en "Ya la usé" ────────────────────────────── */
/* ─── Diferencial en "Ya la usé" — instancia del motor común ───── */
let _usarParteEncId = null;
let _usarParteId    = null;

/* ─── Split (Dividir) del sobrante del margen — fábrica para "Ya la usé" y "Compra con TC" ───
   Mismo comportamiento que el de "Registrar salida" (movencDifMi): el usuario reparte lo que
   sobra entre varias cuentas suyas. ids: {simple, split, toggle, rows, preview} (elementos del sheet). */
function _crearSplitSobrante(instId, key, ids) {
  let modo = false;
  const ctl = {
    activo: () => modo,
    // [{fuente,monto}] si "Dividir" está activo; null si está en modo "una sola cuenta"
    getData: () => modo ? splitGetData(key) : null,
    reset: () => splitReset(key),
    toggle: () => splitToggle(key),
    agregar: () => splitAgregarRow(key),
    preview() {
      const el = document.getElementById(ids.preview);
      if (!el) return;
      if (!modo) { el.textContent = ''; return; }
      const calc = diffCalcular(instId);
      const sobra = calc ? Math.max(0, calc.sinAsignar) : 0;
      const filas = splitGetData(key);
      if (!filas.length) { el.textContent = sobra > 0.5 ? `Repartí ${fmt(sobra)} entre tus cuentas` : ''; el.style.color = 'var(--text3)'; return; }
      const total = filas.reduce((a, r) => a + r.monto, 0);
      const lineas = filas.map(r => `${r.fuente ? fuenteLabel(r.fuente) : '?'}: ${fmt(r.monto)}`).join(' · ');
      const resto = sobra - total;
      if (sobra <= 0.5)      { el.textContent = lineas; el.style.color = 'var(--text2)'; }
      else if (resto > 0.5)  { el.textContent = lineas + ` · Sin asignar: ${fmt(resto)}`; el.style.color = 'var(--amber)'; }
      else if (resto < -0.5) { el.textContent = lineas + ` · Excede: ${fmt(-resto)}`; el.style.color = 'var(--red)'; }
      else                   { el.textContent = lineas + ' \u2713'; el.style.color = 'var(--accent)'; }
    }
  };
  crearSplitWidget(key, {
    simpleId: ids.simple, splitId: ids.split, toggleId: ids.toggle, rowsId: ids.rows,
    getModo: () => modo, setModo: v => { modo = v; },
    getFuentesFn: sel => opcionesCuenta({ selectedVal: sel, placeholder: 'Elegir cuenta' }),
    onPreview: () => ctl.preview()
  });
  return ctl;
}

const _usarParteMi = _crearSplitSobrante('usarParte', 'usarParteMi', {
  simple: 'usar_parte_dif_mi_simple', split: 'usar_parte_dif_mi_split', toggle: 'usar_parte_dif_mi_toggle',
  rows: 'usarParteDifMiRows', preview: 'usar_parte_dif_mi_preview'
});
function _usarParteMiSplitToggle() { _usarParteMi.toggle(); }
function _usarParteMiAgregarRow() { _usarParteMi.agregar(); }

const _dif_usarParte = diffRegistrarInstancia('usarParte', {
  ids: {
    wrap: 'usar-parte-dif-wrap', body: 'usar-parte-dif-body', icon: 'usar-parte-dif-icon',
    real: 'usar_parte_dif_real', partesList: 'usar-parte-dif-benefs',
    resumen: 'usar-parte-dif-resumen', miCuentaWrap: 'usar-parte-dif-mi-cuenta-wrap', miCuenta: 'usar_parte_dif_mi_cuenta'
  },
  permiteBeneficiarios: true,
  permiteIntercambio: false, // "Ya la usé" no soporta intercambio "lo pagué yo" — el dinero ya estaba en el encargo
  permiteMiCuenta: true,
  // El "dijo" de esta instancia viene de la parte del encargo, no de un input del DOM
  getDijo: () => {
    const enc = _usarParteEncId ? getEncargo(_usarParteEncId) : null;
    const parte = enc ? (enc.partes || []).find(p => p.id === _usarParteId) : null;
    return parte ? (parte.monto || 0) : 0;
  },
  descMargen: (mov) => `Margen encargo ${mov._encNombre || ''} — `,
  getMiCuentaSplit: () => _usarParteMi.getData(),
  onReset: () => _usarParteMi.reset(),
  onResumen: () => _usarParteMi.preview()
});

// Wrappers con los nombres viejos — el HTML del sheet sigue llamándolos igual

/* ─── Fuente (origen) en "Ya la usé" ──────────────────────────── */
let _usarParteSplitMode = false;
let _usarParteMargenPendiente = null;

const _sp_usarParte = crearSplitWidget('usarParte', {
  simpleId:'usarParteModoSimple', splitId:'usarParteModoDividido', toggleId:'usarParteSplitToggle', rowsId:'usarParteSplitRows',
  getModo:()=>_usarParteSplitMode, setModo:v=>{_usarParteSplitMode=v;},
  fuentes:_usarParteFuentes,
  onPreview:_usarParteFuentePreview
});


// Solo las cuentas donde el encargo tiene plata guardada.
function _usarParteFuentes() {
  const enc = _usarParteEncId ? getEncargo(_usarParteEncId) : null;
  return { mostrarSaldo: true, soloDe: enc ? _getEncargoSaldoPorCuenta(enc) : [] };
}



function _usarParteFuentePreview() {
  const el = document.getElementById('usar-parte-fuente-preview');
  if (!el) return;
  const enc = _usarParteEncId ? getEncargo(_usarParteEncId) : null;
  const parte = enc ? (enc.partes || []).find(p => p.id === _usarParteId) : null;
  const monto = parte ? (parte.monto || 0) : 0;
  if (!monto) { el.textContent = ''; return; }

  if (_usarParteSplitMode) {
    const splits = _sp_usarParte.data();
    const total = splits.reduce((a, s) => a + s.monto, 0);
    const restante = monto - total;
    if (splits.length === 0) { el.textContent = ''; return; }
    let lines = splits.map(s => `${s.fuente ? fuenteLabel(s.fuente) : 'Sin esp.'}: ${fmt(s.monto)}`).join(' · ');
    if (restante > 0) { el.textContent = lines + ` · Sin asignar: ${fmt(restante)}`; el.style.color = 'var(--amber)'; }
    else if (restante < -0.5) { el.textContent = lines + ` · Excede: ${fmt(-restante)}`; el.style.color = 'var(--red)'; }
    else { el.textContent = lines + ' &#x2713;'; el.style.color = 'var(--accent)'; }
  } else {
    const sel = document.getElementById('usar_parte_fuente');
    const val = sel ? sel.value : '';
    if (val) {
      const enc2 = _usarParteEncId ? getEncargo(_usarParteEncId) : null;
      const saldoEnc = enc2 ? _getEncargoSaldoEnCuenta(enc2, val) : 0;
      el.innerHTML = html`Del encargo guardado en ${fuenteLabel(val)}: <span class="enc-c-text">${fmt(saldoEnc)}</span>`;
      el.style.color = 'var(--text2)';

    } else {
      el.textContent = '';
    }
  }
}


async function _confirmarUsarParte() {
  const enc = getEncargo(_usarParteEncId);
  if (!enc) return;
  const parte = (enc.partes || []).find(p => p.id === _usarParteId);
  if (!parte) return;

  // Leer origen de la plata (fuente simple o split)
  let fuentesOrigen = [];
  if (_usarParteSplitMode) {
    fuentesOrigen = _sp_usarParte.data();
  } else {
    const sel = document.getElementById('usar_parte_fuente');
    const val = sel ? sel.value : '';
    if (val) fuentesOrigen = [{ fuente: val, monto: parte.monto }];
  }

  // Validar que el saldo del encargo en esa cuenta alcance
  for (const f of fuentesOrigen) {
    if (!f.fuente) continue;
    const saldoEnc = _getEncargoSaldoEnCuenta(enc, f.fuente);
    if (f.monto > saldoEnc + 0.5) {
      toast(`El encargo solo tiene ${fmt(saldoEnc)} guardado en ${fuenteLabel(f.fuente)}`, 'err');
      return;
    }
  }

  // Validar el reparto del sobrante (si usó "Dividir") ANTES de tocar ningún saldo
  const _errMiSplit = diffValidarMiCuenta('usarParte');
  if (_errMiSplit) { toast(_errMiSplit, 'err', 5000); return; }

  // Guardar diferencial y mover margen a cuenta propia si aplica — vía el motor común.
  // Nota: el sumarFuente/push del margen se difiere a _usarParteMargenPendiente (ver más abajo)
  // para que su uid() salga después de los movimientos de salida del encargo, igual que antes.
  if (diffEstaAbierto('usarParte')) {
    const calc = diffCalcular('usarParte');
    if (calc.real > 0) {
      const { dijo, real, margen, normales, asignadoNormal } = calc;
      const benefs = normales.map(b => ({ nombre: b.nombre, monto: b.monto }));
      const yoMeQuedo = Math.max(0, margen - asignadoNormal);

      // Reparto del sobrante: filas de "Dividir" si está activo, si no el select único
      const repartoMi = _usarParteMi.getData();
      const filasMi = repartoMi ? repartoMi.filter(r => r.fuente && r.monto > 0) : null;
      const miCuentaSel = document.getElementById('usar_parte_dif_mi_cuenta');
      const miCuenta = filasMi ? (filasMi[0] ? filasMi[0].fuente : '') : (miCuentaSel ? miCuentaSel.value : '');
      const yoMeQuedoFinal = filasMi ? Math.min(filasMi.reduce((a, r) => a + r.monto, 0), yoMeQuedo) : yoMeQuedo;
      const aplicaMi = !!miCuenta && yoMeQuedoFinal > 0.5;

      parte.diferencial = {
        dijo, real, margen,
        beneficiarios: benefs,
        miCuenta: aplicaMi ? miCuenta : '',
        yoMeQuedo: aplicaMi ? yoMeQuedoFinal : 0
      };
      if (aplicaMi && filasMi && filasMi.length > 1) {
        parte.diferencial.miCuentas = filasMi.map(r => ({ cuenta: r.fuente, monto: r.monto }));
      }

      if (aplicaMi) {
        const destinosMi = (filasMi && filasMi.length) ? filasMi : [{ fuente: miCuenta, monto: yoMeQuedo }];
        destinosMi.forEach(r => sumarFuente(r.fuente, r.monto, _ogEnc(parte.id)));
        _usarParteMargenPendiente = destinosMi.map(r => ({ fuente: r.fuente, monto: r.monto }));
      }
    }
  }

  // Guardar origen en la parte
  if (fuentesOrigen.length === 1 && fuentesOrigen[0].fuente) {
    parte.fuente = fuentesOrigen[0].fuente;
    delete parte.fuentes;
  } else if (fuentesOrigen.length > 1) {
    parte.fuentes = fuentesOrigen;
    delete parte.fuente;
  }

  // Registrar la salida en los movimientos del encargo (descuenta del saldo del encargo en esa cuenta)
  if (fuentesOrigen.length > 0) {
    if (!enc.movimientos) enc.movimientos = [];
    if (fuentesOrigen.length === 1 && fuentesOrigen[0].fuente) {
      enc.movimientos.push({
        id: uid(),
        tipo: 'salida',
        monto: parte.monto,
        cuenta: fuentesOrigen[0].fuente,
        desc: `Parte usada: ${parte.desc}`,
        fecha: hoy(),
        _parteId: parte.id
      });
    } else if (fuentesOrigen.length > 1) {
      fuentesOrigen.forEach(f => {
        if (f.fuente && f.monto > 0) {
          enc.movimientos.push({
            id: uid(),
            tipo: 'salida',
            monto: f.monto,
            cuenta: f.fuente,
            desc: `Parte usada: ${parte.desc}`,
            fecha: hoy(),
            _parteId: parte.id
          });
        }
      });
    }
  }

  parte.usada = true;
  parte.usadaEn = hoy();

  // Registrar el ingreso del margen al final, para que su uid() sea mayor que los de salida del encargo
  if (_usarParteMargenPendiente) {
    if (!S.movimientos) S.movimientos = [];
    _usarParteMargenPendiente.forEach(({ fuente, monto }) => {
      S.movimientos.push({
        id: uid(),
        tipo: 'entrada',
        fuente,
        monto,
        fecha: hoy(),
        desc: `Margen encargo ${enc.nombre} — ${parte.desc}`,
        clase: 'ingreso',
        _esExtraIngreso: true   // margen = plata nueva tuya (ver _esEntradaEspejoNoIngreso)
      });
    });
    _usarParteMargenPendiente = null;
  }

  save();
  closeSheet('usar-parte');
  abrirEncargoDetalle(_usarParteEncId);
  toast('Listo — esa parte ya no está comprometida', 'ok');
}

function abrirUsarParteSheet(encId, parteId) {
  const enc = getEncargo(encId);
  if (!enc) return;
  const parte = (enc.partes || []).find(p => p.id === parteId);
  if (!parte) return;
  _usarParteEncId = encId;
  _usarParteId = parteId;

  const infoEl = document.getElementById('usar-parte-info');
  if (infoEl) infoEl.textContent = `"${escHtml(parte.desc)}" · Le dijiste: ${fmt(parte.monto)}`;

  // Reset fuente/split
  _usarParteSplitMode = false;
  document.getElementById('usarParteModoSimple').style.display = '';
  document.getElementById('usarParteModoDividido').style.display = 'none';
  document.getElementById('usarParteSplitRows').innerHTML = '';
  const splitBtn = document.getElementById('usarParteSplitToggle');
  if (splitBtn) {
    splitBtn.textContent = 'Dividir';
    splitBtn.style.background = 'rgba(200,240,96,.1)';
    splitBtn.style.borderColor = 'rgba(200,240,96,.3)';
    splitBtn.style.color = 'var(--accent)';
  }
  // Poblar select con fuentes, preseleccionando la de mayor saldo en el encargo
  const sel = document.getElementById('usar_parte_fuente');
  if (sel) {
    sel.innerHTML = opcionesCuenta(_usarParteFuentes());
    // Preseleccionar la cuenta con más saldo del encargo
    const cuentasConSaldo = _getEncargoSaldoPorCuenta(enc);
    if (cuentasConSaldo.length > 0) {
      sel.value = cuentasConSaldo[0].cuenta;
    }
    sel.onchange = _usarParteFuentePreview;
  }
  const prevEl = document.getElementById('usar-parte-fuente-preview');
  if (prevEl) { prevEl.textContent = ''; }
  _usarParteFuentePreview();

  // Reset diferencial
  diffReset('usarParte');

  openSheet('usar-parte');
}

function _difRenderHistorialParte(parte) {
  const out = [];
  // Mostrar origen de la plata si se registró
  if (parte.fuentes && parte.fuentes.length > 0) {
    const labels = parte.fuentes.map(f => `${fuenteLabel(f.fuente)} ${fmt(f.monto)}`).join(' + ');
    out.push(html`<span class="enc-tag-azul"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="enc-ico-11"><path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/></svg> ${labels}</span>`);
  } else if (parte.fuente) {
    out.push(html`<span class="enc-tag-azul"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="enc-ico-11"><path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/></svg> ${fuenteLabel(parte.fuente)}</span>`);
  }
  // Mostrar diferencial si existe
  if (parte.diferencial) {
    const d = parte.diferencial;
    const benefs = (d.beneficiarios || []).filter(b => b.nombre).map(b =>
      `${b.nombre} ${fmt(b.monto)}`
    ).join(' · ');
    const miParte = (d.miCuentas && d.miCuentas.length > 1 && d.yoMeQuedo > 0)
      ? `Yo (${d.miCuentas.map(r => `${fuenteLabel(r.cuenta)} ${fmt(r.monto)}`).join(' + ')})`
      : (d.miCuenta && d.yoMeQuedo > 0 ? `Yo (${fuenteLabel(d.miCuenta)}) ${fmt(d.yoMeQuedo)}` : '');
    const todas = [benefs, miParte].filter(Boolean).join(' · ');
    out.push(html`<span class="enc-tag-amber"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="enc-ico-15"><path d="M8 1a.5.5 0 0 1 .5.5V2h1a.75.75 0 0 1 0 1.5H8.5v1h.75a2.25 2.25 0 0 1 0 4.5H8.5V10h1a.75.75 0 0 1 0 1.5H8.5v.5a.5.5 0 0 1-1 0V11.5H6.75a.75.75 0 0 1 0-1.5H7.5V9H6.5A2.25 2.25 0 0 1 4.25 6.75v-.5A.75.75 0 0 1 5 5.5h2.5V4H6.5a.75.75 0 0 1 0-1.5H7.5V1.5A.5.5 0 0 1 8 1zM5.75 6.75A.75.75 0 0 0 6.5 7.5H7.5V6H6.5a.75.75 0 0 0-.75.75zM8.5 9v1.5h.25A.75.75 0 0 0 8.5 9z"/><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.2"/></svg> margen ${fmt(d.margen)}${todas ? ': ' + todas : ''}</span>`);
  }
  return html`${out}`;
}

function abrirMovEncargo(tipo) {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  movEncargoTipo = tipo;
  const saldo = encargoSaldo(enc);
  const comprometido = encargoComprometido(enc);
  const libre = encargoLibre(enc);
  if (tipo === 'salida' && libre <= 0) {
    toast(comprometido > 0 ? 'Toda la plata de este encargo ya está comprometida' : 'El encargo no tiene saldo disponible', 'err');
    return;
  }
  document.getElementById('movEncTitle').textContent = tipo==='entrada'?'Registrar entrada de plata':'Registrar salida de plata';
  document.getElementById('movEncNombre').textContent = enc.nombre;
  document.getElementById('movEncSaldo').textContent = (tipo === 'salida' && comprometido > 0)
    ? fmt(libre) + ' disponible (de ' + fmt(saldo) + ', ' + fmt(comprometido) + ' comprometido)'
    : fmt(tipo === 'salida' ? libre : saldo);
  document.getElementById('movenc_desc').value = '';
  document.getElementById('movenc_monto').value = '';
  document.getElementById('movenc_nota').value = '';
  document.getElementById('movenc_fecha').value = hoy();

  // Resetear modo split
  _movEncSplitMode = false;
  const splitToggleBtn = document.getElementById('movenc_split_toggle');
  const simpleModo     = document.getElementById('movenc_cuenta_simple');
  const splitModo      = document.getElementById('movenc_cuenta_split');
  const splitPreview   = document.getElementById('movenc_split_preview');
  if (splitToggleBtn) { splitToggleBtn.textContent = 'Dividir'; splitToggleBtn.style.background='rgba(200,240,96,.1)'; splitToggleBtn.style.borderColor='rgba(200,240,96,.3)'; splitToggleBtn.style.color='var(--accent)'; }
  if (simpleModo) simpleModo.style.display = '';
  if (splitModo)  { splitModo.style.display = 'none'; document.getElementById('movencSplitRows').innerHTML = ''; }
  if (splitPreview) splitPreview.textContent = '';

  // Poblar select de cuentas (modo simple)
  const sel = document.getElementById('movenc_cuenta');
  const _movEncHintEl = document.getElementById('movenc_cuenta_hint');
  // true cuando el select ya pinta el saldo en cada <option> — en ese caso el
  // hint de abajo sería redundante. Ver reglas-visuales.md#selectores-con-saldo.
  let _movEncMuestraSaldoEnOpcion = false;

  // Cambiar label según tipo y mostrar/ocultar botón dividir
  const label = document.getElementById('movenc_cuenta_label');
  if (tipo === 'entrada') {
    // Entrada: mostrar fuentes reales (sin TC — no se puede guardar plata ajena en una TC)
    const fuentes = getFuentesSinTC();
    // FIX (2026-08-15): f.val/f.label sin escapar — mismo patrón que ya se
    // corrigió en opcionesCuenta() (js/core/cuentas-fuentes.js), pero esta es una
    // segunda implementación separada que nunca pasaba por escHtml(). Nombres
    // de cuenta personalizada son texto libre del usuario. Ver CHANGELOG.md.
    sel.innerHTML = html`<option value="">Sin especificar</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
    label.textContent = '¿En qué cuenta guardaste esa plata?';
    if (splitToggleBtn) splitToggleBtn.style.display = 'none';
  } else {
    // Salida: solo cuentas donde el encargo tiene plata
    const cuentasConSaldo = _getEncargoSaldoPorCuenta(enc);
    if (cuentasConSaldo.length === 0) {
      // Si no hay distribución por cuenta, mostrar todas (sin TC)
      const fuentes = getFuentesSinTC();
      sel.innerHTML = html`<option value="">Sin especificar</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
    } else {
      sel.innerHTML = html`<option value="">Sin especificar</option>${cuentasConSaldo.map(f=>html`<option value="${f.cuenta}">${f.label} (${fmt(f.saldo)})</option>`)}`;
      _movEncMuestraSaldoEnOpcion = true;
    }
    label.textContent = '¿De qué cuenta sacaste esa plata?';
    if (splitToggleBtn) splitToggleBtn.style.display = '';
    // Pre-seleccionar la cuenta con más saldo del encargo
    if (cuentasConSaldo.length > 0) {
      sel.value = cuentasConSaldo[0].cuenta;
    }
  }

  if (_movEncHintEl) _movEncHintEl.style.display = _movEncMuestraSaldoEnOpcion ? 'none' : '';
  if (!_movEncMuestraSaldoEnOpcion && sel.value) _actualizarMovEncCuentaHint(enc, sel.value);

  // Listener para mostrar saldo de encargo en esa cuenta (solo si el select no lo muestra ya)
  sel.onchange = function() { if(!_movEncMuestraSaldoEnOpcion) _actualizarMovEncCuentaHint(enc, sel.value); };

  // Mostrar/ocultar diferencial según tipo
  const difWrap = document.getElementById('movenc-dif-wrap');
  if (difWrap) {
    if (tipo === 'salida') {
      difWrap.style.display = '';
      diffReset('movenc');
    } else {
      difWrap.style.display = 'none';
    }
  }

  // Mostrar/ocultar y resetear "Yo puse la plata" según tipo
  const miaWrap = document.getElementById('movenc-mia-wrap');
  const miaBody = document.getElementById('movenc-mia-body');
  const miaIcon = document.getElementById('movenc-mia-icon');
  if (miaWrap) {
    if (tipo === 'salida') {
      miaWrap.style.display = '';
      if (miaBody) miaBody.style.display = 'none';
      if (miaIcon) miaIcon.style.transform = '';
      const saleSel  = document.getElementById('movenc_mia_cuenta_sale');
      const entraSel = document.getElementById('movenc_mia_cuenta_entra');
      if (saleSel)  saleSel.value  = '';
      if (entraSel) entraSel.value = '';
      splitReset('miaSale'); splitReset('miaEntra');
      const miaPrev = document.getElementById('movenc-mia-preview');
      if (miaPrev) miaPrev.textContent = '';
    } else {
      miaWrap.style.display = 'none';
    }
  }

  // Style the confirm button
  const btn = document.getElementById('btn-confirmar-mov-encargo');
  if (tipo === 'entrada') {
    btn.style.background = 'rgba(96,176,240,.25)';
    btn.style.color = 'var(--blue)';
    btn.style.border = '1px solid rgba(96,176,240,.5)';
    btn.style.boxShadow = 'none';
  } else {
    btn.style.background = 'rgba(240,104,104,.85)';
    btn.style.color = '#fff';
    btn.style.border = 'none';
    btn.style.boxShadow = 'none';
  }
  // El monto arranca vacío (reseteado arriba), así que nunca hay faltante al
  // abrir — esto solo deja todo en su estado base (banner oculto, botón
  // Guardar visible) por si el sheet quedó en el estado "faltante" de una
  // apertura anterior.
  _movEncActualizarFaltante();
  openSheet('mov-encargo');
}

function _actualizarMovEncCuentaHint(enc, cuentaVal) {
  const hint = document.getElementById('movenc_cuenta_hint');
  if (!hint) return;
  if (!cuentaVal) { hint.textContent = ''; return; }
  const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, cuentaVal);
  hint.textContent = 'Del encargo en esta cuenta: ' + fmt(saldoEnCuenta);
}

/* ─── Split de fuente en "Retirar plata" del encargo ─────────────── */
let _movEncSplitMode = false;

const _sp_movenc = crearSplitWidget('movenc', {
  simpleId:'movenc_cuenta_simple', splitId:'movenc_cuenta_split', toggleId:'movenc_split_toggle', rowsId:'movencSplitRows',
  getModo:()=>_movEncSplitMode, setModo:v=>{_movEncSplitMode=v;},
  // Con distribución por cuenta: solo las cuentas del encargo con su saldo. Sin distribución: todas las fuentes (con tarjetas), sin saldo.
  fuentes:()=>{ const enc = encargoActualId ? getEncargo(encargoActualId) : null; const l = enc ? _getEncargoSaldoPorCuenta(enc) : []; return l.length ? { mostrarSaldo: true, soloDe: l } : { tarjetas: true }; },
  onPreview:_movEncSplitPreview
});





function _movEncSplitPreview() {
  const el = document.getElementById('movenc_split_preview');
  if (el) {
    const montoTotal = parseMoney(document.getElementById('movenc_monto').value) || 0;
    if (!_movEncSplitMode) { el.textContent = ''; }
    else {
      const splits  = _sp_movenc.data();
      const asignado = splits.reduce((a, s) => a + s.monto, 0);
      const restante = montoTotal - asignado;
      if (splits.length === 0) { el.textContent = ''; }
      else {
        let lines = splits.map(s => `${s.fuente ? fuenteLabel(s.fuente) : 'Sin esp.'}: ${fmt(s.monto)}`).join(' · ');
        if (montoTotal > 0) {
          if (restante > 0.5)       { el.textContent = lines + ` · Sin asignar: ${fmt(restante)}`; el.style.color = 'var(--amber)'; }
          else if (restante < -0.5) { el.textContent = lines + ` · Excede: ${fmt(-restante)}`;     el.style.color = 'var(--red)'; }
          else                      { el.textContent = lines + ' \u2713';                               el.style.color = 'var(--accent)'; }
        } else {
          el.textContent = lines; el.style.color = 'var(--text2)';
        }
      }
    }
  }
  _movEncMiaPreview();
  _movEncActualizarFaltante();
}

function _getEncargoSaldoPorCuenta(enc) {
  // Returns [{cuenta, label, saldo}] sorted by saldo desc
  const map = {};
  // Saldo inicial
  const cuentaIni = enc.cuentaInicial || '';
  if (enc.saldoInicial > 0) {
    const k = cuentaIni || '__sin__';
    map[k] = (map[k]||0) + enc.saldoInicial;
  }
  // Movimientos
  (enc.movimientos||[]).forEach(m => {
    const k = m.cuenta || '__sin__';
    if (m.tipo === 'entrada') map[k] = (map[k]||0) + m.monto;
    else map[k] = (map[k]||0) - m.monto;
  });
  return Object.entries(map)
    .filter(([k,v]) => k !== '__sin__' && v > 0)
    .map(([k,v]) => ({ cuenta: k, label: fuenteLabel(k), saldo: v }))
    .sort((a,b) => b.saldo - a.saldo);
}

function _getEncargoSaldoSinCuenta(enc) {
  // Cuánto del encargo NO está ligado a ninguna cuenta específica ("Sin especificar")
  const cuentaIni = enc.cuentaInicial || '';
  let saldo = 0;
  if (enc.saldoInicial > 0 && !cuentaIni) saldo += enc.saldoInicial;
  (enc.movimientos||[]).forEach(m => {
    if (!m.cuenta) {
      if (m.tipo === 'entrada') saldo += m.monto;
      else saldo -= m.monto;
    }
  });
  return saldo;
}

function _getEncargoSaldoEnCuenta(enc, cuentaVal) {
  const map = {};
  const cuentaIni = enc.cuentaInicial || '';
  if (enc.saldoInicial > 0) {
    const k = cuentaIni || '__sin__';
    map[k] = (map[k]||0) + enc.saldoInicial;
  }
  (enc.movimientos||[]).forEach(m => {
    const k = m.cuenta || '__sin__';
    if (m.tipo === 'entrada') map[k] = (map[k]||0) + m.monto;
    else map[k] = (map[k]||0) - m.monto;
  });
  return map[cuentaVal] || 0;
}

/* ── Salida dividida (Retirar plata + "Dividir"): una sola fila en el historial ──
   (2026-09-30) Los datos NO cambian: cada cuenta del encargo sigue teniendo su propio
   registro en enc.movimientos, porque el saldo del encargo se calcula por cuenta
   (m.cuenta). Lo que cambia es la vista: las porciones de una misma salida se pintan
   como UN movimiento, y borrar ese movimiento borra todas las porciones.
   Aplica solo a "Retirar plata" (no a "Reubicación", que sigue con filas independientes).
   Las salidas nuevas llevan _splitGrupo; las viejas (sin ese campo) se agrupan solo si
   el conjunto está completo (mismas desc/fecha/total y partes 1..N). */
function _encSplitKey(m) {
  if (!m || m.tipo !== 'salida' || !m._splitTotal || !(m._splitDe > 1)) return '';
  if (m._splitGrupo) return m._splitGrupo;
  if (String(m.desc || '').startsWith('Reubicación') || m._esAbonoDeudor || m._esTcEncargo) return '';
  return ['h', m.desc, m.fecha, m._splitTotal, m._splitDe].join('|');
}
function _encGrupoSplit(enc, m) {
  const k = _encSplitKey(m);
  if (!k) return null;
  const partes = (enc.movimientos || []).filter(x => _encSplitKey(x) === k)
    .sort((a, b) => a._splitParte - b._splitParte);
  if (partes.length !== m._splitDe) return null;
  if (!partes.every((x, i) => x._splitParte === i + 1)) return null;
  return partes;
}
// La porción que lleva los efectos secundarios (diferencial / "Yo puse la plata"): la primera.
function _encSplitCarrier(partes) {
  return partes.find(x => x._miaCuentaSale || x.diferencial) || partes[0];
}

function confirmarMovEncargo() {
  const desc  = document.getElementById('movenc_desc').value.trim();
  const monto = parseMoney(document.getElementById('movenc_monto').value) || 0;
  if (!desc)  { toast('Ingresa una descripción', 'err'); return; }
  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  if (!enc.movimientos) enc.movimientos = [];

  if (movEncargoTipo === 'salida' && _movEncSplitMode) {
    // ── MODO SPLIT ──────────────────────────────────────────────────
    const splits = _sp_movenc.data();
    const totalSplit = splits.reduce((a, s) => a + s.monto, 0);
    if (splits.length === 0) { toast('Agrega al menos una cuenta en el split', 'err'); return; }
    if (Math.abs(totalSplit - monto) > 0.5) {
      toast(`La suma del split (${fmt(totalSplit)}) debe ser igual al monto (${fmt(monto)})`, 'err'); return;
    }
    // Validar disponible del encargo total (saldo menos lo ya comprometido en partes)
    const libreActual = encargoLibre(enc);
    if (monto > libreActual) {
      toast(`Disponible del encargo: solo ${fmt(libreActual)} (el resto ya está comprometido)`, 'err'); return;
    }
    // Validar saldo por cuenta individualmente
    for (const s of splits) {
      if (!s.fuente) continue;
      const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, s.fuente);
      if (s.monto > saldoEnCuenta + 0.5) {
        toast(`En ${fuenteLabel(s.fuente)} solo hay ${fmt(saldoEnCuenta)} de este encargo`, 'err'); return;
      }
    }
    // Validar intercambios antes de registrar
    const _errIntSplit = _dif_movenc.validarIntercambios();
    if (_errIntSplit) { toast(_errIntSplit, 'err', 5000); return; }
    const _errMiaSplit = _validarMovEncMia();
    if (_errMiaSplit) { toast(_errMiaSplit, 'err', 5000); return; }
    const _errDifMiSplit = diffValidarMiCuenta('movenc');
    if (_errDifMiSplit) { toast(_errDifMiSplit, 'err', 5000); return; }
    // Registrar un movimiento por cada porción del split
    const fecha = document.getElementById('movenc_fecha').value || hoy();
    const nota  = document.getElementById('movenc_nota').value.trim();
    const _grupoSplitId = uid();
    splits.forEach((s, i) => {
      const mov = {
        id: uid(),
        tipo: 'salida',
        desc,
        monto: s.monto,
        cuenta: s.fuente || '',
        fecha,
        nota,
        ts: Date.now() + i,
        ...(splits.length > 1 ? { _splitTotal: monto, _splitParte: i + 1, _splitDe: splits.length, _splitGrupo: _grupoSplitId } : {})
      };
      enc.movimientos.push(mov);
      // Procesar diferencial e intercambio "yo puse la plata" solo en el primer movimiento del grupo
      if (i === 0) { _procesarDiferencial(mov); _procesarMovEncMia(mov); }
    });
    save();
    refresh();
    closeSheet('mov-encargo');
    abrirEncargoDetalle(encargoActualId);
    toast('Salida registrada', 'ok');

  } else {
    // ── MODO SIMPLE ──────────────────────────────────────────────────
    const cuenta = document.getElementById('movenc_cuenta').value;
    // Validar que no quede saldo negativo al salir
    if (movEncargoTipo === 'salida') {
      const libreActual = encargoLibre(enc);
      if (monto > libreActual) {
        toast(`Disponible del encargo: solo ${fmt(libreActual)} (el resto ya está comprometido)`, 'err'); return;
      }
      if (cuenta) {
        const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, cuenta);
        if (monto > saldoEnCuenta) {
          toast(`En ${fuenteLabel(cuenta)} solo hay ${fmt(saldoEnCuenta)} de este encargo`, 'err'); return;
        }
      }
    }
    const nuevoMov = {
      id: uid(),
      tipo: movEncargoTipo,
      desc,
      monto,
      cuenta: cuenta || '',
      fecha: document.getElementById('movenc_fecha').value || hoy(),
      nota: document.getElementById('movenc_nota').value.trim(),
      ts: Date.now()
    };
    if (movEncargoTipo === 'salida') {
      const _errInt = _dif_movenc.validarIntercambios();
      if (_errInt) { toast(_errInt, 'err', 5000); return; }
      const _errMia = _validarMovEncMia();
      if (_errMia) { toast(_errMia, 'err', 5000); return; }
      const _errDifMi = diffValidarMiCuenta('movenc');
      if (_errDifMi) { toast(_errDifMi, 'err', 5000); return; }
    }
    enc.movimientos.push(nuevoMov);
    if (movEncargoTipo === 'salida') {
      _procesarDiferencial(nuevoMov);
      _procesarMovEncMia(nuevoMov);
    }
    save();
    refresh();
    closeSheet('mov-encargo');
    abrirEncargoDetalle(encargoActualId);
    toast(movEncargoTipo === 'entrada' ? 'Entrada registrada' : 'Salida registrada', 'ok');
  }
}

// Muestra/oculta la opción "prestar lo que falta" cuando una salida simple
// (no dividida) pide más de lo que el encargo tiene libre. Se llama en cada
// input de monto y al abrir/cerrar el modo split (encadenada desde
// _movEncSplitPreview) y al abrir el sheet (abrirMovEncargo).
//
// Alcance a propósito acotado a "salida" en modo simple: en modo split o en
// entradas, el encargo simplemente no alcanza y se mantiene el error
// genérico ya existente en confirmarMovEncargo — mezclar esta feature con
// splits (¿de cuál cuenta del encargo sale cada parte del faltante? ¿de
// cuál cuenta propia?) complica la UI sin un caso real que lo pida todavía.
function _movEncActualizarFaltante() {
  const wrap = document.getElementById('movenc-faltante-wrap');
  if (!wrap) return;
  const btnGuardar = document.getElementById('btn-confirmar-mov-encargo');
  const difWrap = document.getElementById('movenc-dif-wrap');
  const miaWrap = document.getElementById('movenc-mia-wrap');
  const enc = encargoActualId ? getEncargo(encargoActualId) : null;
  const montoEl = document.getElementById('movenc_monto');
  const monto = montoEl ? (parseMoney(montoEl.value) || 0) : 0;

  const ocultarFaltante = () => {
    wrap.style.display = 'none';
    if (btnGuardar) btnGuardar.style.display = '';
    // Diferencial y "yo puse la plata" solo aplican a salidas — se restauran
    // acá porque _movEncActualizarFaltante puede haberlos ocultado antes.
    if (movEncargoTipo === 'salida') {
      if (difWrap) difWrap.style.display = '';
      if (miaWrap) miaWrap.style.display = '';
    }
  };

  if (!enc || movEncargoTipo !== 'salida' || _movEncSplitMode || monto <= 0) {
    ocultarFaltante();
    return;
  }
  const libre = encargoLibre(enc);
  if (monto <= libre + 0.5) {
    ocultarFaltante();
    return;
  }

  // Hay faltante real: mostrar el banner y esconder Guardar/diferencial/mia
  // para no combinar esta feature con esas otras a medio llenar.
  const faltante = monto - libre;
  const detalle = document.getElementById('movenc-faltante-detalle');
  if (detalle) {
    detalle.textContent = libre > 0
      ? `Se retiran ${fmt(libre)} del encargo (todo lo disponible) y los otros ${fmt(faltante)} quedan como un préstamo tuyo aparte a ${enc.nombre}, en "Me deben" — no forman parte de este encargo.`
      : `Este encargo no tiene nada disponible ahora mismo. Los ${fmt(faltante)} completos quedarían como un préstamo tuyo a ${enc.nombre}, en "Me deben".`;
  }
  const selCuenta = document.getElementById('movenc_faltante_cuenta');
  if (selCuenta) {
    const valPrevio = selCuenta.value;
    const fuentes = getFuentesSinTC();
    selCuenta.innerHTML = html`<option value="">Seleccionar cuenta</option>${fuentes.map(f => html`<option value="${f.val}">${f.label}</option>`)}`;
    if (valPrevio && fuentes.some(f => f.val === valPrevio)) selCuenta.value = valPrevio;
  }
  wrap.style.display = '';
  if (btnGuardar) btnGuardar.style.display = 'none';
  if (difWrap) difWrap.style.display = 'none';
  if (miaWrap) miaWrap.style.display = 'none';
  _movEncFaltanteCuentaHint();
}

// Hint en vivo bajo el selector de cuenta propia del banner de faltante:
// avisa ANTES de confirmar si esa cuenta no tiene lo suficiente para cubrir
// el préstamo — mismo criterio (getSaldoFuente) que ya usa "Yo puse la
// plata" (_validarMovEncMia). Este chequeo es solo UX; la validación real
// que bloquea el guardado vive en _movEncConfirmarPrestarFaltante.
function _movEncFaltanteCuentaHint() {
  const hint = document.getElementById('movenc_faltante_cuenta_hint');
  if (!hint) return;
  const wrap = document.getElementById('movenc-faltante-wrap');
  if (!wrap || wrap.style.display === 'none') { hint.textContent = ''; return; }
  const enc = encargoActualId ? getEncargo(encargoActualId) : null;
  const sel = document.getElementById('movenc_faltante_cuenta');
  const fuenteVal = sel ? sel.value : '';
  if (!enc || !fuenteVal) { hint.textContent = ''; hint.style.color = ''; return; }
  const monto = parseMoney(document.getElementById('movenc_monto').value) || 0;
  const faltante = monto - encargoLibre(enc);
  if (faltante <= 0) { hint.textContent = ''; return; }
  const saldo = getSaldoFuente(fuenteVal);
  if (faltante > saldo + 0.5) {
    hint.textContent = `No tienes ${fmt(faltante)} en ${fuenteLabel(fuenteVal)}. Disponible: ${fmt(saldo)}.`;
    hint.style.color = 'var(--red)';
  } else {
    hint.textContent = `Disponible en ${fuenteLabel(fuenteVal)}: ${fmt(saldo)}`;
    hint.style.color = 'var(--text3)';
  }
}

// Confirma "prestar lo que falta": retira del encargo únicamente lo que
// tiene libre (movimiento tipo:'salida' normal, igual que cualquier otra
// salida simple) y registra el resto como un préstamo real, propio, en
// "Me deben" (S.deudores) — con su propia cuenta de origen (la tuya, nunca
// la del encargo) y respetando el sistema de grupos de préstamo (ver
// prestado.md §2.4) vía _autoGrupoIdMov: si la persona ya tiene un grupo
// abierto lo reutiliza, si no arranca uno nuevo.
//
// Las dos partes quedan como movimientos independientes a propósito — el
// préstamo es una deuda real que sigue existiendo sin importar qué pase
// después con el encargo, así que no están encadenados para borrado en
// cascada: cada uno se revierte con su flujo normal (deleteMovEncargo /
// eliminarMovDeudor). _encargoOrigenId/_encargoOrigenMovId en el movimiento
// del deudor son solo trazabilidad, no afectan el borrado de ninguno de los
// dos lados.
function _movEncConfirmarPrestarFaltante() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const desc  = document.getElementById('movenc_desc').value.trim();
  const monto = parseMoney(document.getElementById('movenc_monto').value) || 0;
  if (!desc)  { toast('Ingresa una descripción', 'err'); return; }
  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }

  const libre = encargoLibre(enc);
  if (monto <= libre + 0.5) { toast('El encargo ya alcanza para este monto — usa "Guardar"', 'err'); return; }
  const faltante = monto - libre;

  if (!enc.personaId) {
    toast('Este encargo no tiene una persona vinculada — vinculala desde Editar antes de prestar el faltante', 'err', 4500);
    return;
  }
  const persona = typeof getPersona === 'function' ? getPersona(enc.personaId) : null;
  if (!persona) { toast('No se encontró la persona vinculada a este encargo', 'err'); return; }

  const fuentePrestamo = document.getElementById('movenc_faltante_cuenta').value;
  if (!fuentePrestamo) { toast('Selecciona de cuál cuenta tuya sale lo prestado', 'err'); return; }

  // Fix (2026-08-13): antes se llamaba descontarFuente() sin chequear que la
  // cuenta elegida realmente tuviera esa plata — descontarFuente no valida
  // saldo, así que el préstamo se registraba igual aunque Nequi no tuviera
  // los 20mil, dejando la cuenta en negativo en silencio. Mismo criterio que
  // ya usa "Yo puse la plata" (_validarMovEncMia, más arriba en este mismo
  // archivo): getSaldoFuente() antes de escribir cualquier dato.
  const valPrestamo = Plata.validarSalida(fuentePrestamo, faltante);
  if (!valPrestamo.ok) { toast(valPrestamo.motivo, 'err', 4500); return; }

  const cuenta = document.getElementById('movenc_cuenta').value;
  if (cuenta) {
    const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, cuenta);
    if (libre > saldoEnCuenta + 0.5) {
      toast(`En ${fuenteLabel(cuenta)} solo hay ${fmt(saldoEnCuenta)} de este encargo`, 'err'); return;
    }
  }

  const fecha = document.getElementById('movenc_fecha').value || hoy();
  const nota  = document.getElementById('movenc_nota').value.trim();

  // 1) Retirar del encargo únicamente lo que realmente tiene disponible —
  //    un movimiento tipo:'salida' idéntico a cualquier otra salida simple.
  if (!enc.movimientos) enc.movimientos = [];
  const movEncId = uid();
  enc.movimientos.push({
    id: movEncId,
    tipo: 'salida',
    desc,
    monto: libre,
    cuenta: cuenta || '',
    fecha,
    nota: (nota ? nota + ' · ' : '') + `Resto (${fmt(faltante)}) prestado aparte, fuera del encargo`,
    ts: Date.now()
  });

  // 2) El faltante, como préstamo real tuyo — mismo deudor que ya usa este
  //    encargo si existe (nunca duplicar persona, ver prestado.md §6).
  let deudor = Deudas.porPersona('favor', enc.personaId);
  if (!deudor) {
    deudor = Deudas.agregar('favor', { id: uid(), nombre: persona.nombre, color: persona.color || '#60b0f0', personaId: persona.id, movimientos: [] });
  }
  if (!deudor.movimientos) deudor.movimientos = [];
  const grupoId = _autoGrupoIdMov(deudor, fecha);
  deudor.movimientos.push({
    id: uid(),
    tipo: 'prestamo',
    monto: faltante,
    fecha,
    fuente: fuentePrestamo,
    nota: `Encargo "${enc.nombre}": ${desc} (no alcanzaba ${fmt(libre)} del encargo)`,
    grupoId,
    _encargoOrigenId: enc.id,
    _encargoOrigenMovId: movEncId,
    ts: Date.now() + 1
  });
  descontarFuente(fuentePrestamo, faltante, _ogEnc(movEncId));

  save();
  refresh();
  closeSheet('mov-encargo');
  abrirEncargoDetalle(encargoActualId);
  toast(`${fmt(libre)} retirados del encargo · ${fmt(faltante)} prestados a ${persona.nombre} (Me deben)`, 'ok', 4500);
}

async function deleteMovEncargo(encId, movId) {
  const enc = getEncargo(encId);
  if (!enc) return;

  // Caso especial: "Saldo inicial" no es un registro real en enc.movimientos —
  // son dos campos sueltos del encargo (saldoInicial/cuentaInicial), mostrados
  // con un id fijo ('__saldo_ini__', igual en todo encargo) solo para pintarlo
  // en el historial (ver renderEncargoDetalle()). Antes no tenía botón de
  // eliminar porque el flujo de abajo (que busca en enc.movimientos) nunca
  // lo hubiera encontrado — ver CHANGELOG.md#encargos (2026-08-30).
  if (movId === '__saldo_ini__') {
    if (!(enc.saldoInicial > 0)) return;
    // El saldo inicial es plata AJENA que ya estaba guardada en esa cuenta: nunca formó parte de `c.saldo` (el saldo propio),
    // así que borrarlo solo quita la anotación del encargo y no mueve ninguna cuenta ni el libro.
    const ok = await confirmarEliminar({ titulo: 'Eliminar saldo inicial', objeto: `el saldo inicial de ${fmt(enc.saldoInicial)}`, detalle: 'Solo se quita del encargo; no cambia el saldo de ninguna cuenta.', irreversible: false });
    if (!ok) return;
    enc.saldoInicial = 0;
    enc.cuentaInicial = '';
    save(); refresh();
    abrirEncargoDetalle(encId);
    toast('Saldo inicial eliminado', 'ok');
    return;
  }

  const mov = (enc.movimientos||[]).find(m=>m.id===movId);
  if (!mov) return;

  // Salida creada por un pago de Mesada: su efecto real vive en Mesada (suma a la cuenta destino y
  // deja un movimiento espejo). Borrarla desde acá devolvería la plata al encargo pero dejaría el
  // pago de mesada contándola y la cuenta destino inflada — se borra desde Mesada, que revierte todo.
  const _origenMesada = typeof mesadaOrigenDeMovEncargo === 'function' ? mesadaOrigenDeMovEncargo(movId) : null;
  if (_origenMesada) {
    toast('Esta salida viene de la mesada de ' + (_origenMesada.parent === 'papa' ? 'papá' : 'mamá') + ' (' + _mesNombreDeKey(_origenMesada.key) + '). Para deshacerla, bórrala desde Mesada.', 'info', 4500);
    return;
  }

  // Salida dividida: se borra como UN movimiento. Si llegó el id de una porción que no es la
  // que lleva los efectos secundarios (diferencial / "Yo puse la plata"), se redirige a esa.
  const _grupoDel = _encGrupoSplit(enc, mov);
  if (_grupoDel) {
    const _carrier = _encSplitCarrier(_grupoDel);
    if (_carrier && _carrier.id !== movId) return deleteMovEncargo(encId, _carrier.id);
  }

  // Protección por antigüedad — ver docs/proteccion-antiguedad-movimientos.md.
  // Nota: a diferencia de los demás módulos, acá no afirmamos si la cuenta
  // "sube" o "baja" — el motor de diferencial/intercambios de Encargos hace
  // que la dirección exacta dependa del tipo de movimiento (entrada, salida,
  // "lo cubrí yo", "lo adelanté yo"), así que el aviso de nivel 'viejo' queda
  // genérico en vez de arriesgar un dato incorrecto.
  // Ops posteriores: se cuenta contra el ENCARGO completo, no solo contra
  // mov.cuenta (2026-09-01, revisión de diseño — ver CHANGELOG.md#encargos).
  // Un encargo con plata repartida en varias cuentas (o sin cuenta asignada)
  // sigue siendo una sola bolsa de plata que se mezcla con cada movimiento
  // nuevo, toque o no la misma cuenta externa — filtrar por cuenta subestimaba
  // esa mezcla en encargos con movimientos en cuentas distintas.
  const opsPosteriores = (enc.movimientos||[]).filter(m => m.id!==movId && m.fecha && m.fecha>mov.fecha).length;
  const nivel = nivelAntiguedadMovimiento(mov.fecha, opsPosteriores, 'encargos');
  if (nivel === 'bloqueado') {
    await avisarMovimientoBloqueado();
    return;
  }
  const ok = nivel === 'viejo'
    ? await dialogo('Movimiento antiguo', `Este movimiento de ${fmt(mov.monto)} ya tiene tiempo y puede estar mezclado con operaciones más recientes de este encargo${mov.cuenta ? ' en '+fuenteLabel(mov.cuenta) : ''}. Si lo eliminas, se revertirán sus efectos en tus cuentas ahora mismo — no se recalcula el historial completo. ¿Eliminar de todas formas?`, 'Eliminar de todas formas', true)
    : await confirmarEliminar({ titulo: 'Eliminar movimiento', objeto: 'este movimiento del encargo', detalle: 'Se revertirán todos los efectos en tus cuentas.', irreversible: false });
  if (!ok) return;

  // Revertir efectos secundarios de un pago de préstamo vía encargo
  if (mov && mov._esAbonoDeudor && mov._deudorId) {
    const d = Deudas.lista('favor').find(x => x.id === mov._deudorId);
    if (d) {
      // Eliminar el abono correspondiente del deudor (vinculado por _encMovId,
      // o por _encMovIds si el pago salió de varias cuentas del encargo)
      d.movimientos = (d.movimientos || []).filter(x => !(x._viaEncargo && (x._encMovId === movId || (x._encMovIds && x._encMovIds.includes(movId)))));
    }
    // Si este pago salió de varias cuentas del encargo (mismo _grupoAbonoId),
    // borrar TODAS esas salidas ahora — no solo la que el usuario clickeó —
    // para no dejar un pago "a medias" repartido entre cuentas.
    if (mov._grupoAbonoId) {
      enc.movimientos = (enc.movimientos || []).filter(x => x._grupoAbonoId !== mov._grupoAbonoId);
    }
  }

  // Revertir efectos secundarios de una compra TC de encargo
  if (mov && mov._esTcEncargo) {
    // Revertir el sumarFuente del paso 2: usar _destinoMonto si existe (tcMonto guardado),
    // con fallback a _tcMonto y luego a monto para compatibilidad con registros anteriores.
    if (mov._destino) {
      const montoARevertir = mov._destinoMonto || mov._tcMonto || mov.monto;
      if (montoARevertir) descontarFuente(mov._destino, montoARevertir, _ogEnc(movId, true));
    }

    // Revertir la deuda de la TC (paso 3)
    if (mov._tcId && mov._tcMonto) {
      const tc = (S.tarjetasCredito||[]).find(t=>t.id===mov._tcId);
      if (tc) tc.deuda = Math.max(0, (tc.deuda||0) - mov._tcMonto);
    }

    // Borrar el movimiento de historial de TC vinculado (paso 4)
    if (S.tcMovimientos) {
      S.tcMovimientos = S.tcMovimientos.filter(t => t._encMovId !== movId);
    }

    // Borrar todos los S.movimientos vinculados (destino + diferencial, pasos 2 y 5)
    // y revertir sus sumas. Excluye los de intercambio — esos los maneja el bloque siguiente.
    if (S.movimientos) {
      const difMovs = S.movimientos.filter(m => m._encMovId === movId && !m._esIntercambioEncargo);
      difMovs.forEach(m => { if (m.fuente && m.monto) descontarFuente(m.fuente, m.monto, _ogEnc(movId, true)); });
      S.movimientos = S.movimientos.filter(m => !(m._encMovId === movId && !m._esIntercambioEncargo));
    }
  }

  // Revertir transferencia entre encargos: eliminar también el movimiento
  // espejo en el OTRO encargo (vinculado por _transfId), sea cual sea el
  // lado desde el que se eliminó — nunca dejar una transferencia a medias.
  if (mov && mov._transfEncargo && mov._transfId) {
    const otroEncId = mov._encargoDestino || mov._encargoOrigen;
    const otroEnc = otroEncId ? getEncargo(otroEncId) : null;
    if (otroEnc) {
      otroEnc.movimientos = (otroEnc.movimientos||[]).filter(m => m._transfId !== mov._transfId);
    }
  }

  // Revertir "Me lo regalaron" (traspaso de encargo a cuenta propia)
  if (mov && mov._traspasoEncargo) {
    // Revertir el sumarFuente que se hizo en el paso 2
    if (mov._destino && mov.monto) descontarFuente(mov._destino, mov.monto, _ogEnc(movId, true));
    // Borrar el movimiento de ingreso vinculado (vive en S.movimientos, como el de toda cuenta).
    if (S.movimientos) {
      S.movimientos = S.movimientos.filter(m => m._encMovId !== movId);
    }
  }

  // Revertir intercambios "lo pagué yo" del diferencial (salida normal sin _esTcEncargo)
  if (mov && mov.diferencial && (mov.diferencial.beneficiarios || []).some(b => b.pagadoPorMi)) {
    if (S.movimientos) {
      const intercambioMovs = S.movimientos.filter(m => m._encMovId === movId && m._esIntercambioEncargo);
      intercambioMovs.forEach(m => {
        if (!m.fuente || !m.monto) return;
        if (m._intercambioSalida) {
          sumarFuente(m.fuente, m.monto, _ogEnc(movId, true));
        } else if (m._intercambioEntrada) {
          descontarFuente(m.fuente, m.monto, _ogEnc(movId, true));
        }
      });
      S.movimientos = S.movimientos.filter(m => !(m._encMovId === movId && m._esIntercambioEncargo));
    }
  }

  // Revertir intercambio simple "Yo puse la plata" (sin diferencial — _miaCuentaSale en el mov principal)
  if (mov && mov._miaCuentaSale && !(mov.diferencial && (mov.diferencial.beneficiarios || []).some(b => b.pagadoPorMi))) {
    if (S.movimientos) {
      const intercambioMovs = S.movimientos.filter(m => m._encMovId === movId && m._esIntercambioEncargo);
      intercambioMovs.forEach(m => {
        if (!m.fuente || !m.monto) return;
        if (m._intercambioSalida) {
          // Pagué de mi bolsillo → revertir sumando de vuelta a esa cuenta
          sumarFuente(m.fuente, m.monto, _ogEnc(movId, true));
        } else if (m._intercambioEntrada) {
          // Recuperé en mi cuenta → revertir descontando
          descontarFuente(m.fuente, m.monto, _ogEnc(movId, true));
        }
      });
      S.movimientos = S.movimientos.filter(m => !(m._encMovId === movId && m._esIntercambioEncargo));
    }
  }

  // Revertir el margen que entró a mis cuentas (sobrante libre del diferencial — una entrada
  // por cuenta si se repartió con "Dividir"). La compra con TC ya lo limpió arriba.
  if (mov && mov.diferencial && !mov._esTcEncargo && S.movimientos) {
    S.movimientos.filter(m => m._encMovId === movId && m._esDiferencialEncargo)
      .forEach(m => { if (m.fuente && m.monto) descontarFuente(m.fuente, m.monto, _ogEnc(movId, true)); });
    S.movimientos = S.movimientos.filter(m => !(m._encMovId === movId && m._esDiferencialEncargo));
  }

  enc.movimientos = (enc.movimientos||[]).filter(m => m.id!==movId && !(_grupoDel && _grupoDel.some(x => x.id === m.id)));
  save();
  refresh();
  // cuentaActual vive en cuentas.js (lazy): sin typeof, borrar un movimiento de encargo con
  // cuentas.js sin cargar tiraba ReferenceError antes de reabrir el detalle del encargo.
  if (typeof cuentaActual !== 'undefined' && cuentaActual && typeof renderDetalleCuenta==='function') renderDetalleCuenta(cuentaActual);
  abrirEncargoDetalle(encId);
  toast('Movimiento eliminado y saldos revertidos', 'ok');
}

async function eliminarEncargoActual() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  // Un encargo solo se puede eliminar en $0. Si todavía tiene saldo (a favor
  // o en contra) hay plata pendiente de resolver — no tiene sentido borrar
  // el registro que la está rastreando.
  if (Math.abs(saldo) > 0.5) {
    toast(`Este encargo todavía tiene ${fmt(saldo)} registrado — dejalo en $0 antes de eliminarlo`, 'err', 4500);
    return;
  }

  const ok = await confirmarEliminar({
    titulo: 'Eliminar encargo',
    objeto: `el encargo de ${enc.nombre}`,
    detalle: 'Los movimientos que ya pasaron (compras con TC, pagos de deudas, traspasos, etc.) quedan tal cual — eliminar el encargo no revierte nada, solo deja de llevarle el registro a esta persona.'
  });
  if (!ok) return;

  // A propósito NO se revierte ni se borra ningún movimiento vinculado
  // (S.movimientos, S.tcMovimientos, movimientos de deudores, cuentas
  // custom, etc.). Si el encargo está en $0, todo lo que pasó mientras
  // existió ya quedó correctamente reflejado en tus cuentas/tarjetas/deudas
  // — eliminar el encargo es solo dejar de administrarle plata a esa
  // persona, no deshacer los favores o pagos que ya ocurrieron.
  S.encargos = (S.encargos||[]).filter(e=>e.id!==encargoActualId);
  save();
  volverEncargosLista();
  if(window.logCambio)logCambio('Eliminaste un encargo','','','eliminar');
  toast('Encargo eliminado', 'ok');
}

// ── MENÚ "¿A DÓNDE FUE ESA PLATA?" (salida de encargo) ─────────────────
// Las 4 formas en que la plata deja de estar disponible en el encargo
// (gasto normal, se la quedó el usuario, pasó a otro encargo, se pagó
// con TC) comparten un solo botón de entrada para no saturar la vista
// de detalle con un botón grande por cada variante.
function abrirSalidaEncargoMenu() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const libre = encargoLibre(enc);
  if (libre <= 0) { toast(encargoComprometido(enc) > 0 ? 'Toda la plata de este encargo ya está comprometida' : 'El encargo no tiene saldo disponible', 'err'); return; }
  openSheet('salida-encargo-menu');
}

function _salidaEncMenuIr(destino) {
  closeSheet('salida-encargo-menu');
  if (destino === 'normal') abrirMovEncargo('salida');
  else if (destino === 'mio') abrirTraspasoEncargo();
  else if (destino === 'otroEncargo') abrirTransferenciaEncargo();
  else if (destino === 'tc') abrirCompraConTC();
}

function abrirTraspasoEncargo() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  const comprometido = encargoComprometido(enc);
  const libre = encargoLibre(enc);
  if (libre <= 0) { toast(comprometido > 0 ? 'Toda la plata de este encargo ya está comprometida' : 'El encargo no tiene saldo disponible', 'err'); return; }

  document.getElementById('traspasoEncNombre').textContent = enc.nombre;
  document.getElementById('traspasoEncSaldo').textContent = comprometido > 0
    ? fmt(libre) + ' disponible (de ' + fmt(saldo) + ', ' + fmt(comprometido) + ' comprometido)'
    : fmt(libre);
  document.getElementById('traspaso_monto').value = '';
  document.getElementById('traspaso_desc').value = 'Sobrante de encargo — ' + enc.nombre;
  document.getElementById('traspaso_fecha').value = hoy();
  document.getElementById('traspaso_preview').textContent = '';

  // Poblar select origen: de qué cuenta del encargo salió el regalo
  const selOrigen = document.getElementById('traspaso_origen');
  const cuentasEnc = _getEncargoSaldoPorCuenta(enc);
  let _traspasoOrigenMuestraSaldoEnOpcion = false;
  if (cuentasEnc.length === 0) {
    // Si no hay distribución por cuenta, mostrar todas (sin TC) — mismo criterio que una salida normal
    const fuentesTodas = getFuentesSinTC();
    selOrigen.innerHTML = html`<option value="">Sin especificar</option>${fuentesTodas.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
  } else {
    selOrigen.innerHTML = html`<option value="">Sin especificar</option>${cuentasEnc.map(f=>html`<option value="${f.cuenta}">${f.label} (${fmt(f.saldo)})</option>`)}`;
    // Pre-seleccionar la cuenta con más saldo del encargo
    selOrigen.value = cuentasEnc[0].cuenta;
    _traspasoOrigenMuestraSaldoEnOpcion = true;
  }
  // El hint de saldo solo aporta info nueva cuando el select no la muestra ya
  // en cada opción. Ver reglas-visuales.md#selectores-con-saldo.
  const _traspasoOrigenHintEl = document.getElementById('traspaso_origen_hint');
  if (_traspasoOrigenHintEl) _traspasoOrigenHintEl.style.display = _traspasoOrigenMuestraSaldoEnOpcion ? 'none' : '';
  if (!_traspasoOrigenMuestraSaldoEnOpcion) _actualizarTraspasoOrigenHint(enc);
  selOrigen.onchange = function() { if(!_traspasoOrigenMuestraSaldoEnOpcion) _actualizarTraspasoOrigenHint(enc); };

  // Poblar select destino con mis cuentas que pueden recibir plata (sin tarjetas de crédito)
  const fuentes = FuentesFiltro.receptoras(getFuentes());
  const sel = document.getElementById('traspaso_destino');
  sel.innerHTML = html`<option value="">Seleccionar cuenta</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;

  // Pre-seleccionar la misma cuenta donde más saldo tiene el encargo
  if (cuentasEnc.length > 0) {
    sel.value = cuentasEnc[0].cuenta;
  }
  _actualizarTraspasoHint();
  _actualizarTraspasoPreview(enc);

  sel.onchange = function() { _actualizarTraspasoHint(); _actualizarTraspasoPreview(enc); };
  document.getElementById('traspaso_monto').oninput = function() { _actualizarTraspasoPreview(enc); };

  openSheet('traspaso-encargo');
  focusSheetField('traspaso_monto');
}

function _actualizarTraspasoOrigenHint(enc) {
  const sel = document.getElementById('traspaso_origen');
  const hint = document.getElementById('traspaso_origen_hint');
  if (!hint || !sel) return;
  const val = sel.value;
  if (!val) { hint.textContent = ''; return; }
  hint.textContent = 'El encargo tiene ahí: ' + fmt(_getEncargoSaldoEnCuenta(enc, val));
}

function _actualizarTraspasoHint() {
  const sel = document.getElementById('traspaso_destino');
  const hint = document.getElementById('traspaso_saldo_hint');
  if (!hint) return;
  const val = sel.value;
  if (!val) { hint.textContent = ''; return; }
  hint.textContent = 'Saldo actual: ' + fmt(getSaldoFuente(val));
}

function _actualizarTraspasoPreview(enc) {
  const monto = parseMoney(document.getElementById('traspaso_monto').value) || 0;
  const destino = document.getElementById('traspaso_destino').value;
  const prev = document.getElementById('traspaso_preview');
  if (!prev) return;
  if (!monto || !destino) { prev.textContent = ''; return; }
  const saldoEnc = encargoLibre(enc);
  const saldoCuenta = getSaldoFuente(destino);
  const nuevoEnc = saldoEnc - monto;
  const nuevoCuenta = saldoCuenta + monto;
  const colorEnc = nuevoEnc < 0 ? 'enc-c-red' : 'enc-c-blue';
  prev.innerHTML = html`<span class="${colorEnc}">Encargo (disponible): ${fmt(saldoEnc)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoEnc)}</span><br>
    <span class="enc-c-accent">${fuenteLabel(destino)}: ${fmt(saldoCuenta)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoCuenta)}</span>
    ${nuevoEnc < 0 ? html`<br><span class="enc-aviso-rojo10">Más de lo que el encargo tiene disponible (sin contar lo comprometido)</span>` : ''}`;
}

function confirmarTraspasoEncargo() {
  const monto = parseMoney(document.getElementById('traspaso_monto').value) || 0;
  const destino = document.getElementById('traspaso_destino').value;
  const desc = document.getElementById('traspaso_desc').value.trim();
  const fecha = document.getElementById('traspaso_fecha').value || hoy();

  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }
  if (!destino) { toast('Selecciona la cuenta destino', 'err'); return; }
  if (!FuentesFiltro.puedeRecibir(destino)) { toast('Una tarjeta de crédito no puede recibir plata', 'err'); return; }
  if (!desc) { toast('Ingresa una descripción', 'err'); return; }

  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const libreActual = encargoLibre(enc);
  if (monto > libreActual) {
    toast(`El encargo solo tiene ${fmt(libreActual)} disponible (el resto ya está comprometido)`, 'err'); return;
  }

  // De qué cuenta física salió — elegida por el usuario en el selector
  const cuentaOrigen = document.getElementById('traspaso_origen').value || '';
  if (cuentaOrigen) {
    const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, cuentaOrigen);
    if (monto > saldoEnCuenta) {
      toast(`El encargo solo tiene ${fmt(saldoEnCuenta)} guardado en ${fuenteLabel(cuentaOrigen)}`, 'err');
      return;
    }
  }

  // 1. Registrar salida en el encargo
  if (!enc.movimientos) enc.movimientos = [];
  const encMovId = uid();
  enc.movimientos.push({
    id: encMovId,
    tipo: 'salida',
    desc: desc + ' a ' + fuenteLabel(destino),
    monto,
    cuenta: cuentaOrigen,
    fecha,
    nota: 'Traspaso a cuenta propia',
    _traspasoEncargo: true,   // marca para reversión en deleteMovEncargo
    _destino: destino,        // cuenta destino (para revertir sumarFuente)
    ts: Date.now()
  });

  // 2. Sumar a mi cuenta (cambia "de quién es" la plata)
  sumarFuente(destino, monto, _ogEnc(encMovId));

  // 3. Registrar ingreso visible en el historial de la cuenta destino.
  //    Va en S.movimientos, como el historial de toda cuenta.
  if (!S.movimientos) S.movimientos = [];
  S.movimientos.push({
    id: uid(),
    tipo: 'entrada',
    fuente: destino,
    monto,
    fecha,
    desc: desc + ' (de encargo ' + enc.nombre + ')',
    _encMovId: encMovId,
    clase: 'ingreso',
    _esExtraIngreso: true   // regalo recibido = ingreso real (ver _esEntradaEspejoNoIngreso)
  });

  save();
  refresh();
  closeSheet('traspaso-encargo');
  abrirEncargoDetalle(encargoActualId);
  toast(`${fmt(monto)} traspasado a ${fuenteLabel(destino)}`, 'ok', 3500);
}


// ── MOVER PLATA DE ENCARGO ENTRE CUENTAS ──────────────────────────────────
// Permite reubicar fisicamente la plata de un encargo de una cuenta a otra
// sin alterar el saldo total del encargo.

function abrirMoverEntreCuentasEncargo() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  if (saldo <= 0) { toast('El encargo no tiene saldo disponible', 'err'); return; }

  document.getElementById('moverEncNombre').textContent = enc.nombre;
  document.getElementById('moverEncSaldo').textContent = fmt(saldo);
  document.getElementById('moverenc_monto').value = '';
  document.getElementById('moverenc_fecha').value = hoy();
  document.getElementById('moverenc_preview').innerHTML = '';
  document.getElementById('moverenc_origen_hint').textContent = '';
  document.getElementById('moverenc_destino_hint').textContent = '';

  // Resetear modo split del origen (arranca siempre en modo simple)
  _moverEncSplitMode = false;
  const moverEncToggleBtn = document.getElementById('moverenc_split_toggle');
  const moverEncSimpleModo = document.getElementById('moverenc_origen_simple');
  const moverEncSplitModo  = document.getElementById('moverenc_origen_split');
  if (moverEncToggleBtn) { moverEncToggleBtn.textContent = 'Dividir'; moverEncToggleBtn.style.background = 'rgba(200,240,96,.1)'; moverEncToggleBtn.style.borderColor = 'rgba(200,240,96,.3)'; moverEncToggleBtn.style.color = 'var(--accent)'; }
  if (moverEncSimpleModo) moverEncSimpleModo.style.display = '';
  if (moverEncSplitModo)  { moverEncSplitModo.style.display = 'none'; document.getElementById('moverencSplitRows').innerHTML = ''; }
  const moverEncMontoWrap = document.getElementById('moverenc_monto_wrap');
  if (moverEncMontoWrap) moverEncMontoWrap.style.display = ''; // visible por defecto (modo simple)

  // Sin tarjetas de crédito: ni la plata de un encargo está en una TC ni a una TC se le reubica plata.
  const fuentes = FuentesFiltro.receptoras(getFuentes());
  const cuentasConSaldo = _getEncargoSaldoPorCuenta(enc).filter(c => FuentesFiltro.puedeRecibir(c.cuenta)); // [{cuenta, saldo}]
  const saldoSinCuenta = _getEncargoSaldoSinCuenta(enc);

  // Select origen: solo cuentas donde el encargo tiene plata (incluye "Sin especificar")
  const selOrigen = document.getElementById('moverenc_origen');
  const fuentesConSaldo = fuentes.filter(f => {
    const encargoEnCuenta = cuentasConSaldo.find(c => c.cuenta === f.val);
    return encargoEnCuenta && encargoEnCuenta.saldo > 0;
  });
  const origenOpts = fuentesConSaldo.map(f => {
    const encargoEnCuenta = cuentasConSaldo.find(c => c.cuenta === f.val);
    const saldoEnc = encargoEnCuenta.saldo;
    return html`<option value="${f.val}">${f.label} (${fmt(saldoEnc)} del encargo)</option>`;
  });
  if (saldoSinCuenta > 0) {
    origenOpts.push(html`<option value="__sinesp__">Sin especificar (${fmt(saldoSinCuenta)} del encargo)</option>`);
  }
  selOrigen.innerHTML = html`<option value="">Seleccionar cuenta origen</option>${origenOpts}`;

  // El botón "Dividir" solo tiene sentido si hay al menos 2 cuentas de origen
  // posibles (reales con saldo del encargo, o "Sin especificar") — con una sola
  // no hay nada que repartir.
  const origenesDisponibles = fuentesConSaldo.length + (saldoSinCuenta > 0 ? 1 : 0);
  if (moverEncToggleBtn) moverEncToggleBtn.style.display = origenesDisponibles > 1 ? '' : 'none';

  // Pre-seleccionar la cuenta con más saldo del encargo (o "Sin especificar" si es lo único que hay)
  if (cuentasConSaldo.length > 0) {
    selOrigen.value = cuentasConSaldo[0].cuenta;
    _actualizarMoverEncOrigenHint(enc);
  } else if (saldoSinCuenta > 0) {
    selOrigen.value = '__sinesp__';
    _actualizarMoverEncOrigenHint(enc);
  }

  // Select destino: todas las cuentas
  const selDestino = document.getElementById('moverenc_destino');
  selDestino.innerHTML = html`<option value="">Seleccionar cuenta destino</option>${fuentes.map(f => html`<option value="${f.val}">${f.label}</option>`)}`;

  // Listeners
  selOrigen.onchange = function() {
    _actualizarMoverEncOrigenHint(enc);
    _actualizarMoverEncPreview(enc);
    // Si destino es igual al nuevo origen, limpiar destino
    if (selDestino.value === selOrigen.value) selDestino.value = '';
  };
  selDestino.onchange = function() {
    _actualizarMoverEncDestinoHint();
    _actualizarMoverEncPreview(enc);
  };
  document.getElementById('moverenc_monto').oninput = function() {
    _actualizarMoverEncPreview(enc);
  };

  openSheet('mover-enc-cuentas');
  focusSheetField('moverenc_monto');
}

function _actualizarMoverEncOrigenHint(enc) {
  // El <option> de moverenc_origen ya trae el saldo en su texto siempre
  // ("Nequi (150.000 del encargo)") — este hint sería puro eco. Se deja
  // oculto. Ver reglas-visuales.md#selectores-con-saldo.
  const hint = document.getElementById('moverenc_origen_hint');
  if (hint) hint.style.display = 'none';
}

function _actualizarMoverEncDestinoHint() {
  const sel = document.getElementById('moverenc_destino');
  const hint = document.getElementById('moverenc_destino_hint');
  if (!hint) return;
  const val = sel.value;
  if (!val) { hint.textContent = ''; return; }
  hint.textContent = 'Saldo actual de la cuenta: ' + fmt(getSaldoFuente(val));
  hint.style.color = 'var(--text3)';
}

/* ─── Split de ORIGEN en "Mover entre cuentas" ─────────────────────
   Permite tomar la plata a reubicar de varias cuentas del encargo a
   la vez (ej. 100mil de Nequi + 20mil de Efectivo → una sola cajita),
   en vez de tener que hacer dos reubicaciones manuales. El destino
   sigue siendo siempre una sola cuenta — es solo el origen el que se
   puede repartir. Mismo motor genérico que usan Mesada/Encargos-salida/
   UsarParte (js/core/split.js), instancia propia 'moverenc'. */
let _moverEncSplitMode = false;

const _sp_moverenc = crearSplitWidget('moverenc', {
  simpleId:'moverenc_origen_simple', splitId:'moverenc_origen_split', toggleId:'moverenc_split_toggle', rowsId:'moverencSplitRows',
  getModo:()=>_moverEncSplitMode, setModo:v=>{_moverEncSplitMode=v;},
  getFuentesFn:_moverEncGetFuentesOptions,
  onPreview:_moverEncSplitPreview
});


function _moverEncGetFuentesOptions(selectedVal) {
  const enc = encargoActualId ? getEncargo(encargoActualId) : null;
  if (!enc) return html`<option value="">Elige cuenta</option>`;
  const cuentasConSaldo = _getEncargoSaldoPorCuenta(enc).filter(c => FuentesFiltro.puedeRecibir(c.cuenta));
  const saldoSinCuenta = _getEncargoSaldoSinCuenta(enc);
  // Construido a mano (no vía opcionesCuenta) a propósito: ese helper
  // usa "Sin especificar" como texto neutro de "nada elegido todavía" (value=""),
  // que acá chocaba con nuestra opción real "Sin especificar (bucket con plata
  // del encargo)" — dos opciones con el mismo nombre pero significados
  // distintos. Con un placeholder neutro ("Elige cuenta") no hay ambigüedad:
  // una fila vacía nunca se puede confundir con elegir el bucket sin cuenta.
  const opts = cuentasConSaldo.map(c => html`<option value="${c.cuenta}">${fuenteLabel(c.cuenta)} (${fmt(c.saldo)} del encargo)</option>`);
  if (saldoSinCuenta > 0) {
    opts.push(html`<option value="__sinesp__">Sin especificar (${fmt(saldoSinCuenta)} del encargo)</option>`);
  }
  return html`<option value="">Elige cuenta</option>${opts}`;
}

function _moverEncSplitToggle() {
  splitToggle('moverenc');
  // El monto total ya no se pide aparte en modo dividido: se deduce sumando
  // las filas del split, así que el campo "¿Cuánto vas a mover?" se oculta.
  const montoWrap = document.getElementById('moverenc_monto_wrap');
  if (montoWrap) montoWrap.style.display = _moverEncSplitMode ? 'none' : '';
}

function _moverEncSplitPreview() {
  const enc = getEncargo(encargoActualId);
  if (enc) _actualizarMoverEncPreview(enc);
}

function _actualizarMoverEncPreview(enc) {
  const destino = document.getElementById('moverenc_destino').value;
  const prev = document.getElementById('moverenc_preview');
  if (!prev) return;

  if (_moverEncSplitMode) {
    const splits = _sp_moverenc.data(); // [{fuente, monto}]
    if (splits.length === 0 || !destino) { prev.innerHTML = ''; return; }
    // Filas con monto pero sin cuenta elegida todavía: no cuentan para el
    // cálculo, solo se avisan aparte (evita mostrar matemática sin sentido
    // tipo "Sin especificar: $0 → -$3.000" para una fila que en realidad
    // solo está incompleta).
    const filasIncompletas = splits.some(s => !s.fuente);
    const splitsCompletos = splits.filter(s => s.fuente);
    if (splitsCompletos.some(s => s.fuente === destino)) {
      prev.innerHTML = '<span class="enc-c-red">La cuenta destino no puede repetirse como origen</span>';
      return;
    }
    if (splitsCompletos.length === 0) {
      prev.innerHTML = filasIncompletas ? '<span class="enc-aviso-amber10">Falta elegir la cuenta en una o más filas</span>' : '';
      return;
    }
    const cuentas = _getEncargoSaldoPorCuenta(enc);
    const saldoSinCuenta = _getEncargoSaldoSinCuenta(enc);
    const totalSplit = splitsCompletos.reduce((a, s) => a + s.monto, 0);
    let excedeAlguna = false;

    const lineasOrigen = splitsCompletos.map((s, i) => {
      const esSinEsp = s.fuente === '__sinesp__';
      const label = esSinEsp ? 'Sin especificar' : fuenteLabel(s.fuente);
      const saldoEnOrigen = esSinEsp ? saldoSinCuenta : (cuentas.find(c => c.cuenta === s.fuente)?.saldo || 0);
      const excede = s.monto > saldoEnOrigen;
      if (excede) excedeAlguna = true;
      const color = excede ? 'enc-c-red' : 'enc-c-amber';
      return html`${i > 0 ? raw('<br>') : ''}<span class="${color}">${label} (encargo): ${fmt(saldoEnOrigen)} <i class="fa-solid fa-arrow-right"></i> ${fmt(saldoEnOrigen - s.monto)}</span>`;
    });

    const cuentaDestEnc = cuentas.find(c => c.cuenta === destino);
    const saldoEnDestino = cuentaDestEnc ? cuentaDestEnc.saldo : 0;
    const nuevoDestino = saldoEnDestino + totalSplit;

    prev.innerHTML = html`${lineasOrigen}<br>
      <span class="enc-c-blue">${fuenteLabel(destino)} (encargo): ${fmt(saldoEnDestino)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoDestino)}</span>
      ${excedeAlguna ? html`<br><span class="enc-aviso-rojo10">Excede lo que el encargo tiene en esa cuenta</span>` : ''}
      ${filasIncompletas ? html`<br><span class="enc-aviso-amber10">Falta elegir la cuenta en una o más filas</span>` : ''}`;
    return;
  }

  // ── Modo simple (una sola cuenta origen) ──────────────────────────
  const monto = parseMoney(document.getElementById('moverenc_monto').value) || 0;
  const origen = document.getElementById('moverenc_origen').value;
  if (!monto || !origen || !destino) { prev.innerHTML = ''; return; }
  if (origen === destino) {
    prev.innerHTML = '<span class="enc-c-red">Origen y destino no pueden ser la misma cuenta</span>';
    return;
  }
  const cuentas = _getEncargoSaldoPorCuenta(enc);
  const labelOrigen = origen === '__sinesp__' ? 'Sin especificar' : fuenteLabel(origen);
  const saldoEnOrigen = origen === '__sinesp__'
    ? _getEncargoSaldoSinCuenta(enc)
    : (cuentas.find(c => c.cuenta === origen)?.saldo || 0);
  const excede = monto > saldoEnOrigen;
  const colorOrigen = excede ? 'enc-c-red' : 'enc-c-amber';
  const nuevoOrigen = saldoEnOrigen - monto;
  const cuentaDestEnc = cuentas.find(c => c.cuenta === destino);
  const saldoEnDestino = cuentaDestEnc ? cuentaDestEnc.saldo : 0;
  const nuevoDestino = saldoEnDestino + monto;
  prev.innerHTML = html`<span class="${colorOrigen}">${labelOrigen} (encargo): ${fmt(saldoEnOrigen)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoOrigen)}</span><br>
    <span class="enc-c-blue">${fuenteLabel(destino)} (encargo): ${fmt(saldoEnDestino)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoDestino)}</span>
    ${excede ? html`<br><span class="enc-aviso-rojo10">Excede lo que el encargo tiene en esa cuenta</span>` : ''}`;
}

// Rama split de confirmarMoverEncCuentas: la plata a reubicar sale de varias
// cuentas del encargo a la vez, todo hacia el mismo destino. Se registra una
// 'salida' interna por cada fila del split (mismo criterio de _splitTotal/
// _splitParte/_splitDe que usa la salida dividida de "Retirar plata", ver
// confirmarMovEncargo más arriba) + una única 'entrada' en el destino por el
// total. No se agrupan para borrado — igual que esa salida dividida, cada
// parte queda como un registro independiente en el historial del encargo.
function _confirmarMoverEncCuentasSplit(enc, destino, fecha) {
  const splits = _sp_moverenc.data(); // [{fuente, monto}]
  if (splits.length === 0) { toast('Agrega al menos una cuenta de origen', 'err'); return; }
  if (splits.some(s => !s.fuente)) { toast('Selecciona la cuenta de origen en cada fila', 'err'); return; }
  if (splits.some(s => FuentesFiltro.esTC(s.fuente))) { toast('Una tarjeta de crédito no puede ser cuenta de origen', 'err'); return; }

  const totalSplit = splits.reduce((a, s) => a + s.monto, 0);
  if (!totalSplit) { toast('Ingresa cuánto sale de cada cuenta', 'err'); return; }
  if (splits.some(s => s.fuente === destino)) {
    toast('Origen y destino no pueden ser la misma cuenta', 'err'); return;
  }
  const fuentesUsadas = splits.map(s => s.fuente);
  if (new Set(fuentesUsadas).size !== fuentesUsadas.length) {
    // Guarda de más: el select de cada fila ya excluye las cuentas usadas en
    // las otras (ver splitActualizarOpciones en split.js), no debería pasar.
    toast('No puedes repetir la misma cuenta de origen en dos filas', 'err'); return;
  }
  // Validar saldo del encargo en cada cuenta de origen, una por una
  for (const s of splits) {
    const esSinEsp = s.fuente === '__sinesp__';
    const labelOrigen = esSinEsp ? 'Sin especificar' : fuenteLabel(s.fuente);
    const saldoEnOrigen = esSinEsp ? _getEncargoSaldoSinCuenta(enc) : _getEncargoSaldoEnCuenta(enc, s.fuente);
    if (s.monto > saldoEnOrigen + 0.5) {
      toast('El encargo solo tiene ' + fmt(saldoEnOrigen) + ' en ' + labelOrigen, 'err');
      return;
    }
  }

  if (!enc.movimientos) enc.movimientos = [];
  const partes = splits.length;
  splits.forEach((s, i) => {
    const esSinEsp = s.fuente === '__sinesp__';
    enc.movimientos.push({
      id: uid(),
      tipo: 'salida',
      desc: 'Reubicación a ' + fuenteLabel(destino),
      monto: s.monto,
      // Si el origen es "Sin especificar" se guarda sin cuenta (mismo criterio que el modo simple)
      cuenta: esSinEsp ? '' : s.fuente,
      fecha,
      nota: 'Movimiento interno entre cuentas',
      ts: Date.now() + i,
      ...(partes > 1 ? { _splitTotal: totalSplit, _splitParte: i + 1, _splitDe: partes } : {})
    });
  });

  const labelsOrigen = splits.map(s => s.fuente === '__sinesp__' ? 'Sin especificar' : fuenteLabel(s.fuente));
  enc.movimientos.push({
    id: uid(),
    tipo: 'entrada',
    desc: 'Reubicación desde ' + labelsOrigen.join(' + '),
    monto: totalSplit,
    cuenta: destino,
    fecha,
    nota: 'Movimiento interno entre cuentas',
    ts: Date.now() + partes
  });

  save();
  closeSheet('mover-enc-cuentas');
  abrirEncargoDetalle(encargoActualId);
  toast(fmt(totalSplit) + ' reubicados a ' + fuenteLabel(destino), 'ok', 3500);
}

function confirmarMoverEncCuentas() {
  const destino = document.getElementById('moverenc_destino').value;
  const fecha = document.getElementById('moverenc_fecha').value || hoy();

  if (!destino) { toast('Selecciona la cuenta de destino', 'err'); return; }
  if (!FuentesFiltro.puedeRecibir(destino)) { toast('No puedes mover plata a una tarjeta de crédito', 'err'); return; }

  const enc = getEncargo(encargoActualId);
  if (!enc) return;

  if (_moverEncSplitMode) { _confirmarMoverEncCuentasSplit(enc, destino, fecha); return; }

  const monto = parseMoney(document.getElementById('moverenc_monto').value) || 0;
  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }
  const origen = document.getElementById('moverenc_origen').value;
  if (!origen) { toast('Selecciona la cuenta de origen', 'err'); return; }
  if (FuentesFiltro.esTC(origen)) { toast('Una tarjeta de crédito no puede ser cuenta de origen', 'err'); return; }
  if (origen === destino) { toast('Origen y destino no pueden ser la misma cuenta', 'err'); return; }

  const esOrigenSinEspecificar = origen === '__sinesp__';
  const labelOrigen = esOrigenSinEspecificar ? 'Sin especificar' : fuenteLabel(origen);

  // Verificar saldo del encargo en la cuenta origen (o en "Sin especificar")
  const saldoEnOrigen = esOrigenSinEspecificar
    ? _getEncargoSaldoSinCuenta(enc)
    : (_getEncargoSaldoPorCuenta(enc).find(c => c.cuenta === origen)?.saldo || 0);
  if (monto > saldoEnOrigen) {
    toast('El encargo solo tiene ' + fmt(saldoEnOrigen) + ' en ' + labelOrigen, 'err');
    return;
  }

  // Registrar dos movimientos internos: salida de origen, entrada a destino
  if (!enc.movimientos) enc.movimientos = [];

  enc.movimientos.push({
    id: uid(),
    tipo: 'salida',
    desc: 'Reubicación a ' + fuenteLabel(destino),
    monto,
    // Si el origen es "Sin especificar" se guarda sin cuenta (así lo interpreta el resto del sistema)
    cuenta: esOrigenSinEspecificar ? '' : origen,
    fecha,
    nota: 'Movimiento interno entre cuentas',
    ts: Date.now()
  });

  enc.movimientos.push({
    id: uid(),
    tipo: 'entrada',
    desc: 'Reubicación desde ' + labelOrigen,
    monto,
    cuenta: destino,
    fecha,
    nota: 'Movimiento interno entre cuentas',
    ts: Date.now() + 1
  });

  save();
  closeSheet('mover-enc-cuentas');
  abrirEncargoDetalle(encargoActualId);
  toast(fmt(monto) + ' reubicados de ' + labelOrigen + ' a ' + fuenteLabel(destino), 'ok', 3500);
}

// Listener para el botón confirmar
(function() {
  const btn = document.getElementById('btn-confirmar-mover-enc-cuentas');
  if (btn) btn.addEventListener('click', confirmarMoverEncCuentas);
})();

// ── TRANSFERENCIA DE PLATA ENTRE ENCARGOS ──────────────────────────────
// Caso: A te pide que le pagues a B, y tú les guardas plata a los dos
// (dos encargos distintos). Esa plata deja de ser de A y pasa a ser de
// B — pero sigue siendo ajena todo el tiempo, nunca se vuelve tuya ni
// toca tu patrimonio. Es como "Mover entre cuentas" pero cruzando dos
// encargos en vez de reubicar dentro del mismo.
function abrirTransferenciaEncargo() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  const comprometido = encargoComprometido(enc);
  const libre = encargoLibre(enc);
  if (libre <= 0) { toast(comprometido > 0 ? 'Toda la plata de este encargo ya está comprometida' : 'El encargo no tiene saldo disponible', 'err'); return; }

  const otros = (S.encargos||[]).filter(e => e.id !== enc.id);
  if (!otros.length) { toast('No hay otro encargo al cual transferirle plata', 'err'); return; }

  document.getElementById('transfEncOrigenNombre').textContent = enc.nombre;
  document.getElementById('transfEncOrigenSaldo').textContent = comprometido > 0
    ? fmt(libre) + ' disponible (de ' + fmt(saldo) + ', ' + fmt(comprometido) + ' comprometido)'
    : fmt(libre);
  document.getElementById('transfenc_monto').value = '';
  document.getElementById('transfenc_desc').value = 'Plata para ' + enc.nombre;
  document.getElementById('transfenc_fecha').value = hoy();
  document.getElementById('transfenc_preview').innerHTML = '';

  // Select destino: los demás encargos
  const selDestino = document.getElementById('transfenc_destino');
  selDestino.innerHTML = html`<option value="">Seleccionar encargo</option>${otros.map(o => html`<option value="${o.id}">${o.nombre}</option>`)}`;

  // Select origen: de qué cuenta del encargo actual salió (mismo criterio que Traspaso)
  const selOrigen = document.getElementById('transfenc_origen');
  const cuentasEnc = _getEncargoSaldoPorCuenta(enc);
  const fuentesSinTC = getFuentesSinTC();
  if (cuentasEnc.length === 0) {
    selOrigen.innerHTML = html`<option value="">Sin especificar</option>${fuentesSinTC.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
  } else {
    selOrigen.innerHTML = html`<option value="">Sin especificar</option>${cuentasEnc.map(f=>html`<option value="${f.cuenta}">${f.label} (${fmt(f.saldo)})</option>`)}`;
    selOrigen.value = cuentasEnc[0].cuenta;
  }

  // Select "dónde queda guardada esa plata ahora" para el encargo destino
  // (ej. la tienes en Nequi mientras se la entregas físicamente a esa persona)
  const selCuentaFisica = document.getElementById('transfenc_cuenta_fisica');
  selCuentaFisica.innerHTML = html`<option value="">Sin especificar</option>${fuentesSinTC.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
  if (cuentasEnc.length > 0) selCuentaFisica.value = cuentasEnc[0].cuenta;

  _actualizarTransfEncPreview(enc);
  selDestino.onchange = function() { _actualizarTransfEncPreview(enc); };
  document.getElementById('transfenc_monto').oninput = function() { _actualizarTransfEncPreview(enc); };

  openSheet('transferencia-encargo');
  focusSheetField('transfenc_monto');
}

function _actualizarTransfEncPreview(enc) {
  const monto = parseMoney(document.getElementById('transfenc_monto').value) || 0;
  const destinoId = document.getElementById('transfenc_destino').value;
  const prev = document.getElementById('transfenc_preview');
  if (!prev) return;
  if (!monto || !destinoId) { prev.innerHTML = ''; return; }
  const destino = getEncargo(destinoId);
  if (!destino) { prev.innerHTML = ''; return; }
  const libreOrigen = encargoLibre(enc);
  const nuevoOrigen = libreOrigen - monto;
  const saldoDestino = encargoSaldo(destino);
  const colorOrigen = nuevoOrigen < 0 ? 'enc-c-red' : 'enc-c-blue';
  prev.innerHTML = html`<span class="${colorOrigen}">${enc.nombre} (disponible): ${fmt(libreOrigen)} <i class="fa-solid fa-arrow-right"></i> ${fmt(nuevoOrigen)}</span><br>
    <span class="enc-c-blue">${destino.nombre}: ${fmt(saldoDestino)} <i class="fa-solid fa-arrow-right"></i> ${fmt(saldoDestino + monto)}</span>
    ${nuevoOrigen < 0 ? html`<br><span class="enc-aviso-rojo10">Más de lo que el encargo tiene disponible (sin contar lo comprometido)</span>` : ''}`;
}

function confirmarTransferenciaEncargo() {
  const monto = parseMoney(document.getElementById('transfenc_monto').value) || 0;
  const destinoId = document.getElementById('transfenc_destino').value;
  const desc = document.getElementById('transfenc_desc').value.trim();
  const fecha = document.getElementById('transfenc_fecha').value || hoy();
  const cuentaOrigen = document.getElementById('transfenc_origen').value || '';
  const cuentaFisica = document.getElementById('transfenc_cuenta_fisica').value || '';

  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }
  if (!destinoId) { toast('Selecciona a qué encargo transferir', 'err'); return; }
  if (!desc) { toast('Ingresa una descripción', 'err'); return; }

  const encOrigen = getEncargo(encargoActualId);
  const encDestino = getEncargo(destinoId);
  if (!encOrigen || !encDestino) return;
  if (encOrigen.id === encDestino.id) { toast('El origen y el destino no pueden ser el mismo encargo', 'err'); return; }

  const libreActual = encargoLibre(encOrigen);
  if (monto > libreActual) {
    toast(`El encargo solo tiene ${fmt(libreActual)} disponible (el resto ya está comprometido)`, 'err'); return;
  }
  if (cuentaOrigen) {
    const saldoEnCuenta = _getEncargoSaldoEnCuenta(encOrigen, cuentaOrigen);
    if (monto > saldoEnCuenta) {
      toast(`El encargo solo tiene ${fmt(saldoEnCuenta)} guardado en ${fuenteLabel(cuentaOrigen)}`, 'err');
      return;
    }
  }

  // Vínculo compartido entre las dos puntas de la transferencia — necesario
  // para poder revertir exactamente este par si se elimina cualquiera de
  // los dos lados (ver §3 de encargos.md: nunca dejar huérfano un lado de
  // un movimiento vinculado).
  const transfId = uid();

  if (!encOrigen.movimientos) encOrigen.movimientos = [];
  encOrigen.movimientos.push({
    id: uid(),
    tipo: 'salida',
    desc: desc + ' a ' + encDestino.nombre,
    monto,
    cuenta: cuentaOrigen,
    fecha,
    nota: 'Transferencia a otro encargo',
    _transfEncargo: true,
    _transfId: transfId,
    _encargoDestino: encDestino.id,
    ts: Date.now()
  });

  if (!encDestino.movimientos) encDestino.movimientos = [];
  encDestino.movimientos.push({
    id: uid(),
    tipo: 'entrada',
    desc: desc + ' desde ' + encOrigen.nombre,
    monto,
    cuenta: cuentaFisica,
    fecha,
    nota: 'Transferencia de otro encargo',
    _transfEncargo: true,
    _transfId: transfId,
    _encargoOrigen: encOrigen.id,
    ts: Date.now() + 1
  });

  // A propósito no hay sumarFuente/descontarFuente: la plata sigue siendo
  // ajena todo el tiempo, solo cambia de dueño entre los dos encargos —
  // nunca toca una cuenta propia ni el patrimonio (§3 de encargos.md).
  save();
  refresh();
  closeSheet('transferencia-encargo');
  abrirEncargoDetalle(encargoActualId);
  toast(`${fmt(monto)} transferidos a ${encDestino.nombre}`, 'ok', 3500);
}

// Listener para el botón confirmar
(function() {
  const btn = document.getElementById('btn-confirmar-transferencia-encargo');
  if (btn) btn.addEventListener('click', confirmarTransferenciaEncargo);
})();

// Hook into refresh
// (solo si la pantalla de Encargos está activa: lo garantiza `pantalla`, ya no un if a mano)
Refresh.registrar('encargos-pantalla', () => {
  if (encargoActualId) abrirEncargoDetalle(encargoActualId);
  else renderEncargosList();
}, { pantalla: 'encargos' });

// Abre el sheet «Nuevo encargo». Lo usan el botón de pie de la lista y el botón del estado vacío
// (data-action="encargos:nuevo"): un solo camino, el select de cuentas siempre se puebla igual.
function abrirNuevoEncargo() {
  // Poblar select de cuentas para saldo inicial
  const sel = document.getElementById('enc_cuenta_ini');
  if (sel) {
    const fuentes = getFuentesSinTC();
    // FIX (2026-08-15, reportado por el usuario vía warning de consola
    // "select tag was parsed within another select tag"): f.val/f.label sin
    // escapar acá — mismo patrón que las otras 3 ocurrencias de este bug en
    // este archivo (líneas ~1175/1184/1186) y que opcionesCuenta() en
    // el núcleo. Nombres de cuenta personalizada son texto libre del
    // usuario — con caracteres como <, >, & sin escapar dentro del
    // innerHTML de un <select>, el parser del navegador puede comportarse
    // de forma impredecible. Ver CHANGELOG.md.
    sel.innerHTML = html`<option value="">Sin especificar</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
  }
  openSheet('nuevo-encargo');
}

// Init event listeners for encargos
// (el listener vacío en DOMContentLoaded que vivía acá se sacó en la ronda
// de lazy-loading: no hacía nada — el wiring real siempre corrió top-level
// en el IIFE de abajo, ver auditoria-tecnica.md)
(function initEncargosListeners(){
  const btn_nuevo = document.getElementById('btn-nuevo-encargo');
  if (btn_nuevo) btn_nuevo.addEventListener('click', () => abrirNuevoEncargo());

  // Mostrar/ocultar campo de cuenta inicial según si hay saldo
  const encSaldo = document.getElementById('enc_saldo');
  if (encSaldo) {
    encSaldo.addEventListener('input', function() {
      const v = parseMoney(this.value) || 0;
      const wrap = document.getElementById('enc_cuenta_wrap');
      if (wrap) wrap.style.display = v > 0 ? '' : 'none';
    });
  }

  const btn_crear = document.getElementById('btn-crear-encargo');
  // Nota: se llama como () => crearEncargo() (no crearEncargo directo) para que cada clic
  // lea el valor ACTUAL de la variable global. Más abajo en el archivo (línea ~21597)
  // crearEncargo se reasigna para adjuntar personaId; pasar la referencia directa acá
  // congelaba esa versión vieja y el override nunca corría.
  if (btn_crear) btn_crear.addEventListener('click', () => crearEncargo());

  const btn_volver = document.getElementById('btn-volver-encargos');
  if (btn_volver) btn_volver.addEventListener('click', volverEncargosLista);

  const btn_eliminar = document.getElementById('btn-eliminar-encargo');
  if (btn_eliminar) btn_eliminar.addEventListener('click', eliminarEncargoActual);

  const btn_editar_enc = document.getElementById('btn-editar-encargo');
  if (btn_editar_enc) btn_editar_enc.addEventListener('click', editarEncargoActual);

  const btn_guardar_edit_enc = document.getElementById('btn-guardar-editar-encargo');
  if (btn_guardar_edit_enc) btn_guardar_edit_enc.addEventListener('click', guardarEditarEncargo);

  // GUARD (2026-08-13, encontrado en prueba real de navegador post-lazy):
  // guardarEditarSpotify vive en spotify.js, no en este archivo. Sin guard,
  // si el usuario entra a Encargos antes de haber visitado Spotify (ambos
  // lazy), esto tira ReferenceError acá mismo — y como estaba antes del
  // cierre del IIFE, los dos listeners de abajo (btn_mov/btn_traspaso)
  // tampoco se llegaban a conectar. Mismo tipo de degradación aceptada que
  // ya existe para otros cruces entre módulos lazy: si spotify.js todavía
  // no cargó, este botón puntual queda sin conectar hasta que sí lo haga.
  const btn_guardar_edit_sp = document.getElementById('btn-guardar-editar-spotify');
  if (btn_guardar_edit_sp && typeof guardarEditarSpotify === 'function') btn_guardar_edit_sp.addEventListener('click', guardarEditarSpotify);

  const btn_mov = document.getElementById('btn-confirmar-mov-encargo');
  if (btn_mov) btn_mov.addEventListener('click', confirmarMovEncargo);

  const btn_traspaso = document.getElementById('btn-confirmar-traspaso-encargo');
  if (btn_traspaso) btn_traspaso.addEventListener('click', confirmarTraspasoEncargo);
})();

// Render encargos when tab is clicked
const _origNavEncargos = document.getElementById('nav-encargos');
if (_origNavEncargos) {
  _origNavEncargos.addEventListener('click', function(){
    // Rendered by the nav click handler, but ensure list is shown
    setTimeout(()=>{
      if (!encargoActualId) renderEncargosList();
    }, 50);
  });
}


/* ================================================================
   COMPRA DE ENCARGO CON TARJETA DE CREDITO
   - El encargo pierde el saldo (salida)
   - El dinero NO desaparece: se mueve a una cuenta propia (para pagar TC)
   - La deuda de la TC sube por el valor REAL de la compra
   - El diferencial usa el motor común (instancia 'ctc'): sin beneficiarios
     ni intercambio, solo "real" + cuenta propia para el margen.
   ================================================================ */

const _ctcMi = _crearSplitSobrante('ctc', 'ctcMi', {
  simple: 'ctc_dif_mi_simple', split: 'ctc_dif_mi_split', toggle: 'ctc_dif_mi_toggle',
  rows: 'ctcDifMiRows', preview: 'ctc_dif_mi_preview'
});
function _ctcMiSplitToggle() { _ctcMi.toggle(); }
function _ctcMiAgregarRow() { _ctcMi.agregar(); }

const _dif_ctc = diffRegistrarInstancia('ctc', {
  ids: {
    wrap: 'ctc-dif-wrap', body: 'ctc-dif-body', icon: 'ctc-dif-icon',
    real: 'ctc_dif_real', resumen: 'ctc-dif-resumen',
    miCuentaWrap: 'ctc-dif-margen-wrap', miCuenta: 'ctc_dif_margen_cuenta'
  },
  permiteBeneficiarios: false,
  permiteIntercambio: false,
  permiteMiCuenta: true,
  exigeMargenPositivo: true,
  placeholderSinReal: 'Ingresa el valor real para ver el resumen',
  labelMargenNegativo: 'El valor real debe ser menor que el monto del encargo',
  getDijo: () => parseMoney(document.getElementById('ctc_monto')?.value) || 0,
  descMargen: (mov) => `Diferencial encargo ${mov._encNombre || ''} — `,
  origenSeccion: 'Encargos', // ídem: deleteMovEncargo limpia estos por _encMovId
  getMiCuentaSplit: () => _ctcMi.getData(),
  onReset: () => _ctcMi.reset(),
  onResumen: () => { _ctcMi.preview(); _ctcActualizarPreview(); }
});

// Wrappers con los nombres viejos — el HTML del sheet sigue llamándolos igual

function abrirCompraConTC() {
  const enc = getEncargo(encargoActualId);
  if (!enc) return;
  const saldo = encargoSaldo(enc);
  const comprometido = encargoComprometido(enc);
  const libre = encargoLibre(enc);
  if (libre <= 0) { toast(comprometido > 0 ? 'Toda la plata de este encargo ya está comprometida' : 'El encargo no tiene saldo disponible', 'err'); return; }

  document.getElementById('compraTcEncNombre').textContent = enc.nombre;
  document.getElementById('compraTcEncSaldo').textContent = comprometido > 0
    ? fmt(libre) + ' disponible (de ' + fmt(saldo) + ', ' + fmt(comprometido) + ' comprometido)'
    : fmt(libre);
  document.getElementById('ctc_desc').value = '';
  document.getElementById('ctc_monto').value = '';
  document.getElementById('ctc_nota').value = '';
  document.getElementById('ctc_fecha').value = hoy();
  diffReset('ctc');

  // Poblar select de cuentas del encargo
  const selEnc = document.getElementById('ctc_cuenta_enc');
  const cuentasConSaldo = _getEncargoSaldoPorCuenta(enc);
  let _ctcCuentaEncMuestraSaldoEnOpcion = false;
  if (cuentasConSaldo.length === 0) {
    const fuentes = getFuentesSinTC(); // la plata de un encargo no está en una TC
    selEnc.innerHTML = html`<option value="">Sin especificar</option>${fuentes.map(f => html`<option value="${f.val}">${f.label}</option>`)}`;
  } else {
    selEnc.innerHTML = html`<option value="">Sin especificar</option>${cuentasConSaldo.map(f => html`<option value="${f.cuenta}">${f.label} (${fmt(f.saldo)})</option>`)}`;
    selEnc.value = cuentasConSaldo[0].cuenta;
    _ctcCuentaEncMuestraSaldoEnOpcion = true;
  }
  // El hint solo aporta info nueva cuando el select no la muestra ya en cada
  // opción. Ver reglas-visuales.md#selectores-con-saldo.
  const _ctcCuentaEncHintEl = document.getElementById('ctc_cuenta_enc_hint');
  if (_ctcCuentaEncHintEl) _ctcCuentaEncHintEl.style.display = _ctcCuentaEncMuestraSaldoEnOpcion ? 'none' : '';
  if (!_ctcCuentaEncMuestraSaldoEnOpcion) _ctcActualizarCuentaEncHint();

  // Poblar tarjetas de credito
  const selTC = document.getElementById('ctc_tarjeta');
  const tarjetas = (S.tarjetasCredito || []);
  if (tarjetas.length === 0) {
    selTC.innerHTML = '<option value="">No hay TC registradas</option>';
  } else {
    selTC.innerHTML = html`<option value="">Seleccionar TC</option>${tarjetas.map(t => html`<option value="${t.id}">${t.nombre} (deuda: ${fmt(t.deuda||0)})</option>`)}`;
    // Pre-seleccionar si solo hay una
    if (tarjetas.length === 1) selTC.value = tarjetas[0].id;
  }

  // Poblar destino del dinero (mis cuentas, sin TC: es plata que entra) — el saldo va en el hint de abajo,
  // no en la opción (mismo patrón que traspaso_destino/spPagarFuente).
  const selDest = document.getElementById('ctc_destino');
  const fuentes = FuentesFiltro.receptoras(getFuentes());
  selDest.innerHTML = html`<option value="">Seleccionar cuenta</option>${fuentes.map(f => html`<option value="${f.val}">${f.label}</option>`)}`;
  // Buscar cajita que tenga "tarjeta" o "TC" o "pago" en el nombre para pre-seleccionar
  const cajitaTC = (S.cajitas || []).find(c => {
    const n = (c.nombre||'').toLowerCase();
    return n.includes('tarjeta') || n.includes(' tc') || n.includes('pago tc') || n.includes('tc ');
  });
  if (cajitaTC) selDest.value = 'cajita:' + cajitaTC.id;

  _ctcActualizarDestinoHint();
  _ctcActualizarPreview();

  openSheet('compra-tc-encargo');
  focusSheetField('ctc_desc');
}

function _ctcActualizarCuentaEncHint() {
  const sel = document.getElementById('ctc_cuenta_enc');
  const hint = document.getElementById('ctc_cuenta_enc_hint');
  if (!hint) return;
  const val = sel.value;
  if (!val) { hint.textContent = ''; return; }
  const enc = getEncargo(encargoActualId);
  if (!enc) { hint.textContent = ''; return; }
  const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, val);
  hint.textContent = saldoEnCuenta > 0
    ? 'Del encargo en esta cuenta: ' + fmt(saldoEnCuenta)
    : 'El encargo no tiene saldo en esta cuenta';
  hint.style.color = saldoEnCuenta > 0 ? 'var(--text3)' : 'var(--red)';
}

function _ctcActualizarDestinoHint() {
  const sel = document.getElementById('ctc_destino');
  const hint = document.getElementById('ctc_destino_hint');
  if (!hint) return;
  const val = sel.value;
  if (!val) { hint.textContent = ''; return; }
  hint.textContent = 'Saldo actual: ' + fmt(getSaldoFuente(val));
  hint.style.color = 'var(--text3)';
}

function _ctcActualizarPreview() {
  const prev = document.getElementById('ctc_preview');
  if (!prev) return;
  const monto = parseMoney(document.getElementById('ctc_monto').value) || 0;
  const cuentaEnc = document.getElementById('ctc_cuenta_enc').value;
  const tcId = document.getElementById('ctc_tarjeta').value;
  const destino = document.getElementById('ctc_destino').value;
  if (!monto) { prev.style.display = 'none'; prev.innerHTML = ''; return; }

  const enc = getEncargo(encargoActualId);
  const saldoEnc = enc ? encargoSaldo(enc) : 0;
  const saldoEncCuenta = (enc && cuentaEnc) ? _getEncargoSaldoEnCuenta(enc, cuentaEnc) : saldoEnc;

  // Diferencial — vía motor común
  const difActivo = diffEstaAbierto('ctc');
  const calc = difActivo ? diffCalcular('ctc') : null;
  const real = calc ? calc.real : 0;
  const tcMonto = calc && real > 0 && real < monto ? real : monto;
  const margen = calc && real > 0 && real < monto ? calc.margen : 0;

  // TC info
  const tc = tcId ? (S.tarjetasCredito||[]).find(t=>t.id===tcId) : null;
  const deudaTC = tc ? (tc.deuda||0) : 0;
  const nombreTC = tc ? tc.nombre : (tcId ? tcId : 'TC');

  // Destino
  const saldoDest = destino ? getSaldoFuente(destino) : 0;
  const lblDest = destino ? fuenteLabel(destino) : '';

  const lines = [];
  lines.push(html`<span class="enc-c-red">Encargo ${enc?enc.nombre:''}: ${fmt(saldoEncCuenta)} <i class="fa-solid fa-arrow-right"></i> ${fmt(saldoEncCuenta - monto)}</span>`);
  if (destino) lines.push(html`<span class="enc-c-accent">${lblDest}: ${fmt(saldoDest)} <i class="fa-solid fa-arrow-right"></i> ${fmt(saldoDest + monto)}</span>`);
  if (tc) lines.push(html`<span class="enc-c-red">Deuda ${nombreTC}: ${fmt(deudaTC)} <i class="fa-solid fa-arrow-right"></i> ${fmt(deudaTC + tcMonto)}</span>`);
  if (margen > 0) lines.push(html`<span class="enc-c-accent">Diferencial tuyo: +${fmt(margen)}</span>`);

  prev.innerHTML = html`${lines.map((l,i)=> i===0 ? l : html`<br>${l}`)}`;
  prev.style.display = '';
}

function confirmarCompraConTC() {
  const desc  = document.getElementById('ctc_desc').value.trim();
  const monto = parseMoney(document.getElementById('ctc_monto').value) || 0;
  const cuentaEnc = document.getElementById('ctc_cuenta_enc').value;
  const tcId  = document.getElementById('ctc_tarjeta').value;
  const destino = document.getElementById('ctc_destino').value;
  const nota  = document.getElementById('ctc_nota').value.trim();
  const fecha = document.getElementById('ctc_fecha').value || hoy();

  if (!desc)  { toast('Ingresa una descripción', 'err'); return; }
  if (!monto) { toast('Ingresa un monto válido', 'err'); return; }
  if (!tcId)  { toast('Selecciona la tarjeta de crédito', 'err'); return; }
  if (!destino) { toast('Selecciona a dónde va el dinero para pagar la TC', 'err'); return; }
  if (!FuentesFiltro.puedeRecibir(destino)) { toast('Una tarjeta de crédito no puede recibir plata', 'err'); return; }

  const enc = getEncargo(encargoActualId);
  if (!enc) return;

  const saldoActual = encargoLibre(enc);
  if (monto > saldoActual) {
    toast(`El encargo solo tiene ${fmt(saldoActual)} disponible (el resto ya está comprometido)`, 'err'); return;
  }
  if (cuentaEnc) {
    const saldoEnCuenta = _getEncargoSaldoEnCuenta(enc, cuentaEnc);
    if (monto > saldoEnCuenta + 0.5) {
      toast(`En ${fuenteLabel(cuentaEnc)} solo hay ${fmt(saldoEnCuenta)} de este encargo`, 'err'); return;
    }
  }

  // Reparto del sobrante en varias cuentas (si usó "Dividir") — antes de escribir nada
  const _errCtcMi = diffValidarMiCuenta('ctc');
  if (_errCtcMi) { toast(_errCtcMi, 'err', 5000); return; }

  // Diferencial — vía motor común. tcMonto/margen dependen de si el real es válido (real>0 y real<monto).
  const difActivo = diffEstaAbierto('ctc');
  const calc = difActivo ? diffCalcular('ctc') : null;
  const realValido = calc && calc.real > 0 && calc.real < monto;
  const tcMonto = realValido ? calc.real : monto;
  const margen = realValido ? calc.margen : 0;

  // ── 1. Registrar SALIDA en el encargo (el dinero deja de ser de ellos)
  if (!enc.movimientos) enc.movimientos = [];
  const _encMovId = uid(); // ID del movimiento del encargo — usado para vincular efectos secundarios
  const movEncargo = {
    id: _encMovId,
    tipo: 'salida',
    desc: `Compra pagada con TC: ${desc}`,
    monto,
    cuenta: cuentaEnc || '',
    fecha,
    nota: nota || 'Compra de encargo pagada con TC — dinero convertido para pago de tarjeta.',
    _esTcEncargo: true,
    _encId: enc.id,      // guardar encargo origen para poder encontrar el raw desde detalle
    _destino: destino,   // guardar destino para poder revertir el sumarFuente al eliminar
    _tcId: tcId,         // guardar TC para revertir la deuda al eliminar
    _tcMonto: tcMonto,      // monto real cargado a la TC
    _dijoMonto: monto,      // monto que se le dijo al encargo (puede diferir del real si hay margen)
    _destinoMonto: tcMonto, // monto que realmente entra a la cuenta destino (= tcMonto, para reversión)
    ts: Date.now()
  };
  enc.movimientos.push(movEncargo);

  // ── 2. Mover el dinero del encargo a la cuenta destino
  //    Solo entra el valor real cobrado por la TC (tcMonto), no el total del encargo.
  //    La diferencia (margen) ya fue separada como ganancia tuya en el paso diferencial.
  sumarFuente(destino, tcMonto, _ogEnc(_encMovId));
  if (!S.movimientos) S.movimientos = [];
  S.movimientos.push({
    id: uid(),
    tipo: 'entrada',
    fuente: destino,
    _encMovId,
    clase: 'neutro',
    _esTcEncargo: true,
    monto: tcMonto,
    fecha,
    desc: `TC encargo ${enc.nombre}: ${desc}`,
    nota: 'Dinero del encargo recibido para pagar la tarjeta de crédito.',
    ts: Date.now()
  });

  // ── 3. Aumentar la deuda de la TC por el valor REAL (no margen)
  const tc = (S.tarjetasCredito||[]).find(t=>t.id===tcId);
  if (tc) {
    tc.deuda = (tc.deuda||0) + tcMonto;
  }

  // ── 4. Registrar en el historial de la TC (sin contar como gasto propio)
  if (!S.tcMovimientos) S.tcMovimientos = [];
  S.tcMovimientos.push({
    id: uid(),
    tcId,
    tipo: 'cargo_encargo',
    desc: `Compra encargo ${enc.nombre}: ${desc}`,
    monto: tcMonto,
    fecha,
    nota: nota || 'Cargo de encargo — no es gasto propio',
    encId: enc.id,
    _encMovId  // vínculo para poder limpiar al eliminar el movimiento del encargo
  });

  // ── 5. Si hay diferencial, registrar el margen vía el motor común (usa el mismo _encMovId para poder revertir)
  if (margen > 0.5) {
    const movTemp = { desc, fecha, _encNombre: enc.nombre };
    const diferencial = diffAplicar('ctc', movTemp, _encMovId);
    if (diferencial) movEncargo.diferencial = diferencial;
  }

  // ── 6. Registrar en historial de cambios
  if (window.logCambio) {
    logCambio(
      `Compra TC encargo ${escHtml(enc.nombre)}`,
      fmt(monto),
      tc ? tc.nombre : tcId,
      'tc_encargo'
    );
  }

  save();
  refresh();
  closeSheet('compra-tc-encargo');
  abrirEncargoDetalle(encargoActualId);
  toast(`${fmt(monto)} del encargo a ${fuenteLabel(destino)} · TC sube ${fmt(tcMonto)}`, 'ok', 4000);
}

// Conectar el botón confirmar al cargar
(function() {
  const btn = document.getElementById('btn-confirmar-compra-tc');
  if (btn) btn.addEventListener('click', confirmarCompraConTC);
  // Listeners de cambio en los selects del sheet
  const selEnc = document.getElementById('ctc_cuenta_enc');
  if (selEnc) selEnc.addEventListener('change', _ctcActualizarCuentaEncHint);
  const selDest = document.getElementById('ctc_destino');
  if (selDest) selDest.addEventListener('change', _ctcActualizarDestinoHint);
})();

/* ═══════════════════════════════════════════════════════════════
   WIRING MIGRADO DESDE index.html (_initEventListeners) — previews
   en vivo de "Retirar plata" (movenc), "Compra con TC" (ctc) y los
   tres inputs "valor real" del motor Diferencial (movenc/ctc/
   usarParte). Documentado como hecho en CHANGELOG.md (2026-07-27),
   pero nunca había llegado a este archivo — agregado ahora. Mismo
   patrón que el bloque equivalente ya existente en prestado.js.
   ═══════════════════════════════════════════════════════════════ */
[
  ['movenc_monto', 'input', _movEncSplitPreview],
  ['movenc_monto', 'input', _dif_movenc.resumen],
  ['movenc_monto', 'input', _movEncMiaPreview],
  ['movenc_dif_real', 'input', _movEncMiaPreview],
  ['movenc_mia_cuenta_sale', 'change', _movEncMiaPreview],
  ['movenc_mia_cuenta_entra', 'change', _movEncMiaPreview],
  ['movenc_faltante_cuenta', 'change', _movEncFaltanteCuentaHint],
  ['ctc_monto', 'input', _ctcActualizarPreview],
  ['ctc_monto', 'input', _dif_ctc.resumen],
  ['ctc_cuenta_enc', 'change', _ctcActualizarPreview],
  ['ctc_tarjeta', 'change', _ctcActualizarPreview],
  ['ctc_destino', 'change', _ctcActualizarPreview],
  ['movenc_dif_real', 'input', _dif_movenc.resumen],
  ['ctc_dif_real', 'input', _dif_ctc.resumen],
  ['usar_parte_dif_real', 'input', _dif_usarParte.resumen],
].forEach(([elId, evt, fn]) => {
  const el = document.getElementById(elId);
  if (el) el.addEventListener(evt, fn);
});

/* ═══════════════════════════════════════════════════════════════
   REGISTRO DE EVENTOS (js/core/events.js)
   Reemplaza los onclick="..." inline que tenía este módulo — mismo
   patrón que spotify.js y mesada.js. Los handlers con argumentos
   dinámicos (ids de encargo/movimiento/parte) se generan en el HTML
   con Events.attr(...); los que no llevan argumento (botones fijos
   de los sheets) se registran acá con el mismo nombre de acción que
   ya tenía el atributo data-action escrito a mano en el markup.

   IMPORTANTE — por qué cada entrada es `(...args) => fn(...args)` y
   no la función directa: `Events.registerAll`/`on` guardan el VALOR
   que reciben en el momento en que este bloque corre. Si más adelante
   otro módulo que llegue después reasigna una de estas
   funciones (`abrirEncargoDetalle = function(id) {...}`, el patrón de
   monkey-patch que usa el resto de la app para agregar integraciones), esa
   reasignación cambia la variable global pero NO lo que ya quedó
   copiado acá adentro — los clicks con data-action seguirían llamando
   a la versión vieja, sin el hook del módulo nuevo, en silencio
   (sin error en consola). Encerrar cada una en una arrow function
   hace que Events resuelva el nombre en cada click, no una sola vez
   al cargar — mismo fix ya aplicado puntualmente a `spotify:editar`
   (ver CHANGELOG.md), generalizado acá a todo el bloque para que
   ninguna función de Encargos pueda quedar huérfana de esta forma,
   la haya envuelto alguien o no todavía.
   ═══════════════════════════════════════════════════════════════ */

Events.registerAll('encargos', {
  nuevo:                  (...args) => abrirNuevoEncargo(...args),        // botón del estado vacío (el de pie usa un listener por id)
  abrirMov:               (...args) => abrirMovEncargo(...args),          // data-args: ["entrada"] | ["salida"]
  abrirSalidaMenu:        (...args) => abrirSalidaEncargoMenu(...args),
  salidaMenuIr:           (...args) => _salidaEncMenuIr(...args),         // data-args: ["normal"|"mio"|"otroEncargo"|"tc"]
  abrirMoverCuentas:      (...args) => abrirMoverEntreCuentasEncargo(...args),
  moverEncSplitToggle:      (...args) => _moverEncSplitToggle(...args),
  moverEncAgregarSplitRow:  (...args) => _sp_moverenc.addRow(...args),
  abrirNuevaParte:        (...args) => abrirNuevaParte(...args),
  movSplitToggle:         (...args) => _sp_movenc.toggle(...args),
  movAgregarSplitRow:     (...args) => _sp_movenc.addRow(...args),
  difToggle:              (...args) => _dif_movenc.toggle(...args),
  difAddBenef:            (...args) => _dif_movenc.addParte(...args),
  miaToggle:              (...args) => _movEncMiaToggle(...args),
  miaSaleSplitToggle:     (...args) => _sp_miaSale.toggle(...args),
  miaSaleAgregarRow:      (...args) => _sp_miaSale.addRow(...args),
  miaEntraSplitToggle:    (...args) => _sp_miaEntra.toggle(...args),
  miaEntraAgregarRow:     (...args) => _sp_miaEntra.addRow(...args),
  difMiSplitToggle:       (...args) => _sp_movencDifMi.toggle(...args),
  ctcMiSplitToggle:       (...args) => _ctcMiSplitToggle(...args),
  ctcMiAgregarRow:        (...args) => _ctcMiAgregarRow(...args),
  usarParteMiSplitToggle: (...args) => _usarParteMiSplitToggle(...args),
  usarParteMiAgregarRow:  (...args) => _usarParteMiAgregarRow(...args),
  difMiAgregarRow:        (...args) => _sp_movencDifMi.addRow(...args),
  confirmarPrestarFaltante: (...args) => _movEncConfirmarPrestarFaltante(...args),
  guardarParte:           (...args) => guardarParte(...args),
  cerrarParteSheet:       (...args) => cerrarPartSheet(...args),
  usarParteSplitToggle:   (...args) => _sp_usarParte.toggle(...args),
  usarParteAgregarSplitRow: (...args) => _sp_usarParte.addRow(...args),
  usarParteDifToggle:     (...args) => _dif_usarParte.toggle(...args),
  usarParteAddBenef:      (...args) => _dif_usarParte.addParte(...args),
  confirmarUsarParte:     (...args) => _confirmarUsarParte(...args),
  ctcDifToggle:           (...args) => _dif_ctc.toggle(...args),
  // Con argumentos dinámicos (id de encargo / movimiento / parte):
  abrirDetalle:           (...args) => abrirEncargoDetalle(...args),       // (encId)
  abrirDesdeCuenta:       (...args) => abrirEncargoDesdeCuenta(...args),   // (encId)
  deleteMov:              (...args) => deleteMovEncargo(...args),         // (encId, movId)
  usarParte:              (...args) => usarParte(...args),                // (encId, parteId)
  editarParte:            (...args) => editarParte(...args),              // (encId, parteId)
  eliminarParte:          (...args) => eliminarParte(...args),             // (encId, parteId)
});

/* ═══════════════════════════════════════════════════════════════
   INTEGRACIÓN CON EL SISTEMA DE PERSONAS
   (antes js/modules/encargos-personas.js — fusionado acá el 2026-08-03)

   Selector de persona en "Nuevo encargo", el hook que exige y asigna
   personaId al crear, y los botones/avatares de "ver perfil" en la
   lista y en el detalle de un encargo. Ver docs/encargos.md.

   Antes vivía en un archivo aparte, cargado más abajo en index.html,
   por la premisa de que dependía de getPersona()/abrirSelPersona()/
   PERSONA_COLORES/_inyectarPersonaSheets() (definidos en personas.js,
   que cargaba después). Esa premisa no se sostenía contra el código
   real: todas esas llamadas viven DENTRO de funciones (nunca a nivel
   superior del archivo), así que solo se ejecutan en el click —mucho
   después de que personas.js ya terminó de cargar, sin importar el
   orden entre <script defer>. Lo único que este bloque necesita a
   nivel superior (crearEncargo, renderEncargosList, abrirEncargoDetalle,
   openSheet) ya está definido arriba, en este mismo archivo. Fusión
   verificada con node --check; ver CHANGELOG.md#encargos para el detalle.
   ═══════════════════════════════════════════════════════════════ */

function _irAEncargo(encargoId) {
  document.getElementById('sheet-perfil-persona').classList.remove('open');
  setTimeout(() => { showScreen('encargos'); abrirEncargoDetalle(encargoId); }, 180);
}
Events.on('encargos-personas:irAEncargo', _irAEncargo);
/* ═══════════════════════════════════════════════════════════════
   INTEGRACIÓN: Nuevo encargo usa selector de persona
   ═══════════════════════════════════════════════════════════════ */
// Campo «¿De quién es la plata?»: PersonaPicker (js/modules/personas.js), markup estático en index.html. Arranca vacío al abrir la hoja.
const _encPicker = () => PersonaPicker.crear({ prefijo: 'enc-persona', inputId: 'enc_nombre', titulo: '¿De quién es la plata?' });
Ui.hoja('nuevo-encargo', function() { _encPicker().limpiar(); }, { key: 'encargos-persona' });

/* ═══════════════════════════════════════════════════════════════
   BOTÓN DE PERFIL EN LISTA DE ENCARGOS Y DEUDORES
   ═══════════════════════════════════════════════════════════════ */

// Agregar botón de perfil al header del detalle de encargo (lo llama abrirEncargoDetalle() tras pintar)
function _encDetallePersona(enc) {
  const av = document.getElementById('encargoAvatar');
  const chipViejo = document.getElementById('enc-det-perfil-chip');
  if (!enc || !enc.personaId) {
    // Este encargo no está vinculado a una persona: limpiar cualquier
    // onclick/estilo que haya quedado pegado del último encargo CON persona
    // que se visitó, ya que el avatar y el chip son elementos reutilizados
    // entre pantallas de detalle, no se recrean por encargo.
    if (av) {
      av.onclick = null;
      av.title = '';
      av.style.cursor = '';
      av.style.background = '';
      av.style.color = '';
      av.style.borderColor = '';
    }
    if (chipViejo) chipViejo.remove();
    return;
  }
  const p = getPersona(enc.personaId);
  if (!p) return;
  // Aplicar color de la persona al avatar del detalle
  if (av) {
    pintarAvatarPersona(av, p, { conIniciales: false });
    // Hacer clickeable para abrir perfil
    av.onclick = () => abrirPerfilPersona(p.id);
    av.title = 'Ver perfil de ' + p.nombre;
    av.style.cursor = 'pointer';
  }
  // Agregar chip de "Ver perfil" bajo el nombre y el saldo (no entre los dos)
  const nombreEl = document.getElementById('encargoNombreDet');
  const saldoLabelEl = document.getElementById('encargoSaldoLabel');
  const anclaEl = saldoLabelEl || nombreEl;
  if (anclaEl && !document.getElementById('enc-det-perfil-chip')) {
    const chip = document.createElement('button');
    chip.id = 'enc-det-perfil-chip';
    chip.type = 'button';
    chip.innerHTML = html`<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="enc-ico-12"><path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.029 10 8 10c-2.029 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/></svg> Ver perfil completo`;
    chip.style.cssText = 'font-size:10px;color:var(--text3);background:none;border:none;cursor:pointer;font-family:"DM Mono",monospace;padding:0;margin-top:2px;display:block;';
    chip.addEventListener('click', () => abrirPerfilPersona(p.id));
    anclaEl.after(chip);
  } else if (document.getElementById('enc-det-perfil-chip')) {
    const chip = document.getElementById('enc-det-perfil-chip');
    chip.onclick = () => abrirPerfilPersona(p.id);
  }
}

Ui.pantalla('encargos', () => { if (typeof renderEncargosList === 'function') renderEncargosList(); }, { key: 'encargos-render' });
