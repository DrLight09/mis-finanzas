/* ═══════════════════════════════════════════════════════════════
   js/modules/gastos.js

   Módulo Gastos — gasto variable (día a día, incluidas compras y
   pagos de TC que aparecen en el historial) y gasto fijo
   (recurrentes mensuales, con su flujo de pago).

   Sexto módulo migrado desde el <script> inline de index.html
   (después de Spotify, Mesada, Encargos, Préstamos y Tarjetas de
   Crédito) — ver AUDITORIA-TECNICA.md, puntos 1, 2 y 3.

   Un solo archivo alcanza (como con Mesada): nada de acá depende de
   código definido más abajo en index.html. Sí depende de tres
   funciones de Tarjetas de Crédito (tcCrearCompra,
   tcEliminarCompraInterna, tcEliminarPagoInterna), pero solo se
   llaman dentro de handlers de click — nunca al cargar el script —
   así que el orden real de los <script src> no importa acá.

   onclick → data-action/Events: 6 casos migrados, 0 restantes en
   este módulo (filtro de mes, eliminar gasto variable, eliminar y
   pagar gasto fijo, y los dos botones de estado vacío). Los
   onmouseenter/onmouseleave de los botones "eliminar" (2 pares) se
   dejaron igual que en los cinco módulos anteriores en su momento —
   se migraron recién en una sesión posterior a la clase CSS
   compartida .btn-delete-hover (index.html), al detectarse que la CSP
   también bloquea handlers inline generados dinámicamente, no solo
   los que vienen del HTML estático — ver auditoria-tecnica.md #1 y
   CHANGELOG.md#infraestructura--seguridad. El resto de los módulos
   con el mismo patrón sigue pendiente.

   .innerHTML sin escapar: repetido un quinto módulo seguido — texto
   libre (fuenteLabel()/tc.nombre) sin escHtml(). 4 sitios
   corregidos: badge de fuente en cada gasto, los 2 toast() de error
   de addGastoVar, el toast() de "compra cargada a...", y el
   <option> del selector en abrirPagarGastoFijo() (reimplementaba su
   propio selector a mano en vez de usar poblarFuente(), mismo
   hallazgo puntual que ya tenía Tarjetas de Crédito).

   Migración a html`` (auditoria-tecnica.md #2, sesión posterior):
   renderMesFiltros(), renderGastosVar() (itemHtml incluida) y
   renderGastosFijos() migrados, más el <option> de
   abrirPagarGastoFijo(). Los toast() de arriba se dejan con
   escHtml() a mano — mismo criterio ya aplicado en el resto de
   módulos migrados (Mesada, Spotify, Inicio, Análisis). Dos
   hallazgos reales de paso:
   1. Sombra de variable: `let html=''` en renderGastosVar() tapaba
      la función global html`` — mismo bug ya corregido antes en
      mesada.js. Renombrada a `contenido` (ahora un array, no un
      string — los fragmentos html``/arrays anidados se concatenan
      solos sin re-escapar, sin necesitar `.join('')` ni `raw()`).
   2. `f.val` (value del <option> de cuentas) NO se envolvió en
      raw() pese a parecerse al caso de `ing.id` en analisis.js:
      sin `js/core/cuentas-fuentes.js`/`getFuentes()` a la vista no hay forma de
      confirmar que `val` sea siempre un id fijo y no texto de una
      cuenta personalizada — se escapa por defecto hasta confirmar
      lo contrario. Una simulación jsdom con un `val` malicioso
      confirmó que envolverlo en raw() sí sería explotable si el
      supuesto fuera falso.
   Validado con node --check y jsdom (payloads maliciosos en desc,
   cat, nota, fuenteLabel de splits, _origenSeccion, nombre de gasto
   fijo, y label/val de fuentes) verificando por DOM real (no por
   substring del HTML serializado, que puede mostrar `<`/`>`
   literales dentro de un atributo sin ser un problema real) que
   ningún payload crea nodos/atributos nuevos. Sin verificar en
   navegador real.

   Hallazgo nuevo (mismo problema de fondo, no es un onclick): el
   sheet "pagar-gasto-fijo" tenía un onclick y un onchange inline en
   controles estáticos (no en plantillas de este módulo). En su
   momento se movieron al bloque de wiring centralizado de
   index.html, siguiendo la convención que existía entonces para
   controles estáticos de sheets. Esa convención cambió el
   2026-07-26 (ver auditoria-tecnica.md, punto 3): ahora cada módulo
   con su propio archivo también hace el wiring de sus propios
   controles estáticos, para poder vaciar _initEventListeners() del
   todo. Este archivo ya sigue el criterio nuevo — ver el bloque de
   wiring al final, antes de Events.registerAll.
   ═══════════════════════════════════════════════════════════════ */

let mesFilter = 'todos';
let gastoTab = 'var';
let pgfIdActual = null;

/* ── Split de fuentes — gasto variable (motor genérico, ver
   js/core/split.js). Sin TC en modo dividido: una compra en TC es un
   CARGO a la tarjeta, no un retiro de saldo de cuenta, y el motor de
   split trata cada fila igual (sumar/descontar saldo) — no distingue
   un cargo de un movimiento real de cuenta. Mismo criterio que el
   pago de Spotify dividido, ver spotify.js. El select simple de
   gv_fuente sigue permitiendo TC exactamente igual que antes. ── */
let gvSplitMode = false;

// Solo cuentas con saldo >= $1,00 (FuentesFiltro, js/core/fuentes-filtro.js): de una cuenta
// vacía no puede salir plata. Sin TC en modo dividido (ver comentario de arriba).
// ── Libro (js/core/cuentas-fuentes.js) ─────────────────────────────────────────────────────────────────────────────────
// _ogGv(ref, rev): cada sumar/descontarFuente deja en el libro { modulo:'gastos', ref:<id del gasto> }. Con rev=true es una reversión (tipo 'reversion', mismo ref que lo que deshace).
const _ogGv = Libro.origen('gastos');


/* gv_fuente (modo simple, "¿De dónde salió la plata?"): lo puebla openSheet('gasto-var') en
   js/core/navegacion.js (poblarFuente + FuentesFiltro.podar: solo cuentas con saldo >= $1,00
   y TC con cupo disponible). No se puebla acá. */

const gvSplit = crearSplitWidget('gv', {
  simpleId: 'gvModoSimple', splitId: 'gvModoDividido', toggleId: 'gvSplitToggle', rowsId: 'gvSplitRows',
  getModo: () => gvSplitMode, setModo: v => { gvSplitMode = v; },
  fuentes: { sentido: 'sale', placeholder: 'Selecciona una cuenta...', sinOpcionesTexto: FuentesFiltro.MSG_SIN_SALDO },
  onPreview: actualizarGvSplitPreview
});

// Preview del split de gasto — mismo estilo que actualizarSpPagarPreview
// en spotify.js (modo dividido: todo o nada, sin margen de "sin asignar").
function actualizarGvSplitPreview() {
  const prev = document.getElementById('gvSplitPreview');
  if (!prev) return;
  const monto = parseMoney(document.getElementById('gv_monto').value) || 0;
  const splits = gvSplit.data();
  if (!monto) { prev.textContent = ''; return; }
  const totalSplit = splits.reduce((a, s) => a + s.monto, 0);
  const restante = monto - totalSplit;
  if (splits.length === 0) { prev.textContent = fmt(monto) + ' por repartir entre cuentas'; prev.style.color = 'var(--text2)'; return; }
  const lines = splits.map(s => fuenteLabel(s.fuente || '') + ': \u2212' + fmt(s.monto)).join(' · ');
  if (restante > 0) { prev.textContent = lines + ' · Sin asignar: ' + fmt(restante); prev.style.color = 'var(--amber)'; }
  else if (restante < 0) { prev.textContent = lines + ' · Excede por: ' + fmt(-restante); prev.style.color = 'var(--red)'; }
  else { prev.textContent = lines + ' · Todo repartido'; prev.style.color = 'var(--accent)'; }
}

/* ---- TABS ---- */

function switchGastoTab(t) {
  gastoTab = t;
  document.getElementById('tab-var').classList.toggle('active', t === 'var');
  document.getElementById('tab-fijo').classList.toggle('active', t === 'fijo');
  document.getElementById('panel-var').style.display = t === 'var' ? '' : 'none';
  document.getElementById('panel-fijo').style.display = t === 'fijo' ? '' : 'none';
}

/* ---- ESTADO VACÍO: helpers que unifican el flujo con el botón fantasma ---- */

// ¿El usuario ya decidió a mano si es una compra grande? Mientras no, la casilla sigue a la sugerencia según el monto.
let _gvGrandeManual = false;

// Impacto del gasto ANTES de guardarlo (calcImpactoCompra, inicio.js): qué parte de tu plata disponible es y cuántos meses cubrirías
// después. Y sugiere marcar la casilla de compra grande cuando el monto lo amerita (sin pisar lo que el usuario ya eligió).
function actualizarGvImpacto() {
  const el = document.getElementById('gv-impacto');
  const chk = document.getElementById('gv_grande');
  if (!el || typeof calcImpactoCompra !== 'function') return;
  const monto = parseMoney(document.getElementById('gv_monto').value) || 0;
  const imp = calcImpactoCompra(monto);
  el.textContent = imp ? imp.texto : '';
  ['red', 'amber'].forEach(t => el.classList.remove('ix-gv-impacto-' + t));
  if (imp && (imp.nivel === 'red' || imp.nivel === 'amber')) el.classList.add('ix-gv-impacto-' + imp.nivel);
  if (chk && !_gvGrandeManual) chk.checked = !!(imp && imp.grande);
}

// Marcar o quitar «compra grande» a un gasto ya registrado (p. ej. la moto de hace dos semanas). Es una propiedad del propio gasto
// (`grande`), no un estado aparte: todo lo demás (patrimonio, liquidez, Salud) se recalcula solo.
function toggleCompraGrande(id) {
  const g = (S.gastosVar || []).find(x => x.id === id);
  if (!g) return;
  // Se guarda SIEMPRE una decisión explícita (true/false): lo que el usuario dice manda sobre la detección automática, y no cambia
  // sola si más adelante cambia su historial.
  const eraGrande = Periodo.compraGrandeEstado(g, Periodo.umbralCompraGrande()) !== 'no';
  g.grande = !eraGrande;
  save(); refresh();
  toast(g.grande ? 'Marcada como compra grande: cuenta completa en tu patrimonio, pero no como gasto habitual' : 'Listo: ya no cuenta como compra grande', 'ok');
}

function abrirNuevoGastoVar() {
  // Sin ninguna cuenta con saldo (ni TC con cupo) no hay de dónde sacar la plata: el sheet no se abre.
  if (!FuentesFiltro.hayUtilizable(getFuentes(), FuentesFiltro.PRESET.SALIDA)) { toast(FuentesFiltro.MSG_SIN_SALDO, 'err'); return; }
  poblarCatSelect('gv_cat', getCatsVar());
  _gvGrandeManual = false;
  const _gvChk = document.getElementById('gv_grande'); if (_gvChk) _gvChk.checked = false;
  const _gvImp = document.getElementById('gv-impacto'); if (_gvImp) _gvImp.textContent = '';
  // Resetear split (mismo patrón que abrirRegistrarMesada en mesada.js /
  // openSheet_pagarSpotify en spotify.js)
  gvSplitMode = false;
  document.getElementById('gvModoSimple').style.display = '';
  document.getElementById('gvModoDividido').style.display = 'none';
  document.getElementById('gvSplitRows').innerHTML = '';
  const gvToggleBtn = document.getElementById('gvSplitToggle');
  if (gvToggleBtn) {
    gvToggleBtn.textContent = 'Dividir';
    gvToggleBtn.style.background = 'rgba(200,240,96,.1)';
    gvToggleBtn.style.borderColor = 'rgba(200,240,96,.3)';
    gvToggleBtn.style.color = 'var(--accent)';
  }
  const gvSplitPrev = document.getElementById('gvSplitPreview');
  if (gvSplitPrev) gvSplitPrev.textContent = '';
  openSheet('gasto-var');
}

// Id del gasto fijo que se está editando (null = uno nuevo). Mismo molde que el sheet de «Ingreso fijo».
let _gfEditId = null;

function _gfPoblar(g) {
  const t = document.getElementById('gf-sheet-title');
  if (t) t.textContent = g ? 'Editar gasto fijo' : 'Gasto fijo mensual';
  document.getElementById('gf_n').value = g ? (g.nombre || '') : '';
  document.getElementById('gf_m').value = g ? fmtInput(g.monto || 0) : '';
  const d = document.getElementById('gf_d');
  if (d) d.value = g && g.dia ? String(g.dia) : '';
  if (g && g.cat) document.getElementById('gf_c').value = g.cat;
}

/* ---- BIENES (una moto, un computador): activos no líquidos, aparte del patrimonio financiero (ver calcBienes en js/core/patrimonio.js) ---- */
let _bienEditId = null;     // id del bien que se edita (null = uno nuevo)
let _bienOrigenId = null;   // id del gasto del que nace («Registrar como bien»)

function _bienPoblar(b) {
  document.getElementById('bien-sheet-title').textContent = _bienEditId ? 'Editar bien' : 'Registrar bien';
  document.getElementById('bien_n').value = b ? (b.nombre || '') : '';
  document.getElementById('bien_v').value = b && b.valor ? fmtInput(b.valor) : '';
  document.getElementById('bien_f').value = b && b.fecha ? b.fecha : hoy();
  document.getElementById('bien_d').value = b && b.depreciacionAnual ? String(b.depreciacionAnual).replace('.', ',') : '';
}

// Desde un gasto marcado como compra grande: el bien nace con su nombre, su monto como valor inicial y su fecha.
function abrirSheetBien(origenGastoId) {
  _bienEditId = null;
  _bienOrigenId = origenGastoId || null;
  const g = _bienOrigenId ? (S.gastosVar || []).find(x => x.id === _bienOrigenId) : null;
  _bienPoblar(g ? { nombre: g.desc, valor: g.monto, fecha: g.fecha } : null);
  openSheet('bien');
}

function abrirEditarBien(id) {
  const b = (S.bienes || []).find(x => x.id === id);
  if (!b) return;
  _bienEditId = id;
  _bienOrigenId = b.origenGastoId || null;
  _bienPoblar(b);
  openSheet('bien');
}

function guardarBien() {
  const nombre = document.getElementById('bien_n').value.trim();
  const valor = parseMoney(document.getElementById('bien_v').value);
  const fecha = document.getElementById('bien_f').value;
  const depTxt = document.getElementById('bien_d').value.trim().replace(',', '.');
  if (!nombre) { toast('Ponle un nombre al bien', 'err'); return; }
  if (!(valor > 0)) { toast('Ingresa el valor estimado', 'err'); return; }
  if (!fecha) { toast('Indica la fecha de ese valor', 'err'); return; }
  const dep = depTxt === '' ? null : Number(depTxt);
  if (dep !== null && !(isFinite(dep) && dep >= 0 && dep <= 100)) { toast('La depreciación debe estar entre 0 y 100 %', 'err'); return; }
  if (!S.bienes) S.bienes = [];
  const editando = _bienEditId ? S.bienes.find(x => x.id === _bienEditId) : null;
  const datos = { nombre, valor, fecha };
  if (dep) datos.depreciacionAnual = dep;
  if (editando) {
    Object.assign(editando, datos);
    if (!dep) delete editando.depreciacionAnual;
  } else {
    const nuevo = { id: uid(), ...datos };
    if (_bienOrigenId) nuevo.origenGastoId = _bienOrigenId;
    S.bienes.push(nuevo);
  }
  _bienEditId = null; _bienOrigenId = null;
  save(); refresh(); closeSheet('bien');
  if (window.logCambio) logCambio(editando ? 'Editaste un bien' : 'Registraste un bien', nombre, valor, 'bien');
  toast(editando ? 'Bien actualizado' : 'Bien registrado: va aparte de tu plata disponible', 'ok');
}

async function eliminarBien(id) {
  const ok = await confirmarEliminar({ titulo: 'Eliminar bien', objeto: 'este bien', detalle: 'El gasto con el que lo compraste no se toca.', irreversible: false });
  if (!ok) return;
  S.bienes = (S.bienes || []).filter(x => x.id !== id);
  save(); refresh();
  toast('Bien eliminado', 'ok');
}

function abrirNuevoGastoFijo() {
  _gfEditId = null;
  poblarCatSelect('gf_c', getCatsFijo());
  _gfPoblar(null);
  openSheet('gasto-fijo');
}

// Editar un gasto fijo (p. ej. ponerle o cambiarle el día de vencimiento) sin borrarlo y perder su nombre y categoría. Los pagos ya
// registrados guardan su propio monto y mes: cambiar el monto de la plantilla no los toca.
function abrirEditarGastoFijo(id) {
  const g = (S.gastosFijos || []).find(x => x.id === id);
  if (!g) return;
  _gfEditId = id;
  poblarCatSelect('gf_c', getCatsFijo());
  _gfPoblar(g);
  openSheet('gasto-fijo');
}

/* ---- GASTOS VARIABLES ---- */

function renderMesFiltros() {
  const meses = new Set();
  meses.add('todos');
  (S.gastosVar || []).forEach(g => { if (g.fecha) meses.add(mesKey(g.fecha)); });
  Periodo.retirosManuales().forEach(r => { if (r.fecha) meses.add(mesKey(r.fecha)); }); // un mes con solo un retiro también se puede elegir
  const sorted = ['todos', ...[...meses].filter(m => m !== 'todos').sort().reverse()];
  // Con un solo mes (o ninguno) filtrar no aporta nada: «Todos» y ese mes muestran lo mismo. El filtro aparece desde el
  // segundo mes con gastos. Si el filtro quedó en un mes que ya no existe (se borraron sus gastos), vuelve a «todos» para
  // no dejar la lista filtrada sin forma de cambiarlo.
  const hayVariosMeses = sorted.length > 2;
  if (!hayVariosMeses || !sorted.includes(mesFilter)) mesFilter = 'todos';
  const filtroEl = document.getElementById('mesFilter');
  mostrarSi(filtroEl, hayVariosMeses);
  filtroEl.innerHTML = !hayVariosMeses ? '' : html`${sorted.map(m => html`
    <div class="${raw('mf-chip ' + (mesFilter === m ? 'active' : ''))}" ${raw(Events.attr('gastos:setMesFiltro', m))}>
      ${m === 'todos' ? 'Todos' : MC[parseInt(m.split('-')[1]) - 1] + ' ' + m.split('-')[0]}
    </div>`)}`;
  renderGastosVar();
}

function setMesFiltro(m) { mesFilter = m; renderMesFiltros(); }

/* Etiqueta del encabezado de día en el historial: "Hoy", "Ayer" o
   "sáb 19 sep" (con año si no es el actual). La fecha se arma con
   new Date(y, m-1, d) y NO con new Date('YYYY-MM-DD'): esta última la
   interpreta en UTC y en Colombia (UTC-5) mostraría el día anterior. */
function _gvDiaLabel(fecha) {
  const p = /^(\d{4})-(\d{2})-(\d{2})$/.exec(fecha || '');
  if (!p) return 'Sin fecha';
  const y = +p[1], mo = +p[2] - 1, d = +p[3];
  const hoyStr = hoy();
  if (fecha === hoyStr) return 'Hoy';
  const hoyD = Fecha.esValida(hoyStr) ? _fechaSafe(hoyStr) : new Date();
  if (fecha === Fecha.sumarDias(hoyStr, -1)) return 'Ayer';
  const dias = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  return dias[new Date(y, mo, d).getDay()] + ' ' + d + ' ' + Fecha.nombreMes(mo + 1).toLowerCase() + (y !== hoyD.getFullYear() ? ' ' + y : '');
}

function renderGastosVar() {
  const el = document.getElementById('gastosVarList');
  // Orden: fecha del gasto (más reciente primero) y, dentro del mismo día,
  // el último que registraste arriba. S.gastosVar solo se agrega al final
  // (push), así que la posición en el array ES el orden de creación: se
  // guarda el índice ANTES de filtrar y se usa de desempate. Antes se
  // ordenaba solo por fecha y, como el sort es estable, los gastos de un
  // mismo día quedaban en orden de creación (el más viejo arriba).
  let conIdx = (S.gastosVar || []).map((g, i) => ({ g, i }));
  // 'Restar dinero' (S.movimientos, clase gasto) cuenta como gasto del mes en Inicio, Análisis y Wrapped (Periodo): acá
  // se muestra también, de solo lectura (no es un gasto variable: se elimina desde Cuentas), para que esta pantalla
  // sume lo mismo que el resto. Va después de los gastos del mismo día (índice -1).
  Periodo.retirosManuales().forEach(r => conIdx.push({ g: Object.assign({}, r, { _secundario: true, _origenSeccion: 'Cuentas · Restar dinero' }), i: -1 }));
  if (mesFilter !== 'todos') conIdx = conIdx.filter(x => mesKey(x.g.fecha) === mesFilter);
  conIdx.sort((a, b) => (b.g.fecha || '').localeCompare(a.g.fecha || '') || b.i - a.i);
  const gastos = conIdx.map(x => x.g);
  // Totales (misma regla de siempre, ver regla 3.3): solo cuenta como gasto
  // real lo que salió de una cuenta y no está contado en otro lado.
  const gastosVarPuros = gastos.filter(g => !_esGastoVarNoReal(g));
  const gastosTC = gastos.filter(g => g._esCompraTC);
  const total = gastosVarPuros.filter(g => !g._esCompraTC).reduce((a, g) => a + (g.monto || 0), 0);
  const totalTC = gastosTC.reduce((a, g) => a + (g.monto || 0), 0);
  document.getElementById('totalGVFilt').textContent = fmt(total);
  // Mostrar total TC si hay
  const tcTotalEl = document.getElementById('totalGVFiltTC');
  if (tcTotalEl) {
    if (totalTC > 0) { tcTotalEl.textContent = '+ ' + fmt(totalTC) + ' en TC'; tcTotalEl.style.display = ''; }
    else { tcTotalEl.style.display = 'none'; }
  }
  // Qué se muestra en el historial: todo lo de antes (gastos puros, compras
  // TC, pagos TC y pagos de fijos) en UNA sola lista cronológica. Lo que
  // sigue oculto es lo mismo que ya lo estaba: movimientos de alcancía y
  // extras de préstamo (_esGastoVarNoReal sin ninguna de las otras banderas).
  const visibles = gastos.filter(g => !_esGastoVarNoReal(g) || g._esCompraTC || g._esPagoTC || g.esPagoGastoFijo);
  // Sin gastos no hay nada que totalizar. Y el botón de pie se esconde solo cuando el estado
  // vacío ya trae el suyo («Registrar primer gasto», solo con el filtro «todos»); en un mes
  // sin gastos el estado vacío no tiene botón, así que el de pie sigue siendo la acción.
  mostrarSi(document.getElementById('gvTotalCard'), visibles.length > 0);
  mostrarSi(document.querySelector('.btn-open-gasto-var'), visibles.length > 0 || mesFilter !== 'todos');
  if (!visibles.length) {
    el.innerHTML = emptyState(
      '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.8" stroke-linecap="round"><path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 3 14 9 20 9"/><line x1="8" y1="13" x2="16" y2="13"/></svg>',
      'Sin gastos registrados',
      mesFilter === 'todos' ? 'Aún no has registrado ningún gasto. Añade el primero para ver tu resumen mensual.' : 'No hay gastos en este mes.',
      mesFilter === 'todos' ? 'Registrar primer gasto' : '',
      { action: 'gastos:abrirNuevoGastoVar', args: [] }
    );
    return;
  }

  // Umbral de detección automática, UNA vez para toda la lista (no por fila).
  const umbralGrande = Periodo.umbralCompraGrande();

  function itemHtml(g) {
    const esFijo = !!g.esPagoGastoFijo;
    const esTC = !!g._esCompraTC;
    const esPagoTC = !!g._esPagoTC;
    const esSecundario = !!g._secundario;
    const claseMonto = esFijo ? 'gasto-monto-fijo' : esTC ? 'c-red' : esPagoTC ? 'c-green' : 'c-red';
    // Etiquetas de tipo. Un fijo pagado con TC tiene las dos banderas: antes
    // aparecía dos veces (en "Compras en TC" y en "Pagos de fijos") y la
    // etiqueta de fijo tapaba la de TC. Ahora es una sola fila con ambas.
    const tipoBadges = esFijo
      ? [html`<span class="badge badge-xs gasto-badge-fijo">Fijo — ya sumado en Fijos mensuales</span>`,
         esTC ? html`<span class="badge badge-xs bg-red">TC — deuda</span>` : '']
      : esTC
        ? [html`<span class="badge badge-xs bg-red">TC — deuda</span>`, html`<span class="badge badge-xs bg-blue">${g.cat}</span>`]
        : esPagoTC
          ? [html`<span class="badge badge-xs bg-green">Pago TC</span>`]
          : [html`<span class="badge badge-xs bg-blue">${g.cat}</span>`];
    // «Compra grande»: etiqueta («automática» si la detectó la app, no el usuario) y, en gastos propios de monto relevante o ya
    // grandes, un botón para corregirla en cualquiera de los dos sentidos.
    const estGrande = (esFijo || esPagoTC || esSecundario) ? 'no' : Periodo.compraGrandeEstado(g, umbralGrande);
    if (estGrande !== 'no') tipoBadges.push(html`<span class="badge badge-xs gasto-badge-grande">${estGrande === 'auto' ? 'Compra grande · automática' : 'Compra grande'}</span>`);
    // Una compra grande suele ser un bien (una moto vale algo): si aún no se registró como tal, se ofrece, aparte del patrimonio.
    if (estGrande !== 'no') {
      tipoBadges.push((S.bienes || []).some(b => b.origenGastoId === g.id)
        ? html`<span class="badge badge-xs bg-blue">Bien registrado</span>`
        : html`<button type="button" class="gasto-btn-editar" data-stop-propagation="true" ${raw(Events.attr('gastos:abrirSheetBien', g.id))}>Registrar como bien</button>`);
    }
    const puedeMarcar = !esFijo && !esPagoTC && !esSecundario && (estGrande !== 'no' || (g.monto || 0) >= Periodo.COMPRA_GRANDE_AUTO.minimo);
    const etiquetaBtn = estGrande === 'auto' ? 'No es compra grande' : estGrande === 'si' ? 'Quitar «grande»' : 'Marcar grande';
    const btnGrande = puedeMarcar
      ? html`<button type="button" class="gasto-btn-editar" data-stop-propagation="true" ${raw(Events.attr('gastos:toggleCompraGrande', g.id))}>${etiquetaBtn}</button>` : '';
    return filaMovimiento({
      clase: (esFijo || esPagoTC) ? 'gasto-item-atenuado' : '',
      nombreClase: 'row-name gasto-nombre-fila',
      nombre: g.desc,
      nombreExtra: esSecundario ? html`<span class="gasto-chip-auto"><svg aria-hidden="true" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>Automático</span>` : '',
      sub: g.fecha,
      monto: `${esPagoTC ? '-' : ''}${fmt(g.monto)}`,
      montoClase: claseMonto,
      acciones: esSecundario
        ? html`<span title="Generado automáticamente — elimínalo desde ${g._origenSeccion || 'la sección de origen'}" class="gasto-candado"><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></span>`
        : html`${btnGrande}${botonEliminarFila('gastos:deleteGastoVar', [g.id])}`,
      meta: html`
        ${tipoBadges}
        ${g.splits && g.splits.length ? html`<span class="badge badge-xs">Dividido: ${g.splits.map(s => fuenteLabel(s.fuente || '')).join(', ')}</span>` : (g.fuente ? html`<span class="badge badge-xs ${raw(fuenteBadgeClass(g.fuente))}">${fuenteLabel(g.fuente)}</span>` : '')}
        ${(!(esFijo || esTC) && g.nota) ? html`<span class="gasto-nota">${g.nota}</span>` : ''}`
    });
  }

  // Agrupar por día (visibles ya viene ordenado, así que los días quedan
  // contiguos). Cada día lleva su subtotal con la misma regla del total de
  // arriba: gasto real + "en TC" aparte; pagos de fijos y pagos de TC no suman.
  const dias = [];
  visibles.forEach(g => {
    const f = g.fecha || '';
    const ult = dias[dias.length - 1];
    if (ult && ult.fecha === f) ult.items.push(g); else dias.push({ fecha: f, items: [g] });
  });

  // Nota: la variable local se llama `contenido`, no `html` — nombrarla
  // `html` taparía la función global html`` dentro de esta misma función
  // (mismo hallazgo real ya corregido en mesada.js, ver auditoria-tecnica.md #2).
  const contenido = dias.map((dia, idx) => {
    const realDia = dia.items.filter(g => !_esGastoVarNoReal(g) && !g._esCompraTC).reduce((a, g) => a + (g.monto || 0), 0);
    const tcDia = dia.items.filter(g => g._esCompraTC).reduce((a, g) => a + (g.monto || 0), 0);
    const partes = [];
    if (realDia > 0) partes.push(fmt(realDia));
    if (tcDia > 0) partes.push((realDia > 0 ? '+ ' : '') + fmt(tcDia) + ' en TC');
    return html`<div class="gasto-dia${raw(idx === 0 ? ' gasto-dia-primero' : '')}">
      <span class="gasto-dia-label">${_gvDiaLabel(dia.fecha)}</span>
      <span class="gasto-dia-total">${partes.join(' ')}</span>
    </div>${dia.items.map(itemHtml)}`;
  });
  el.innerHTML = html`${contenido}`;
}

function addGastoVar() {
  const desc = document.getElementById('gv_desc').value.trim();
  const monto = parseMoney(document.getElementById('gv_monto').value) || 0;
  // Validación inline (marca el campo y muestra el mensaje debajo); solo enfoca el primer error.
  if (!Formulario.validar([
    { campo: 'gv_desc', mensaje: 'La descripción es obligatoria', regla: () => !!desc },
    { campo: 'gv_monto', mensaje: 'Ingresa un monto mayor a 0', regla: () => !!monto },
  ])) return;

  let fuente = '';
  let splits = null;
  if (gvSplitMode) {
    splits = gvSplit.data();
    const totalSplit = splits.reduce((a, s) => a + s.monto, 0);
    if (splits.length === 0 || Math.abs(totalSplit - monto) > 1) {
      const prev = document.getElementById('gvSplitPreview');
      if (prev) {
        prev.textContent = totalSplit < monto ? 'Falta asignar ' + fmt(monto - totalSplit) + ' a alguna cuenta' : 'El total dividido supera el monto del gasto';
        prev.style.color = 'var(--red)';
      }
      return;
    }
    const vs = Plata.validarSalidas(splits); // suma por fuente: dos filas de la misma cuenta cuentan juntas
    if (!vs.ok) { toast(vs.motivo, 'err'); return; }
  } else {
    fuente = document.getElementById('gv_fuente').value;
    if (!fuente) { toast('Selecciona de dónde salió la plata', 'err'); return; }
    const v = Plata.validarSalida(fuente, monto);
    if (!v.ok) { toast(v.motivo, 'err'); return; }
  }

  const compraId = uid();
  const fechaGasto = document.getElementById('gv_fecha').value || hoy();
  const catGasto = document.getElementById('gv_cat').value;
  const notaGasto = document.getElementById('gv_nota').value.trim();
  if (!S.gastosVar) S.gastosVar = [];
  const esTCFuente = fuente && Fuente.esTC(fuente);
  const gastoObj = { id: compraId, desc, monto, fecha: fechaGasto, cat: catGasto, fuente, splits: splits || undefined, nota: notaGasto, clase: 'gasto' };
  // La decisión de la casilla se guarda explícita: true si la marcó; false si no la marcó en un gasto desde el monto mínimo (así la
  // detección automática no se la cambia después). En gastos pequeños no se guarda nada (no hay nada que decidir).
  const _gvChkEl = document.getElementById('gv_grande');
  if (_gvChkEl) {
    if (_gvChkEl.checked) gastoObj.grande = true;
    else if (monto >= Periodo.COMPRA_GRANDE_AUTO.minimo) gastoObj.grande = false;
  }
  // Si la fuente es TC, registrar la compra a través del mismo servicio que
  // usa el módulo de tarjetas (tcCrearCompra) — misma lógica, un solo lugar.
  if (esTCFuente) {
    const tcId = fuente.split(':')[1];
    const tc = (S.tarjetasCredito || []).find(x => x.id === tcId);
    if (tc) {
      const compra = tcCrearCompra(tc, { desc, monto, fecha: fechaGasto, cat: catGasto, nota: notaGasto });
      gastoObj._esCompraTC = true;
      gastoObj._tcId = tcId;
      gastoObj._tcCompraId = compra.id;
      S.gastosVar.push(gastoObj);
      toast('Compra cargada a ' + tc.nombre + ' — deuda: ' + fmt(tc.deuda), 'ok', 3500);
    } else {
      S.gastosVar.push(gastoObj);
    }
  } else if (splits) {
    S.gastosVar.push(gastoObj);
    splits.forEach(s => descontarFuente(s.fuente, s.monto, _ogGv(gastoObj.id)));
    toast('Gasto registrado — dividido entre ' + splits.length + ' cuentas', 'salida');
    if (window.logCambio) { const _gvd = document.getElementById('gv_desc'); logCambio('Registraste un gasto', _gvd ? _gvd.value : '', monto, 'gasto'); }
  } else {
    S.gastosVar.push(gastoObj);
    descontarFuente(fuente, monto, _ogGv(gastoObj.id));
    toast('Gasto registrado', 'salida');
    if (window.logCambio) { const _gvd = document.getElementById('gv_desc'); const _gvm = parseMoney(document.getElementById('gv_monto').value); logCambio('Registraste un gasto', _gvd ? _gvd.value : '', _gvm, 'gasto'); }
  }
  document.getElementById('gv_desc').value = '';
  document.getElementById('gv_monto').value = '';
  document.getElementById('gv_nota').value = '';
  const _gvChk2 = document.getElementById('gv_grande'); if (_gvChk2) _gvChk2.checked = false;
  _gvGrandeManual = false;
  document.getElementById('gv_fecha').value = hoy();
  gvSplitMode = false;
  save(); refresh(); closeSheet('gasto-var');
}

async function deleteGastoVar(id) {
  const g = (S.gastosVar || []).find(x => x.id === id);
  if (g && g._secundario) {
    const seccion = g._origenSeccion || 'la sección de origen';
    await avisarNoSePuede('Movimiento vinculado', `Este gasto fue generado automáticamente desde ${seccion}. Para eliminarlo, ve a ${seccion} y borra el registro allá — eso revertirá todo correctamente.`);
    return;
  }

  // Protección por antigüedad — ver docs/proteccion-antiguedad-movimientos.md.
  // Este mismo gasto también se puede borrar desde la pantalla de movimientos
  // de una cuenta (rama 'gasto' de eliminarMovimiento() en movimientos.js,
  // que ya la tenía) — duplicado acá porque este botón (pantalla de Gastos)
  // es un segundo punto de entrada que no pasaba por esa función, dejando
  // este camino sin ninguna protección. Ver CHANGELOG.md#gastos (2026-09-01).
  // `confirmado` evita pedir dos confirmaciones seguidas cuando el nivel es
  // 'viejo' (mismo patrón que eliminarMovimiento() en movimientos.js).
  const prot = await Reversibles.proteger('gasto', g);
  if (!prot.ok) return;
  const confirmado = prot.confirmado;
  if (!confirmado) {
    const ok = await confirmarEliminar({ titulo: 'Eliminar gasto', objeto: 'este gasto' });
    if (!ok) return;
  }
  const _histAntes = medirPatrimonioParaHistorial(); // el historial de patrimonio deja de contar este gasto
  if (g) {
    if (g._esCompraTC && g._tcId) {
      // Revertir: marcar la compra como eliminada (nunca se borra físicamente) y recalcular
      const tc = (S.tarjetasCredito || []).find(x => x.id === g._tcId);
      if (tc && g._tcCompraId) tcEliminarCompraInterna(tc, g._tcCompraId);
    } else if (g._esPagoTC && g._tcId) {
      // Revertir pago: restaurar la deuda en la TC y devolver plata a la cuenta
      const tc = (S.tarjetasCredito || []).find(x => x.id === g._tcId);
      if (tc && g._tcPagoId) tcEliminarPagoInterna(tc, g._tcPagoId);
      if (g.fuente) sumarFuente(g.fuente, g.monto, _ogGv(g.id, true));
    } else {
      // Gasto normal: devolver el dinero a la cuenta origen (una sola cuenta,
      // o cada una de las cuentas del split si el gasto se dividió — ver
      // addGastoVar)
      if (g.splits && g.splits.length) {
        g.splits.forEach(s => { if (s.fuente) sumarFuente(s.fuente, s.monto || 0, _ogGv(g.id, true)); });
      } else if (g.fuente) {
        sumarFuente(g.fuente, g.monto, _ogGv(g.id, true));
      }
    }
    // Bug fix: si era pago de gasto fijo, desmarcar como pagado
    if (g.esPagoGastoFijo && g.gastoFijoId) {
      const mes = mesKey(g.fecha);
      if (S.pagosGastosFijos) delete S.pagosGastosFijos[g.gastoFijoId + '_' + mes];
    }
  }
  S.gastosVar = (S.gastosVar || []).filter(x => x.id !== id);
  if (g) purgarEfectoEnHistorial(_histAntes, g);
  save(); refresh();
  toast('Gasto eliminado', 'ok');
  if (window.logCambio && g) logCambio('Eliminaste un gasto', g.desc || '', g.monto, 'eliminar');
}

/* ---- GASTOS FIJOS ---- */

function renderGastosFijos() {
  const el = document.getElementById('gastosFijosList');
  const g = S.gastosFijos || [];
  // Solo lo que el usuario creó. El pago de Spotify NO es un gasto fijo: lo registra el módulo como gasto variable (con su marca) al pagar.
  const todos = g;
  // totalGF: solo contar gastos fijos reales que ya fueron PAGADOS este mes (no los virtuales ni los pendientes)
  const mesClaveTot = mesActual();
  const totalGFPagado = Periodo.gastosFijosDelMes(mesClaveTot).reduce((a, p) => a + p.monto, 0);
  document.getElementById('totalGF').textContent = fmt(totalGFPagado);
  // El estado vacío ya trae «Agregar gasto fijo»: el botón de pie y el total solo aparecen con datos.
  mostrarSi(document.querySelector('.btn-open-gasto-fijo'), todos.length > 0);
  mostrarSi(document.getElementById('gfTotalCard'), todos.length > 0);
  if (!todos.length) {
    el.innerHTML = emptyState(
      '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
      'Sin gastos fijos',
      'Agrega tus gastos recurrentes como arriendo, Netflix o servicios para tenerlos siempre visibles.',
      'Agregar gasto fijo',
      { action: 'gastos:abrirNuevoGastoFijo', args: [] }
    );
    return;
  }
  const mesClave = mesActual();
  // Vencimientos pendientes del mes (solo los gastos fijos con día): ver Periodo.gastosFijosProgramados.
  const venc = new Map(Periodo.gastosFijosProgramados(mesClave, hoy()).map(g => [g.id, g]));
  el.innerHTML = html`${todos.map((x, i) => {
    const pagos = S.pagosGastosFijos || {};
    const infoPago = x.id ? pagos[x.id + '_' + mesClave] : null;
    const pagado = !!infoPago;
    let accionHtml;
    if (pagado) {
      accionHtml = html`<div class="gasto-pago-col">
        <span class="badge badge-xs gasto-badge-pagado">Pagado</span>
        <div class="gasto-fecha-pago">${infoPago.fecha || ''}</div>
      </div>`;
    } else {
      accionHtml = html`<button type="button" ${raw(Events.attr('gastos:abrirPagarGastoFijo', x.id))} class="gasto-btn-pagar">Pagar</button>`;
    }
    const g = venc.get(x.id);
    let vencHtml = '';
    if (g) {
      const txt = g.dias < 0 ? `Venció hace ${-g.dias} ${-g.dias === 1 ? 'día' : 'días'}` : g.dias === 0 ? 'Vence hoy' : g.dias <= 7 ? `Vence en ${g.dias} ${g.dias === 1 ? 'día' : 'días'}` : `Vence el día ${g.dia}`;
      const tono = g.dias < 0 ? 'gasto-vence-red' : g.dias <= UMBRALES.atencion.gastoFijoAvisoDias ? 'gasto-vence-amber' : '';
      vencHtml = html`<span class="gasto-vence ${tono}">${txt}</span>`;
    }
    return filaMovimiento({
      nombre: x.nombre,
      monto: fmt(x.monto),
      montoClase: 'c-red',
      acciones: html`<button type="button" class="gasto-btn-editar" data-stop-propagation="true" ${raw(Events.attr('gastos:abrirEditarGastoFijo', x.id))}>Editar</button>${botonEliminarFila('gastos:deleteGastoFijo', [x.id])}`,
      metaClase: 'gasto-meta-fijo',
      meta: html`<span class="badge badge-xs bg-blue">${x.cat}</span>${vencHtml}${accionHtml}`
    });
  })}`;
}

function addGastoFijo() {
  const n = document.getElementById('gf_n').value.trim(), m = parseMoney(document.getElementById('gf_m').value) || 0;
  if (!Formulario.validar([
    { campo: 'gf_n', mensaje: 'El nombre es obligatorio', regla: () => !!n },
    { campo: 'gf_m', mensaje: 'Ingresa un monto mayor a 0', regla: () => !!m },
  ])) return;
  // Día de vencimiento: opcional. Vacío = sin aviso de vencimiento; si se escribe, debe ser un día válido (1–31).
  const diaTxt = (document.getElementById('gf_d') || { value: '' }).value.trim();
  const dia = diaTxt === '' ? null : Number(diaTxt);
  if (dia !== null && !(Number.isInteger(dia) && dia >= 1 && dia <= 31)) { toast('El día de vencimiento debe estar entre 1 y 31', 'err'); return; }
  const cat = document.getElementById('gf_c').value;
  const editando = _gfEditId ? (S.gastosFijos || []).find(x => x.id === _gfEditId) : null;
  if (editando) {
    editando.nombre = n; editando.monto = m; editando.cat = cat;
    if (dia !== null) editando.dia = dia; else delete editando.dia;
  } else {
    const nuevo = { id: uid(), nombre: n, monto: m, cat };
    if (dia !== null) nuevo.dia = dia;
    S.gastosFijos.push(nuevo);
  }
  _gfEditId = null;
  document.getElementById('gf_n').value = ''; document.getElementById('gf_m').value = '';
  if (document.getElementById('gf_d')) document.getElementById('gf_d').value = '';
  save(); refresh(); closeSheet('gasto-fijo');
  // El nombre y el monto se leen ANTES de limpiar el formulario (antes se leían después y el registro de cambios guardaba vacío).
  if (window.logCambio) logCambio(editando ? 'Editaste gasto fijo' : 'Agregaste gasto fijo', n, m, 'gasto_fijo');
  toast(editando ? 'Gasto fijo actualizado' : 'Gasto fijo agregado', 'ok');
}

async function deleteGastoFijo(id) {
  const ok = await confirmarEliminar({ titulo: 'Eliminar gasto fijo', objeto: 'este gasto fijo', detalle: 'Los pagos ya registrados se conservan en tu historial de gastos.', irreversible: false });
  if (!ok) return;
  S.gastosFijos = (S.gastosFijos || []).filter(x => x.id !== id);
  // Los pagos ya registrados NO se borran: esa plata salió de una cuenta de verdad y el análisis
  // por mes (Periodo.pagosFijos) los sigue contando con su categoría y monto pagado.
  save(); refresh();
  toast('Gasto fijo eliminado', 'ok');
}

/* ---- PAGO DE GASTOS FIJOS ---- */

function abrirPagarGastoFijo(id) {
  const gf = (S.gastosFijos || []).find(x => x.id === id);
  if (!gf) return;
  pgfIdActual = id;
  document.getElementById('pgf-title').textContent = 'Pagar: ' + gf.nombre;
  document.getElementById('pgf-monto').textContent = fmt(gf.monto);
  document.getElementById('pgf-cat-badge').textContent = gf.cat;
  document.getElementById('pgf-fecha').value = hoy();
  document.getElementById('pgf-error').style.display = 'none';
  if (document.getElementById('pgf-nota')) document.getElementById('pgf-nota').value = '';
  // Poblar fuentes
  const sel = document.getElementById('pgf-fuente');
  // Solo cuentas con saldo >= $1,00 y TC con cupo (FuentesFiltro, js/core/fuentes-filtro.js).
  // FuentesFiltro.optsHtml filtra por saldo/cupo y arma las <option> con opcionesCuenta (js/core/cuentas-fuentes.js),
  // que escapa label y val: este sheet ya no reimplementa el selector a mano.
  sel.innerHTML = FuentesFiltro.optsHtml(getFuentes(), { ...FuentesFiltro.PRESET.SALIDA, placeholder: 'Seleccionar cuenta', sinOpcionesTexto: FuentesFiltro.MSG_SIN_SALDO });
  document.getElementById('pgf-saldo-info').textContent = '';
  openSheet('pagar-gasto-fijo');
}

function pgfActualizarSaldo() {
  const fuente = document.getElementById('pgf-fuente').value;
  const info = document.getElementById('pgf-saldo-info');
  if (!fuente) { info.textContent = ''; return; }
  const gf = (S.gastosFijos || []).find(x => x.id === pgfIdActual);
  const monto = gf ? gf.monto : 0;
  // Pagar con tarjeta de crédito es un CARGO (sube la deuda de la tarjeta), no un
  // retiro de saldo — mismo criterio que addGastoVar() (tcCrearCompra) y
  // confirmarPagarSpotify() (spotify.js). Antes este preview trataba la TC como
  // una cuenta con saldo, mostrando "Saldo disponible" de algo que en realidad es cupo.
  if (Fuente.esTC(fuente)) {
    const tcId = fuente.split(':')[1];
    const tc = (S.tarjetasCredito || []).find(x => x.id === tcId);
    if (tc) {
      const nuevaDeuda = (tc.deuda || 0) + monto;
      const cupoDisp = tc.cupo ? tcCupoDisponible(tc) : null;
      info.innerHTML = 'Deuda: ' + fmt(tc.deuda || 0) + ' <i class="fa-solid fa-arrow-right gasto-flecha"></i> ' + fmt(nuevaDeuda);
      info.style.color = (cupoDisp !== null && monto > cupoDisp) ? 'var(--red)' : 'var(--accent)';
    } else {
      info.textContent = '';
    }
    return;
  }
  const rs = Plata.resumenSalida(fuente, monto); // misma regla que al confirmar
  info.textContent = rs.texto;
  info.style.color = rs.ok ? 'var(--accent)' : 'var(--red)';
}

function confirmarPagarGastoFijo() {
  const fuente = document.getElementById('pgf-fuente').value;
  const fecha = document.getElementById('pgf-fecha').value || hoy();
  const errEl = document.getElementById('pgf-error');
  errEl.style.display = 'none';
  if (!fuente) { errEl.textContent = 'Selecciona una cuenta para el pago.'; errEl.style.display = 'block'; return; }
  if (!pgfIdActual) return;
  const gf = (S.gastosFijos || []).find(x => x.id === pgfIdActual);
  if (!gf) return;
  // Verificar si ya fue pagado este mes
  if (!S.pagosGastosFijos) S.pagosGastosFijos = {};
  if (S.pagosGastosFijos[gf.id + '_' + mesActual()]) {
    errEl.textContent = 'Este gasto ya fue pagado este mes.'; errEl.style.display = 'block'; return;
  }
  const nota = document.getElementById('pgf-nota') ? document.getElementById('pgf-nota').value.trim() : '';
  if (!S.gastosVar) S.gastosVar = [];
  const gastoObj = { id: uid(), desc: 'Pago de ' + gf.nombre, monto: gf.monto, fecha, cat: gf.cat, fuente, nota: nota || 'Pago de gasto fijo', clase: 'neutro', esPagoGastoFijo: true, gastoFijoId: gf.id }; // neutro: el pago ya cuenta en Periodo.gastosFijosDelMes
  if (Fuente.esTC(fuente)) {
    // Cargar el pago a la tarjeta (sube tc.deuda) en vez de descontar saldo de una
    // cuenta — misma ruta que addGastoVar() usa para un gasto variable con TC.
    const tcId = fuente.split(':')[1];
    const tc = (S.tarjetasCredito || []).find(x => x.id === tcId);
    if (!tc) { errEl.textContent = 'Tarjeta no encontrada.'; errEl.style.display = 'block'; return; }
    const vTc = Plata.validarSalida('tc:' + tcId, gf.monto);
    if (!vTc.ok) { errEl.textContent = vTc.motivo; errEl.style.display = 'block'; return; }
    const compra = tcCrearCompra(tc, { desc: 'Pago de ' + gf.nombre, monto: gf.monto, fecha, cat: gf.cat, nota: nota || 'Pago de gasto fijo' });
    gastoObj._esCompraTC = true;
    gastoObj._tcId = tcId;
    gastoObj._tcCompraId = compra.id;
    S.gastosVar.push(gastoObj);
  } else {
    const vSal = Plata.validarSalida(fuente, gf.monto);
    if (!vSal.ok) { errEl.textContent = vSal.motivo; errEl.style.display = 'block'; return; }
    descontarFuente(fuente, gf.monto, _ogGv(gastoObj.id));
    S.gastosVar.push(gastoObj);
  }
  // Registrar pago del mes
  if (!S.pagosGastosFijos) S.pagosGastosFijos = {};
  // cat/nombre se guardan en el pago: si el gasto fijo se elimina después, el pago (plata que ya salió)
  // sigue contando en los análisis con su categoría.
  S.pagosGastosFijos[gf.id + '_' + mesActual()] = { fecha, fuente, monto: gf.monto, cat: gf.cat, nombre: gf.nombre };
  save(); refresh();
  closeSheet('pagar-gasto-fijo');
  if (window.logCambio) { const _pgfg = (S.gastosFijos || []).find(x => x.id === pgfIdActual); if (_pgfg) logCambio('Pagaste ' + _pgfg.nombre, '', _pgfg.monto, 'gasto_fijo'); }
  toast('Pago registrado correctamente', 'salida');
}

/* ── Wiring de controles propios de la pantalla ──────────────────────────
   Movido desde _initEventListeners() (index.html) el 2026-07-26 — ver
   auditoria-tecnica.md, punto 3. No son onclick inline (no hay problema
   de CSP acá), es solo mover el addEventListener directo a su módulo
   dueño en vez de dejarlo mezclado con el de otros dominios en
   index.html. Todos estos ids ya existen en el DOM estático antes de
   este <script> (verificado contra index.html), así que no hace falta
   esperar a DOMContentLoaded.

   Los botones fantasma (.btn-open-gasto-var/fijo) reimplementaban a
   mano poblarCatSelect+openSheet en vez de llamar a
   abrirNuevoGastoVar()/abrirNuevoGastoFijo() (que ya existen acá arriba
   y ya se usan para el botón del estado vacío) — se dedupe de paso. ── */
const _gBtnGastoVar = document.querySelector('.btn-open-gasto-var');
if (_gBtnGastoVar) _gBtnGastoVar.addEventListener('click', abrirNuevoGastoVar);
const _gBtnGastoFijo = document.querySelector('.btn-open-gasto-fijo');
if (_gBtnGastoFijo) _gBtnGastoFijo.addEventListener('click', abrirNuevoGastoFijo);

const _gBtnGVSave = document.getElementById('btn-guardar-gasto-var');
if (_gBtnGVSave) _gBtnGVSave.addEventListener('click', () => addGastoVar());
const _gBtnBienSave = document.getElementById('btn-guardar-bien');
if (_gBtnBienSave) _gBtnBienSave.addEventListener('click', () => guardarBien());
const _gBtnGFSave = document.getElementById('btn-guardar-gasto-fijo');
if (_gBtnGFSave) _gBtnGFSave.addEventListener('click', () => addGastoFijo());
const _gBtnPGFConfirm = document.getElementById('btn-confirmar-pagar-gf');
if (_gBtnPGFConfirm) _gBtnPGFConfirm.addEventListener('click', confirmarPagarGastoFijo);
const _gPgfFuenteSel = document.getElementById('pgf-fuente');
if (_gPgfFuenteSel) _gPgfFuenteSel.addEventListener('change', pgfActualizarSaldo);

// gv_fuente: llama al helper compartido mostrarAlertaFuente() (núcleo,
// también lo usa Cuentas con el prefijo 'mov') — el elemento es propio
// de Gastos, así que el wiring vive acá aunque el helper sea de núcleo.
const _gGvFuente = document.getElementById('gv_fuente');
if (_gGvFuente) _gGvFuente.addEventListener('change', () => mostrarAlertaFuente('gv'));

// ── Split de fuentes — gasto variable (gv), ver crearSplitWidget arriba ──
const _gGvSplitToggle = document.getElementById('gvSplitToggle');
if (_gGvSplitToggle) _gGvSplitToggle.addEventListener('click', gvSplit.toggle);
const _gGvBtnAddRow = document.getElementById('btn-add-gv-split-row');
if (_gGvBtnAddRow) _gGvBtnAddRow.addEventListener('click', gvSplit.addRow);
const _gGvMonto = document.getElementById('gv_monto');
if (_gGvMonto) _gGvMonto.addEventListener('input', actualizarGvSplitPreview);
if (_gGvMonto) _gGvMonto.addEventListener('input', actualizarGvImpacto);
const _gGvGrande = document.getElementById('gv_grande');
if (_gGvGrande) _gGvGrande.addEventListener('change', () => { _gvGrandeManual = true; });

/* ---- Registro de acciones en el sistema centralizado de eventos ---- */
Events.registerAll('gastos', {
  setMesFiltro,
  deleteGastoVar,
  deleteGastoFijo,
  abrirPagarGastoFijo,
  abrirNuevoGastoVar,
  abrirNuevoGastoFijo,
  abrirEditarGastoFijo,
  toggleCompraGrande,
  abrirSheetBien,
  abrirEditarBien,
  eliminarBien,
});

/* ── Ciclo de vida de la UI (antes ramas dentro de openSheet/showScreen, navegacion.js) ───────────────────── */
Ui.hoja('gasto-var', () => {
  poblarFuente('gv_fuente', true);
  FuentesFiltro.podar('gv_fuente', { ...FuentesFiltro.PRESET.SALIDA, sinOpcionesTexto: FuentesFiltro.MSG_SIN_SALDO });
  const hint = document.getElementById('gv_fuente_hint');
  if (hint) hint.style.visibility = 'hidden';
  // Al elegir cuenta: muestra el saldo disponible (o el cupo si es una TC).
  document.getElementById('gv_fuente').onchange = function () {
    const sd = document.getElementById('gv_fuente_saldo');
    if (!sd) return;
    const val = this.value;
    if (!val) { sd.textContent = ''; return; }
    const saldo = getSaldoFuente(val);
    if (Fuente.esTC(val)) {
      const tc = (S.tarjetasCredito || []).find(x => x.id === Fuente.id(val));
      if (!tc || !tc.cupo) { sd.textContent = 'El gasto se cargará a la TC — no sale plata de tus cuentas.'; sd.style.color = 'var(--text2)'; return; }
      sd.textContent = 'Cupo disponible: ' + fmt(saldo);
    } else {
      sd.textContent = 'Saldo disponible: ' + fmt(saldo);
    }
    sd.style.color = saldo > 0 ? 'var(--accent)' : 'var(--red)';
  };
}, { key: 'gastos-fuente' });

Ui.pantalla('gastos', () => {
  // renderMesFiltros() ya dispara renderGastosVar(); alcanza con estas dos (funciones puras de render).
  if (typeof renderMesFiltros === 'function') renderMesFiltros();
  if (typeof renderGastosFijos === 'function') renderGastosFijos();
}, { key: 'gastos-render' });
