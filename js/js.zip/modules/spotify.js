/* ═══════════════════════════════════════════════════════════════
   js/modules/spotify.js

   Módulo Spotify de mis-finanzas — funciones base (personas del plan,
   cobros, pago al servicio, ganancia). Documentación funcional
   completa en docs/spotify.md — este archivo es la implementación.

   La integración con el sistema de Personas (selector "¿Quién es?" al agregar o
   editar un integrante) vive más abajo, en este mismo archivo.

   Depende de globals del núcleo compartido (S, save, refresh,
   escHtml, fmt, toast, dialogo, uid, hoy, emptyState, getFuentes*,
   sumarFuente, descontarFuente, calcC, getSaldoFuente) y de
   js/core/events.js (Events), que debe cargarse antes que este.

   Pagar Spotify con una tarjeta de crédito (fuente 'tc:<id>') es un CARGO a la
   tarjeta, no un descuento de saldo — usa getTCById/tcCupoDisponible/tcRecalcular
   de js/modules/tarjetas_credito.js, igual que Encargos/Préstamos (S.tcMovimientos
   con tipo 'cargo_*'). No se asume que tarjetas_credito.js ya esté cargado (ver
   auditoria-tecnica.md, acoplamiento spotify↔tarjetas_credito): los 3 puntos que
   usan esas funciones pasan primero por _spEnsureTC(), que llama a
   Loader.ensure('tarjetas') si hace falta — ver ese helper, arriba de
   openSheet_pagarSpotify().
   ═══════════════════════════════════════════════════════════════ */

/* ---- SPOTIFY ---- */
let spDestinoIdx=null;
let spDestinoPago=0;
let spDestinoNombre='';

// ── Pago parcial con deuda pendiente (cobro a un integrante) ───────────────
// Mismo concepto que "pago parcial con deuda pendiente" de Mesada (ver
// mesada.js y docs/mesada.md#pago-parcial-con-deuda-pendiente): si alguien
// paga menos de lo esperado para los períodos elegidos y se marca
// explícitamente el toggle, el registro de tipo 'cobro' en spotifyHistorial
// guarda además:
//   cuotaEsperada        // periodos × cuota, snapshot del momento del cobro
//   pendiente            // cuánto falta por recibir de ESE cobro puntual
//   pendienteHistorial   // [{monto,fecha,destino,nota}] abonos posteriores
// El período de todas formas se cuenta como cubierto (proximoPago avanza
// igual) — lo pendiente es solo la plata, no el período. Si no se marca el
// toggle, un monto menor al esperado se registra tal cual, sin deuda (mismo
// criterio que Mesada: "ese mes solo fueron 60mil, no me quedó debiendo
// nada"). Índice del registro de spotifyHistorial que se está resolviendo
// desde el sheet "sp-hist-pend":
let spResolverIdx=null;

/* ── Split de fuentes (motor genérico, ver js/core/split.js) ─────
   Dos instancias: 'spc' (cobro — plata que ENTRA, mismo patrón que
   Mesada) y 'spp' (pago a Spotify — plata que SALE, mismo patrón que
   "Ya la usé" en Encargos). Sin TC en ninguna de las dos: cobrar plata
   ajena a una tarjeta no aplica (mismo criterio que ya usaba el select
   simple de cobro, getFuentesSinTC), y el motor de split trata cada
   fila por igual (sumar/descontar saldo) — no distingue un cargo a TC
   de un movimiento de cuenta, así que combinarlas en un split no lo
   soporta el motor genérico. El modo simple de "Pagar Spotify" sigue
   permitiendo TC exactamente igual que antes. */
let spcSplitMode=false;
let sppSplitMode=false;

// Cuando un solo cobro dividido termina repartido en DOS registros de historial
// (parte cierra deuda de un ciclo viejo, el resto es del ciclo nuevo — ver
// confirmarSpDestino), cada registro necesita su propia porción del split para
// que borrar uno solo revierta solo esa porción de cada cuenta, no el total.
// ── Libro (core-state.js): origen de cada cambio de saldo ────────────────────────────────────────────────
// _ogSp(ref, rev): cada sumar/descontarFuente deja en el libro { modulo:'spotify', ref:<id del registro de spotifyHistorial,
// o del pago> }. Con rev=true es una reversión (tipo 'reversion'). `opts.exacto` ya no existe: el saldo no se recorta en 0.
const _ogSp = Libro.origen('spotify');

function _spProporcionarSplits(splits,montoParcial,montoTotal){
  if(!splits||!splits.length||montoTotal<=0||montoParcial<=0)return null;
  const factor=montoParcial/montoTotal;
  return splits.map(s=>({fuente:s.fuente,monto:Math.round(s.monto*factor)}));
}


// Split de PAGO a Spotify (plata que SALE): solo cuentas con saldo >= $50 (PRESET.SPOTIFY). Distinto del de COBRO ('spc'): allí la
// plata ENTRA y una cuenta vacía es un destino válido, así que no se filtra por saldo.
const _sp_spc = crearSplitWidget('spc', {
  simpleId:'spCobModoSimple', splitId:'spCobModoDividido', toggleId:'spCobSplitToggle', rowsId:'spCobSplitRows',
  getModo:()=>spcSplitMode, setModo:v=>{spcSplitMode=v;},
  fuentes:{ placeholder:'Selecciona una cuenta...', placeholderDeshabilitado:true },
  onPreview:actualizarSpDestinoPreview
});

const _sp_spp = crearSplitWidget('spp', {
  simpleId:'spPagarModoSimple', splitId:'spPagarModoDividido', toggleId:'spPagarSplitToggle', rowsId:'spPagarSplitRows',
  getModo:()=>sppSplitMode, setModo:v=>{sppSplitMode=v;},
  fuentes:{ sentido:'sale', preset:'SPOTIFY', placeholder:'Selecciona una cuenta...', sinOpcionesTexto:FuentesFiltro.MSG_SIN_SALDO },
  onPreview:actualizarSpPagarPreview
});

function getSpCajita(){
  // Finds or returns null for the Spotify cajita
  if(S.spotify.cajitaId){
    const c=(S.cajitas||[]).find(x=>x.id===S.spotify.cajitaId);
    if(c)return c;
  }
  // Try to find one named Spotify
  const c=(S.cajitas||[]).find(x=>x.nombre&&x.nombre.toLowerCase().includes('spotify'));
  if(c){S.spotify.cajitaId=c.id;return c;}
  return null;
}

function getSpCajitaSaldo(){
  const c=getSpCajita();
  // calcC() (interés real de la cajita) vive en js/core/nu-calc.js, núcleo de carga de entrada.
  return c?calcC(c).val:0;
}

// spNombreDe() y spPersonaPagadaVigente() se movieron a js/core/calc-helpers.js
// (2026-09-20): son cálculo puro sobre `p`/`getPersona`, y "Necesita atención"
// (inicio.js) las necesita en el PRIMER render. Con este archivo lazy, esas
// tarjetas aparecían recién al cargarlo y empujaban todo Inicio hacia abajo
// (CLS). Siguen siendo globales: este archivo las usa igual que antes.

function spPeriodosVencidos(p,fechaCorte,estricto){
  // Cuenta cuántos períodos de 30 días de este integrante ya se vencieron a la fecha
  // de corte dada, partiendo de su `proximoPago` vigente — que ya refleja todos los
  // cobros aplicados hasta ahora (cada cobro lo avanza N*30 días al confirmarse).
  // Reemplaza al viejo cálculo "monto − total cobrado en el ciclo", que solo detectaba
  // como mucho UN período de deuda por persona: si alguien pagó un período dentro de
  // un ciclo largo y luego se le venció OTRO sin pagarlo, "total cobrado ≥ una cuota"
  // ya daba pend=0 aunque en la realidad debía el período nuevo. Ver CHANGELOG.md.
  if(!p||!p.proximoPago)return 0;
  const corte=_fechaSafe(fechaCorte);
  let cursor=_fechaSafe(p.proximoPago);
  let n=0;
  // `estricto`: no cuenta el período que empieza EXACTAMENTE el día de corte (ver
  // SP_EMPATE_PERIODOS más abajo — ese período ya pertenece al ciclo nuevo).
  while(estricto?cursor<corte:cursor<=corte){ n++; cursor.setDate(cursor.getDate()+30); }
  return n;
}

function spCicloCobrosActual(){
  // Cobros registrados en el historial desde el último pago real a Spotify (ciclo actual).
  // Si nunca se ha pagado, todo el historial de cobros pertenece al ciclo actual.
  // Se excluyen los cobros con _pagoIdCierre: aunque queden posicionados después del
  // último pago (porque se registraron más tarde), son plata que en realidad saldó
  // deuda de ESE ciclo que ya cerró — ver confirmarSpDestino().
  const hist=S.spotify.historial||[];
  let lastPagoIdx=-1;
  for(let i=hist.length-1;i>=0;i--){ if(hist[i].tipo==='pago'){lastPagoIdx=i;break;} }
  return hist.map((h,idx)=>({...h,_idx:idx})).filter(h=>h.tipo==='cobro'&&h._idx>lastPagoIdx&&!h._pagoIdCierre);
}

function spCobradoDePersona(p,cicloCobros){
  // Suma lo que una persona ya aportó en el ciclo actual, vinculando por id.
  return (cicloCobros||spCicloCobrosActual()).filter(h=>h.spId===p.id).reduce((a,h)=>a+(h.monto||0),0);
}

function nextMonthFixed(dateStr, mesesAdelantar){
  // Avanza N*30 dias desde la fechaProximoPago (no desde hoy ni desde cuando pago)
  // Ej: si la proxima fecha era el 8-jun y pago el 5-jun o el 10-jun, la siguiente es 8-jun + 30d
  if(!dateStr)return'';
  const d=_fechaSafe(dateStr);
  const dias=(mesesAdelantar||1)*30;
  d.setDate(d.getDate()+dias);
  return d.toISOString().split('T')[0];
}

// ── Períodos flotantes y atribución de cobros a ciclos ─────────────────────
// Un cobro de N períodos es UN solo registro (una sola entrada de plata), pero cada
// período tiene su propia fecha de inicio: proximoPagoAntes + 30·k. Ciclo (entre dos
// pagos reales a Spotify) y período (30 días de cada integrante) son calendarios
// distintos, así que la plata de un cobro multi-período no siempre cae toda en el
// mismo ciclo. Reglas (ver spotify.md §7bis):
//  · El primer período (k=0) cuenta en el ciclo donde se registró el cobro — igual que
//    siempre (por posición en el historial).
//  · Los períodos siguientes (k≥1) se atribuyen por FECHA DE INICIO: al ciclo que estaba
//    abierto ese día. Mientras esa fecha no llegue y no se haya pagado Spotify, están
//    "flotantes": son plata cobrada pero todavía no cuentan en "Recaudado".
//  · Empate (el período empieza el mismo día que se paga Spotify): va al ciclo que se
//    cierra, salvo que esa persona ya tenga SP_EMPATE_PERIODOS o más períodos en él
//    (entonces va al nuevo).
// Todo se DERIVA del historial: no se guarda ningún estado nuevo, así que borrar un
// cobro o un pago a Spotify reacomoda los períodos solo.
const SP_PERIODO_DIAS=30;
const SP_EMPATE_PERIODOS=2;

function spSumarDias(fechaStr,dias){
  const d=_fechaSafe(fechaStr);
  d.setDate(d.getDate()+dias);
  return d.toISOString().split('T')[0];
}

function spTramosDeCobro(h){
  // Divide un registro de cobro en sus períodos. Un cobro sin `proximoPagoAntes` (la persona
  // no tenía fecha de próximo pago) → tramos sin fecha de inicio: nunca flotan.
  // `_periodoOffset`: períodos del mismo pago que ya cubrió el registro hermano de
  // "Pago atrasado del ciclo anterior" (ver confirmarSpDestino).
  const total=Math.max(1,Math.round(h.periodos||1));
  const offset=Math.min(total-1,Math.max(0,Math.round(h._periodoOffset||0)));
  const n=total-offset;
  const monto=h.monto||0;
  const porTramo=Math.round(monto/n);
  const out=[];
  for(let j=0;j<n;j++){
    const kAbs=offset+j;
    const tieneFecha=!!h.proximoPagoAntes;
    const fechaInicio=tieneFecha?spSumarDias(h.proximoPagoAntes,kAbs*SP_PERIODO_DIAS):null;
    out.push({kAbs,inicioRef:fechaInicio||h.fecha||'',inicio:(kAbs>=1&&tieneFecha)?fechaInicio:null,monto:j===n-1?monto-porTramo*(n-1):porTramo});
  }
  return out;
}

function spMontoAntesDe(h,fechaCorte){
  // Plata de este cobro que ya cubría períodos ANTERIORES a `fechaCorte` (el primer
  // período siempre cuenta; los siguientes solo si empezaron antes del corte).
  return spTramosDeCobro(h).filter(t=>!t.inicio||t.inicio<fechaCorte).reduce((a,t)=>a+t.monto,0);
}

function spAsignarPeriodos(hist){
  // Devuelve un tramo por período de cada cobro, con el ciclo al que pertenece
  // (0 = antes del primer pago a Spotify; M = pagos.length = ciclo abierto).
  hist=hist||S.spotify.historial||[];
  const pagos=[];
  hist.forEach((h,idx)=>{ if(h.tipo==='pago')pagos.push({idx,id:h.id,fecha:h.fecha||''}); });
  const M=pagos.length;
  const hoyStr=hoy();
  const tramos=[];
  hist.forEach((h,idx)=>{
    if(h.tipo!=='cobro')return;
    let cPos=0;
    pagos.forEach(pg=>{ if(pg.idx<idx)cPos++; });
    const clave=h.spId||h.nombre||'';
    if(h._pagoIdCierre){
      // Plata que saldó deuda de un ciclo ya cerrado: pertenece a ESE ciclo, entera.
      const j=pagos.findIndex(pg=>pg.id===h._pagoIdCierre&&pg.idx<idx);
      tramos.push({h,idx,clave,cPos,kAbs:0,inicio:null,inicioRef:h.fecha||'',monto:h.monto||0,ciclo:j>=0?j:cPos,flotante:false});
      return;
    }
    spTramosDeCobro(h).forEach(t=>{
      let ciclo=cPos;
      if(t.inicio){
        const porFecha=pagos.filter(pg=>pg.fecha<t.inicio).length;
        ciclo=Math.max(cPos,porFecha);
      }
      tramos.push({h,idx,clave,cPos,kAbs:t.kAbs,inicio:t.inicio,inicioRef:t.inicioRef,monto:t.monto,ciclo,flotante:false});
    });
  });
  // Empate: período que empieza el mismo día que un pago a Spotify. Por defecto queda en
  // el ciclo que cierra; si esa persona ya tiene SP_EMPATE_PERIODOS o más períodos en él,
  // pasa al nuevo.
  const porPersona={};
  tramos.forEach(t=>{ (porPersona[t.clave]=porPersona[t.clave]||[]).push(t); });
  Object.values(porPersona).forEach(lista=>{
    lista.slice().sort((a,b)=>(a.inicioRef||'').localeCompare(b.inicioRef||'')||a.kAbs-b.kAbs).forEach(t=>{
      if(!t.inicio)return;
      if(!pagos.some(pg=>pg.fecha===t.inicio))return;
      const previos=lista.filter(o=>o!==t&&o.ciclo===t.ciclo&&(o.inicioRef||'')<(t.inicioRef||'')).length;
      if(previos>=SP_EMPATE_PERIODOS&&t.ciclo<M)t.ciclo+=1;
    });
  });
  // Flotante = todavía sin resolver: sigue en el mismo ciclo abierto donde se registró el
  // cobro (no se ha pagado Spotify desde entonces) y su período aún no empieza. Si ya hubo
  // un pago a Spotify antes de esa fecha, el período quedó asignado al ciclo nuevo y
  // cuenta ahí de inmediato.
  tramos.forEach(t=>{ t.flotante=(t.ciclo===M&&t.cPos===M&&!!t.inicio&&t.inicio>hoyStr); });
  return tramos;
}

function spResumenCicloActual(hist){
  // "Recaudado este ciclo" = tramos del ciclo abierto que ya empezaron. Los períodos
  // prepagados que todavía no empiezan quedan aparte, como `flotante`.
  const tramos=spAsignarPeriodos(hist);
  const M=(hist||S.spotify.historial||[]).filter(h=>h.tipo==='pago').length;
  let recaudado=0,flotante=0;
  tramos.forEach(t=>{
    if(t.h._pagoIdCierre||t.ciclo!==M)return;
    if(t.flotante)flotante+=t.monto; else recaudado+=t.monto;
  });
  return {recaudado,flotante,tramos};
}

// ¿El costo del plan es un número mayor que cero? Una sola condición para el aviso de renderSpotify y para
// el bloqueo de «Pagar Spotify»: sin costo no hay cuota ni ganancia que calcular.
function spCostoValido(){
  const c=S.spotify.costo;
  return typeof c==='number' && isFinite(c) && c>0;
}

// Abre «Pagar Spotify» solo con el costo configurado; si no, lleva al campo del costo.
function abrirPagarSpotify(){
  if(!spCostoValido()){
    toast('Configura el costo del plan para registrar pagos','err');
    const inp=document.getElementById('spotifyCosto');
    if(inp){ inp.focus(); inp.select(); }
    return;
  }
  openSheet('pagar-spotify');
}

function renderSpotify(){
  const el=document.getElementById('spotifyList');
  const p=S.spotify.personas||[];
  const costo=S.spotify.costo||0;
  // "Recaudado"/"Pendiente" se calculan desde el historial del ciclo actual (movimientos reales),
  // no desde el flag "pagado" — así no se descuadran si solo tocas el badge para corregir un error.
  const cicloCobros=spCicloCobrosActual();
  // "Recaudado" cuenta por PERÍODOS, no por registro: un cobro de varios períodos solo
  // aporta los que ya empezaron; el resto queda flotante (ver spAsignarPeriodos).
  const resCiclo=spResumenCicloActual();
  const cob=resCiclo.recaudado;
  // Si alguien prepagó varios períodos, su cobertura puede caer en un ciclo anterior
  // (antes del último pago real) y "desaparecer" de cicloCobros — pero mientras su
  // proximoPago siga en el futuro, sigue cubierto y no debe contar como pendiente.
  // Dos fuentes de "pendiente" distintas, y ninguna sustituye a la otra:
  // 1) Personas no vigentes: su período actual todavía no está cubierto en absoluto.
  // 2) Personas vigentes con un cobro parcial ("quedó debiendo la diferencia", ver
  //    §3 spotify.md): el período SÍ quedó cubierto (proximoPago avanzó), pero falta
  //    plata puntual de ese cobro (`pendiente` en el registro). No se solapan: un
  //    período que aparece en (1) nunca tiene registro de cobro que sumar en (2).
  const cobPend=p.reduce((a,x)=>{
    if(spPersonaPagadaVigente(x))return a;
    return a+spPeriodosVencidos(x,hoy())*(x.monto||0);
  },0)+cicloCobros.reduce((a,h)=>a+(h.pendiente>0?h.pendiente:0),0);
  const cajitaSaldo=getSpCajitaSaldo();
  
  document.getElementById('spCob').textContent=fmt(cob);
  document.getElementById('spPend').textContent=fmt(cobPend);
  document.getElementById('spProg').style.width=(costo>0?Math.min(100,cob/costo*100):0).toFixed(0)+'%';
  document.getElementById('spProgLabel').textContent=(costo>0?Math.round(cob/costo*100)+'% recaudado':'')+(resCiclo.flotante>0?(costo>0?' · ':'')+'+ '+fmt(resCiclo.flotante)+' adelantado (aún no cuenta)':'');

  // Aviso cuando el costo del plan no es válido (misma condición que el bloqueo de «Pagar Spotify»)
  let warnEl=document.getElementById('sp-costo-warn');
  if(!spCostoValido()){
    if(!warnEl){
      warnEl=document.createElement('div');
      warnEl.id='sp-costo-warn';
      warnEl.className='sp-costo-aviso';
      warnEl.innerHTML='<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg><span class="sp-costo-aviso-txt">Configura el costo del plan para empezar a registrar pagos.</span><button type="button" class="btn btn-sm sp-costo-aviso-btn">Configurar costo</button>';
      warnEl.querySelector('button').addEventListener('click', ()=>{ const inp=document.getElementById('spotifyCosto'); if(inp){ inp.focus(); inp.select(); } });
      const spList=document.getElementById('spotifyList');
      if(spList&&spList.parentNode) spList.parentNode.insertBefore(warnEl,spList);
    }
  } else {
    if(warnEl) warnEl.remove();
  }

  // Estado de la cajita = ¿alcanza lo guardado ahí para cubrir el costo?
  // (Esto es solo un chequeo de liquidez de la cajita puntual, no la ganancia real:
  // la ganancia real ya se calcula en renderSpStats a partir de todo el historial,
  // sin importar a qué cuenta llegó cada cobro.)
  const cajitaEl=document.getElementById('spCajitaSaldo');
  cajitaEl.textContent=fmt(cajitaSaldo);
  const statusEl=document.getElementById('spCajitaStatus');
  if(costo>0){
    const diferencia=cajitaSaldo-costo;
    if(diferencia>0){
      statusEl.textContent='Te sobra '+fmt(diferencia);
      statusEl.style.color='var(--accent)';
    } else if(cajitaSaldo>0){
      statusEl.textContent='Faltan '+fmt(-diferencia)+' para pagar';
      statusEl.style.color='var(--amber)';
    } else {
      statusEl.textContent='Sin saldo en cajita';
      statusEl.style.color='var(--text3)';
    }
  } else {
    statusEl.textContent='';
  }
  
  // El estado vacío ya trae «Agregar persona»: el botón de pie solo aparece con personas.
  mostrarSi(document.getElementById('btn-add-spotify-persona'),p.length>0);
  if(!p.length){el.innerHTML=emptyState(
    '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.8" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    'Sin personas en Spotify',
    'Agrega a las personas que comparten tu plan para hacer seguimiento de sus cobros mensuales.',
    'Agregar persona',
    {action:'spotify:abrirSheetAgregar'}
  );}
  else {
    // Ordenar por proximidad al próximo pago: vencidos primero (más negativos), luego más próximos
    const pOrdenado=[...p].map((x,i)=>({...x,_origIdx:i})).sort((a,b)=>{
      const far=99999;
      const dA=a.proximoPago?Math.ceil((_fechaSafe(a.proximoPago)-new Date())/86400000):far;
      const dB=b.proximoPago?Math.ceil((_fechaSafe(b.proximoPago)-new Date())/86400000):far;
      return dA-dB;
    });
    // Migrado a html`` (js/core/html-tag.js, ver auditoria-tecnica.md, punto 2):
    // escapa por defecto en vez de depender de acordarse de escHtml() en cada
    // interpolación de texto libre (spNombreDe/fuenteLabel). Arrays de fragmentos
    // (pOrdenado.map(...)) se dejan sin .join('') — html`` externo los concatena
    // sin volver a escapar cada fragmento interno ya seguro.
    el.innerHTML=html`<div class="card">${pOrdenado.map((x)=>{
    const i=x._origIdx;
      let fechaInfo='';
      if(x.proximoPago){
        const diasRestantes=Math.ceil((_fechaSafe(x.proximoPago)-new Date())/86400000);
        const vencido=diasRestantes<0;
        const hoy0=diasRestantes===0;
        fechaInfo=html`<span class="badge badge-xs ${raw(vencido?'bg-red':hoy0?'bg-amber':'bg-purple')}">${vencido?'Vencido hace '+Math.abs(diasRestantes)+'d':hoy0?'Vence hoy':'Paga en '+diasRestantes+'d · '+x.proximoPago}</span>`;
      }
      const destinoBadge=x.ultimoDestinoSplit
        ?html`<span class="badge bg-purple sp-badge-flecha"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg> Dividido</span>`
        :(x.ultimoDestino?html`<span class="badge ${raw(fuenteBadgeClass(x.ultimoDestino))} sp-badge-flecha"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg> ${fuenteLabel(x.ultimoDestino)}</span>`:'');
      return html`<div class="sp-row">
        <div class="sp-flex-c">
          <div class="avatar">${spNombreDe(x).substring(0,2).toUpperCase()}</div>
          <div>
            <div class="row-name row-name-13">${spNombreDe(x)}</div>
            <div class="row-sub">${fmt(x.monto)}/período${(x.mesesAdelantados>1&&spPersonaPagadaVigente(x))?raw(' · <span class="sp-meses-badge">'+x.mesesAdelantados+'p adelantados</span>'):''}</div>
            ${fechaInfo?html`<div class="sp-mt-3">${fechaInfo}</div>`:''}
            ${destinoBadge?html`<div class="sp-mt-2">${destinoBadge}</div>`:''}
          </div>
        </div>
        <div class="sp-acciones">
          <span class="badge sp-click ${raw(spPersonaPagadaVigente(x)?'bg-green':'bg-red')}" ${raw(Events.attr('spotify:marcarPago', i))} title="${spPersonaPagadaVigente(x)?'Ya pagó · clic para revertir':'Cobrar a '+spNombreDe(x)}">${spPersonaPagadaVigente(x)?'Pagó':'Cobrar'}</span>
          <div class="sp-flex-2">
            <button type="button" class="btn-icon sp-btn-34 sp-btn-acento" ${raw(Events.attr('spotify:editar', i))} title="Editar"><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
            <button type="button" class="btn-icon sp-btn-34" ${raw(Events.attr('spotify:eliminar', i))}><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></button>
          </div>
        </div>
      </div>`;
    })}</div>`;
  }
  
  // Badge en home: avisar si hay pagos próximos o vencidos (<= 3 días)

  // Historial
  renderSpHistorial();
  // Estadísticas
  renderSpStats();
}

function renderSpHistorial(){
  const el=document.getElementById('spHistorial');
  if(!el)return;
  const total=S.spotify.historial||[];
  // Mapear con índice real, luego ordenar por fecha descendente. A igual fecha,
  // gana el orden de registro descendente (el más reciente en agregarse va primero) —
  // así un cobro atrasado con fecha vieja no se cuela por encima de uno más reciente.
  const hist=total.map((h,i)=>({...h,_realIdx:i}))
    .sort((a,b)=>(b.fecha||'').localeCompare(a.fecha||'')||(b._realIdx-a._realIdx))
    .slice(0,12);
  if(!hist.length){el.innerHTML='<div class="card card-sm sp-hist-vacio">Sin pagos registrados aún.</div>';return;}
  // Migrado a html`` (js/core/html-tag.js, ver auditoria-tecnica.md, punto 2).
  // Hallazgo real de paso: fuenteLabel() en `fuentesInfo` (nombre de cajita/cuenta,
  // texto libre) nunca pasaba por escHtml() acá — a diferencia del badge de
  // "último destino" en renderSpotify(), que sí se había corregido antes. Al
  // interpolarse como UN solo ${...}, html`` lo escapa igual que cualquier otro
  // campo, sin tocar los separadores fijos (' · ', ' + ').
  el.innerHTML=html`${hist.map(h=>{
    const tienePendiente=h.tipo==='cobro'&&(h.pendiente||0)>0;
    const yaSaldado=h.tipo==='cobro'&&h.cuotaEsperada&&!tienePendiente;
    const pendienteHtml=tienePendiente
      ?html`<div class="sp-pend-fila">
          <span class="badge badge-xs bg-amber">Debe ${fmt(h.pendiente)}</span>
          <span class="sp-pend-link" ${raw(Events.attr('spotify:resolverPendiente', h._realIdx))}>Registrar pago de lo pendiente</span>
        </div>`
      :yaSaldado?html`<div class="sp-saldo-ok"><i class="fa-solid fa-check sp-mr-3"></i>Saldó lo pendiente</div>`:'';
    // Cada abono de lo pendiente, como su propia línea — antes quedaban invisibles,
    // fundidos dentro de h.monto (ver CHANGELOG.md#spotify, fix de visibilidad de abonos).
    const abonosHtml=(h.pendienteHistorial&&h.pendienteHistorial.length)
      ?html`<div class="sp-abonos">${h.pendienteHistorial.map((ab,abIdx)=>html`<div class="sp-abono-fila"><span class="sp-flex1"><span class="c-green">+ ${fmt(ab.monto)}</span> · ${ab.fecha}${ab.destino?' · '+fuenteLabel(ab.destino):''}${ab.nota?html` · <span class="c-blue">${ab.nota}</span>`:''}</span><span class="sp-deshacer" ${raw(Events.attr('spotify:deshacerAbonoPendiente', h._realIdx, abIdx))}>deshacer</span></div>`)}</div>`
      :'';
    const extraHtml=(h.tipo==='cobro'&&(h.extra||0)>0)
      ?html`<div class="sp-extra-nota"><span class="c-blue">+ ${fmt(h.extra)} extra</span> · ${h.extraFuente?fuenteLabel(h.extraFuente):'sin cuenta'} · aparte del cobro de Spotify</div>`
      :'';
    const fuentesInfo=h.splits&&h.splits.length
      ?' · '+h.splits.map(s=>fuenteLabel(s.fuente||'')).join(' + ')
      :(h.fuente?' · '+fuenteLabel(h.fuente):'');
    return html`
    <div class="card card-sm sp-hist-card">
      <div class="row sp-hist-row">
        <div class="sp-flex1">
          <div class="sp-hist-tit">${h.tipo==='pago'?'Pago a Spotify':'Cobro de '+h.nombre}</div>
          <div class="sp-hist-sub">${h.fecha}${fuentesInfo}${h.nota?html` · <span class="c-blue">${h.nota}</span>`:''}</div>
          ${pendienteHtml}
          ${abonosHtml}
          ${extraHtml}
        </div>
        <div class="sp-hist-der">
          <div class="sp-hist-monto ${raw(h.tipo==='pago'?'c-red':'c-green')}">${h.tipo==='pago'?'−':'+'} ${fmt(h.monto)}</div>
          <button type="button" class="btn-icon sp-btn-36" ${raw(Events.attr('spotify:eliminarHistorial', h._realIdx))}><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></button>
        </div>
      </div>
    </div>`;
  })}`;
}

function renderSpStats(){
  const el=document.getElementById('spStats');
  if(!el)return;
  const personas=S.spotify.personas||[];
  const hist=S.spotify.historial||[];
  const costo=S.spotify.costo||0;

  // Sin personas ni historial no hay nada que mostrar: el título «Estadísticas» tampoco
  // (quedaba pegado al de «Historial de pagos», que sí lleva su mensaje de vacío).
  const _hayStats=personas.length>0||hist.length>0;
  mostrarSi(document.getElementById('spStatsTitulo'),_hayStats);
  if(!_hayStats){
    el.innerHTML='';
    return;
  }

  // ── Cobros y pagos del historial
  const cobros=hist.filter(h=>h.tipo==='cobro');
  const pagosSpotify=hist.filter(h=>h.tipo==='pago');
  const totalCobradoHist=cobros.reduce((a,h)=>a+(h.monto||0),0);
  const totalPagadoHist=pagosSpotify.reduce((a,h)=>a+(h.monto||0),0);

  // ── Cuota del admin (su "plan gratis")
  const totalSlots=personas.length+1;
  const cuotaAdmin=costo>0?Math.round(costo/totalSlots):0;
  const ciclosPagados=pagosSpotify.length;
  // Se usa la cuota guardada en cada pago (según la cantidad de personas de esa época).
  const ahorroCuotaAdmin=pagosSpotify.reduce((a,h)=>a+(h._cuotaAdmin||0),0);

  // ── Ingreso mensual estimado (personas activas) — solo se usa como respaldo
  // mientras no haya ningún ciclo pagado todavía
  const ingresoEstimado=personas.reduce((a,p)=>a+(p.monto||0),0);
  const margen=costo>0?ingresoEstimado-costo+cuotaAdmin:0;

  // ── Ganancia REAL por ciclo pagado: recorre el historial y corta un "ciclo"
  // cada vez que aparece un pago real a Spotify. Así el flujo mensual deja de
  // ser un número teórico fijo y refleja lo que de verdad ganaste cada mes.
  const ciclosCompletos=[];
  // El cobrado de cada ciclo se arma con la atribución por PERÍODOS (spAsignarPeriodos):
  // un período prepagado cuyo inicio cae después de un pago a Spotify cuenta en el ciclo
  // siguiente, no en el que estaba abierto cuando entró la plata. Los cobros con
  // _pagoIdCierre siguen sumándose al ciclo que saldaron (o al que estaba acumulando si
  // el pago que referenciaban ya no existe).
  const tramosStats=spAsignarPeriodos(hist);
  hist.filter(h=>h.tipo==='pago').forEach((h,j)=>{
    const cobradoCiclo=tramosStats.filter(t=>t.ciclo===j).reduce((a,t)=>a+t.monto,0);
    const cuotaAdminDeEseCiclo=h._cuotaAdmin||0;
    // Dos lecturas del mismo ciclo (ver docs/spotify.md §7):
    //   mano     = cobrado − pagado             → plata nueva libre para gastar
    //   ganancia = cobrado − pagado + tu parte  → beneficio total (suma el mes que te salió gratis)
    ciclosCompletos.push({fecha:h.fecha, cobrado:cobradoCiclo, pagado:h.monto||0, mano:cobradoCiclo-(h.monto||0), ganancia:cobradoCiclo-(h.monto||0)+cuotaAdminDeEseCiclo});
  });
  // Plata cobrada por períodos que todavía no empiezan: no es ganancia de ningún ciclo aún.
  const flotanteTotal=tramosStats.filter(t=>t.flotante).reduce((a,t)=>a+t.monto,0);
  const promedioCiclo=ciclosCompletos.length?ciclosCompletos.reduce((a,c)=>a+c.ganancia,0)/ciclosCompletos.length:null;
  const ultimoCiclo=ciclosCompletos.length?ciclosCompletos[ciclosCompletos.length-1].ganancia:null;
  const mejorCiclo=ciclosCompletos.length?Math.max(...ciclosCompletos.map(c=>c.ganancia)):null;
  const peorCiclo=ciclosCompletos.length?Math.min(...ciclosCompletos.map(c=>c.ganancia)):null;
  const promedioMano=ciclosCompletos.length?ciclosCompletos.reduce((a,c)=>a+c.mano,0)/ciclosCompletos.length:null;

  // ── Ganancia real: solo calculable cuando hay pagos registrados
  const gananciaMano=(totalCobradoHist-flotanteTotal)-totalPagadoHist;       // sin tu parte
  const gananciaReal=gananciaMano+ahorroCuotaAdmin;                           // con tu parte
  // Extras: plata de más que dieron las personas. Va aparte, nunca suma a la ganancia de Spotify.
  const extrasTotal=cobros.reduce((a,h)=>a+(h.extra||0),0);
  const extrasN=cobros.filter(h=>(h.extra||0)>0).length;
  const hayCiclo=ciclosPagados>0;

  const cV=(v)=>v>0?'c-green':v<0?'c-red':'sp-t-neu';
  const sg=(v)=>(v>=0?'+':'\u2212')+fmt(Math.abs(v));

  let html=`<div class="sp-stats-grid">`;

  // Flujo mensual: promedio real por ciclo pagado (si ya hay al menos uno),
  // o una proyección teórica mientras tanto — claramente marcada como tal.
  if(promedioCiclo!==null){
    const nCiclos=ciclosCompletos.length;
    // Con tu parte en juego hay dos lecturas distintas y se muestran las dos, lado a lado.
    // Sin cuota del admin (costo sin configurar) serían idénticas: se muestra una sola.
    const hayDosLecturas=ahorroCuotaAdmin>0;
    // Último / mejor / peor: si no hubo variación (mejor = peor) repetir los tres números
    // no aporta nada — se colapsa a una línea y vuelve solo en cuanto aparezca una diferencia.
    let pieCiclos;
    if(nCiclos===1){
      pieCiclos=`único ciclo pagado todavía`;
    } else if(Math.round(mejorCiclo)===Math.round(peorCiclo)){
      pieCiclos=`todos los ciclos: ${sg(ultimoCiclo)} · sin variación`;
    } else {
      pieCiclos=`último: ${sg(ultimoCiclo)} · mejor: ${sg(mejorCiclo)} · peor: ${sg(peorCiclo)}`;
    }
    const colMano=`<div class="sp-flex1">
          <div class="sp-stat-eyebrow">En mano</div>
          <div class="stat-value ${cV(promedioMano)}" title="Cobrado menos pagado: plata nueva que te queda libre para gastar.">${sg(promedioMano)}</div>
          <div class="sp-stat-sub">cobrado \u2212 pagado</div>
        </div>`;
    const colTotal=`<div class="sp-flex1">
          <div class="sp-stat-eyebrow">${hayDosLecturas?'Beneficio total':'Por ciclo'}</div>
          <div class="stat-value ${cV(promedioCiclo)}" title="${hayDosLecturas?'En mano más tu parte del plan, que te salió gratis y no pagaste de tu bolsillo.':'Cobrado menos pagado.'}">${sg(promedioCiclo)}</div>
          <div class="sp-stat-sub">${hayDosLecturas?'+ tu parte del plan':'cobrado \u2212 pagado'}</div>
        </div>`;
    html+=`<div class="stat sp-span-all">
      <div class="sp-stat-cab">
        <div class="stat-label sp-mb0">Promedio real por ciclo pagado</div>
        <div class="sp-stat-nota">basado en ${nCiclos} ciclo${nCiclos!==1?'s':''} pagado${nCiclos!==1?'s':''}</div>
      </div>
      <div class="sp-flex-12">
        ${hayDosLecturas?colMano+`<div class="sp-vsep"></div>`+colTotal:colTotal}
      </div>
      <div class="sp-stat-pie">${hayDosLecturas?'beneficio total · ':''}${pieCiclos}</div>
    </div>`;
  } else {
    html+=`<div class="stat sp-span-all">
      <div class="stat-label">Margen proyectado</div>
      <div class="sp-stat-base">
        <div class="stat-value ${cV(margen)}">${margen>=0?'+':''}${fmt(Math.abs(margen))}</div>
        <div class="sp-stat-nota2">cobras ${fmt(ingresoEstimado)} en cuotas · el plan cuesta ${costo>0?fmt(costo):'—'}</div>
      </div>
      <div class="sp-stat-hint">proyección con tu configuración actual, no con tu frecuencia real de pago — registra un pago a Spotify para ver el promedio real por ciclo</div>
    </div>`;
  }

  // Total cobrado
  html+=`<div class="stat">
    <div class="stat-label">Total cobrado</div>
    <div class="stat-value c-green">${fmt(totalCobradoHist)}</div>
    <div class="sp-stat-hint">${cobros.length} cobro${cobros.length!==1?'s':''}${flotanteTotal>0?` · ${fmt(flotanteTotal)} adelantado`:''}</div>
  </div>`;

  // Segunda stat: ganancia real si hay ciclo, balance del ciclo si no
  if(!hayCiclo&&totalCobradoHist>0&&costo>0){
    // Sin pagos a Spotify aún: mostrar cuánto falta/sobra para cubrir el costo
    const pendiente=costo-(totalCobradoHist-flotanteTotal);
    const sobra=(totalCobradoHist-flotanteTotal)-costo;
    html+=`<div class="stat">
      <div class="stat-label">Balance del ciclo</div>
      ${pendiente>0
        ?`<div class="stat-value c-amber">\u2212${fmt(pendiente)}</div>
          <div class="sp-stat-hint" title="Falta recaudar para cubrir el plan completo, tu parte incluida.">falta para cubrir el plan</div>`
        :`<div class="stat-value c-green">+${fmt(sobra)}</div>
          <div class="sp-stat-hint" title="Esto es lo que ganas después de cubrir el plan completo, incluida tu propia parte.">ya cubriste el plan</div>`
      }
    </div>`;
  } else if(hayCiclo){
    html+=`<div class="stat">
      <div class="stat-label">Ganancia acumulada</div>
      <div class="stat-value ${cV(gananciaReal)}">${gananciaReal>=0?'+':'\u2212'}${fmt(Math.abs(gananciaReal))}</div>
      <div class="sp-stat-hint" title="${ahorroCuotaAdmin>0?'Cobrado menos pagado, más tu parte del plan, que ya quedó cubierta y no la pagaste de tu bolsillo.':'Cobrado menos pagado.'}">${gananciaReal<0?'de tu bolsillo · ':''}cobrado \u2212 pagado${ahorroCuotaAdmin>0?' + tu parte':''}</div>
      ${ahorroCuotaAdmin>0?`<div class="sp-stat-sub" title="Cobrado menos pagado, sin sumar tu parte: la plata nueva que realmente tienes libre.">en mano: <span class="${cV(gananciaMano)}">${sg(gananciaMano)}</span></div>`:''}
    </div>`;
  } else {
    html+=`<div class="stat">
      <div class="stat-label">Ganancia acumulada</div>
      <div class="stat-value sp-t-muted">\u2014</div>
      <div class="sp-stat-hint">sin cobros aún</div>
    </div>`;
  }

  // Extras recibidos: independientes de Spotify (no entran a cobrado, ni a la ganancia,
  // ni al promedio). Solo aparece si alguna vez te dieron de más.
  if(extrasTotal>0){
    html+=`<div class="stat sp-span-all">
      <div class="stat-label">Extras recibidos</div>
      <div class="sp-stat-base">
        <div class="stat-value c-blue">+${fmt(extrasTotal)}</div>
        <div class="sp-stat-nota2">${extrasN} vez${extrasN!==1?'es':''} te dieron de más</div>
      </div>
      <div class="sp-stat-hint">aparte de Spotify · no suman a la ganancia ni al promedio · cuentan como ingreso extra</div>
    </div>`;
  }

  // Aviso contextual mientras no haya un ciclo pagado
  if(!hayCiclo&&costo>0){
    html+=`<div class="sp-aviso-final">
      Registra el pago a Spotify cuando lo hagas para ver la ganancia real acumulada.
    </div>`;
  }

  html+=`</div>`;
  el.innerHTML=html;
}
async function deleteSpHistorial(i){
  const h=S.spotify.historial[i];
  if(!h)return;

  // Protección por antigüedad — ver docs/proteccion-antiguedad-movimientos.md.
  // Aplica solo a 'pago' (el pago real a Spotify): un 'cobro' individual sigue
  // borrándose igual que siempre, su alcance ya es pequeño y contenido (solo
  // revierte el proximoPago de un integrante).
  if(h.tipo==='pago'){
    const opsPosteriores=S.spotify.historial.filter((h2,idx2)=>idx2>i&&h2.tipo==='pago').length;
    const nivel=nivelAntiguedadMovimiento(h.fecha,opsPosteriores,'spotify');
    if(nivel==='bloqueado'){
      await avisarMovimientoBloqueado();
      return;
    }
    if(nivel==='viejo'){
      const viaTC=!!h._tcMovId;
      const ok=await confirmarBorrarMovimientoViejo(fuenteLabel(h.fuente),h.monto||0,viaTC?'baja':'sube',viaTC?'deuda':'saldo');
      if(!ok)return;
      // Ya se confirmó con el aviso específico de arriba — no repetir con el genérico de abajo.
      return _borrarSpHistorial(i,h);
    }
  }

  const tienePendienteAlBorrar=h.tipo==='cobro'&&(h.pendiente||0)>0;
  const msgBorrar=tienePendienteAlBorrar
    ?'¿Eliminar este registro del historial? Esta acción no se puede deshacer. Esto revierte la plata movida por este registro (incluyendo abonos de lo pendiente ya recibidos) y cancela la deuda de '+fmt(h.pendiente)+' que quedaba abierta.'
    :'¿Eliminar este registro del historial? Esta acción no se puede deshacer. Esto también revierte la plata movida por este registro'+((h.tipo==='cobro'&&(h.extra||0)>0)?', incluido el extra de '+fmt(h.extra):'')+'.';
  const ok=await dialogo('Eliminar movimiento',msgBorrar,'Eliminar',true);
  if(!ok)return;
  return _borrarSpHistorial(i,h);
}

// Cuerpo real del borrado — separado de deleteSpHistorial() para que tanto el
// camino normal (confirmación genérica) como el de aviso por antigüedad
// (confirmación específica, ver arriba) terminen en el mismo lugar sin
// duplicar la reversión de saldos.
async function _borrarSpHistorial(i,h){
  const _histAntes=medirPatrimonioParaHistorial(); // el historial de patrimonio deja de contar este registro

  if(h.tipo==='cobro'){
    // Si este cobro tuvo pago parcial con deuda pendiente (ver §3 de docs/spotify.md),
    // h.monto incluye tanto el monto original como los abonos de pendienteHistorial ya
    // recibidos — hay que separarlos porque cada abono pudo entrar a una cuenta distinta
    // (mismo criterio que _borrarMesadaPago() en mesada.js).
    const historialPendTotal=(h.pendienteHistorial||[]).reduce((acc,ab)=>acc+(ab.monto||0),0);
    const montoOriginalCobro=Math.max(0,(h.monto||0)-historialPendTotal);
    // Revertir el movimiento secundario: la plata que entró a la(s) cuenta(s) destino al cobrar
    if(h.splits&&h.splits.length){
      h.splits.forEach(s=>{ if(s.fuente)descontarFuente(s.fuente,s.monto||0,_ogSp(h.id,true)); });
    } else if(h.fuente){
      descontarFuente(h.fuente,montoOriginalCobro,_ogSp(h.id,true));
    }
    // Revertir cada abono de lo pendiente por separado (cada uno pudo ir a otra cuenta)
    (h.pendienteHistorial||[]).forEach(ab=>{
      if(ab.destino)descontarFuente(ab.destino,ab.monto||0,_ogSp(h.id,true));
    });
    // Revertir el EXTRA (si dio de más): sale de su cuenta y se quita su movimiento espejo.
    if((h.extra||0)>0&&h.extraFuente){
      descontarFuente(h.extraFuente,h.extra,_ogSp(h.id,true));
      if(h.extraMovId)borrarMovEspejo(h.extraFuente,h.extraMovId);
    }
    // Si este cobro estaba saldando deuda de un ciclo ya cerrado (_pagoIdCierre), devolver
    // esa plata al pendiente congelado de ese pago — si el pago referenciado ya no existe
    // (se borró aparte), no hay nada que restaurar, se queda como estaba.
    if(h._pagoIdCierre&&h.spId){
      const pagoRef=(S.spotify.historial||[]).find(x=>x.id===h._pagoIdCierre&&x.tipo==='pago');
      if(pagoRef){
        if(!pagoRef._pendienteAlCerrar)pagoRef._pendienteAlCerrar={};
        pagoRef._pendienteAlCerrar[h.spId]=(pagoRef._pendienteAlCerrar[h.spId]||0)+(h.monto||0);
      }
    }
    // Si este era el cobro MÁS RECIENTE de la persona, su "Pagó" queda sin respaldo → vuelve a Pendiente.
    // Si no es el más reciente (la persona pagó 2+ veces este ciclo y se borra uno viejo), no se toca
    // el estado, porque el cobro más nuevo sigue respaldando el "Pagó".
    const p=(S.spotify.personas||[]).find(x=>h.spId?x.id===h.spId:x.nombre===h.nombre);
    if(p){
      const mismaPersona=(h2)=>h.spId?h2.spId===h.spId:h2.nombre===h.nombre;
      const esElMasReciente=!S.spotify.historial.some((h2,idx2)=>idx2>i&&h2.tipo==='cobro'&&mismaPersona(h2));
      if(esElMasReciente){
        p.pagado=false;
        // Si ya no queda ningún "hermano" del mismo lote (mismos meses adelantados desde la
        // misma fecha previa), es seguro devolver la fecha de próximo pago a como estaba antes.
        if(h.proximoPagoAntes!==undefined){
          const quedaHermano=S.spotify.historial.some((h2,idx2)=>idx2!==i&&h2.tipo==='cobro'&&mismaPersona(h2)&&h2.proximoPagoAntes===h.proximoPagoAntes);
          if(!quedaHermano)p.proximoPago=h.proximoPagoAntes;
        }
      }
    }
  } else if(h.tipo==='pago'){
    // Revertir el movimiento secundario: la plata que salió de la cuenta al pagar Spotify,
    // o el cargo hecho a la tarjeta de crédito si se pagó con TC (ver confirmarPagarSpotify).
    if(h._tcMovId){
      const mov=(S.tcMovimientos||[]).find(m=>m.id===h._tcMovId&&!m.eliminado);
      if(mov){
        // mov.eliminado se marca siempre (es solo un dato) aunque la carga de
        // tarjetas_credito.js falle o tarde — así el estado no queda a medias.
        // Solo tcRecalcular() (una función real del módulo) espera la carga.
        mov.eliminado=true;
        if(await _spEnsureTC()){
          const tc=getTCById(mov.tcId);
          if(tc)tcRecalcular(tc);
        }
      }
    } else if(h.splits&&h.splits.length){
      h.splits.forEach(s=>{ if(s.fuente)sumarFuente(s.fuente,s.monto||0,_ogSp(h.id,true)); });
    } else if(h.fuente){
      sumarFuente(h.fuente,h.monto||0,_ogSp(h.id,true));
    }
    // Eliminar el gasto variable que se generó junto con este pago
    if(h._gastoVarId&&S.gastosVar){
      S.gastosVar=S.gastosVar.filter(g=>g.id!==h._gastoVarId);
    }
    // Este pago reseteó "pagado" a false para el ciclo — devolver a cada persona
    // exactamente el estado que tenía justo antes de ese reseteo masivo, en vez de
    // dejar a todo el mundo en "Pendiente" sin forma de deshacerlo.
    if(h._estadoAntes&&Array.isArray(h._estadoAntes)){
      h._estadoAntes.forEach(snap=>{
        const per=(S.spotify.personas||[]).find(x=>x.id===snap.id);
        if(per)per.pagado=snap.pagado;
      });
    }
  }

  S.spotify.historial.splice(i,1);
  purgarEfectoEnHistorial(_histAntes,h);
  save();refresh();
  toast('Movimiento eliminado y plata revertida','ok');
}

// Deshace un abono puntual de lo pendiente (equivalente a deshacerPendienteMesada
// en mesada.js) sin tocar el resto del cobro: revierte solo la plata de ESE abono,
// se lo quita a pendienteHistorial, y devuelve ese monto de h.monto a h.pendiente.
// Distinto de deleteSpHistorial/_borrarSpHistorial, que borran el cobro completo
// (con todos sus abonos) de una sola vez.
async function deshacerAbonoPendienteSp(i,abIdx){
  const h=S.spotify.historial[i];
  if(!h||!h.pendienteHistorial)return;
  const ab=h.pendienteHistorial[abIdx];
  if(!ab)return;
  const ok=await dialogo('Deshacer abono',`¿Deshacer este abono de ${fmt(ab.monto)}? Esta acción no se puede deshacer. Esto revierte esa plata de ${ab.destino?fuenteLabel(ab.destino):'la cuenta elegida'} y vuelve a marcar esa parte como pendiente.`,'Deshacer',true);
  if(!ok)return;
  if(ab.destino)descontarFuente(ab.destino,ab.monto||0,_ogSp(h.id,true));
  h.monto=Math.max(0,(h.monto||0)-(ab.monto||0));
  h.pendiente=(h.pendiente||0)+(ab.monto||0);
  h.pendienteHistorial.splice(abIdx,1);
  save();refresh();
  toast('Abono deshecho — vuelve a quedar pendiente '+fmt(h.pendiente),'ok',3000);
}

function marcarPagoSpotify(i){
  const p=S.spotify.personas[i];
  if(spPersonaPagadaVigente(p)){
    // Ya pagó (y sigue vigente) → esto es solo una corrección manual del badge.
    // NO revierte ningún cobro ni movimiento de plata: si quieres revertir el dinero
    // cobrado, elimina el movimiento correspondiente en el Historial de pagos.
    p.pagado=false;
    save();renderSpotify();
    return;
  }
  // Cobrar → abrir sheet con períodos adelantados + destino
  spDestinoIdx=i;
  spDestinoPago=p.monto||0;
  spDestinoNombre=spNombreDe(p);
  // Desc
  document.getElementById('spDestinoDesc').textContent=`${spNombreDe(p)} — ${fmt(p.monto)}/período`;
  // Meses: select con 1 mes predeterminado
  const mesesSel=document.getElementById('spMesesSelect');
  mesesSel.value='1';
  document.getElementById('spMesesTotal').textContent='Total a cobrar: '+fmt(p.monto*1);
  // Monto realmente recibido — editable, prellenado con el total esperado.
  // Si se reduce por debajo de lo esperado, aparece el toggle "quedó debiendo".
  const montoRecInp=document.getElementById('spMontoRecibido');
  if(montoRecInp)montoRecInp.value=fmtInput(p.monto*1);
  const chkDebeSp=document.getElementById('spQuedaDebiendo');
  if(chkDebeSp)chkDebeSp.checked=false;
  const debeWrapSp=document.getElementById('spDebeWrap');
  if(debeWrapSp)debeWrapSp.style.display='none';
  const extraWrapSp=document.getElementById('spExtraWrap');
  if(extraWrapSp)extraWrapSp.style.display='none';
  const extraSelSp=document.getElementById('spExtraDestino');
  if(extraSelSp){extraSelSp.innerHTML='';delete extraSelSp.dataset.modo;}
  // Resetear split (mismo patrón que abrirRegistrarMesada en mesada.js)
  spcSplitMode=false;
  document.getElementById('spCobModoSimple').style.display='';
  document.getElementById('spCobModoDividido').style.display='none';
  document.getElementById('spCobSplitRows').innerHTML='';
  const spCobToggleBtn=document.getElementById('spCobSplitToggle');
  if(spCobToggleBtn){
    spCobToggleBtn.textContent='Dividir';
    spCobToggleBtn.style.background='rgba(200,240,96,.1)';
    spCobToggleBtn.style.borderColor='rgba(200,240,96,.3)';
    spCobToggleBtn.style.color='var(--accent)';
  }
  document.getElementById('spCobPreview').textContent='';
  // Fuentes: select, forzando una elección explícita (incluida "Sin especificar")
  // No se puede guardar plata ajena en una TC (mismo criterio que Encargos, "Yo debo",
  // Mis deudas y Alcancía) — por eso getFuentesSinTC() y no getFuentes().
  const fuentes=getFuentesSinTC();
  const destSel=document.getElementById('spDestinoSelect');
  // Migrado a html`` (js/core/html-tag.js, ver auditoria-tecnica.md, punto 2).
  destSel.innerHTML=html`<option value="" disabled selected>Selecciona una opción...</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}<option value="__sin_especificar__">Sin especificar (no mover)</option>`;
  // Editable para poder anotar un cobro días después sin que quede fechado hoy
  // por error (ver docs/spotify.md §7ter — el ciclo se decide por la fecha real).
  const fechaEl=document.getElementById('spFecha');
  if(fechaEl)fechaEl.value=hoy();
  const spNotaEl=document.getElementById('spNota');
  if(spNotaEl)spNotaEl.value='';
  openSheet('sp-destino');
}

function selSpMeses(){
  const n=parseInt(document.getElementById('spMesesSelect').value)||1;
  const monto=(S.spotify.personas[spDestinoIdx]?.monto||0)*n;
  document.getElementById('spMesesTotal').textContent='Total a cobrar: '+fmt(monto);
  // Cambiar la cantidad de períodos redefine "lo esperado" — resetea el monto
  // recibido a ese nuevo total (el usuario puede volver a editarlo si pagó de menos).
  const montoRecInp=document.getElementById('spMontoRecibido');
  if(montoRecInp)montoRecInp.value=fmtInput(monto);
  actualizarSpDestinoPreview();
}

// Muestra/oculta el toggle "quedó debiendo la diferencia" según el monto
// recibido ingresado vs. lo esperado para los períodos elegidos — mismo
// patrón que _syncMpDebeWrap() en mesada.js.
function _syncSpDebeWrap(){
  const wrap=document.getElementById('spDebeWrap');
  const chk=document.getElementById('spQuedaDebiendo');
  const lbl=document.getElementById('spDebeLabel');
  if(!wrap||!chk||spDestinoIdx===null)return;
  const p=S.spotify.personas[spDestinoIdx];
  const n=parseInt(document.getElementById('spMesesSelect').value)||1;
  const montoEsperado=(p?.monto||0)*n;
  const v=parseMoney(document.getElementById('spMontoRecibido').value)||0;
  const diff=montoEsperado-v;
  if(v>0&&diff>0){
    wrap.style.display='flex';
    if(lbl)lbl.textContent='Te está debiendo '+fmt(diff)+' — ¿marcar como pendiente?';
  } else {
    wrap.style.display='none';
    chk.checked=false;
  }
}

// Opciones del destino del EXTRA (plata de más que dio la persona). En modo simple
// se ofrece "Misma cuenta del cobro" como opción visible (no se asume en silencio);
// en modo dividido no existe "la misma cuenta", así que hay que elegir una.
// Como todo destino donde ENTRA plata: sin TC, sin filtro por saldo.
function _spExtraOpts(esSplit){
  const fuentes=getFuentesSinTC();
  const primera=esSplit
    ?'<option value="" disabled selected>Selecciona una opción...</option>'
    :'<option value="__mismo__" selected>Misma cuenta del cobro</option>';
  return html`${raw(primera)}${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}<option value="__sin_especificar__">Sin especificar (no mover)</option>`;
}

// Muestra/oculta el bloque "te dio un extra" según lo recibido vs. lo esperado.
// El extra = recibido − (períodos × cuota). Nunca es parte del cobro de Spotify.
function _syncSpExtraWrap(){
  const wrap=document.getElementById('spExtraWrap');
  const sel=document.getElementById('spExtraDestino');
  const lbl=document.getElementById('spExtraLabel');
  if(!wrap||!sel||spDestinoIdx===null)return;
  const p=S.spotify.personas[spDestinoIdx];
  const n=parseInt(document.getElementById('spMesesSelect').value)||1;
  const montoEsperado=(p?.monto||0)*n;
  const v=parseMoney(document.getElementById('spMontoRecibido').value)||0;
  const extra=v-montoEsperado;
  if(extra>1){
    wrap.style.display='block';
    if(lbl)lbl.textContent='Te dio un extra de +'+fmt(extra);
    const modo=spcSplitMode?'split':'simple';
    // Solo se reconstruyen las opciones si cambió el modo (o si está vacío), para no
    // pisar la cuenta que el usuario ya eligió mientras sigue escribiendo el monto.
    if(sel.dataset.modo!==modo||!sel.options.length){
      const previo=sel.value;
      sel.innerHTML=_spExtraOpts(spcSplitMode);
      sel.dataset.modo=modo;
      if(previo&&Array.from(sel.options).some(o=>o.value===previo))sel.value=previo;
    }
  } else {
    wrap.style.display='none';
    sel.innerHTML='';
    delete sel.dataset.modo;
  }
}

// Preview del split de cobro — mismo estilo que actualizarMpPreview() en
// mesada.js. En modo simple no hay nada que mostrar acá (spMesesTotal ya
// cubre el total); solo pinta cuando spcSplitMode está activo. Siempre
// sincroniza el toggle de "quedó debiendo", independientemente del modo.
function actualizarSpDestinoPreview(){
  _syncSpDebeWrap();
  _syncSpExtraWrap();
  const prev=document.getElementById('spCobPreview');
  if(!prev)return;
  if(!spcSplitMode){prev.textContent='';return;}
  // El split reparte lo REALMENTE recibido, no lo esperado — si la persona pagó
  // de menos, es esa plata (ya menor) la que hay que repartir entre cuentas.
  const n=parseInt(document.getElementById('spMesesSelect').value)||1;
  const montoEsperadoSplit=(S.spotify.personas[spDestinoIdx]?.monto||0)*n;
  const montoRecInp=parseMoney(document.getElementById('spMontoRecibido').value);
  const recibidoSplit=(montoRecInp||montoRecInp===0)?montoRecInp:montoEsperadoSplit;
  // Si dio de más, el extra tiene su propio destino: el split reparte solo la cuota.
  const monto=Math.min(recibidoSplit,montoEsperadoSplit);
  const splits=_sp_spc.data();
  const totalSplit=splits.reduce((a,s)=>a+s.monto,0);
  const restante=monto-totalSplit;
  if(splits.length===0){prev.textContent=fmt(monto)+' por distribuir';prev.style.color='var(--text2)';return;}
  const lines=splits.map(s=>fuenteLabel(s.fuente||'')+': +'+fmt(s.monto)).join(' · ');
  if(restante>0){prev.textContent=lines+' · Sin asignar: '+fmt(restante);prev.style.color='var(--amber)';}
  else if(restante<0){prev.textContent=lines+' · Excede por: '+fmt(-restante);prev.style.color='var(--red)';}
  else{prev.textContent=lines+' · Todo distribuido';prev.style.color='var(--accent)';}
}

function confirmarSpDestino(){
  if(spDestinoIdx===null)return;
  const p=S.spotify.personas[spDestinoIdx];
  const meses=parseInt(document.getElementById('spMesesSelect').value)||1;
  const montoEsperado=(p.monto||0)*meses;

  // Monto REALMENTE recibido — editable (campo spMontoRecibido), prellenado
  // con montoEsperado. Si quedó vacío o inválido, se asume el total esperado
  // (mismo comportamiento de siempre, para no romper el flujo si el campo
  // no se tocó).
  const montoRecInp=parseMoney(document.getElementById('spMontoRecibido').value);
  const montoTotal=(montoRecInp||montoRecInp===0)?montoRecInp:montoEsperado;
  if(montoTotal<=0){
    toast('Ingresa cuánto te pagó','err');
    return;
  }
  // Pagar DE MÁS ya no se rechaza: lo que exceda (períodos × cuota) es un EXTRA.
  // El cobro de Spotify queda en la cuota exacta (así ganancia, promedio y
  // "Recaudado" no se inflan) y el extra se registra aparte, como ingreso extra,
  // en la cuenta que se elija. Ver docs/spotify.md §7quater.
  const extraSp=montoTotal>montoEsperado+1?Math.round((montoTotal-montoEsperado)*100)/100:0;
  const cuotaRecibida=extraSp>0?montoEsperado:montoTotal;
  // "Quedó debiendo la diferencia": solo aplica si el usuario marcó el toggle
  // explícitamente. Si no lo marca, un monto menor al esperado se registra
  // tal cual, sin deuda — el período de todas formas se cuenta como cubierto.
  const chkDebeSp=document.getElementById('spQuedaDebiendo');
  const quedaDebiendoSp=!!(chkDebeSp&&chkDebeSp.checked);
  const diferenciaSp=quedaDebiendoSp?Math.max(0,montoEsperado-montoTotal):0;

  // ── Modo dividido: validar y aplicar el split ANTES de tocar nada más ──
  let splits=null;
  let spDestinoSel='';
  if(spcSplitMode){
    splits=_sp_spc.data();
    const totalSplit=splits.reduce((a,s)=>a+s.monto,0);
    if(splits.length===0||totalSplit<=0){
      document.getElementById('spCobPreview').textContent='Asigna el cobro a al menos una cuenta';
      document.getElementById('spCobPreview').style.color='var(--red)';
      return;
    }
    if(totalSplit>cuotaRecibida+1){
      document.getElementById('spCobPreview').textContent=extraSp>0?'El total dividido supera la cuota (el extra va aparte)':'El total dividido supera lo cobrado';
      document.getElementById('spCobPreview').style.color='var(--red)';
      return;
    }
  } else {
    const destVal=document.getElementById('spDestinoSelect').value;
    if(!destVal){
      toast('Selecciona a dónde metiste la plata (o marca "Sin especificar")','err');
      return;
    }
    spDestinoSel=destVal==='__sin_especificar__'?'':destVal;
  }

  // Destino del extra: explícito, igual que el del cobro (nunca se asume en silencio).
  // Se valida acá, antes de tocar ningún saldo ni el historial.
  let extraFuenteSp='';
  if(extraSp>0){
    const exVal=document.getElementById('spExtraDestino')?.value||'';
    if(!exVal){
      toast('Selecciona a dónde fue el extra (o marca "Sin especificar")','err');
      return;
    }
    extraFuenteSp=exVal==='__mismo__'?spDestinoSel:(exVal==='__sin_especificar__'?'':exVal);
  }

  const fechaEl=document.getElementById('spFecha');
  const fechaCobro=(fechaEl&&fechaEl.value)?fechaEl.value:hoy();
  const notaUsuario=document.getElementById('spNota')?.value.trim()||'';
  const nombreActual=spNombreDe(p);
  const proximoPagoAntes=p.proximoPago||'';
  p.pagado=true;
  p.mesesAdelantados=meses;
  p.ultimoDestino=spDestinoSel||'';
  p.ultimoDestinoSplit=!!splits;
  // Sumar dinero a la(s) fuente(s). `_cobroRef` es el id del PRIMER registro de historial que nace de este cobro (el de
  // cierre de deuda vieja si lo hay; si no, el cobro normal): así el libro apunta a un registro que existe.
  const _cobroRef=uid();
  if(splits){
    splits.forEach(s=>{ if(s.fuente)sumarFuente(s.fuente,s.monto,_ogSp(_cobroRef)); });
  } else if(spDestinoSel){
    sumarFuente(spDestinoSel,cuotaRecibida,_ogSp(_cobroRef));
  }
  // Avanzar fecha de cobro N meses pero respetando el día original fijo
  if(p.proximoPago)p.proximoPago=nextMonthFixed(p.proximoPago,meses);
  if(!S.spotify.historial)S.spotify.historial=[];
  const notaPeriodos=meses>1?`${meses} períodos × ${fmt(p.monto||0)} (pago adelantado)`:'';
  const notaBase=[notaUsuario,notaPeriodos].filter(Boolean).join(' · ');

  // Si el último pago a Spotify cerró un ciclo donde esta persona quedó debiendo algo
  // (_pendienteAlCerrar, congelado en confirmarPagarSpotify), este cobro salda primero
  // esa deuda vieja — se registra como un movimiento aparte atribuido a ESE ciclo
  // cerrado, no al ciclo actual, sin importar que hoy ya vayamos en uno nuevo. Solo lo
  // que sobre después de saldarla cuenta como plata del ciclo en curso. Así una persona
  // puede pagar atrasado después de que yo ya le pagué a Spotify (porque confío en que
  // me va a pagar) sin que esa plata infle "Recaudado" del ciclo nuevo ni le reste
  // ganancia al ciclo que ya cerré. Ver docs/spotify.md §7ter.
  let lastPago=null;
  for(let i=S.spotify.historial.length-1;i>=0;i--){ if(S.spotify.historial[i].tipo==='pago'){lastPago=S.spotify.historial[i];break;} }
  let restante=cuotaRecibida;
  let periodosCierre=0;
  if(lastPago&&lastPago._pendienteAlCerrar&&lastPago._pendienteAlCerrar[p.id]>0){
    const pendienteViejo=lastPago._pendienteAlCerrar[p.id];
    const cierreMonto=Math.min(restante,pendienteViejo);
    lastPago._pendienteAlCerrar[p.id]=pendienteViejo-cierreMonto;
    if(lastPago._pendienteAlCerrar[p.id]<=0)delete lastPago._pendienteAlCerrar[p.id];
    S.spotify.historial.push({id:_cobroRef,spId:p.id,tipo:'cobro',nombre:nombreActual,monto:cierreMonto,periodos:meses,fuente:spDestinoSel||'',splits:_spProporcionarSplits(splits,cierreMonto,cuotaRecibida)||undefined,fecha:fechaCobro,nota:'Pago atrasado del ciclo anterior'+(notaBase?' · '+notaBase:''),proximoPagoAntes,_pagoIdCierre:lastPago.id,_secundario:true,_origenSeccion:'Spotify'});
    restante-=cierreMonto;
    // Períodos del pago que ya cubrió el registro de cierre: el registro "resto" arranca
    // después de ellos (ver spTramosDeCobro / _periodoOffset).
    periodosCierre=Math.min(meses,Math.max(1,Math.round(cierreMonto/(p.monto||cierreMonto))));
  }
  // Registrar en historial el resto (o el total, si no había deuda vieja) como UN solo
  // registro — aunque cubra varios períodos, es una sola plata que entró en un solo
  // movimiento a la cuenta. El detalle de cuántos períodos y a cómo cada uno queda en
  // la nota. Se guarda el nombre ACTUAL de la persona vinculada, no el crudo, para que
  // no quede fijado desactualizado.
  if(restante>0||diferenciaSp>0){
    const nuevoCobro={id:periodosCierre>0?uid():_cobroRef,spId:p.id,tipo:'cobro',nombre:nombreActual,monto:restante,periodos:meses,fuente:spDestinoSel||'',splits:_spProporcionarSplits(splits,restante,cuotaRecibida)||undefined,fecha:fechaCobro,nota:notaBase,proximoPagoAntes,_secundario:true,_origenSeccion:'Spotify'};
    if(periodosCierre>0)nuevoCobro._periodoOffset=periodosCierre;
    if(diferenciaSp>0){
      nuevoCobro.cuotaEsperada=montoEsperado;
      nuevoCobro.pendiente=diferenciaSp;
      nuevoCobro.pendienteHistorial=[];
    }
    S.spotify.historial.push(nuevoCobro);
  }
  // Extra: queda colgado del ÚLTIMO registro que acaba de nacer de este cobro (si hubo
  // "pago atrasado" son dos registros; el extra no pertenece a ningún período). La plata
  // entra a la cuenta elegida y deja un movimiento espejo visible en su historial,
  // marcado como ingreso extra (_esExtraIngreso) y protegido contra borrado directo.
  if(extraSp>0){
    const ultimoReg=S.spotify.historial[S.spotify.historial.length-1];
    if(ultimoReg){
      ultimoReg.extra=extraSp;
      if(extraFuenteSp){
        sumarFuente(extraFuenteSp,extraSp,_ogSp(ultimoReg.id));
        ultimoReg.extraFuente=extraFuenteSp;
        const movId=registrarMovEspejo({cuenta:extraFuenteSp,flujo:'entrada',monto:extraSp,fecha:fechaCobro,desc:'Extra de Spotify · '+nombreActual,origen:'Spotify',clase:'ingreso',extra:{_esExtraIngreso:true}});
        if(movId)ultimoReg.extraMovId=movId;
      }
    }
  }
  spDestinoIdx=null;
  spcSplitMode=false;
  save();refresh();closeSheet('sp-destino');
  if(diferenciaSp>0){
    toast(`Cobro registrado · ${escHtml(nombreActual)} quedó debiendo ${fmt(diferenciaSp)}`,'ok',3500);
  } else {
    const sufijoExtra=extraSp>0?` · extra +${fmt(extraSp)}`:'';
    toast((meses>1?`Cobrados ${meses} períodos adelantados a ${escHtml(nombreActual)} · ${fmt(cuotaRecibida)}`:`Cobro registrado · ${escHtml(nombreActual)}`)+sufijoExtra,'ok');
  }
}

// ── Registrar pago de lo pendiente de un cobro puntual ──────────────────────
// Mismo patrón que abrirResolverPendiente()/confirmarPendienteMesada() en
// mesada.js, pero aplicado a un registro de spotifyHistorial en vez de a un
// mes calendario. `i` es el índice REAL en S.spotify.historial (h._realIdx).
function resolverPendienteSpHistorial(i){
  const h=S.spotify.historial[i];
  if(!h||!(h.pendiente>0))return;
  spResolverIdx=i;
  document.getElementById('spResTitle').textContent='Pendiente de '+escHtml(h.nombre);
  document.getElementById('spResDesc').textContent='Te debía '+fmt(h.pendiente)+'. ¿Cuánto te dio ahora?';
  document.getElementById('spResMonto').value=fmtInput(h.pendiente);
  document.getElementById('spResFecha').value=hoy();
  document.getElementById('spResNota').value='';
  const fuentes=getFuentesSinTC();
  const destSel=document.getElementById('spResDestino');
  // Migrado a html`` (js/core/html-tag.js, ver auditoria-tecnica.md, punto 2).
  destSel.innerHTML=html`<option value="">No especificar / lo gasté</option>${fuentes.map(f=>html`<option value="${f.val}">${f.label}</option>`)}`;
  actualizarSpResolverPreview();
  openSheet('sp-hist-pend');
}

function actualizarSpResolverPreview(){
  const prev=document.getElementById('spResPreview');
  if(!prev||spResolverIdx===null)return;
  const h=S.spotify.historial[spResolverIdx];
  const v=parseMoney(document.getElementById('spResMonto').value)||0;
  if(!h||!v){prev.textContent='';return;}
  if(v>h.pendiente+1){
    prev.textContent='Eso es más de lo que quedó pendiente ('+fmt(h.pendiente)+')';
    prev.style.color='var(--red)';
    return;
  }
  const restante=h.pendiente-v;
  prev.textContent=restante>0?('Quedaría debiendo '+fmt(restante)+' más'):'Con esto queda saldado';
  prev.style.color=restante>0?'var(--amber)':'var(--accent)';
}

function confirmarSpResolverPendiente(){
  if(spResolverIdx===null)return;
  const h=S.spotify.historial[spResolverIdx];
  if(!h||!(h.pendiente>0))return;
  let monto=parseMoney(document.getElementById('spResMonto').value)||0;
  if(monto<=0)return;
  if(monto>h.pendiente)monto=h.pendiente; // no se puede saldar más de lo que quedó pendiente
  const fecha=document.getElementById('spResFecha').value||hoy();
  const nota=document.getElementById('spResNota').value.trim();
  const destino=document.getElementById('spResDestino').value;
  if(destino)sumarFuente(destino,monto,_ogSp(h.id));
  if(!h.pendienteHistorial)h.pendienteHistorial=[];
  // id + _secundario/_origenSeccion: mismo criterio que cualquier otro registro
  // de spotifyHistorial (ver §3 de docs/spotify.md) — permite que cuentas.js
  // sintetice una tarjeta propia por abono (ver getMovimientosCuenta) y que
  // eliminarMovimiento() (movimientos.js) lo bloquee contra borrado directo
  // igual que el cobro original, redirigiendo a Spotify.
  h.pendienteHistorial.push({id:uid(),monto,fecha,destino,nota,_secundario:true,_origenSeccion:'Spotify'});
  h.pendiente=Math.max(0,h.pendiente-monto);
  h.monto=(h.monto||0)+monto;
  spResolverIdx=null;
  save();refresh();
  closeSheet('sp-hist-pend');
  toast(h.pendiente>0?('Abono registrado — todavía debe '+fmt(h.pendiente)):'¡Pendiente saldado!','ok',3000);
}

// FIX (auditoria-tecnica.md — acoplamiento spotify↔tarjetas_credito): las 3
// llamadas a getTCById/tcCupoDisponible/tcRecalcular de este archivo asumían
// que tarjetas_credito.js ya estaba cargado porque hasta ahora cargaba eager.
// Este helper asegura la carga bajo demanda con Loader.ensure('tarjetas')
// antes de usarlas — funciona igual si tarjetas_credito.js sigue cargando
// eager (typeof ya es 'function', Loader.ensure ni se llama) que si en el
// futuro se vuelve un grupo lazy real. Si la descarga falla (sin conexión),
// avisa con un toast en vez de dejar la acción muda.
async function _spEnsureTC(){
  if(typeof getTCById==='function') return true;
  try{
    await Loader.ensure('tarjetas');
    return true;
  }catch(err){
    toast('No se pudo cargar Tarjetas de Crédito. Revisa tu conexión e intenta de nuevo.','err',4000);
    return false;
  }
}

function openSheet_pagarSpotify(){
  const costo=S.spotify.costo||0;
  // Resetear split (mismo patrón que abrirRegistrarMesada en mesada.js)
  sppSplitMode=false;
  document.getElementById('spPagarModoSimple').style.display='';
  document.getElementById('spPagarModoDividido').style.display='none';
  document.getElementById('spPagarSplitRows').innerHTML='';
  const sppToggleBtn=document.getElementById('spPagarSplitToggle');
  if(sppToggleBtn){
    sppToggleBtn.textContent='Dividir';
    sppToggleBtn.style.background='rgba(200,240,96,.1)';
    sppToggleBtn.style.borderColor='rgba(200,240,96,.3)';
    sppToggleBtn.style.color='var(--accent)';
  }
  // Pre-llenar con el costo
  document.getElementById('spPagarMonto').value=costo?fmtInput(costo):'';
  // Poblar fuentes
  const cajita=getSpCajita();
  const sel=document.getElementById('spPagarFuente');
  // Solo cuentas con saldo >= $50 y TC con cupo disponible (FuentesFiltro.PRESET.SPOTIFY,
  // js/core/fuentes-filtro.js). Si la cajita de Spotify no llega al mínimo, no se preselecciona.
  sel.innerHTML=FuentesFiltro.optsHtml(getFuentes(),{...FuentesFiltro.PRESET.SPOTIFY,selectedVal:cajita?'cajita:'+cajita.id:''});
  actualizarSpPagarPreview();
  const notaEl=document.getElementById('spPagarNota');
  if(notaEl)notaEl.value='';
  // Editable para poder registrar tarde un pago que en la realidad ya ocurrió antes
  // (ver docs/spotify.md §7ter — el ciclo se decide por la fecha real, no por el orden
  // en que se anotó).
  const fechaPagoEl=document.getElementById('spPagarFecha');
  if(fechaPagoEl)fechaPagoEl.value=hoy();
}

async function actualizarSpPagarPreview(){
  const prev=document.getElementById('spPagarPreview');
  const fuenteInfo=document.getElementById('spPagarFuenteSaldo');
  // Modo dividido: el desglose de saldo por TC no aplica (no hay TC en split,
  // ver comentario junto a spcSplitMode/sppSplitMode más arriba).
  if(sppSplitMode){
    fuenteInfo.textContent='';
    const monto=parseMoney(document.getElementById('spPagarMonto').value)||0;
    const splits=_sp_spp.data();
    if(!monto){prev.textContent='';return;}
    const totalSplit=splits.reduce((a,s)=>a+s.monto,0);
    const restante=monto-totalSplit;
    if(splits.length===0){prev.textContent=fmt(monto)+' por repartir entre cuentas';prev.style.color='var(--text2)';return;}
    const lines=splits.map(s=>fuenteLabel(s.fuente||'')+': \u2212'+fmt(s.monto)).join(' · ');
    if(restante>0){prev.textContent=lines+' · Sin asignar: '+fmt(restante);prev.style.color='var(--amber)';}
    else if(restante<0){prev.textContent=lines+' · Excede por: '+fmt(-restante);prev.style.color='var(--red)';}
    else{prev.textContent=lines+' · Todo repartido';prev.style.color='var(--accent)';}
    return;
  }
  const monto=parseMoney(document.getElementById('spPagarMonto').value)||0;
  const fuente=document.getElementById('spPagarFuente').value;
  // Pagar con tarjeta de crédito es un CARGO (sube la deuda de la tarjeta), no un
  // retiro de saldo de una cuenta/cajita — por eso se muestra aparte, igual que en
  // ptcActualizarPreview() (tarjetas_credito.js) para el flujo inverso de "Pagar TC".
  if(fuente&&fuente.startsWith('tc:')){
    if(!(await _spEnsureTC())){ fuenteInfo.textContent=''; prev.textContent=''; return; }
    const tc=getTCById(fuente.slice(3));
    if(tc){
      const cupoDisp=tc.cupo?tcCupoDisponible(tc):null;
      fuenteInfo.textContent=cupoDisp!==null?'Cupo disponible: '+fmt(cupoDisp):'';
      if(monto>0){
        const nuevaDeuda=(tc.deuda||0)+monto;
        prev.innerHTML='Deuda: '+fmt(tc.deuda||0)+' <i class="fa-solid fa-arrow-right cuenta-flecha"></i> '+fmt(nuevaDeuda);
        prev.style.color=(cupoDisp!==null&&monto>cupoDisp)?'var(--red)':'var(--accent)';
      } else {
        prev.textContent='';
      }
    } else {
      fuenteInfo.textContent='';prev.textContent='';
    }
  } else if(fuente){
    const actual=getSaldoFuente(fuente);
    if(monto>0){
      // El cálculo de abajo ya incluye el saldo actual como primer término
      // ($actual − $monto = $resultado) — mostrar además "Saldo disponible: $actual"
      // aquí arriba repite el mismo número sin agregar nada. Se muestra esta
      // línea solo cuando todavía no hay cálculo que mostrar (monto vacío).
      fuenteInfo.textContent='';
      const resultado=actual-monto;
      prev.textContent=fmt(actual)+' − '+fmt(monto)+' = '+fmt(resultado);
      prev.style.color=resultado<0?'var(--red)':'var(--accent)';
    } else{
      fuenteInfo.textContent='Saldo disponible: '+fmt(actual);
      prev.textContent='';
    }
  } else {
    fuenteInfo.textContent='';prev.textContent='';
  }
}

async function confirmarPagarSpotify(){
  const _pagoRef=uid(); // id del gasto de este pago: lo usan el libro y, más abajo, S.gastosVar
  const monto=parseMoney(document.getElementById('spPagarMonto').value)||0;
  const nota=document.getElementById('spPagarNota')?document.getElementById('spPagarNota').value.trim():'';
  if(!monto){toast('Ingresa el monto a pagar','err');return;}
  const fechaPagoEl0=document.getElementById('spPagarFecha');
  const fechaPago0=(fechaPagoEl0&&fechaPagoEl0.value)?fechaPagoEl0.value:hoy();
  let tcMovId=null;
  let fuente='';
  let splits=null;
  let notaGasto=nota||'Pago mensual Spotify';

  if(sppSplitMode){
    // Modo dividido: sin TC (ver comentario junto a spcSplitMode/sppSplitMode
    // más arriba) — todo o nada, valida saldo en CADA cuenta antes de
    // descontar de cualquiera, para no dejar el pago a medias si una falla.
    splits=_sp_spp.data();
    const totalSplit=splits.reduce((a,s)=>a+s.monto,0);
    if(splits.length===0||Math.abs(totalSplit-monto)>1){
      const prev=document.getElementById('spPagarPreview');
      prev.textContent=totalSplit<monto?'Falta asignar '+fmt(monto-totalSplit)+' a alguna cuenta':'El total dividido supera el monto a pagar';
      prev.style.color='var(--red)';
      return;
    }
    for(const s of splits){
      const v=validarSalidaFuente(s.fuente,s.monto); // core-state.js: saldo/cupo, mensaje ya escapado
      if(!v.ok){toast(v.mensaje,'err',3500);return;}
    }
    splits.forEach(s=>descontarFuente(s.fuente,s.monto,_ogSp(_pagoRef)));
    notaGasto+=' · dividido entre '+splits.map(s=>fuenteLabel(s.fuente)).join(', ');
  } else {
    fuente=document.getElementById('spPagarFuente').value;
    if(fuente&&fuente.startsWith('tc:')){
      if(!(await _spEnsureTC())) return;
      // Pagar con tarjeta de crédito es un CARGO: sube la deuda de la tarjeta, no
      // descuenta el saldo de una cuenta/cajita. Mismo patrón que Encargos/Préstamos
      // (ver tcRecalcular en tarjetas_credito.js, que suma S.tcMovimientos con
      // tipo 'cargo_*'), en vez de descontarFuente().
      const tc=getTCById(fuente.slice(3));
      if(!tc){toast('Tarjeta no encontrada','err');return;}
      const v=validarSalidaFuente(fuente,monto);
      if(!v.ok){toast(v.mensaje,'err',3500);return;}
      if(!S.tcMovimientos)S.tcMovimientos=[];
      tcMovId=uid();
      S.tcMovimientos.push({id:tcMovId,tcId:tc.id,tipo:'cargo_spotify',monto,fecha:fechaPago0,nota:nota||'Pago Spotify',eliminado:false});
      tcRecalcular(tc);
    } else if(fuente){
      const v=validarSalidaFuente(fuente,monto);
      if(!v.ok){toast(v.mensaje,'err',3500);return;}
      descontarFuente(fuente,monto,_ogSp(_pagoRef));
    }
  }
  if(!S.spotify.historial)S.spotify.historial=[];
  // Registrar también como gasto variable para que aparezca en la sección Gastos
  if(!S.gastosVar)S.gastosVar=[];
  const gastoId=_pagoRef;
  // La fecha es la que escribió quien paga («Fecha en que pagaste»), no la de hoy: el balance cuenta el gasto en el mes en que salió la plata.
  S.gastosVar.push({id:gastoId,desc:'Spotify Premium',monto,fecha:fechaPago0,cat:'Suscripciones',fuente,nota:notaGasto,clase:'gasto',_secundario:true,_origenSeccion:'Spotify'});
  // Se guarda la cuota del administrador vigente EN ESTE MOMENTO (según cuántas personas
  // hay ahora), para que si la cantidad de integrantes cambia en el futuro, la ganancia
  // de este ciclo ya pagado no se recalcule con datos de otra época.
  const totalSlotsAhora=(S.spotify.personas||[]).length+1;
  const cuotaAdminAhora=S.spotify.costo>0?Math.round(S.spotify.costo/totalSlotsAhora):0;
  // Foto de quién estaba "Pagó" justo antes de resetear el ciclo: si más adelante se
  // elimina este pago del historial, hay que poder devolver a cada persona a como
  // estaba, no dejar a todos en "Pendiente" sin poder deshacerlo.
  const estadoAntesReset=(S.spotify.personas||[]).map(p=>({id:p.id,pagado:!!p.pagado}));

  const fechaPago=fechaPago0;

  // Este pago puede registrarse DÍAS después de haber ocurrido en la realidad (ej: pagué
  // el 1, pero recién hoy lo anoto). Si mientras tanto ya se registraron cobros que en la
  // fecha real ya eran del ciclo NUEVO (posteriores a fechaPago), no hay que tratarlos
  // como si hubieran cerrado el ciclo viejo — hay que "moverlos" después de este pago en
  // el historial para que spCicloCobrosActual() los cuente donde de verdad corresponden.
  // Ver docs/spotify.md §7ter.
  let lastPagoIdx=-1;
  for(let i=S.spotify.historial.length-1;i>=0;i--){ if(S.spotify.historial[i].tipo==='pago'){lastPagoIdx=i;break;} }
  const antesDelSegmento=S.spotify.historial.slice(0,lastPagoIdx+1);
  const segmentoAbierto=S.spotify.historial.slice(lastPagoIdx+1);

  const quedanCerrando=[];   // de verdad pertenecen al ciclo que se está cerrando ahora
  const pasanANuevo=[];      // ya eran, en la realidad, del ciclo que arranca con este pago
  const cubiertoPorPersona={}; // acumulado ya confirmado como "cerrando", para el desempate del mismo día
  segmentoAbierto.forEach(h=>{
    // Los cobros que ya son cierre de un ciclo aún más viejo (_pagoIdCierre) no se tocan.
    if(h.tipo!=='cobro'||h._pagoIdCierre){ quedanCerrando.push(h); return; }
    if(h.fecha<fechaPago){
      quedanCerrando.push(h);
      if(h.spId)cubiertoPorPersona[h.spId]=(cubiertoPorPersona[h.spId]||0)+spMontoAntesDe(h,fechaPago);
    } else if(h.fecha>fechaPago){
      pasanANuevo.push(h);
    } else {
      // Mismo día que este pago: desempate por deuda, no por hora exacta. Si esa persona
      // ya tenía cubierta su cuota del ciclo que se cierra ANTES de este cobro puntual,
      // este cobro ya era, en la realidad, del ciclo nuevo — aunque comparta fecha.
      const persona=h.spId?(S.spotify.personas||[]).find(x=>x.id===h.spId):null;
      const cuota=persona?(persona.monto||0):0;
      const yaCubierto=h.spId?(cubiertoPorPersona[h.spId]||0):0;
      // Empate: pasa al ciclo nuevo solo si ya tenía SP_EMPATE_PERIODOS o más períodos
      // cubiertos en el que se cierra (antes bastaba con uno).
      if(cuota>0&&yaCubierto>=cuota*SP_EMPATE_PERIODOS){
        pasanANuevo.push(h);
      } else {
        quedanCerrando.push(h);
        if(h.spId)cubiertoPorPersona[h.spId]=yaCubierto+spMontoAntesDe(h,fechaPago);
      }
    }
  });

  // Foto de cuánto le quedó debiendo cada persona al ciclo que se está cerrando (mismo
  // cálculo que "Pendiente por cobrar" en pantalla, pero congelado por persona y calculado
  // solo sobre lo que de verdad quedó en este ciclo tras la separación de arriba). Sirve
  // para que, si alguien paga atrasado DESPUÉS de este pago, ese cobro se le atribuya al
  // ciclo que en realidad estaba saldando — ver confirmarSpDestino() y docs/spotify.md §7ter.
  const pendienteAlCerrar={};
  (S.spotify.personas||[]).forEach(x=>{
    if(spPersonaPagadaVigente(x))return;
    // Se cuenta por PERÍODOS vencidos (via proximoPago), no por dinero total cobrado
    // contra una sola cuota — un ciclo puede durar más de un período de esta persona,
    // y alguien puede pagar el primero y dejar vencer un segundo sin pagarlo dentro del
    // mismo ciclo. Comparar solo "cobrado ≥ una cuota" no detectaba ese segundo período.
    // Si ya tenía SP_EMPATE_PERIODOS o más períodos cubiertos en este ciclo, el período
    // que empieza justo hoy (día del pago) es del ciclo nuevo: no se le cuenta como deuda
    // de este. Con menos, sigue siendo deuda del ciclo que cierra (como siempre).
    const cubiertosCiclo=cubiertoPorPersona[x.id]||0;
    const empateAlNuevo=(x.monto||0)>0&&cubiertosCiclo>=x.monto*SP_EMPATE_PERIODOS;
    const periodosVencidos=spPeriodosVencidos(x,fechaPago,empateAlNuevo);
    const pend=periodosVencidos*(x.monto||0);
    if(pend>0)pendienteAlCerrar[x.id]=pend;
  });

  const pagoObj={id:uid(),tipo:'pago',monto,fuente,splits:splits||undefined,fecha:fechaPago,nota,_gastoVarId:gastoId,_cuotaAdmin:cuotaAdminAhora,_estadoAntes:estadoAntesReset,_pendienteAlCerrar:pendienteAlCerrar,_tcMovId:tcMovId};
  S.spotify.historial=[...antesDelSegmento,...quedanCerrando,pagoObj,...pasanANuevo];
  // Reset pagados del ciclo — pero respeta a quienes ya prepagaron períodos futuros:
  // si su próxima fecha de cobro sigue en el futuro, su "Pagó" sigue vigente y no debe
  // volver a Pendiente solo porque yo ya le pagué a Spotify.
  (S.spotify.personas||[]).forEach(p=>{
    const hoy0=new Date();hoy0.setHours(0,0,0,0);
    const sigueVigente=p.proximoPago&&_fechaSafe(p.proximoPago)>hoy0;
    if(!sigueVigente)p.pagado=false;
  });
  sppSplitMode=false;
  save();refresh();closeSheet('pagar-spotify');
}

function addSpotify(){
  const n=document.getElementById('sp_n').value.trim();
  const m=parseMoney(document.getElementById('sp_m').value)||0;
  if(!n){toast('Ingresa el nombre','err');return;}
  const yaExisteNombre=(S.spotify.personas||[]).some(p=>(p.nombre||'').trim().toLowerCase()===n.toLowerCase());
  if(yaExisteNombre){
    toast(`Ya hay un integrante llamado "${escHtml(n)}". Usa un nombre distinto (agrega un apellido o apodo) para no mezclar sus cobros en el historial.`,'err',4200);
    return;
  }
  const fechaIngresoRaw=document.getElementById('sp_fecha_ingreso').value;
  if(!fechaIngresoRaw){toast('Ingresa la fecha de ingreso','err');return;}
  // proximoPago = fechaIngreso + 30 dias (primer cobro)
  const dIng=_fechaSafe(fechaIngresoRaw);
  dIng.setDate(dIng.getDate()+30);
  const proximoPago=dIng.toISOString().split('T')[0];
  S.spotify.personas.push({id:uid(),nombre:n,monto:m,pagado:false,proximoPago,fechaIngreso:fechaIngresoRaw,ultimoDestino:'',ultimoDestinoSplit:false,mesesAdelantados:1});
  document.getElementById('sp_n').value='';
  document.getElementById('sp_m').value='';
  document.getElementById('sp_fecha_ingreso').value='';
  save();refresh();closeSheet('spotify');
  toast(`${escHtml(n)} agregado · primer cobro el ${proximoPago}`,'ok');
}
async function deleteSpotify(i){
  const p=(S.spotify.personas||[])[i];
  if(!p)return;
  const nombreActual=spNombreDe(p);
  const ok=await dialogo('Eliminar integrante',`¿Eliminar a ${nombreActual} de Spotify? Esta acción no se puede deshacer. Su historial de cobros anteriores se conserva en las estadísticas, pero dejará de aparecer en la lista.`,'Eliminar',true);
  if(!ok)return;
  S.spotify.personas.splice(i,1);
  save();refresh();
  toast(`${escHtml(nombreActual)} eliminado de Spotify`,'ok');
}

let _spEditIdx = null;
function editarSpotify(i) {
  const p = S.spotify.personas[i];
  if (!p) return;
  _spEditIdx = i;
  document.getElementById('sp_edit_n').value = p.nombre || '';
  // Cargar monto
  const mEl = document.getElementById('sp_edit_m');
  if (mEl) { mEl.value = fmtInput(p.monto || 0); mEl.dispatchEvent(new Event('input', {bubbles:true})); }
  document.getElementById('sp_edit_fecha_ingreso').value = p.fechaIngreso || '';
  openSheet('editar-spotify');
}
function guardarEditarSpotify() {
  if (_spEditIdx === null) return;
  const p = S.spotify.personas[_spEditIdx];
  if (!p) return;
  const n = document.getElementById('sp_edit_n').value.trim();
  if (!n) { toast('Ingresa el nombre', 'err'); return; }
  const m = parseMoney(document.getElementById('sp_edit_m').value) || 0;
  const fechaIngresoRaw = document.getElementById('sp_edit_fecha_ingreso').value;
  const fechaAnterior = p.fechaIngreso;
  p.nombre = n;
  p.monto = m;
  if (fechaIngresoRaw) {
    // Recalcular próximo pago SOLO si la fecha de ingreso realmente cambió — si no,
    // se pisaría el avance ya ganado por pagos adelantados o ciclos ya cobrados.
    if (fechaIngresoRaw !== fechaAnterior) {
      if (fechaAnterior && p.proximoPago) {
        // Es una corrección de una fecha de ingreso que ya se venía usando (no la primera
        // vez que se define): desplazar proximoPago por la misma cantidad de días que
        // cambió la fecha de ingreso, para no perder los períodos que ya se pagaron.
        const deltaDias = Math.round((_fechaSafe(fechaIngresoRaw) - _fechaSafe(fechaAnterior)) / 86400000);
        const dProx = _fechaSafe(p.proximoPago);
        dProx.setDate(dProx.getDate() + deltaDias);
        p.proximoPago = dProx.toISOString().split('T')[0];
      } else {
        // No había fecha de ingreso previa: es la primera vez que se calcula, cálculo normal.
        const dIng = _fechaSafe(fechaIngresoRaw);
        dIng.setDate(dIng.getDate() + 30);
        p.proximoPago = dIng.toISOString().split('T')[0];
      }
    }
    p.fechaIngreso = fechaIngresoRaw;
  }
  _spEditIdx = null;
  save(); refresh(); closeSheet('editar-spotify');
  toast(escHtml(n) + ' actualizado', 'ok');
}

/* ── Wiring de controles propios de la pantalla ──────────────────────────
   Movido desde _initEventListeners() (index.html) el 2026-07-26 — ver
   auditoria-tecnica.md, punto 3. No son onclick inline (no hay problema
   de CSP acá), es solo mover el addEventListener directo a su módulo
   dueño en vez de dejarlo mezclado con el de otros ~15 dominios en
   index.html. Todos estos ids ya existen en el DOM estático antes de
   este <script> (verificado contra index.html), así que no hace falta
   esperar a DOMContentLoaded. ── */
const _spBtnAdd = document.getElementById('btn-add-spotify-persona');
if (_spBtnAdd) _spBtnAdd.addEventListener('click', () => openSheet('spotify'));
const _spBtnPagar = document.getElementById('btn-pagar-spotify');
if (_spBtnPagar) _spBtnPagar.addEventListener('click', abrirPagarSpotify);

const _spBtnSave = document.getElementById('btn-guardar-spotify');
// OJO: igual que con Gastos — index.html sobrescribe el global addSpotify
// más abajo (_injectErrorSpans(), le agrega validación inline) DESPUÉS de
// que este módulo se carga. Llamar addSpotify() dentro de una flecha
// resuelve la referencia en vivo al momento del click, no la capturada
// acá. Corregido 2026-07-26, ver auditoria-tecnica.md punto 3.
if (_spBtnSave) _spBtnSave.addEventListener('click', () => addSpotify());
const _spBtnDest = document.getElementById('btn-confirmar-sp-destino');
if (_spBtnDest) _spBtnDest.addEventListener('click', confirmarSpDestino);
const _spMesesSelect = document.getElementById('spMesesSelect');
if (_spMesesSelect) _spMesesSelect.addEventListener('change', selSpMeses);
const _spMontoRecibido = document.getElementById('spMontoRecibido');
if (_spMontoRecibido) _spMontoRecibido.addEventListener('input', actualizarSpDestinoPreview);
const _mSpDebeWrap = document.getElementById('spDebeWrap');
if (_mSpDebeWrap) _mSpDebeWrap.addEventListener('click', () => document.getElementById('spQuedaDebiendo').click());
const _mSpQuedaDebiendo = document.getElementById('spQuedaDebiendo');
if (_mSpQuedaDebiendo) _mSpQuedaDebiendo.addEventListener('click', (e) => e.stopPropagation());
// ── Sheet "Registrar pago de lo pendiente" (sp-hist-pend) ──
const _spBtnResConf = document.getElementById('btn-confirmar-sp-res-pend');
if (_spBtnResConf) _spBtnResConf.addEventListener('click', confirmarSpResolverPendiente);
const _spResMonto = document.getElementById('spResMonto');
if (_spResMonto) _spResMonto.addEventListener('input', actualizarSpResolverPreview);
const _spBtnPagarConf = document.getElementById('btn-confirmar-pagar-spotify');
if (_spBtnPagarConf) _spBtnPagarConf.addEventListener('click', confirmarPagarSpotify);

const _spPagarFuente = document.getElementById('spPagarFuente');
if (_spPagarFuente) _spPagarFuente.addEventListener('change', actualizarSpPagarPreview);
const _spPagarMonto = document.getElementById('spPagarMonto');
if (_spPagarMonto) _spPagarMonto.addEventListener('input', actualizarSpPagarPreview);

// ── Split de fuentes — cobro (spc) y pago (spp), ver crearSplitWidget arriba ──
const _spCobSplitToggle = document.getElementById('spCobSplitToggle');
if (_spCobSplitToggle) _spCobSplitToggle.addEventListener('click', _sp_spc.toggle);
const _spCobBtnAddRow = document.getElementById('btn-add-spcob-split-row');
if (_spCobBtnAddRow) _spCobBtnAddRow.addEventListener('click', _sp_spc.addRow);

const _spPagarSplitToggle = document.getElementById('spPagarSplitToggle');
if (_spPagarSplitToggle) _spPagarSplitToggle.addEventListener('click', _sp_spp.toggle);
const _spPagarBtnAddRow = document.getElementById('btn-add-spp-split-row');
if (_spPagarBtnAddRow) _spPagarBtnAddRow.addEventListener('click', _sp_spp.addRow);

/* ═══════════════════════════════════════════════════════════════
   REGISTRO DE EVENTOS (funciones base — la integración con Personas
   registra las suyas más abajo, en su propio bloque)
   ═══════════════════════════════════════════════════════════════ */

Events.registerAll('spotify', {
  marcarPago: marcarPagoSpotify,
  // OJO: NO pasar editarSpotify directo acá. El bloque INTEGRACIÓN SPOTIFY ↔
  // PERSONAS (más abajo) lo reemplaza (monkeypatch) para precargar la persona vinculada al abrir
  // el sheet — si acá se captura la referencia original, el botón queda
  // pegado a la versión sin esa parte. Con la flecha se resuelve el
  // nombre en cada click, igual que hacía el onclick="..." de antes.
  editar: (...args) => editarSpotify(...args),
  eliminar: deleteSpotify,
  eliminarHistorial: deleteSpHistorial,
  resolverPendiente: resolverPendienteSpHistorial,
  deshacerAbonoPendiente: deshacerAbonoPendienteSp,
});
Events.on('spotify:abrirSheetAgregar', () => openSheet('spotify'));

/* ═══════════════════════════════════════════════════════════════
   INTEGRACIÓN CON EL SISTEMA DE PERSONAS

   Selector de persona al agregar/editar un integrante, para que sean
   personas reales de S.personas en vez de nombres sueltos. Ver
   docs/spotify.md.

   Todas las llamadas a getPersona()/abrirSelPersona()/_inyectarPersonaSheets()
   (personas.js) viven dentro de funciones, nunca a nivel superior, así que solo
   corren en el click — sin depender del orden de carga entre scripts.
   ═══════════════════════════════════════════════════════════════ */


/* ═══════════════════════════════════════════════════════════════
   INTEGRACIÓN SPOTIFY ↔ PERSONAS
   Conecta el módulo Spotify con el sistema de personas para que
   los miembros del plan sean personas reales de S.personas.
   ═══════════════════════════════════════════════════════════════ */

let _spPersonaId = null;       // personaId seleccionado en "Agregar"
let _spEditPersonaId = null;   // personaId en "Editar"

/* ── Reemplazar campo de texto en sheet-spotify con selector de persona ── */
function _initSpotifyPersonaSelector() {
  const sheet = document.getElementById('sheet-spotify');
  if (!sheet || sheet._personaHook) return;
  sheet._personaHook = true;

  const spNEl = document.getElementById('sp_n');
  if (!spNEl) return;
  const ig = spNEl.closest('.ig');
  if (!ig) return;

  ig.innerHTML = `
    <div class="il">¿Quién es?</div>
    <div id="sp-persona-btn" ${Events.attr('spotify:abrirSelectorPersona')}
      class="sp-persona-btn">
      <div id="sp-persona-avatar" class="avatar sp-persona-avatar" style="display:none;"></div>
      <span id="sp-persona-label">Seleccionar persona...</span>
      <svg aria-hidden="true" class="sp-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>
    </div>
    <input type="hidden" id="sp_n" value="">`;
}

function _onSelPersonaSpotify(personaId) {
  const p = getPersona(personaId);
  if (!p) return;
  _spPersonaId = personaId;
  document.getElementById('sp_n').value = p.nombre;

  const btn = document.getElementById('sp-persona-btn');
  const lbl = document.getElementById('sp-persona-label');
  const av  = document.getElementById('sp-persona-avatar');
  if (btn) btn.style.borderColor = 'var(--accent)';
  if (lbl) { lbl.textContent = p.nombre; lbl.style.color = 'var(--text)'; }
  if (av) pintarAvatarPersona(av, p, { mostrar: true });
}

/* ── Reemplazar campo de texto en sheet-editar-spotify con selector ── */
function _initSpotifyEditPersonaSelector() {
  const sheet = document.getElementById('sheet-editar-spotify');
  if (!sheet || sheet._personaEditHook) return;
  sheet._personaEditHook = true;

  const spEditNEl = document.getElementById('sp_edit_n');
  if (!spEditNEl) return;
  const ig = spEditNEl.closest('.ig');
  if (!ig) return;

  ig.innerHTML = `
    <div class="il">¿Quién es?</div>
    <div id="sp-edit-persona-btn" ${Events.attr('spotify:onClickEditPersonaBtn')}
      class="sp-persona-btn">
      <div id="sp-edit-persona-avatar" class="avatar sp-persona-avatar" style="display:none;"></div>
      <span id="sp-edit-persona-label">Seleccionar persona...</span>
      <svg aria-hidden="true" id="sp-edit-persona-chevron" class="sp-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>
    </div>
    <div id="sp-edit-persona-hint" class="sp-persona-hint" style="display:none;">Para asignarle este cobro a otra persona, elimina este integrante y agrega uno nuevo — así el historial no se mezcla entre los dos.</div>
    <input type="hidden" id="sp_edit_n" value="">`;
}

// Si la persona editada ya está vinculada a alguien (personaId), el botón queda
// bloqueado: cambiar de persona a mitad de camino es justo lo que causaba
// desincronizaciones. Para eso ya existe un camino simple y confiable: eliminar
// este integrante y agregar uno nuevo (ver hint debajo del botón).
let _spEditPersonaLocked = false;
function _onClickSpEditPersonaBtn() {
  if (_spEditPersonaLocked) return;
  _abrirSelPersonaSpotifyEdit();
}

let _spEditPersonaPickerAbierto = false;    // se puso true al abrir el buscador en "Editar"
let _spEditPersonaPickerConfirmado = false; // se puso true solo si de verdad se eligió/creó alguien

// Wrapper del botón "¿Quién es?" en Editar: además de abrir el buscador, marca que
// se abrió, para poder detectar si se cierra sin confirmar ninguna selección nueva.
function _abrirSelPersonaSpotifyEdit() {
  _spEditPersonaPickerAbierto = true;
  abrirSelPersona(_onSelPersonaSpotifyEdit, '¿Quién es?');
}

function _onSelPersonaSpotifyEdit(personaId) {
  const p = getPersona(personaId);
  if (!p) return;
  _spEditPersonaId = personaId;
  _spEditPersonaPickerConfirmado = true;
  document.getElementById('sp_edit_n').value = p.nombre;

  const btn = document.getElementById('sp-edit-persona-btn');
  const lbl = document.getElementById('sp-edit-persona-label');
  const av  = document.getElementById('sp-edit-persona-avatar');
  if (btn) btn.style.borderColor = 'var(--accent)';
  if (lbl) { lbl.textContent = p.nombre; lbl.style.color = 'var(--text)'; }
  if (av) pintarAvatarPersona(av, p, { mostrar: true });
}

/* ── Hook en openSheet para inicializar los selectores ─────────── */
// OJO: a diferencia de addSpotify (definido arriba en este mismo archivo y
// por eso ya hoisted al parsear), openSheet vive en js/core/sheet-stack.js,
// que carga DESPUÉS de este módulo (ver comentario de orden de carga en
// sheet-stack.js). Capturar `openSheet` acá arriba, a nivel superior,
// lanzaba "openSheet is not defined" porque el global todavía no existía
// al parsear spotify.js. Antes se envolvía en DOMContentLoaded (los scripts
// con defer, incluido sheet-stack.js, ya habían terminado de ejecutarse
// para cuando ese evento disparaba). CORREGIDO (ronda de lazy-loading de
// spotify/prestado/cuentas/analisis/encargos, ver auditoria-tecnica.md):
// con spotify.js como grupo lazy, este archivo puede cargar mucho DESPUÉS
// de que DOMContentLoaded ya disparó — ese listener nunca se habría
// ejecutado, y openSheet('spotify') jamás habría inyectado los sheets de
// Personas. openSheet sigue siendo seguro de capturar acá arriba sin
// esperar ningún evento: vive en js/core/sheet-stack.js, que es núcleo y
// siempre carga eager mucho antes de que cualquier módulo lazy (spotify
// incluido) pueda siquiera empezar a descargarse.
const _origOpenSheetSpotifyPersonas = openSheet;
openSheet = function(id) {
  if (id === 'spotify') {
    _inyectarPersonaSheets();
    _spPersonaId = null;
    _initSpotifyPersonaSelector();
    // Resetear UI del selector
    const lbl = document.getElementById('sp-persona-label');
    const av  = document.getElementById('sp-persona-avatar');
    const btn = document.getElementById('sp-persona-btn');
    if (lbl) { lbl.textContent = 'Seleccionar persona...'; lbl.style.color = 'var(--text2)'; }
    if (av)  av.style.display = 'none';
    if (btn) btn.style.borderColor = 'var(--border2)';
    const spN = document.getElementById('sp_n');
    if (spN) spN.value = '';
  }
  if (id === 'editar-spotify') {
    _inyectarPersonaSheets();
    _initSpotifyEditPersonaSelector();
  }
  _origOpenSheetSpotifyPersonas.apply(this, arguments);
};

/* ── Hook en addSpotify para guardar personaId ──────────────────── */
const _origAddSpotifyPersonas = addSpotify;
addSpotify = function() {
  // Validar que se seleccionó una persona (ya que sp_n es ahora input oculto)
  const spN = document.getElementById('sp_n');
  if (spN && !spN.value.trim()) {
    const btn = document.getElementById('sp-persona-btn');
    if (btn) {
      btn.style.borderColor = 'var(--red)';
      setTimeout(() => { if (btn) btn.style.borderColor = 'var(--border2)'; }, 2000);
    }
    toast('Selecciona una persona', 'err');
    return;
  }
  const pId = _spPersonaId;
  if (pId && (S.spotify.personas||[]).some(x=>x.personaId===pId)) {
    toast('Esta persona ya está agregada en Spotify','err');
    return;
  }
  _origAddSpotifyPersonas.apply(this, arguments);
  // Asignar personaId al último spotifyPersona creado
  if (pId && S.spotify.personas && S.spotify.personas.length) {
    const last = S.spotify.personas[S.spotify.personas.length - 1];
    if (last && !last.personaId) {
      last.personaId = pId;
      // Sincronizar nombre con la persona
      const p = getPersona(pId);
      if (p) last.nombre = p.nombre;
      save();
      // FIX: faltaba esto. _origAddSpotifyPersonas() (arriba) ya renderizó
      // la fila ANTES de que este hook asignara personaId — sin este
      // segundo render, la fila se quedaba con el estado de "sin persona"
      // (avatar sin color, iniciales crudas de 2 letras) hasta que alguna
      // otra acción disparara un refresh() en cualquier parte de la app.
      // El dato en S siempre quedó bien guardado — era solo la pantalla.
      renderSpotify();
    }
  }
  _spPersonaId = null;
};

/* ── Hook en editarSpotify para pre-cargar la persona vinculada ─── */
const _origEditarSpotifyPersonas = editarSpotify;
editarSpotify = function(i) {
  _origEditarSpotifyPersonas.apply(this, arguments);
  const sp = (S.spotify.personas || [])[i];
  if (!sp) return;
  _spEditPersonaId = sp.personaId || null;
  _spEditPersonaLocked = !!sp.personaId;
  // Pre-cargar UI del selector tras abrir el sheet
  setTimeout(() => {
    _initSpotifyEditPersonaSelector();
    const btn = document.getElementById('sp-edit-persona-btn');
    const chevron = document.getElementById('sp-edit-persona-chevron');
    const hint = document.getElementById('sp-edit-persona-hint');
    if (sp.personaId) {
      const p = getPersona(sp.personaId);
      if (p) _onSelPersonaSpotifyEdit(sp.personaId);
      // Bloqueado: ya hay una persona vinculada — se ve como texto, no como control
      if (btn) { btn.style.cursor = 'default'; btn.style.background = 'var(--bg2)'; }
      if (chevron) chevron.style.display = 'none';
      if (hint) hint.style.display = 'block';
    } else {
      // Rellenar con el nombre directo si no tiene personaId
      const lbl = document.getElementById('sp-edit-persona-label');
      const spEditN = document.getElementById('sp_edit_n');
      if (lbl && sp.nombre) { lbl.textContent = sp.nombre; lbl.style.color = 'var(--text)'; }
      if (btn && sp.nombre) btn.style.borderColor = 'var(--accent)';
      if (spEditN) spEditN.value = sp.nombre || '';
      // Sin vínculo todavía: queda disponible para elegir/crear la persona una vez
      if (btn) { btn.style.cursor = 'pointer'; btn.style.background = 'var(--bg3)'; }
      if (chevron) chevron.style.display = '';
      if (hint) hint.style.display = 'none';
    }
    // Resetear banderas DESPUÉS de precargar: mostrar el estado actual no cuenta
    // como una selección nueva confirmada por el usuario.
    _spEditPersonaPickerAbierto = false;
    _spEditPersonaPickerConfirmado = false;
  }, 80);
};

/* ── Hook en guardarEditarSpotify para guardar personaId ────────── */
const _origGuardarEditarSpotifyPersonas = guardarEditarSpotify;
guardarEditarSpotify = function() {
  // Si se abrió el buscador de "¿Quién es?" pero se cerró sin confirmar ninguna
  // selección (ni elegir a alguien de la lista, ni crear una persona nueva), el
  // input oculto sigue con el nombre anterior — avisar en vez de guardarlo en silencio.
  if (_spEditPersonaPickerAbierto && !_spEditPersonaPickerConfirmado) {
    const spActual = (S.spotify.personas || [])[_spEditIdx];
    toast(`No se seleccionó una persona nueva — se mantuvo a "${spActual ? escHtml(spActual.nombre) : 'la persona anterior'}"`, 'info', 4000);
  }
  // Capturar idx ANTES de llamar al original (que lo pone a null)
  const idxAntes = _spEditIdx;
  // Si se vinculó (por primera vez) a una persona que ya está usada por OTRO integrante
  // de Spotify, bloquear — mismo criterio que ya aplica en addSpotify.
  if (_spEditPersonaId) {
    const yaUsadaPorOtro = (S.spotify.personas || []).some((x, idx) => idx !== idxAntes && x.personaId === _spEditPersonaId);
    if (yaUsadaPorOtro) {
      toast('Esta persona ya está agregada en Spotify', 'err');
      return;
    }
  }
  _origGuardarEditarSpotifyPersonas.apply(this, arguments);
  // Asignar personaId al spotifyPersona editado (si se confirmó una selección nueva)
  if (idxAntes !== null && S.spotify.personas && S.spotify.personas[idxAntes]) {
    const sp = S.spotify.personas[idxAntes];
    if (_spEditPersonaId) {
      sp.personaId = _spEditPersonaId;
    }
    // Sincronización final: si el registro sigue vinculado a una persona (personaId,
    // ya sea la que había antes o la recién elegida), el nombre SIEMPRE se resuelve
    // desde ese vínculo — nunca se deja el texto crudo que haya quedado en el campo
    // oculto. Así nombre y personaId no pueden quedar desincronizados, así falle
    // silenciosamente la confirmación del buscador de personas.
    if (sp.personaId) {
      sp.nombre = spNombreDe(sp);
    }
    save();
    refresh();
  }
  _spEditPersonaId = null;
  _spEditPersonaPickerAbierto = false;
  _spEditPersonaPickerConfirmado = false;
};

/* ── Hook en renderSpotify para aplicar color de persona ─────────── */
const _origRenderSpotifyPersonas = renderSpotify;
renderSpotify = function() {
  _origRenderSpotifyPersonas.apply(this, arguments);
  // Aplicar color y nombre correcto a cada avatar del listado Spotify
  const lista = document.getElementById('spotifyList');
  if (!lista) return;
  const p = S.spotify.personas || [];
  // Ordenar igual que en renderSpotify
  const pOrdenado = [...p].map((x, i) => ({ ...x, _origIdx: i })).sort((a, b) => {
    const far = 99999;
    const dA = a.proximoPago ? Math.ceil((_fechaSafe(a.proximoPago) - new Date()) / 86400000) : far;
    const dB = b.proximoPago ? Math.ceil((_fechaSafe(b.proximoPago) - new Date()) / 86400000) : far;
    return dA - dB;
  });
  const rows = lista.querySelectorAll('.sp-row');
  rows.forEach((row, idx) => {
    const sp = pOrdenado[idx];
    if (!sp || !sp.personaId) return;
    const persona = getPersona(sp.personaId);
    if (!persona) return;
    const av = row.querySelector('.avatar');
    if (av) pintarAvatarPersona(av, persona);
    // Actualizar nombre si cambió
    const nameEl = row.querySelector('.row-name');
    if (nameEl) nameEl.textContent = persona.nombre;
  });
};

/* ═══════════════════════════════════════════════════════════════
   REGISTRO DE EVENTOS (acciones propias de la integración con
   Personas — el resto vive en spotify.js)
   ═══════════════════════════════════════════════════════════════ */

Events.registerAll('spotify', {
  abrirSelectorPersona: () => abrirSelPersona(_onSelPersonaSpotify, '¿Quién es?'),
  onClickEditPersonaBtn: _onClickSpEditPersonaBtn,
});
