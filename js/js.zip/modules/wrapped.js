/* ═══════════════════════════════════════════════════════════════
   js/modules/wrapped.js

   Módulo "Wrapped" — experiencia de revelación anual tipo Spotify
   Wrapped, pantalla nueva accesible desde "Más" → Tu resumen. Duodécimo
   grupo lazy (ver js/core/lazy-loader.js).

   FORMATO: presentación tipo "historias" (Instagram/Spotify Wrapped) —
   una revelación por pantalla completa, avanzando con tap, swipe o
   flechas del teclado, con una barra de progreso tipo stories arriba.
   Reemplaza la versión anterior de una sola pantalla con scroll de
   tarjetas apiladas (ver CHANGELOG.md#wrapped) — era el punto abierto
   de diseño documentado en wrapped.md §7 ("reconsiderar UX hacia una
   presentación tipo slide/story tap-through").

   IMPORTANTE — esto NO es un dashboard de control (para eso ya existe
   Análisis financiero, que se puede consultar en cualquier momento).
   Wrapped es a propósito lo opuesto: una revelación con sorpresa y
   animación. Por eso: (1) NUNCA muestra ingresos/gastos/tasa de ahorro
   en crudo — solo "datos curiosos" (categoría del año, mejor/peor mes,
   gasto más grande, Alcancía, la curva de patrimonio animándose), y
   (2) es a propósito **solo anual, no mensual** — la especialidad de un
   wrapped depende de que no se vea seguido; una versión mensual
   competiría de lleno con "Top categorías" de Análisis financiero, que
   ya cubre ese chequeo periódico. Ver wrapped.md §7.

   No es un módulo de datos: no guarda absolutamente nada nuevo en S.
   Todo se calcula en vivo cada vez que se abre la pantalla — mismo
   principio que el resto de la app ("los movimientos son la fuente de
   verdad, nunca un valor cacheado que pueda desincronizarse").

   NOTA HONESTA SOBRE EL FORMATO ("revelación", "dato curioso"): la
   mayoría de los slides son, a propósito, "etiqueta + número grande +
   una línea de contexto" (ver `_wrappedSlideBignum`) — no hay
   personajes, "personalidad financiera" ni animaciones por slide más
   allá del conteo ascendente, el dibujo de la línea y el confeti final.
   Es una decisión, no una carencia: cada frase de `_wrappedCopy*` ya
   varía según los datos reales de ESTE usuario (qué tan dominante fue
   su categoría, cuánto se alejó su mejor/peor mes de su propio
   promedio) en vez de ser un texto genérico — eso es lo que hace que se
   sienta "revelado" y no solo "mostrado". Si en algún momento se quiere
   ir más lejos (más variantes de copy, algo tipo "tu perfil financiero
   del año"), es una extensión de diseño nueva a discutir — no algo que
   este comentario ya prometía y el código no cumplía.

   A propósito SÍ cubre Mesada, Spotify, Encargos, Préstamos (Me deben /
   Yo debo) y Plata Comprometida — decisión de diseño nueva (2026-09-13,
   ver wrapped.md §7ter): es plata que no es "tuya" en el sentido de
   patrimonio propio, pero sigue siendo parte de la historia financiera
   del usuario en ese año ("cuidaste la plata de 3 personas", "le
   prestaste a Juan", "recibiste tu mesada todo el año sin fallar"), y
   ese es exactamente el tipo de "dato curioso" que ya cubre este módulo
   para las categorías propias. Cada dominio nuevo tiene su propia
   función `_wrappedCalcular*` que lee directamente la estructura de
   datos de su módulo dueño (`S.encargos`, `S.deudores`/`S.misDeudas`,
   `S.mesadas`, `(S.spotify||{}).historial`, `S.plataComprometida`; ver
   plata-comprometida.md §4) — nunca se copia un cálculo que ya vive
   centralizado en el módulo dueño (`getDeudorSaldo`, `encargoSaldo`,
   etc., ver prestado.md/encargos.md); donde no existe una función
   central reusable para un total anual (caso de la ganancia de Spotify,
   que solo se calcula inline dentro de `spotify.js`), este módulo hace
   su propia suma simplificada y lo dice explícito en el comentario de
   esa función, mismo criterio que ya usaba `_wrappedCalcularPeriodo`
   para ingresos/gastos propios.

   Depende de (todas con guard typeof, ninguna es obligatoria):
   - `_esGastoVarNoReal` / `_esEntradaEspejoNoIngreso` — helpers de
     Análisis financiero (núcleo eager, ver analisis-financiero.md §9bis).
   - `window._alcRachaAhorro` — expuesta por alcancia.js (grupo lazy
     aparte); si Alcancía no cargó todavía, esa cifra puntual no se
     muestra.
   - `getPersonaNombre` — expuesta por personas.js (núcleo eager, ver
     personas.md §8); si no existe todavía, cada dominio nuevo cae al
     nombre crudo que ya guarda su propio registro (`d.nombre`,
     `enc.nombre`), escapado igual con `escHtml`.
   - `showScreen` — núcleo eager (navegacion.js); usada solo para volver
     a "Más" al cerrar la historia. Con guard typeof: si no existe, el
     botón cerrar simplemente no navega (no rompe nada).
   - `fmt`, `escHtml`, `hoy` — núcleo eager.
   ═══════════════════════════════════════════════════════════════ */
(function(){
'use strict';

/* ─── HELPERS DE RANGO DE FECHA ────────────────────────────────────────────
   Todas las fechas en S son strings "YYYY-MM-DD" — comparación por slice,
   sin depender de ningún formato de "mesK" propio de otra pantalla. */
function _wrappedEnRango(fecha, tipo, mesK, anioK){
  // Guard estricto de tipo, no solo de "truthy": un dato corrupto donde
  // `fecha` llegara como número, `Date`, u otro tipo no-string rompería
  // `.slice()` más abajo en vez de simplemente excluir ese registro.
  if(typeof fecha !== 'string' || !fecha) return false;
  return tipo === 'mes' ? fecha.slice(0,7) === mesK : fecha.slice(0,4) === anioK;
}

function _wrappedHoy(){
  return hoy();
}

/* Único punto que decide "año actual" y "mes actual (0-indexado)" para todo
   el módulo — antes `_wrappedMejorPeorMesAnio` y `_wrappedSerieMensualAnio`
   llamaban a `new Date()` directamente en vez de pasar por `_wrappedHoy()`,
   dos fuentes de "hoy" que en producción siempre coinciden (`_wrappedHoy`
   ya cae a `new Date()` si no existe `hoy()`) pero que en tests hacían que
   mockear `hoy()` no alcanzara para controlar de verdad qué mes se toma
   como "el actual". */
function _wrappedAnioYMesActual(){
  const hoyStr = _wrappedHoy();
  return { anioActual: hoyStr.slice(0,4), mesActualIdx: parseInt(hoyStr.slice(5,7),10) - 1 };
}

/* ─── VALIDACIÓN DE DATOS (solo debug, nunca se muestra al usuario) ───────
   Wrapped no es dueño de ningún dato — lee estructuras que ya arma el
   resto de la app (S.movimientos, S.gastosVar, S.patrimonioHistorial,
   S.alcancia) y que van evolucionando con el tiempo, con datos JSON reales
   que a veces llegan en una forma inesperada. Esta función no cambia ningún cálculo ni bloquea el
   render: solo junta advertencias sobre la FORMA de esos datos (¿es
   array?, ¿los montos son números?, ¿las fechas tienen pinta de
   "YYYY-MM-DD"?) para que un problema de normalización aguas arriba se
   note en consola en vez de manifestarse en silencio como un slide con un
   número raro. Los cálculos de más abajo (`_wrappedCalcularPeriodo`, etc.)
   ya degradan solos ante datos faltantes o corruptos (`||[]`,
   `Number.isFinite`, el guard de tipo en `_wrappedEnRango`) — esto no
   reemplaza esa defensividad, es una capa aparte para DIAGNOSTICAR, no
   para corregir nada. */
function _wrappedFechaLuceValida(f){
  return typeof f === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(f);
}

function _wrappedValidarDatos(S){
  if(!S || typeof S !== 'object'){
    return ['S no existe o no es un objeto — Wrapped no tiene nada que leer.'];
  }
  const warnings = [];
  if(S.movimientos !== undefined && !Array.isArray(S.movimientos)){
    warnings.push('S.movimientos existe pero no es un array.');
  }
  if(S.gastosVar !== undefined && !Array.isArray(S.gastosVar)){
    warnings.push('S.gastosVar existe pero no es un array.');
  }
  if(S.patrimonioHistorial !== undefined && !Array.isArray(S.patrimonioHistorial)){
    warnings.push('S.patrimonioHistorial existe pero no es un array.');
  }
  if(S.alcancia !== undefined && S.alcancia !== null && typeof S.alcancia !== 'object'){
    warnings.push('S.alcancia existe pero no es un objeto.');
  }
  if(S.encargos !== undefined && !Array.isArray(S.encargos)){
    warnings.push('S.encargos existe pero no es un array.');
  }
  if(S.deudores !== undefined && !Array.isArray(S.deudores)){
    warnings.push('S.deudores existe pero no es un array.');
  }
  if(S.misDeudas !== undefined && !Array.isArray(S.misDeudas)){
    warnings.push('S.misDeudas existe pero no es un array.');
  }
  if(S.mesadas !== undefined && S.mesadas !== null && typeof S.mesadas !== 'object'){
    warnings.push('S.mesadas existe pero no es un objeto.');
  }
  if((S.spotify||{}).historial !== undefined && !Array.isArray((S.spotify||{}).historial)){
    warnings.push('(S.spotify||{}).historial existe pero no es un array.');
  }
  if(S.plataComprometida !== undefined && !Array.isArray(S.plataComprometida)){
    warnings.push('S.plataComprometida existe pero no es un array.');
  }

  const revisarMontos = (arr, nombre) => {
    if(!Array.isArray(arr)) return;
    const malos = arr.filter(x => x && x.monto !== undefined && !Number.isFinite(Number(x.monto))).length;
    if(malos > 0) warnings.push(nombre + ': ' + malos + ' registro(s) con "monto" que no es un número.');
  };
  revisarMontos(S.movimientos, 'S.movimientos');
  revisarMontos(S.gastosVar, 'S.gastosVar');

  const revisarFechas = (arr, nombre) => {
    if(!Array.isArray(arr)) return;
    const malas = arr.filter(x => x && x.fecha !== undefined && !_wrappedFechaLuceValida(x.fecha)).length;
    if(malas > 0) warnings.push(nombre + ': ' + malas + ' registro(s) con "fecha" que no luce "YYYY-MM-DD".');
  };
  revisarFechas(S.movimientos, 'S.movimientos');
  revisarFechas(S.gastosVar, 'S.gastosVar');
  revisarFechas(S.patrimonioHistorial, 'S.patrimonioHistorial');

  return warnings;
}

/* Único punto que decide si Wrapped se abrió en modo debug (?debug=1 o
   #debug en la URL) — antes vivía duplicado dentro de `_wrappedLogDebug`
   (consola) y del panel de debug visual (ver `_wrappedDebugPanelHtml` /
   `renderWrapped`, 2026-09-15) — dos copias del mismo try/catch que
   podían desincronizarse si alguna vez se tocaba una sin la otra. Envuelto
   en try/catch porque `URLSearchParams`/`window.location` no deberían
   fallar nunca en un navegador real, pero esta función corre en cada
   apertura de la pantalla y no vale la pena arriesgar la historia entera
   por un diagnóstico que es puramente informativo. */
function _wrappedDebugOn(){
  try{
    return typeof window !== 'undefined' && !!window.location &&
      (new URLSearchParams(window.location.search).get('debug') === '1' ||
       (window.location.hash || '').indexOf('debug') !== -1);
  } catch(e){ return false; }
}

/* Imprime las advertencias en consola solo si Wrapped se abrió en modo
   debug — nunca se le muestra nada de esto al usuario final, ver el
   comentario de `_wrappedValidarDatos`. */
function _wrappedLogDebug(S){
  if(!_wrappedDebugOn()) return;
  const warnings = _wrappedValidarDatos(S);
  if(warnings.length && typeof console !== 'undefined' && console.warn){
    console.warn('[wrapped] advertencias de datos:', warnings);
  }
}

/* ─── PANEL DE DEBUG VISUAL (2026-09-15) ───────────────────────────────────
   Hasta ahora `?debug=1`/`#debug` solo imprimía advertencias en la consola
   (`_wrappedLogDebug`) — útil, pero obliga a tener las devtools abiertas y
   no muestra NADA sobre por qué el motor de insights/personalidad eligió
   lo que eligió. Este panel es puramente de inspección para quien ajusta
   el motor (mismo criterio que ya regía la consola): se arma a partir del
   snapshot que `_wrappedBuildSlides` ya deja en `slides._wrappedDebugInfo`
   (ver ese comentario) — no dispara ningún cálculo nuevo, no guarda nada
   en `S`, y jamás se inyecta al DOM si `_wrappedDebugOn()` es falso (ver
   `renderWrapped`).

   A propósito NO incluye ingresos/gastos/tasaAhorro en crudo aunque sean
   datos que este módulo sí calcula internamente (`_wrappedCalcularPeriodo`,
   ver wrapped.md §3) — ese aislamiento existe para separar "qué pasó
   financieramente" (terreno de Análisis financiero) de "qué decidió
   mostrar Wrapped y por qué" (terreno de este panel), y no hay necesidad
   real de cruzar esa línea solo para depurar el motor de selección: el
   puntaje y las banderas ya alcanzan para explicar cada elección. */
function _wrappedDebugPanelHtml(S, debugInfo){
  const warnings = _wrappedValidarDatos(S);
  const warnHtml = warnings.length
    ? warnings.map(w => `<div class="wrapped-debug-warn"><i class="fa-solid fa-triangle-exclamation"></i> ${escHtml2(w)}</div>`).join('')
    : `<div class="wrapped-debug-ok"><i class="fa-solid fa-circle-check"></i> Sin advertencias — la forma de los datos pasó las validaciones básicas.</div>`;

  const info = debugInfo || {};
  const insights = info.candidatosInsights || [];
  const insightsRows = insights.map(c => `<tr>
      <td class="${c.elegido ? 'wrapped-debug-sel' : 'wrapped-debug-unsel'}">${c.elegido ? '<i class="fa-solid fa-check"></i>' : '—'}</td>
      <td>${escHtml2(c.label)}</td>
      <td>${Math.round(c.score)}</td>
      <td>${[c.esRecord && 'récord', c.esCambioComportamiento && 'cambio', c.involucraMeta && 'meta', c.involucraPersona && 'persona'].filter(Boolean).join(', ') || '—'}</td>
    </tr>`).join('');

  const pers = info.personalidad;
  const persRows = pers
    ? pers.candidatos.map(c => {
        const esTop = c.tipo === pers.elegido, esSec = c.tipo === pers.secundario;
        return `<tr>
          <td class="${esTop ? 'wrapped-debug-top' : (esSec ? 'wrapped-debug-sel' : 'wrapped-debug-unsel')}">${esTop ? '<i class="fa-solid fa-star"></i> principal' : (esSec ? 'secundario' : '—')}</td>
          <td>${escHtml2(c.tipo)}</td>
          <td>${escHtml2(c.evidencia)}</td>
        </tr>`;
      }).join('')
    : '';

  return `
    <h4>Validación de datos</h4>
    ${warnHtml}
    <h4>Resumen</h4>
    <table>
      <tr><td>Slides totales</td><td>${info.totalSlides != null ? info.totalSlides : '—'}</td></tr>
      <tr><td>Candidatos de insights</td><td>${insights.length} (entraron ${insights.filter(c=>c.elegido).length} de ${WRAPPED_MAX_INSIGHTS_POOL} posibles)</td></tr>
      <tr><td>Personalidad</td><td>${pers ? escHtml2(pers.elegido) + (pers.secundario ? ' + ' + escHtml2(pers.secundario) : '') : 'sin señal clara este año'}</td></tr>
    </table>
    <h4>Candidatos de insights (<i class="fa-solid fa-check"></i> = entró a la historia final)</h4>
    ${insights.length ? `<table><tr><th></th><th>label</th><th>puntaje</th><th>señales</th></tr>${insightsRows}</table>` : '<div class="wrapped-debug-ok">Sin candidatos este año.</div>'}
    <h4>Personalidad — candidatos que aplicaron</h4>
    ${pers ? `<table><tr><th></th><th>tipo</th><th>evidencia</th></tr>${persRows}</table>` : '<div class="wrapped-debug-ok">Ninguno aplicó este año.</div>'}
  `;
}
/* `escHtml2`: mismo criterio de §3 (todo texto derivado de un dato del
   usuario pasa por escape antes de interpolarse) aplicado también al
   panel de debug — usa `escHtml` real si el núcleo ya cargó, y una
   versión mínima propia si no, para que el panel nunca dependa de un
   guard `typeof` distinto al resto del archivo. */
function escHtml2(s){
  if(typeof escHtml === 'function') return escHtml(s);
  return String(s == null ? '' : s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* Agrupa una lista ya filtrada de gastos (variables + fijos pagados) por
   categoría y devuelve la líder por MONTO — pero también, si es distinta,
   la líder por FRECUENCIA (cantidad de movimientos). Una compra de
   $300.000 y veinte compras de $20.000 pueden "ganar" la misma categoría
   por monto sin que cuenten la misma historia — separar las dos
   dimensiones permite que el copy lo note (ver `_wrappedCopyCategoria`)
   sin inventar categorías nuevas ni depender de más de un año de
   historial (a diferencia de "categoría que más creció" o "categoría más
   inesperada", que si se hacen mal con poco historial dirían algo que no
   es realmente así — quedan fuera de esta pasada, ver wrapped.md §7).
   Función compartida entre el período completo (`_wrappedCalcularPeriodo`)
   y la comparación de mitades de año (`_wrappedCambioDeHabitos`), para no
   repetir la lógica de agrupar por categoría en dos lugares. */
/* Agrupa una lista de gastos por categoría en {monto, count} — extraído
   de `_wrappedTopCategoriaDe` (2026-09-15) para que el nuevo ranking
   completo de categorías (`_wrappedRankingCategorias`, ver abajo) pueda
   reusar el mismo agrupado en vez de reimplementarlo — mismo principio
   de §3 de no duplicar un cálculo ya centralizado. */
function _wrappedAgruparPorCategoria(items){
  const catMap = {}; // cat -> { monto, count }
  items.forEach(g => {
    const cat = g.cat || 'Sin categoría';
    if(!catMap[cat]) catMap[cat] = { monto: 0, count: 0 };
    catMap[cat].monto += (g.monto||0);
    catMap[cat].count += 1;
  });
  return catMap;
}

function _wrappedTopCategoriaDe(items, totalGastos){
  const catMap = _wrappedAgruparPorCategoria(items);
  let topPorMonto = null, topPorFrecuencia = null;
  Object.keys(catMap).forEach(cat => {
    const { monto, count } = catMap[cat];
    if(!topPorMonto || monto > topPorMonto.monto) topPorMonto = { cat, monto };
    if(!topPorFrecuencia || count > topPorFrecuencia.count) topPorFrecuencia = { cat, count };
  });
  if(topPorMonto){
    // `catShare` es de uso puramente interno: sirve para elegir el tono
    // del texto ("le diste con todo a X" vs "tu categoría más frecuente
    // fue X"), nunca se pinta como número — mismo principio que ya se
    // aplicaba con `balance` para rankear el mejor/peor mes sin mostrarlo
    // en crudo.
    topPorMonto.catShare = totalGastos > 0 ? topPorMonto.monto / totalGastos : 0;
    // Si la categoría que más plata consumió NO es la misma que más se
    // repitió, guardamos la otra para que el copy pueda mencionar el
    // contraste ("gastaste más en X, pero Y fue la que más se repitió").
    topPorMonto.topPorFrecuencia = (topPorFrecuencia && topPorFrecuencia.cat !== topPorMonto.cat) ? topPorFrecuencia : null;
  }
  return topPorMonto;
}

/* Ranking completo de categorías por monto, con el % que cada una
   representó del total de gastos del período — a diferencia de
   `_wrappedTopCategoriaDe` (que solo devuelve la ganadora, para elegir
   el tono del copy), esto es para el slide nuevo de barras por
   categoría (ver `_wrappedBuildSlides`), que sí necesita mostrar varias
   a la vez. Reutiliza `_wrappedAgruparPorCategoria` — no repite el
   agrupado. Igual que `catShare`, nunca se pinta `totalGastos` en
   crudo, solo el porcentaje que cada categoría representa de él. */
function _wrappedRankingCategorias(items, totalGastos, maxCats){
  const catMap = _wrappedAgruparPorCategoria(items);
  const ranking = Object.keys(catMap)
    .map(cat => ({
      cat,
      monto: catMap[cat].monto,
      pct: totalGastos > 0 ? (catMap[cat].monto / totalGastos * 100) : 0
    }))
    .sort((a,b) => b.monto - a.monto);
  return maxCats ? ranking.slice(0, maxCats) : ranking;
}

/* Categoría con mayor monto PROMEDIO por movimiento (2026-09-15) — eje
   distinto al de `_wrappedTopCategoriaDe` (que rankea por monto total) y
   al de "frecuencia" (que rankea por cantidad de movimientos): esta
   busca la categoría que más "pesa" cada vez que aparece, aunque no sea
   ni la más frecuente ni la de mayor monto total. Requiere al menos 2
   movimientos en la categoría — con uno solo, "promedio por movimiento"
   es literalmente ese único movimiento y no dice nada nuevo (ya lo
   cubriría, si acaso, el slide de "gasto más grande"). Reutiliza
   `_wrappedAgruparPorCategoria`, mismo criterio de no duplicar el
   agrupado. */
function _wrappedCategoriaMasConcentrada(items){
  const catMap = _wrappedAgruparPorCategoria(items);
  let top = null;
  Object.keys(catMap).forEach(cat => {
    const { monto, count } = catMap[cat];
    if(count < 2) return;
    const avgPerOcc = monto / count;
    if(!top || avgPerOcc > top.avgPerOcc) top = { cat, avgPerOcc, count };
  });
  return top;
}

/* ─── CÁLCULO PURO de un período (mes o año) ──────────────────────────────
   Sigue calculando ingresos/gastos/balance internamente (hace falta para
   rankear "mejor/peor mes"), pero el render NUNCA pinta esos números
   crudos — solo los usa como insumo de datos curiosos (top categoría,
   gasto más grande, ranking de meses). Reutiliza los mismos criterios de
   "gasto/ingreso real" que Análisis financiero (analisis-financiero.md
   §9bis). */
/* Mesada + Ingresos fijos como ingreso del período — mismo criterio EXACTO
   que analisis.js (§2 de analisis-financiero.md, líneas 59-84 del código
   real): "Ingresos estimados" ahí es mesada + ingresos fijos + entradas
   manuales, nunca solo esto último. Antes de este fix, `totalIngresos` de
   acá abajo solo sumaba entradas manuales — eso hacía que "Tu mejor/peor
   mes" pudiera dar un balance más bajo (incluso negativo) que el que
   Análisis financiero ya muestra para ese mismo mes, con la misma plata
   real. Se lee `S.mesadas`/`S.ingresosFijos` directo, sin pasar por
   `getMesadaData()`/`_getCuotaAnio()`/`getIngresosFijosMes()` (funciones
   de otros módulos lazy que pueden no estar cargados) — no hace falta ni
   el guard `typeof` porque acá solo se lee la FORMA de `S`, ya
   documentada (mesada.md §4, analisis-financiero.md §3), igual que el
   resto de este archivo lee `S.alcancia`/`S.gastosVar` directo. */
// (Sin uso interno desde que Mesada pasó a Periodo.mesadaDelMes — js/core/periodo.js; se conserva
// exportada por los tests.)
function _wrappedCuotaAnioFallback(cuotas, anio){
  if(!cuotas || typeof cuotas !== 'object') return 0;
  let mejorAnio = null;
  Object.keys(cuotas).forEach(k => {
    const kn = parseInt(k,10);
    if(Number.isFinite(kn) && kn <= anio && (mejorAnio===null || kn>mejorAnio)) mejorAnio = kn;
  });
  return mejorAnio!==null ? (cuotas[mejorAnio]||0) : 0;
}
// Mesada e ingresos fijos de un mes: definición única en js/core/periodo.js (la misma de
// Inicio y Análisis). `mesIdx` es 0-indexado (convención de Mesada), `mesK` es 'YYYY-MM'.
function _wrappedMesadaMes(S, anio, mesIdx){
  return Periodo.mesadaDelMes(Fecha.mesKey(anio, mesIdx + 1), S);
}
function _wrappedIngresosFijosMes(S, mesK){
  return Periodo.ingresosFijosDelMes(mesK, S);
}
// Cuotas de Spotify cobradas en el mes (regla de caja, la misma de Inicio y Análisis). El slide propio de Spotify
// (_wrappedCalcularSpotify) sigue siendo otra lectura: cobrado − pagado del período.
function _wrappedSpotifyMes(S, mesK){
  return Periodo.spotifyDelMes(mesK, S);
}

/* Extraído de `_wrappedCalcularPeriodo` (2026-09-14) para que las nuevas
   funciones de la tercera tanda (comparaciones, récords, descubrimientos,
   ver más abajo) puedan filtrar "gasto real del período" sin reimplementar
   el mismo filtro — mismo principio de §3, nunca duplicar un cálculo ya
   centralizado. No cambia ningún comportamiento existente: `_wrappedCalcularPeriodo`
   ahora llama a esto en vez de tener las mismas líneas inline. */
function _wrappedItemsRealesPeriodo(S, tipo, mesK, anioK){
  const gastosVar = S.gastosVar || [];
  // Pagos de gastos fijos: normalizados por Periodo.pagosFijos (mapa u array, con categoría y el
  // monto realmente pagado). Pertenecen al mes que cubre el pago (su clave), igual que en Análisis.
  const pagosFijos = Periodo.pagosFijos(S);
  const esGastoNoReal = typeof _esGastoVarNoReal === 'function' ? _esGastoVarNoReal : (()=>false);
  return {
    gastosVarPeriodo: gastosVar.filter(g => _wrappedEnRango(g.fecha, tipo, mesK, anioK) && !esGastoNoReal(g)),
    pagosFijosPeriodo: pagosFijos.filter(p => _wrappedEnRango(p.mes + '-01', tipo, mesK, anioK))
  };
}

// Entradas que cuentan como ingreso real: la definición única del núcleo
// (entradasIngresoReal — la misma de Inicio y Análisis). Recibe el estado porque Wrapped
// trabaja sobre el `S` que le pasan, no necesariamente el global.
function _wrappedEntradasIngreso(S){
  // Sin el núcleo cargado (tests/demos aisladas) se mantiene el comportamiento anterior sin filtro.
  return typeof entradasIngresoReal === 'function'
    ? entradasIngresoReal(S)
    : ((S && S.movimientos) || []).filter(m => m && m.tipo==='entrada');
}

function _wrappedCalcularPeriodo(S, tipo, mesK, anioK){
  S = S || {};
  const movs = S.movimientos || [];


  const { gastosVarPeriodo, pagosFijosPeriodo } = _wrappedItemsRealesPeriodo(S, tipo, mesK, anioK);
  const ingresosPeriodo   = _wrappedEntradasIngreso(S).filter(m => _wrappedEnRango(m.fecha, tipo, mesK, anioK));

  // Mesada + ingresos fijos del período, sumados mes a mes (ver comentario
  // arriba de `_wrappedMesadaMes`/`_wrappedIngresosFijosMes`) — para "mes"
  // es un solo mes; para "anio" se recorren los meses transcurridos, nunca
  // meses futuros del año en curso (un ingreso fijo recurrente no debe
  // contarse antes de que ese mes exista).
  let ingresoMesadaFijos = 0;
  if(tipo === 'mes' && mesK){
    const anio = parseInt(mesK.split('-')[0], 10);
    const mesIdx = parseInt(mesK.split('-')[1], 10) - 1;
    ingresoMesadaFijos = _wrappedMesadaMes(S, anio, mesIdx) + _wrappedIngresosFijosMes(S, mesK) + _wrappedSpotifyMes(S, mesK);
  } else if(tipo === 'anio' && anioK){
    const anio = parseInt(anioK, 10);
    const { anioActual, mesActualIdx } = _wrappedAnioYMesActual();
    const mesMax = (anioK === anioActual) ? mesActualIdx : 11;
    for(let m=0; m<=mesMax; m++){
      const mesKLoop = Fecha.mesKey(anioK, m+1);
      ingresoMesadaFijos += _wrappedMesadaMes(S, anio, m) + _wrappedIngresosFijosMes(S, mesKLoop) + _wrappedSpotifyMes(S, mesKLoop);
    }
  }

  const totalGastos   = gastosVarPeriodo.reduce((s,g)=>s+(g.monto||0),0) + pagosFijosPeriodo.reduce((s,p)=>s+(p.monto||0),0);
  const totalIngresos = ingresosPeriodo.reduce((s,m)=>s+(m.monto||0),0) + ingresoMesadaFijos;
  const balance = totalIngresos - totalGastos;

  // Top categoría (gastos variables reales + gastos fijos pagados) —
  // devuelve tanto la líder por monto como, si difiere, la líder por
  // frecuencia (ver `_wrappedTopCategoriaDe`, comentario ahí para el
  // razonamiento de por qué importan las dos dimensiones).
  const topCategoria = _wrappedTopCategoriaDe([...gastosVarPeriodo, ...pagosFijosPeriodo], totalGastos);

  // Gasto más grande del período — "dato curioso" tipo Wrapped, nunca
  // mostrado así de puntual en Análisis financiero. Guarda también su
  // fecha y categoría (para contextualizarlo en el copy, ver
  // `_wrappedCopyGasto`) y el gasto promedio del período (uso interno,
  // solo para decidir qué tan grande fue *en relación al propio usuario*
  // — nunca en pesos fijos, que no tendría sentido entre personas con
  // gastos de escalas muy distintas).
  let gastoMasGrande = null;
  gastosVarPeriodo.forEach(g => {
    if(!gastoMasGrande || (g.monto||0) > gastoMasGrande.monto) gastoMasGrande = { desc: g.desc || g.cat || 'Gasto', monto: g.monto||0, cat: g.cat || null, fecha: g.fecha || null };
  });
  const avgGasto = gastosVarPeriodo.length ? gastosVarPeriodo.reduce((s,g)=>s+(g.monto||0),0) / gastosVarPeriodo.length : 0;

  // Alcancía del período: depósitos del ciclo activo dentro del rango +
  // ciclos ya destapados cuyo cierre (fechaFin) cae dentro del rango.
  //
  // Verificado contra alcancia.js/alcancia.md (2026-09-12): al destapar,
  // `a.saldoRegistrado` se resetea a 0 de inmediato y el ciclo cerrado
  // queda copiado en `a.historial[]` — pero `a.movimientos[]` NO se limpia
  // en ese momento. Solo se limpia cuando el usuario elige explícitamente
  // "Iniciar nueva alcancía" (`alcanciaIniciarNueva()`); mientras tanto la
  // alcancía queda en estado "fantasma" (`a._destapada === true`, ver
  // alcancia.md §2/§6) con los depósitos del ciclo ya cerrado todavía
  // presentes en `a.movimientos[]`. Sumar ambas fuentes sin excluir ese
  // solape contaría la misma plata dos veces durante esa ventana — por
  // eso `a.movimientos` solo se suma cuando hay un ciclo genuinamente
  // activo (`!a._destapada`); una vez destapado, esa plata ya vive
  // únicamente en el `historial` que se suma abajo.
  let alcanciaPeriodo = 0, alcanciaCiclos = 0;
  const a = S.alcancia;
  if(a){
    let huboDepositoCicloActivo = false;
    if(!a._destapada){
      (a.movimientos||[]).forEach(m => {
        if(_wrappedEnRango(m.fecha, tipo, mesK, anioK)){ alcanciaPeriodo += (m.monto||0); huboDepositoCicloActivo = true; }
      });
    }
    if(huboDepositoCicloActivo) alcanciaCiclos++;
    (a.historial||[]).forEach(h => {
      if(_wrappedEnRango(h.fechaFin, tipo, mesK, anioK)){ alcanciaPeriodo += (h.saldoRegistrado||0); alcanciaCiclos++; }
    });
  }

  // Conteo de registros discretos (uso nuevo: slide "actividad", ver
  // `_wrappedBuildSlides`) — no incluye mesada/ingresos fijos porque esos
  // no son registros individuales en `S.movimientos`, son un total
  // recurrente calculado aparte (ver `_wrappedMesadaMes`/`_wrappedIngresosFijosMes`
  // arriba); contarlos como "un movimiento" sería inventar un número que
  // no corresponde a nada que el usuario efectivamente haya registrado.
  const nGastos = gastosVarPeriodo.length + pagosFijosPeriodo.length;
  const nIngresos = ingresosPeriodo.length;

  return { totalGastos, totalIngresos, balance, topCategoria, gastoMasGrande, alcanciaPeriodo, alcanciaCiclos, avgGasto, nGastos, nIngresos };
}

/* ─── Mejor y peor mes del año ─────────────────────────────────────────── */
/* ─── "Racha real" de meses con seguimiento (2026-09-16) ────────────────
   Caso real reportado: alguien empieza a usar la app en septiembre, pero
   además cargó UN registro suelto de meses atrás porque se acordaba (la
   mesada de enero, "me acuerdo que me la dieron el 30"). Sin esto, ese
   enero pasaba el filtro `totalIngresos > 0 || totalGastos > 0` de
   `_wrappedMejorPeorMesAnio`/`_wrappedHistoriasMensuales` como si fuera un
   mes real y comparable — con cero gastos (porque no se registró nada más
   ese mes, no porque no se haya gastado nada), enero le ganaba a los
   meses reales en balance por default y encima le tocaba una frase de
   "mes tranquilo" que en realidad describe un vacío de datos.

   La app no tiene ningún campo de "cuándo empezaste a usarme de verdad"
   (a diferencia de, por ejemplo, `creadoEn` por persona en
   el núcleo) — no hay forma de preguntarle directamente. Lo que sí
   se puede inferir de los propios datos: el principio real del historial
   es la RACHA de meses activos que termina en `mesMax` (el mes más
   reciente). Se camina hacia atrás desde ahí y se corta apenas aparecen
   DOS meses seguidos sin ningún ingreso/gasto — dos, no uno, a propósito:
   un solo mes flojo (viaje, poco movimiento) es normal en un historial
   real y no debería borrar meses reales anteriores; un hueco de dos
   meses o más, seguido de un registro aislado más atrás, es la señal de
   "ahí no había seguimiento todavía". Mismo espíritu que el resto del
   archivo (umbrales relativos al propio usuario, no un número mágico en
   pesos — ver `catShare>=0.15` en `_wrappedCambioDeHabitos`, el 70/30 de
   `_wrappedCambioFuerte`).

   Importante — esto NO toca ningún total anual: `_wrappedCalcularPeriodo`
   sobre el año completo sigue contando el ingreso de enero (la plata sí
   entró, es real). Solo se excluye de las comparaciones POR MES, que es
   justo donde un mes con "ingreso sin ningún gasto registrado" se ve
   artificialmente perfecto frente a meses con seguimiento real. */
function _wrappedInicioRachaReal(S, anioK, mesMax){
  let inicio = mesMax;
  let vaciosSeguidos = 0;
  for(let m = mesMax; m >= 0; m--){
    const mesK = Fecha.mesKey(anioK, m+1);
    const stats = _wrappedCalcularPeriodo(S, 'mes', mesK, anioK);
    if(stats.totalIngresos > 0 || stats.totalGastos > 0){
      vaciosSeguidos = 0;
      inicio = m;
    } else {
      vaciosSeguidos++;
      if(vaciosSeguidos >= 2) break; // hueco real: acá termina la racha
    }
  }
  return inicio;
}

function _wrappedMejorPeorMesAnio(S, anioK){
  const { anioActual, mesActualIdx } = _wrappedAnioYMesActual();
  const mesMax = (anioK === anioActual) ? mesActualIdx : 11;
  const mesInicio = _wrappedInicioRachaReal(S, anioK, mesMax);
  const meses = [];
  for(let m=mesInicio; m<=mesMax; m++){
    const mesK = Fecha.mesKey(anioK, m+1);
    const stats = _wrappedCalcularPeriodo(S, 'mes', mesK, anioK);
    if(stats.totalIngresos > 0 || stats.totalGastos > 0){
      // ingresos/gastos van acá desde 2026-09-15 para que el copy del
      // mejor/peor mes pueda contar el desglose puntual de ESE mes (no el
      // agregado del año — sigue siendo un highlight puntual, permitido
      // por §3, igual que ya lo era el balance).
      meses.push({ mesK, balance: stats.balance, ingresos: stats.totalIngresos, gastos: stats.totalGastos });
    }
  }
  if(!meses.length) return { mejor: null, peor: null, promedio: null };
  const mejor = meses.reduce((a,b)=> b.balance > a.balance ? b : a);
  const peor  = meses.reduce((a,b)=> b.balance < a.balance ? b : a);
  // `promedio` (balance típico del año) es de uso puramente interno: sirve
  // para decidir si el mejor/peor mes fue "un poco" o "mucho" mejor/peor
  // que lo normal de ESE usuario — nunca se pinta como cifra, evita
  // depender de umbrales fijos en pesos que no tendrían sentido para
  // ingresos muy distintos entre personas.
  const promedio = meses.reduce((s,m)=>s+m.balance,0) / meses.length;
  // Empates: si más de un mes comparte exactamente el balance extremo, el
  // `reduce` de arriba se queda arbitrariamente con el primero — acá se
  // detecta el empate para que el copy pueda nombrarlo en vez de fingir
  // que hubo un único ganador (ver `_wrappedCopyMejorMes`/`_wrappedCopyPeorMes`).
  const empateMejor = meses.filter(m => m.balance === mejor.balance).length > 1;
  const empatePeor  = meses.filter(m => m.balance === peor.balance).length > 1;
  return { mejor, peor, promedio, empateMejor, empatePeor };
}

/* ─── VISTA MENSUAL — "Este mes pasó algo" (2026-09-13) ────────────────
   Reabre la decisión descartada en la versión original de wrapped.md §7
   ("vista mensual... competiría con Top categorías de Análisis, le
   quitaría a Wrapped la sensación de sorpresa") — decisión de producto
   explícita del usuario, no una reconsideración técnica.

   Para evitar justamente el riesgo que motivó el descarte original, esto
   NO es un slide por mes (serían hasta 12 pantallas casi idénticas en
   forma, deslucido comparado con el resto de la historia) — es UNA sola
   pantalla con una lista compacta de una frase por mes, exactamente lo
   que pedía el brief original ("no mostrar doce tablas... mostrar
   solamente pequeñas historias"). Reutiliza `_wrappedCalcularPeriodo`
   mes a mes — el mismo patrón de loop que ya usa `_wrappedMejorPeorMesAnio`
   — nunca reimplementa el cálculo de balance/categoría por su cuenta.
   Omite meses sin ningún ingreso/gasto real (no forzar una frase sobre un
   mes vacío) y no se muestra si quedan menos de 3 meses con actividad. */
function _wrappedLineaMes(mes, avgBalance){
  if(avgBalance !== 0 && mes.balance > avgBalance * 1.4 && mes.balance > 0) return 'Uno de tus mejores meses.';
  if(mes.balance < 0 || (avgBalance > 0 && mes.balance < avgBalance * 0.5)) return 'Uno de tus meses más ajustados.';
  // "Sin categoría" es el bucket de gastos SIN `cat` (típicamente pagos de
  // gasto fijo) — como casi siempre son el gasto más grande del mes, sin
  // esta excepción "dominaba" casi todos los meses del año con una frase
  // que no dice nada real (encontrado probando contra un JSON real).
  if(mes.topCategoria && mes.topCategoria.cat !== 'Sin categoría' && (mes.topCategoria.catShare||0) >= 0.4){
    return `Dominado por ${escHtml(mes.topCategoria.cat)}.`;
  }
  return 'Un mes tranquilo, sin grandes sobresaltos.';
}
function _wrappedHistoriasMensuales(S, anioK, mesMax){
  if(mesMax < 2) return null; // menos de 3 meses posibles: no amerita un repaso mes a mes
  const mesInicio = _wrappedInicioRachaReal(S, anioK, mesMax); // ver cabecera de esa función
  const meses = [];
  for(let m=mesInicio; m<=mesMax; m++){
    const mesK = Fecha.mesKey(anioK, m+1);
    const stats = _wrappedCalcularPeriodo(S, 'mes', mesK, anioK);
    if(stats.totalIngresos > 0 || stats.totalGastos > 0){
      meses.push({ mesK, balance: stats.balance, topCategoria: stats.topCategoria });
    }
  }
  if(meses.length < 3) return null;

  const avgBalance = meses.reduce((s,m)=>s+m.balance,0) / meses.length;
  return meses.map(mes => ({ mesK: mes.mesK, balance: mes.balance, linea: _wrappedLineaMes(mes, avgBalance) }));
}

/* ─── Resumen de crecimiento de patrimonio en el año (número final) ──────
   Mismo criterio que analisis-financiero.md §5: `valorVisible` (sin
   alcancía) y se resta el `montoBase` acumulado para no contar
   aperturas/ajustes como crecimiento real. */
// 'patrimonio' (cierra en rojo, o cayó con gastos sobre ingresos) · 'sin-ingresos' (hay gastos y ningún ingreso) · null (año normal).
function _wrappedAnioDificil(patrimonio, s){
  if(s && s.totalGastos > 0 && !(s.totalIngresos > 0)) return 'sin-ingresos';
  if(patrimonio && Number.isFinite(patrimonio.fin) && (patrimonio.fin < 0 || (patrimonio.diff < 0 && s && s.balance < 0))) return 'patrimonio';
  return null;
}

function _wrappedPatrimonioAnio(S, anioK){
  const val = p => (typeof p.valorVisible === 'number') ? p.valorVisible : (p.valor||0);
  const cierres = S.patrimonioCierres || {};
  // Con el cierre de diciembre del año anterior el año se mide COMPLETO (la serie diaria se poda a 365 días y a mediados de enero ya no
  // conserva el 1 de enero). Sin él, se usa la serie diaria como siempre.
  const previo = cierres[(Number(anioK) - 1) + '-12'];
  const delAnio = Object.keys(cierres).filter(k => k.slice(0,4) === String(anioK)).sort();
  let inicio, fin, diff;
  if(previo && delAnio.length){
    inicio = val(previo);
    fin = val(cierres[delAnio[delAnio.length - 1]]);
    const baseAnio = delAnio.reduce((a, k) => a + (cierres[k].base || 0), 0);
    diff = (fin - inicio) - baseAnio;
  } else {
    const hist = (S.patrimonioHistorial || [])
      .filter(p => (p.fecha||'').slice(0,4) === anioK)
      .slice()
      .sort((a,b) => (a.fecha||'').localeCompare(b.fecha||''));
    if(hist.length < 2) return null;
    const primero = hist[0], ultimo = hist[hist.length-1];
    let montoBaseAcumulado = 0;
    hist.forEach(p => { if(p !== primero) montoBaseAcumulado += (p.montoBase||0); });
    inicio = val(primero); fin = val(ultimo);
    diff = (fin - inicio) - montoBaseAcumulado;
  }
  // Porcentaje solo sobre una base POSITIVA y proporcionada: sobre una base negativa o minúscula no significa nada (+39.900 % al empezar
  // con $5.000; −800 % al pasar de −$100.000 a −$900.000; «casi se duplicó» al pasar de −$900.000 a −$100.000, que sigue en deuda).
  // Sin porcentaje, el texto habla de montos y de cruzar el cero (ver _wrappedCopyPatrimonio). Tope de ±300 % para presentar uno.
  let pct = inicio > 0 ? (diff/inicio)*100 : null;
  if(pct !== null && Math.abs(pct) > UMBRALES.wrapped.patrimonio.tope) pct = null;
  // inicio/fin: el patrimonio visible al empezar y al terminar el año (para saber si se cruzó el cero).
  return { diff, pct, inicio, fin };
}

/* ─── Serie mensual de patrimonio (Enero → mes actual) para el gráfico
   animado ─────────────────────────────────────────────────────────────
   Un punto por mes: el último `valorVisible` conocido de ese mes
   (forward-fill desde el mes anterior si ese mes no tuvo snapshot propio).
   Los meses sin ningún dato todavía (ni propio ni heredado) se recortan
   del principio de la serie — no se puede graficar antes del primer dato
   real. */
function _wrappedSerieMensualAnio(S, anioK){
  const { anioActual, mesActualIdx } = _wrappedAnioYMesActual();
  const mesMax = (anioK === anioActual) ? mesActualIdx : 11;
  const hist = (S.patrimonioHistorial || [])
    .filter(p => p.fecha)
    .slice()
    .sort((a,b) => a.fecha.localeCompare(b.fecha));
  const val = p => (typeof p.valorVisible === 'number') ? p.valorVisible : (p.valor||0);

  let ultimoConocido = null;
  hist.forEach(p => { if(p.fecha.slice(0,4) < anioK) ultimoConocido = val(p); });

  const serie = [];
  for(let m=0; m<=mesMax; m++){
    const mesK = Fecha.mesKey(anioK, m+1);
    const puntosDelMes = hist.filter(p => p.fecha.slice(0,7) === mesK);
    if(puntosDelMes.length) ultimoConocido = val(puntosDelMes[puntosDelMes.length-1]);
    serie.push({ mesK, valor: ultimoConocido });
  }
  const primerIdxConDato = serie.findIndex(p => p.valor !== null);
  return primerIdxConDato === -1 ? [] : serie.slice(primerIdxConDato);
}

const _MES_NOMBRE = Fecha.MESES_CORTOS;
function _wrappedMesKaNombre(mesK){
  const partes = (mesK||'').split('-');
  const idx = parseInt(partes[1],10) - 1;
  return (_MES_NOMBRE[idx]||'') + ' ' + (partes[0]||'');
}
function _wrappedMesKaAbrev(mesK){
  const partes = (mesK||'').split('-');
  return _MES_NOMBRE[parseInt(partes[1],10)-1] || '';
}

const _MES_NOMBRE_LARGO = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
/* "7 de septiembre de 2026" — solo para el slide de intro (ver
   `_wrappedRangoFechasAnio`). Nunca se reusa el `_MES_NOMBRE` abreviado
   de arriba porque una fecha completa en una portada lee mejor en
   formato largo; son dos usos distintos, no una duplicación del mismo
   dato. */
function _wrappedFmtFechaLarga(fecha){
  if(!_wrappedFechaLuceValida(fecha)) return '';
  const partes = fecha.split('-');
  const dia = parseInt(partes[2],10);
  const mes = _MES_NOMBRE_LARGO[parseInt(partes[1],10)-1] || '';
  if(!mes || !Number.isFinite(dia)) return '';
  return `${dia} de ${mes} de ${partes[0]}`;
}

/* ─── RANGO EXACTO DE FECHAS CON DATOS (2026-09-14, pase de diseño) ─────
   Puramente para el slide de intro ("del 12 de enero al 6 de septiembre")
   — no es un cálculo financiero nuevo, solo un min/max de fechas ya
   presentes en estructuras que este archivo ya lee en otro lado
   (mismo criterio de "no duplicar" de wrapped.md §3, que habla de
   cifras de plata, no de fechas de portada). Reutiliza exactamente los
   mismos filtros de "gasto/ingreso real" que `_wrappedCalcularPeriodo`
   (vía `_wrappedItemsRealesPeriodo`) para no contar como "inicio de tus
   datos" un movimiento espejo o no-real que el resto del módulo ya
   ignora. Si no hay ni un solo dato válido en el año, devuelve `null` —
   el slide de intro simplemente no pinta la fecha (degradar, nunca
   romper, ver wrapped.md §3 último punto). */
function _wrappedRangoFechasAnio(S, anioK){
  const { gastosVarPeriodo, pagosFijosPeriodo } = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);
  const ingresosPeriodo = _wrappedEntradasIngreso(S).filter(m => _wrappedEnRango(m.fecha, 'anio', null, anioK));
  const fechas = [...gastosVarPeriodo, ...pagosFijosPeriodo, ...ingresosPeriodo]
    .map(x => x && x.fecha)
    .filter(_wrappedFechaLuceValida)
    .sort();
  if(!fechas.length) return null;
  return { inicio: fechas[0], fin: fechas[fechas.length-1] };
}

/* ═══════════════════════════════════════════════════════════════════════
   SISTEMA DE COPY CONTEXTUAL
   ═══════════════════════════════════════════════════════════════════════
   No es un "banco de frases" grande con variantes elegidas al azar para
   evitar repetición (eso se descartó a propósito, ver wrapped.md §7: hoy
   no hay más de un año de historia real, así que "no repetirse entre
   años" todavía no es un problema real de este usuario). Es más chico y
   más simple: cada texto se elige entre 2-4 variantes fijas según una
   señal derivada de los mismos datos ya calculados arriba (qué tan
   grande fue el cambio de patrimonio en %, qué tan dominante fue la
   categoría, cuánto se alejó el mejor/peor mes del promedio del propio
   usuario). El objetivo puntual es que la historia de un año donde
   "todo estuvo parejo" se lea distinto a la de un año con un quiebre
   fuerte — no que nunca se repita la misma frase.
   Ninguna de estas funciones calcula nada nuevo: todas reciben los
   mismos objetos que ya arma `_wrappedCalcularPeriodo` /
   `_wrappedMejorPeorMesAnio` / `_wrappedPatrimonioAnio`, para no crear
   una segunda fuente de verdad sobre esas cifras (ver `mis-finanzas.md`
   → "los movimientos son la fuente de verdad" / CHANGELOG.md → filtros
   duplicados de Análisis financiero). Solo deciden *cómo contarlo*.
   ═══════════════════════════════════════════════════════════════════════ */

/* ─── BANCO DE FRASES ("banco de ideas", 2026-09-14) ────────────────────
   Extiende el sistema de copy contextual de §7 sin contradecirlo: la
   rama que aplica (leve/fuerte/extremo, etc.) sigue eligiéndose por una
   señal real de los datos, exactamente igual que antes — eso es lo que
   carga información de verdad y wrapped.md §7 explícitamente decidió NO
   reemplazar por un sorteo. Lo único que agrega esta capa es variedad de
   REDACCIÓN dentro de cada rama: antes, caer en "patrimonio subió
   fuerte" siempre mostraba la misma oración exacta, año tras año. Ahora
   cada rama tiene 2-4 formas de decir lo mismo y se elige una.

   La elección es determinista, no un `Math.random()` suelto (rompería
   la regla de "sin estado nuevo" de §3 si alguna vez hiciera falta
   reproducir el mismo resumen, ej. al generar una tarjeta para
   compartir): la semilla sale de `s.totalIngresos`/`s.totalGastos` y el
   patrimonio del año — los mismos totales que `_wrappedCalcularPeriodo`
   ya calcula solo para uso interno (§3), nunca mostrados en pantalla.
   Mismos datos → mismas frases (no se siente "con bug" al tocar "Ver de
   nuevo"); otro año o otro usuario → frases distintas. Dentro de una
   misma apertura se evita repetir la frase exacta en dos slides
   distintos (`_wrappedFrasesUsadas`). Ver `_wrappedIniciarBanco`,
   llamada una vez al principio de `_wrappedBuildSlides`. */
let _wrappedBankSeed = '';
let _wrappedFrasesUsadas = null;

function _wrappedHashStr(str){
  let h = 0;
  for(let i=0;i<str.length;i++) h = (h*31 + str.charCodeAt(i)) | 0;
  return Math.abs(h);
}
/* Generador determinista simple (Park-Miller) — alcanza para elegir
   entre un puñado de frases, no hace falta nada más sofisticado. */
function _wrappedSeededRandom(seed){
  let s = seed % 2147483647;
  if(s <= 0) s += 2147483646;
  return function(){
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}
function _wrappedIniciarBanco(seedBase){
  _wrappedBankSeed = String(seedBase);
  _wrappedFrasesUsadas = new Set();
}
/* `disambiguador` es opcional — agrega entropía propia del dato en
   cuestión (ej. el mes, el nombre de la categoría o de la persona) para
   que dos claves distintas con el mismo `_wrappedBankSeed` no terminen
   sincronizadas en la misma posición del arreglo por casualidad. */
function _wrappedBankPick(key, opciones, disambiguador){
  if(!opciones || opciones.length === 0) return '';
  if(opciones.length === 1) return opciones[0];
  const rand = _wrappedSeededRandom(_wrappedHashStr(_wrappedBankSeed + '|' + key + '|' + (disambiguador||'')) || 1);
  let elegido, intentos = 0;
  do {
    elegido = opciones[Math.floor(rand() * opciones.length)];
    intentos++;
  } while(_wrappedFrasesUsadas && _wrappedFrasesUsadas.has(elegido) && intentos < 8);
  if(_wrappedFrasesUsadas) _wrappedFrasesUsadas.add(elegido);
  return elegido;
}

/* Antes era un texto fijo — ahora, mismo criterio que el resto del banco
   de frases (§_wrappedBankPick): varía entre aperturas sin depender de
   ningún dato nuevo, solo para que la pantalla de entrada no se sienta
   idéntica cada vez que se abre Wrapped. */
function _wrappedCopyIntro(){
  return _wrappedBankPick('intro-headline', [
    'A ver qué te tiene guardado tu propia plata.',
    'Repasemos qué hiciste con tu plata este año.',
    'Tenemos que hablar de lo que pasó con tu dinero.',
    'Esto es lo que hiciste con tu plata, con pruebas.',
    'Cada movimiento que registraste cuenta una historia. Esta es la tuya.',
    'Ni tú te acuerdas de todo esto. Por suerte, quedó registrado.',
    'Todo lo que anotaste este año, junto por primera vez.',
  ]);
}

/* Frases-puente sin dato: separan "capítulos" del wrapped (ancla → pool de
   insights → personalidad) sin calcular ni mostrar nada nuevo — mismo
   principio de §3 (nunca duplicar/inventar una cifra). `key` distingue el
   punto de la historia para que las dos pausas de una misma apertura no
   salgan siempre con la misma frase. */
function _wrappedCopyPuente(key){
  if(key === 'personalidad'){
    return _wrappedBankPick('puente-personalidad', [
      'Y con todo eso ya visto, una última pregunta.',
      'Antes de cerrar, juntemos todo esto en una sola idea.',
      'Ahora, la conclusión de todo lo anterior.',
    ]);
  }
  return _wrappedBankPick('puente-insights', [
    'Pero eso no es lo único interesante.',
    'Y aquí viene lo curioso.',
    'Hasta acá, todo esperable. Sigamos.',
    'Ahora, algunos datos que probablemente se te pasaron por alto.',
    'Hay más — y de acá en más se pone interesante.',
  ]);
}

/* ═══ WRAPPED SIN DATOS SUFICIENTES — «no alcanzó el tiempo» ═══
   Cuando el año no tiene datos suficientes (criterio en js/core/wrapped-gate.js, `_wrappedDatosAnio`), en vez de un Wrapped de 17
   diapositivas casi vacías se muestra un mensaje honesto, con humor suave y sin culpa: no se inventa nada. Dos niveles:
   'nada' (ningún registro) y 'poco' (hay algo, pero menos del mínimo; se muestra lo poco que hay). Las frases se eligen con el banco
   con semilla de siempre (`_wrappedBankPick`): para un mismo año y nivel siempre sale la misma, y no se repite ninguna dentro del mismo
   resumen. Marcadores: {anio} {dias} {registros} {desde} {minDias} {minMeses}. Texto en tuteo (lo vigila tests/estilos.test.js).
   Para sumar frases basta añadirlas aquí: la prueba exige un mínimo por lista y que todos los marcadores se resuelvan. */
const WRAPPED_BANCO_INSUFICIENTE = {
  nada: {
    titular: [
      'Este año no alcanzó el tiempo',
      'Aquí no hay nada que contar… todavía',
      'Llegamos tarde a {anio}',
      'Un {anio} en blanco',
      'Esta historia aún no empieza',
      'No pudimos armar tu {anio}',
      'El resumen quedó en pausa',
      'Hoja en blanco',
      'Aún no hay película que proyectar',
      'Nada que mostrar (todavía)',
      'Se nos acabó el tiempo antes de empezar',
      '{anio} pasó sin dejar datos',
    ],
    explica: [
      'No encontramos movimientos registrados en {anio}, así que no hay un resumen que armar.',
      'Para contar un año hace falta que el año quede registrado. En {anio} no llegó nada a la app.',
      'Sin registros no hay historia. Cuando empieces a anotar tus movimientos, aquí aparecerá tu resumen.',
      'La app no alcanzó a ver nada de {anio}. No pasa nada: se empieza cuando se quiere.',
      'Estábamos listos, pero {anio} no dejó datos con los que trabajar.',
      'Un resumen necesita materia prima, y de {anio} no tenemos ni una pizca.',
      'No hay movimientos de {anio}. Prometemos no inventar nada.',
      'Todo en orden con las cuentas: simplemente no hay cuentas que contar de {anio}.',
    ],
  },
  poco: {
    titular: [
      'No alcanzó el tiempo',
      'Tu {anio} apenas empezaba',
      'Llegamos a ver solo un pedacito',
      'Todavía no hay mucho que contar',
      'El año se acabó antes de que arrancáramos',
      'Un resumen a medio hacer',
      'Esto fue más un tráiler que una película',
      'Faltó cuerda para contar {anio}',
      'No pudimos completar tu {anio}',
      'Un {anio} corto de datos',
      'Poco material, mucha buena intención',
      'Apenas alcanzamos a calentar motores',
    ],
    explica: [
      'Solo alcanzamos a ver {dias} con registros, desde el {desde}. Para un resumen completo necesitamos al menos {minDias} días en {minMeses} meses distintos.',
      'Con {registros} en {dias} no alcanza para contar una historia. Hacen falta al menos {minDias} días distintos en {minMeses} meses.',
      'Empezaste a registrar el {desde}. Es un buen comienzo, pero {anio} se acabó antes de juntar suficiente.',
      'Un resumen honesto necesita más que {dias} de datos. Preferimos no inventar lo que no vimos.',
      'Lo que hay es poco para sacar conclusiones, y no queremos adivinar tu año.',
      'Vimos {registros} desde el {desde}: la punta del iceberg, pero no el iceberg.',
      'Con tan pocos días registrados, cualquier conclusión sería pura imaginación. Mejor esperar al próximo.',
      'Esto se parece más a un boceto que a un retrato. Con más días registrados, el próximo sale completo.',
    ],
  },
  promesa: [
    'El próximo enero lo contamos completo.',
    'Sigue registrando y el año que viene hay función.',
    'Nos vemos el próximo enero, con más datos y mejores historias.',
    'Cada movimiento que anotes hoy es una escena del próximo resumen.',
    'Esto apenas empieza. El próximo Wrapped va a tener mucho más que decir.',
    'Dale tiempo al tiempo: en enero hablamos.',
    'Tu próximo año ya está empezando. Que quede registrado.',
    'No es un adiós, es un «hasta el próximo enero».',
    'Prepara las palomitas: el próximo año sí hay película.',
    'Un poquito cada día y en enero habrá mucho que mostrar.',
    'Esta vez no alcanzó; la próxima, con tus datos, seguro que sí.',
    'Guardamos tu lugar para el próximo enero.',
  ],
};

function _wrappedSlidesInsuficiente(datos, anioK){
  const tier = datos.tier === 'nada' ? 'nada' : 'poco';
  _wrappedIniciarBanco('insuf|' + anioK + '|' + tier); // misma semilla → mismas frases al volver a abrirlo
  const banco = WRAPPED_BANCO_INSUFICIENTE[tier];
  const n = v => Number(v).toLocaleString('es-CO');
  const dias = n(datos.dias || 0) + ((datos.dias || 0) === 1 ? ' día' : ' días');
  const registros = n(datos.registros || 0) + ((datos.registros || 0) === 1 ? ' movimiento' : ' movimientos');
  const desde = datos.primera ? _fechaSafe(datos.primera, 12).toLocaleDateString('es-CO', { day: 'numeric', month: 'long' }) : '';
  const um = (typeof window !== 'undefined' && window._wrappedUmbrales) || { dias: 30, meses: 3 };
  const valores = { anio: anioK, dias, registros, desde, minDias: um.dias, minMeses: um.meses };
  const llenar = txt => escHtml(txt.replace(/\{(\w+)\}/g, (m, k) => (k in valores ? valores[k] : m)));
  const titular = llenar(_wrappedBankPick('insuf-titular-' + tier, banco.titular));
  const explica = llenar(_wrappedBankPick('insuf-explica-' + tier, banco.explica));
  const promesa = llenar(_wrappedBankPick('insuf-promesa', WRAPPED_BANCO_INSUFICIENTE.promesa));

  const slides = [{
    id: 'insuf-titular', mood: 'amber',
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-eyebrow">Tu ${anioK}</div>
      <div class="wrapped-headline">${titular}</div>
      <div class="wrapped-sub">${explica}</div>
    </div>`
  }];
  if(tier === 'poco'){
    slides.push({
      id: 'insuf-lo-que-hay', mood: 'accent',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Lo poco que alcanzamos a ver</div>
        <div class="wrapped-headline">Esto fue lo que vimos</div>
        <div class="wrapped-pill-list">
          <span class="wrapped-pill">${escHtml(dias)} con registros</span>
          <span class="wrapped-pill">${escHtml(registros)}</span>
          ${desde ? `<span class="wrapped-pill">Desde el ${escHtml(desde)}</span>` : ''}
        </div>
      </div>`
    });
  }
  slides.push({
    id: 'insuf-cierre', mood: 'purple',
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-tag"><i class="fa-solid fa-tag"></i> Wrapped ${anioK}</div>
      <div class="wrapped-eyebrow">Para el próximo</div>
      <div class="wrapped-headline">${promesa}</div>
      <div class="wrapped-cta-row">
        <button type="button" class="wrapped-cta" data-wrapped-action="replay">Ver de nuevo</button>
        <button type="button" class="wrapped-cta ghost" data-wrapped-action="cerrar">Cerrar</button>
      </div>
    </div>`
  });
  return slides;
}

/* ═══ WRAPPED GUARDADO POR AÑO ═══
   `S.wrappedAnios[AAAA] = { version, generadoEn, slides:[{id,mood,confetti?,html}] }` — el HTML ya armado de cada diapositiva
   (≈ 4,5 KB comprimidos por año). Guardar es una ACCIÓN EXPLÍCITA del usuario (botón «Guardar este Wrapped» en la última diapositiva):
   abrir el Wrapped, aunque sea mil veces, no guarda nada. Si no se guarda, se pierde al cerrar la ventana de enero (modelo Spotify).
   Un Wrapped guardado se puede ver siempre y se puede ELIMINAR (Configuración → Mis Wrapped, con confirmación y PIN). Mientras la ventana
   de enero siga abierta, al abrir uno guardado se recalcula y se reemplaza (así entra un movimiento de diciembre añadido tarde); pasada la
   ventana queda fijo. Esto separa tres operaciones antes mezcladas en renderWrapped: generar (`_wrappedBuildSlides`), guardar
   (`_wrappedGuardar`) y mostrar (`renderWrapped`). El mensaje «no alcanzó el tiempo» NUNCA se guarda: no hay nada que recordar.
   El recuerdo no depende del detalle (que un cierre de períodos puede podar) ni cambia si cambian las reglas de cálculo.
   Lo que depende de quien mira y no del año — el desenfoque de «Ocultar saldos» — NO se congela: se quita al guardar y se aplica al mostrar.
   OJO, contrato de CSS: el HTML guardado usa clases (wrapped-*, c-*, fa-*) que viven en este archivo/styles.css; renombrar una rompe en
   silencio los recuerdos viejos. tests/wrapped-guardado.test.js lo vigila con una instantánea de referencia (solo se pueden AÑADIR clases). */
const WRAPPED_SNAPSHOT_VERSION = 1;

// Botón de la última diapositiva. Se intercambia por su versión «Guardado» cuando el año ya está guardado (y así se guarda el HTML).
const _WRAPPED_BTN_GUARDAR = '<button type="button" class="wrapped-cta" data-wrapped-action="guardar">Guardar este Wrapped</button>';
const _WRAPPED_BTN_GUARDADO = '<button type="button" class="wrapped-cta ghost" disabled>Guardado</button>';
function _wrappedMarcarGuardado(slides){
  return slides.map(sl => (sl.id === 'cierre' ? Object.assign({}, sl, { html: sl.html.replace(_WRAPPED_BTN_GUARDAR, _WRAPPED_BTN_GUARDADO) }) : sl));
}

function _wrappedSinMascara(html){ return html.replace(/\s*\bsaldo-hidden\b/g, ''); }
function _wrappedConMascara(html){
  return html.replace(/class="(wrapped-bignum [^"]*?)"/, (m, c) => (/saldo-hidden/.test(c) ? m : 'class="' + c + ' saldo-hidden"'));
}

function _wrappedSnapshotDe(slides){
  return {
    version: WRAPPED_SNAPSHOT_VERSION,
    generadoEn: hoy(),
    slides: _wrappedMarcarGuardado(slides).map(sl => {
      const o = { id: sl.id, html: _wrappedSinMascara(sl.html) };
      if(sl.mood) o.mood = sl.mood;
      if(sl.confetti) o.confetti = true;
      return o;
    })
  };
}

// Guardar un año (acción explícita del usuario): reemplaza el guardado de ese año si lo había. Nunca se llama con el mensaje de «no alcanzó».
function _wrappedGuardar(S, anioK, slides){
  if(slides.some(sl => sl.id === 'insuf-titular')) throw new Error('El mensaje «no alcanzó el tiempo» no se guarda');
  if(!S.wrappedAnios) S.wrappedAnios = {};
  S.wrappedAnios[anioK] = _wrappedSnapshotDe(slides);
  if(typeof save === 'function') save();
}

// Las diapositivas guardadas listas para pintar: aquí sí se aplica la preferencia actual de ocultar saldos.
function _wrappedSlidesDeSnapshot(snap){
  const ocultar = _wrappedSaldosOcultos();
  return snap.slides.map(sl => Object.assign({}, sl, { html: (ocultar && sl.id === 'alcancia') ? _wrappedConMascara(sl.html) : sl.html }));
}

// Frase sobre el patrimonio del año. `ctx` (opcional): { balance, gastoMasGrande } del año, para explicar la CAUSA de una caída.
function _wrappedCopyPatrimonio(patrimonio, ctx){
  const { diff, pct, inicio, fin } = patrimonio;
  const sabeCero = Number.isFinite(inicio) && Number.isFinite(fin);
  const aRojos = sabeCero && inicio >= 0 && fin < 0;   // cruzó a deuda
  const deRojos = sabeCero && inicio < 0 && fin >= 0;  // salió de deuda
  const sigueRojos = sabeCero && inicio < 0 && fin < 0;
  let frase;
  if(aRojos){
    frase = _wrappedBankPick('patrimonio-entraRojos', [
      'terminaste el año debiendo más de lo que tienes.',
      'tu patrimonio cruzó a números rojos este año.',
      'este año pasaste de tener a deber más de lo que tienes.',
    ]);
  } else if(deRojos){
    frase = _wrappedBankPick('patrimonio-saleRojos', [
      'saliste de números rojos este año.',
      'empezaste debiendo más de lo que tenías y terminaste con el patrimonio en positivo.',
      'este año dejaste atrás los números rojos.',
    ]);
  } else if(sigueRojos){
    frase = diff >= 0
      ? _wrappedBankPick('patrimonio-rojosMejora', [
          'sigues debiendo más de lo que tienes, pero la deuda neta bajó este año.',
          'tu patrimonio sigue en números rojos, aunque terminó menos hundido que al empezar.',
        ])
      : _wrappedBankPick('patrimonio-rojosEmpeora', [
          'terminaste el año debiendo más que al empezarlo.',
          'tu patrimonio siguió en números rojos y se hundió más este año.',
        ]);
  } else if(pct === null){
    frase = diff >= 0
      ? _wrappedBankPick('patrimonio-sinBase-sube', [
          'tu patrimonio creció este año.',
          'tu patrimonio terminó más arriba de donde empezó.',
          'este año tu patrimonio fue para arriba.',
        ])
      : _wrappedBankPick('patrimonio-sinBase-baja', [
          'tu patrimonio bajó este año.',
          'tu patrimonio terminó más abajo de donde empezó.',
          'este año tu patrimonio fue para abajo.',
        ]);
  } else {
    const pctTxt = Math.abs(Math.round(pct));
    if(diff >= 0){
      if(pct >= UMBRALES.wrapped.patrimonio.crecimientoFuerte) frase = _wrappedBankPick('patrimonio-fuerte', [
        `fue un año grande: tu patrimonio subió +${pctTxt}%.`,
        `+${pctTxt}%. Este año tu patrimonio jugó en otra liga.`,
        pct >= 90 ? `tu patrimonio casi se duplicó este año (+${pctTxt}%).` : `tu patrimonio creció más de la mitad este año (+${pctTxt}%).`,
        `pocas veces un año rinde +${pctTxt}% — este fue de esos.`,
      ]);
      else if(pct >= UMBRALES.wrapped.patrimonio.crecimientoMedio) frase = _wrappedBankPick('patrimonio-medio', [
        `tu patrimonio creció con fuerza este año (+${pctTxt}%).`,
        `+${pctTxt}% de crecimiento — nada de qué quejarse.`,
        `este año tu plata trabajó de verdad (+${pctTxt}%).`,
      ]);
      else frase = _wrappedBankPick('patrimonio-leve', [
        `tu patrimonio subió un poco este año (+${pctTxt}%).`,
        `+${pctTxt}%, sin hacer ruido pero yendo para arriba.`,
        `no fue un año explosivo, pero tu patrimonio sí subió (+${pctTxt}%).`,
      ]);
    } else if(pct <= -UMBRALES.wrapped.patrimonio.caidaFuerte) frase = _wrappedBankPick('patrimonio-cayoFuerte', [
      `este año le exigiste bastante al bolsillo (-${pctTxt}%).`,
      `-${pctTxt}%. Este año pesó, y se nota.`,
      `no fue un año fácil para tu patrimonio (-${pctTxt}%).`,
    ]);
    else if(pct <= -UMBRALES.wrapped.patrimonio.caidaLeve) frase = _wrappedBankPick('patrimonio-cayoModerado', [
      `tu patrimonio bajó este año (-${pctTxt}%): vale la pena mirar por qué.`,
      `-${pctTxt}%. No fue un buen año para tu patrimonio.`,
      `tu patrimonio cerró un ${pctTxt}% más abajo de donde empezó.`,
    ]);
    else frase = _wrappedBankPick('patrimonio-cayoLeve', [
      `tu patrimonio bajó un poco este año (-${pctTxt}%).`,
      `-${pctTxt}%, una caída pequeña.`,
      `apenas bajó (-${pctTxt}%).`,
    ]);
  }
  // Causa de la caída (solo si bajó y se conocen los datos del año): una compra, o gastar más de lo ingresado, o algo que no explican
  // los ingresos y gastos (deudas, ajustes). Sin esto la frase solo decía CUÁNTO bajó.
  if(diff < 0 && ctx){
    const caida = -diff, g = ctx.gastoMasGrande;
    if(g && g.monto > 0 && g.monto >= UMBRALES.wrapped.compraExplicaCaida * caida){
      frase += ` Casi toda la caída fue por una compra: ${escHtml(String(g.desc || 'un gasto'))} (${fmt(g.monto)}).`;
    } else if(Number.isFinite(ctx.balance)){
      frase += ctx.balance < 0
        ? ` Gastaste ${fmt(-ctx.balance)} más de lo que ingresaste.`
        : ' Tus ingresos superaron tus gastos, pero el patrimonio bajó: revisa deudas o ajustes.';
    }
  }
  return frase;
}

function _wrappedCopyCategoria(topCategoria){
  const share = topCategoria.catShare || 0;
  let base;
  if(share >= 0.4) base = _wrappedBankPick('categoria-dominante', [
    'Le diste con todo a esta categoría — fue, por lejos, la que más plata se llevó.',
    'Esta categoría no tuvo competencia real este año.',
    'Ganó por goleada: ninguna otra categoría se le acercó.',
  ], topCategoria.cat);
  else if(share >= 0.2) base = _wrappedBankPick('categoria-fuerte', [
    'Fue la que más plata se llevó este año.',
    'Se llevó la mayor tajada de tu gasto.',
    'Ninguna otra categoría gastó tanto como esta.',
  ], topCategoria.cat);
  else base = _wrappedBankPick('categoria-normal', [
    'Fue la categoría donde más gastaste este año.',
    'De todas, esta fue la que más te costó.',
    'La que más veces vio salir tu plata.',
  ], topCategoria.cat);
  // Si la categoría que más se REPITIÓ es otra distinta a la que más
  // plata consumió (ver `_wrappedTopCategoriaDe`), vale la pena
  // mencionarlo — "gastaste más en viajes, pero mercado fue con la que
  // más veces pagaste" cuenta una historia distinta a solo el monto.
  if(topCategoria.topPorFrecuencia){
    base += ' ' + _wrappedBankPick('categoria-frecuencia', [
      `Aunque la que más se repitió fue ${escHtml(topCategoria.topPorFrecuencia.cat)}.`,
      `Eso sí — la que más veces pagaste fue ${escHtml(topCategoria.topPorFrecuencia.cat)}.`,
      `Frecuencia y monto no coincidieron: la más repetida fue ${escHtml(topCategoria.topPorFrecuencia.cat)}.`,
    ], topCategoria.topPorFrecuencia.cat);
  }
  return base;
}

// `fmt2` (2026-09-15, ver §3 nota junto al slide "actividad"): se agrega
// SOLO para poder narrar el desglose puntual de ESTE mes (ingresos y
// gastos de un mes concreto ya era un highlight permitido vía `balance`;
// esto simplemente lo hace explícito en vez de dejarlo implícito en la
// cifra grande) — no cambia qué se calcula, solo cómo se cuenta. Ninguna
// otra función `_wrappedCopy*` necesitaba `fmt2` porque ninguna otra
// agrega un desglose de plata dentro del texto, solo la cifra grande ya
// formateada por `_wrappedSlideBignum`.
function _wrappedCopyMejorMes(mejor, promedio, empate, fmt2){
  let base;
  if(empate) base = _wrappedBankPick('mejorMes-empate', [
    'empatado con otro mes — los dos fueron tu mejor resultado del año.',
    'no hubo un solo ganador: este mes empató el primer lugar.',
    'compartió la corona con otro mes — un empate en la cima.',
  ], mejor.mesK);
  else if(promedio !== null && promedio > 0 && mejor.balance > promedio * 1.5){
    base = _wrappedBankPick('mejorMes-lejos', [
      'muy por encima de tu ritmo normal.',
      'se salió por completo de tu promedio — para bien.',
      'nada que ver con un mes cualquiera.',
    ], mejor.mesK);
  }
  else if(mejor.balance > 0) base = _wrappedBankPick('mejorMes-positivo', [
    'tu mes con mejor resultado del año.',
    'el mes que más plata te dejó.',
    'el que se lleva la corona este año.',
  ], mejor.mesK);
  else base = _wrappedBankPick('mejorMes-menosMalo', [
    'el menos difícil de todos — que también cuenta.',
    'no fue positivo, pero fue el que menos dolió.',
  ], mejor.mesK);
  return base + _wrappedCopyDesgloseMes(mejor, fmt2);
}

function _wrappedCopyPeorMes(peor, promedio, empate, fmt2){
  let base;
  if(empate) base = _wrappedBankPick('peorMes-empate', [
    'empatado con otro mes — ninguno de los dos fue fácil.',
    'dos meses se pelearon el último lugar.',
    'compartió el podio menos deseado con otro mes.',
  ], peor.mesK);
  else if(peor.balance >= 0) base = _wrappedBankPick('peorMes-noTanMal', [
    'y ni en tu peor mes te fue mal.',
    'el "peor" mes del año y aun así cerró positivo.',
    'hasta tu mes más flojo se mantuvo en verde.',
  ], peor.mesK);
  else if(promedio !== null && promedio > 0 && peor.balance < promedio * -0.5){
    base = _wrappedBankPick('peorMes-lejos', [
      'se salió bastante de tu ritmo normal.',
      'nada que ver con cómo te fue el resto del año.',
    ], peor.mesK);
  }
  else base = _wrappedBankPick('peorMes-normal', [
    'tu mes más ajustado del año.',
    'el que más apretó el bolsillo.',
    'el mes que costó un poco más sostener.',
  ], peor.mesK);
  return base + _wrappedCopyDesgloseMes(peor, fmt2);
}

/* Frase compartida entre mejor/peor mes: "con $X de ingresos y $Y en
   gastos" — es lo que hoy le falta al slide para no sentirse "solo un
   número con una etiqueta": conecta el balance grande con de dónde salió.
   Degrada a cadena vacía si `fmt2` no llegó o los datos no están (meses
   viejos donde `_wrappedMejorPeorMesAnio` no los haya calculado). */
function _wrappedCopyDesgloseMes(mesObj, fmt2){
  if(typeof fmt2 !== 'function' || !Number.isFinite(mesObj.ingresos) || !Number.isFinite(mesObj.gastos)) return '';
  return ' Cerró con ' + fmt2(mesObj.ingresos) + ' de ingresos y ' + fmt2(mesObj.gastos) + ' en gastos.';
}

/* Contextualiza el gasto más grande: en qué mes fue y qué tan grande fue
   *en relación al propio gasto típico del usuario* (nunca contra un
   umbral fijo en pesos, que no tendría sentido entre personas con gastos
   de escalas muy distintas). */
// `totalGastosAnio` (2026-09-15) se usa EXACTAMENTE como `catShare` en
// `_wrappedCopyCategoria`: solo para derivar una proporción a mostrar
// ("representó el X% de tus gastos"), nunca se pinta el total en crudo —
// mismo criterio ya aceptado por §3, no una excepción nueva.
function _wrappedCopyGasto(gastoMasGrande, avgGasto, totalGastosAnio){
  const mesTxt = gastoMasGrande.fecha ? _wrappedMesKaNombre(gastoMasGrande.fecha.slice(0,7)) : null;
  const pctTotal = (totalGastosAnio > 0) ? Math.round(gastoMasGrande.monto / totalGastosAnio * 100) : null;
  const clausulaPct = (pctTotal !== null && pctTotal >= 1)
    ? ` Representó el ${pctTotal}% de todo lo que gastaste este año.`
    : '';
  let intensidad;
  if(avgGasto > 0 && gastoMasGrande.monto >= avgGasto * 5){
    const veces = Math.round(gastoMasGrande.monto / avgGasto);
    intensidad = _wrappedBankPick('gasto-extremo', [
      `${veces} veces más grande que tu gasto promedio — muchísimo más que cualquiera de tus otros gastos del año.`,
      `${veces} veces tu gasto típico. En otra categoría, literalmente.`,
      `nada se le acerca: ${veces} veces por encima de lo que gastas normalmente.`,
    ], gastoMasGrande.desc);
  } else if(avgGasto > 0 && gastoMasGrande.monto >= avgGasto * 2){
    const veces = (gastoMasGrande.monto / avgGasto).toFixed(1).replace(/\.0$/,'');
    intensidad = _wrappedBankPick('gasto-alto', [
      `${veces} veces tu gasto típico.`,
      `${veces} veces más de lo que gastas normalmente.`,
      `${veces} veces por encima de lo habitual — se notó.`,
    ], gastoMasGrande.desc);
  } else {
    intensidad = _wrappedBankPick('gasto-normal', [
      'el que más te costó este año.',
      'tu gasto más grande del año, sin más vueltas.',
    ], gastoMasGrande.desc);
  }
  if(!mesTxt) return (intensidad.charAt(0).toUpperCase() + intensidad.slice(1)) + clausulaPct;
  return _wrappedBankPick('gasto-conector', [
    `Pasó en ${mesTxt} — ${intensidad}`,
    `Fue en ${mesTxt}: ${intensidad}`,
    `${mesTxt} se llevó el título — ${intensidad}`,
  ], mesTxt) + clausulaPct;
}

function _wrappedCopyAlcancia(alcanciaPeriodo, gastoMasGrande, ciclos){
  // `ciclos` (2026-09-15): cuántas "alcancías" distintas aportaron a esta
  // cifra (ciclo activo con depósitos + ciclos ya destapados este año,
  // ver el conteo en `_wrappedCalcularPeriodo`). Con 2+ se aclara antes
  // que nada — si no, el número se lee como si viniera de una sola
  // alcancía continua, y no siempre es así.
  const notaCiclos = (Number.isFinite(ciclos) && ciclos >= 2)
    ? ' ' + _wrappedBankPick('alcancia-variosCiclos', [
        `Repartido en ${ciclos} alcancías distintas este año.`,
        `Fue la suma de ${ciclos} ciclos de Alcancía distintos.`,
        `No fue de una sola vez — sumó entre ${ciclos} ciclos distintos.`,
      ])
    : '';
  if(gastoMasGrande && alcanciaPeriodo >= gastoMasGrande.monto){
    const descSeguro = gastoMasGrande.desc ? escHtml(gastoMasGrande.desc) : null;
    const gastoTxt = descSeguro ? '"'+descSeguro+'"' : 'tu gasto más grande';
    return _wrappedBankPick('alcancia-superaGasto', [
      `Eso es más de lo que gastaste en ${gastoTxt}, tu compra más grande del año.`,
      `Ahorraste más de lo que costó ${gastoTxt} — tu gasto más grande del año.`,
      `Sí: guardaste más plata de la que se fue en ${gastoTxt}.`,
    ], gastoMasGrande.desc) + notaCiclos;
  }
  return _wrappedBankPick('alcancia-generica', [
    'una plata que, sin la Alcancía, seguramente ni hubieras notado que tenías.',
    'plata que se fue guardando sin que la extrañaras.',
    'ahorro que pasó casi desapercibido, pero ahí está.',
  ]) + notaCiclos;
}

function _wrappedCopyRacha(racha){
  if(racha >= 6) return _wrappedBankPick('racha-larga', [
    'Eso ya no es suerte, es una costumbre.',
    'A esta altura, ya es un hábito instalado.',
    'Ya no es racha, es tu forma de ahorrar.',
  ], racha);
  if(racha >= 4) return _wrappedBankPick('racha-media', [
    'vas agarrando el ritmo.',
    'ya le encontraste la vuelta.',
    'se está empezando a notar la constancia.',
  ], racha);
  return _wrappedBankPick('racha-corta', [
    'cada una ahorrando más que la anterior.',
    'un buen comienzo de racha.',
    'apenas arrancando, pero arrancando bien.',
  ], racha);
}

/* Línea de cierre: se arma en base a "señales" (candidatas, con
   prioridad) derivadas de lo que ya se calculó para el resto de la
   historia — se elige la primera que aplique, nunca al azar, para que el
   cierre siempre hable de lo más notable que realmente pasó ese año.
   Dentro de la señal elegida sí hay banco de variantes (ver cabecera de
   sección), igual que el resto del sistema de copy. */
function _wrappedCopyCierre(ctx){
  const { anioK, patrimonio, racha, s, gastoMasGrande } = ctx;

  if(patrimonio && patrimonio.pct !== null && patrimonio.pct >= 50){
    return _wrappedBankPick('cierre-patrimonioFuerte', [
      `¿${anioK}? El año en que tu patrimonio casi se duplicó.`,
      `${anioK} en una línea: tu patrimonio se disparó.`,
      `El año en que tu plata dio un salto grande. Eso fue ${anioK}.`,
    ], anioK);
  }
  if(racha >= 4){
    return _wrappedBankPick('cierre-racha', [
      `${anioK} fue el año de la racha: ${racha} alcancías seguidas mejorando.`,
      `${racha} alcancías seguidas — así se resume tu ${anioK}.`,
      `Si ${anioK} fue algo, fue constancia: ${racha} alcancías seguidas.`,
    ], anioK);
  }
  if(patrimonio && patrimonio.pct !== null && patrimonio.pct <= -25){
    return _wrappedBankPick('cierre-patrimonioCayo', [
      `${anioK} no fue el año de acumular. Fue el año de sostener — y eso también cuenta.`,
      `${anioK} pesó, pero seguiste de pie.`,
    ], anioK);
  }
  if(s.alcanciaPeriodo > 0 && gastoMasGrande && s.alcanciaPeriodo >= gastoMasGrande.monto){
    return _wrappedBankPick('cierre-ahorroSuperaGasto', [
      `${anioK}: el año en que ahorraste más de lo que gastaste en tu compra más grande.`,
      `${anioK}, resumido: guardaste más de lo que gastaste en grande.`,
      `${anioK} en números: tu ahorro le ganó a tu gasto más grande.`,
    ], anioK);
  }
  if(s.topCategoria && (s.topCategoria.catShare||0) >= 0.4){
    return _wrappedBankPick('cierre-categoria', [
      `${anioK}, resumido en una palabra: ${escHtml(s.topCategoria.cat)}.`,
      `Si ${anioK} fuera una palabra, sería ${escHtml(s.topCategoria.cat)}.`,
      `${escHtml(s.topCategoria.cat)} — así se llamó ${anioK}, si tuviera que ponerle un nombre.`,
    ], anioK + s.topCategoria.cat);
  }
  return _wrappedBankPick('cierre-generico', [
    `Eso fue ${anioK}. Nos vemos el año que viene.`,
    `${anioK}, en el archivo. Hasta el próximo resumen.`,
    `Ese fue tu ${anioK}. Gracias por seguir registrando.`,
  ], anioK);
}

/* Copy de los dominios "de terceros" — mismo criterio que el resto del
   sistema de copy: solo eligen el tono, nunca recalculan nada. */
function _wrappedCopyEncargos(e, fmt2){
  if(e.nPersonas > 1){
    // Antes, con 2+ personas, `topEncargo` (quién te encargó más) se
    // calculaba pero nunca se mencionaba — solo se usaba cuando había
    // una sola persona. Ahora se agrega como frase extra, igual que ya
    // hace `_wrappedCopyPrestado` con su `topDeudor` sin importar cuántas
    // personas hubo en total.
    const detalleTop = (e.topEncargo && e.topEncargo.nombre)
      ? ' ' + _wrappedBankPick('encargos-top', [
          `La mayor parte te la encargó ${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)}${(typeof fmt2 === 'function' && Number.isFinite(e.topEncargo.monto)) ? `, con ${fmt2(e.topEncargo.monto)}` : ''}.`,
          `Quien más confió en ti para guardarle plata fue ${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)}.`,
          `${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)} fue quien más plata te encargó cuidar.`,
        ], e.topEncargo.nombre)
      : '';
    return _wrappedBankPick('encargos-varias', [
      `Repartida entre ${e.nPersonas} personas que confiaron en ti para guardarla.`,
      `${e.nPersonas} personas te encargaron su plata este año.`,
    ], e.nPersonas) + detalleTop;
  }
  if(e.topEncargo && e.topEncargo.nombre) return _wrappedBankPick('encargos-una', [
    `La mayor parte te la encargó ${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)}.`,
    `Fue ${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)} quien más confió en ti para guardarle plata.`,
    `${_wrappedNombrePersona(e.topEncargo.personaId, e.topEncargo.nombre)} te encargó su plata todo el año.`,
  ], e.topEncargo.nombre);
  return _wrappedBankPick('encargos-generica', [
    'Plata ajena que pasó por tus manos este año.',
    'Este año también cuidaste plata que no era tuya.',
  ]);
}
function _wrappedCopyPrestado(p, fmt2){
  if(p.topDeudor && p.topDeudor.nombre){
    const nombre = _wrappedNombrePersona(p.topDeudor.personaId, p.topDeudor.nombre);
    const detalle = (typeof fmt2 === 'function' && Number.isFinite(p.topDeudor.n))
      ? `, con ${fmt2(p.topDeudor.monto)} prestados en ${p.topDeudor.n} movimiento${p.topDeudor.n===1?'':'s'}`
      : '';
    return _wrappedBankPick('prestado-topDeudor', [
      `Tu cliente más frecuente fue ${nombre}${detalle}.`,
      `${nombre} fue quien más confió en tu "banco" este año${detalle}.`,
      `A ${nombre} fue a quien más le prestaste${detalle}.`,
    ], p.topDeudor.nombre);
  }
  if(p.totalDevuelto >= p.totalPrestado && p.totalDevuelto > 0) return _wrappedBankPick('prestado-cobradoTodo', [
    'Y este año te pagaron más de lo que prestaste.',
    'Y salieron las cuentas: te devolvieron más de lo que prestaste.',
    'Este año la balanza quedó a tu favor: cobraste más de lo que prestaste.',
  ]);
  return _wrappedBankPick('prestado-generica', [
    'Plata que le diste una mano a alguien más.',
    'Este año le tendiste la mano a alguien con plata.',
  ]);
}
function _wrappedCopyMisDeudas(m){
  if(m.totalPagado >= m.totalRecibido && m.totalPagado > 0) return _wrappedBankPick('misDeudas-pagoTodo', [
    'Y este año pagaste más de lo que te prestaron.',
    'Cuentas saldadas: pagaste más de lo que te prestaron.',
    'Le metiste parejo: pagaste incluso más de lo que recibiste.',
  ]);
  return _wrappedBankPick('misDeudas-generica', [
    'Plata que alguien más te prestó a ti.',
    'Este año también recibiste una mano de alguien.',
    'Este año también hubo quien te tendió la mano con plata.',
  ]);
}
function _wrappedCopyMesada(m){
  const partes = [];
  if(m.porPadre.papa) partes.push('papá');
  if(m.porPadre.mama) partes.push('mamá');
  if(partes.length === 2) return _wrappedBankPick('mesada-ambos', [
    'Entre papá y mamá, sin faltar un mes.',
    'Papá y mamá, mes tras mes, sin fallar.',
    'Los dos, papá y mamá, cumplieron todo el año.',
  ]);
  return _wrappedBankPick('mesada-uno', [
    `De parte de ${partes[0]}.`,
    `${partes[0].charAt(0).toUpperCase()+partes[0].slice(1)} no falló ni un mes.`,
    `Todo vino de ${partes[0]}, sin excepción.`,
  ], partes[0]);
}
function _wrappedCopySpotify(s, fmt2){
  // `fmt2` (2026-09-15, mismo criterio que `_wrappedCopyDesgloseMes`):
  // solo para narrar el desglose cobrado/pagado del período — ambos ya
  // eran cifras permitidas por wrapped.md §7ter (el balance ya se
  // mostraba), esto solo las hace explícitas en vez de dejarlas
  // implícitas en el neto.
  const detalle = (typeof fmt2 === 'function' && Number.isFinite(s.cobrado) && Number.isFinite(s.pagado))
    ? ` Cobraste ${fmt2(s.cobrado)} y pagaste ${fmt2(s.pagado)} por la cuenta compartida.`
    : '';
  if(s.balance > 0) return _wrappedBankPick('spotify-favor', [
    'Administrar la cuenta te dejó plata a favor este año.',
    'Cobraste más de lo que pagaste por la cuenta compartida.',
    'Ser el administrador de la cuenta te salió rentable este año.',
  ]) + detalle;
  if(s.balance < 0) return _wrappedBankPick('spotify-contra', [
    'Este año pusiste algo de tu bolsillo para cubrir la cuenta.',
    'Este año la cuenta te costó un poco de tu propio bolsillo.',
    'Administrar la cuenta este año te salió del propio bolsillo.',
  ]) + detalle;
  return _wrappedBankPick('spotify-parejo', [
    'Cobraste y pagaste el plan, sin ganar ni perder.',
    'La cuenta quedó exactamente pareja este año.',
    'Ni ganaste ni perdiste con la cuenta compartida — quedó justa.',
  ]) + detalle;
}
function _wrappedCopyComprometida(c){
  if(c.topItem && c.topItem.desc) return _wrappedBankPick('comprometida-item', [
    `La más grande fue "${escHtml(c.topItem.desc)}".`,
    `Nada le ganó a "${escHtml(c.topItem.desc)}" este año.`,
    `La que más pesó fue "${escHtml(c.topItem.desc)}".`,
  ], c.topItem.desc);
  return _wrappedBankPick('comprometida-generica', [
    'Plata que estabas esperando y por fin llegó.',
    'Plata comprometida que finalmente cayó este año.',
    'Esperaste, pero al final llegó.',
  ]);
}

function _wrappedCopyInteresesTC(it){
  const detalleTarjeta = (it.topTarjeta && it.topTarjeta.nombre)
    ? ` La mayor parte se la llevó ${escHtml(it.topTarjeta.nombre)}.`
    : '';
  return _wrappedBankPick('interesesTC-base', [
    'Eso es plata que se fue sin comprar absolutamente nada.',
    'Ni una compra, ni un antojo — puro costo de tener deuda.',
    'Plata que el banco se llevó solo por esperar a que pagaras.',
  ]) + detalleTarjeta;
}

/* Mismo criterio de `_wrappedCopyInteresesTC` — nunca dice "por esperar a
   que pagaras" (eso es específico de intereses de deuda, no de una
   comisión), texto propio para no describir algo que no pasó. */
function _wrappedCopyComisionesTC(it){
  const detalleTarjeta = (it.topTarjeta && it.topTarjeta.nombre)
    ? ` La mayor parte se la cobró ${escHtml(it.topTarjeta.nombre)}.`
    : '';
  return _wrappedBankPick('comisionesTC-base', [
    'Cargos del banco, no compras tuyas.',
    'Plata que se fue en comisiones, no en nada que hayas elegido.',
    'El costo de tener la tarjeta, aparte de lo que compraste con ella.',
  ]) + detalleTarjeta;
}

/* ─── RENDER: gráfico de línea animado (SVG) ──────────────────────────────
   Puntos conectados por líneas, uno por mes, coloreado según si el
   patrimonio terminó arriba o abajo de donde empezó. El *dibujo* de la
   línea se anima con stroke-dasharray/-dashoffset (ver
   `_wrappedAnimarLinea`, se dispara al entrar al slide) — no es una
   gráfica estática como la de Análisis financiero, es una revelación.
   Devuelve '' si hay menos de 2 meses con dato.

   Pase de pulido (2026-09-15): se agregó un área de relleno degradada
   bajo la línea (puramente decorativa — mismos puntos, ningún dato
   nuevo) y un anillo que "respira" alrededor del punto final, para que
   la revelación se sienta más premium. De paso se encontró que el
   `animation-delay` de cada `.wrapped-dot` no tenía ningún
   `@keyframes`/`animation` asociado en el CSS — los puntos no estaban
   animando nada, solo aparecían de golpe. Corregido junto con esto (ver
   `_wrappedInyectarEstilos`). */
function _wrappedGraficoAnimadoSvg(serie){
  if(!serie || serie.length < 2) return '';
  const w = 300, h = 150, padX = 14, padY = 20;
  const valores = serie.map(p => p.valor);
  const min = Math.min(...valores), max = Math.max(...valores);
  const rango = (max - min) || 1;
  const stepX = (w - padX*2) / (serie.length - 1);
  const coords = serie.map((p,i) => ({
    x: padX + i*stepX,
    y: padY + (1 - (p.valor - min)/rango) * (h - padY*2)
  }));
  const subeOBaja = serie[serie.length-1].valor >= serie[0].valor;
  const color = subeOBaja ? 'var(--accent)' : 'var(--red)';
  const pathD = coords.map((c,i) => (i===0?'M':'L') + c.x.toFixed(1) + ',' + c.y.toFixed(1)).join(' ');
  const baseY = h - padY;
  const ultimo = coords[coords.length-1];
  const areaD = pathD + ` L${ultimo.x.toFixed(1)},${baseY} L${coords[0].x.toFixed(1)},${baseY} Z`;
  const dots = coords.map((c,i) => {
    return `<circle class="wrapped-dot" style="animation-delay:${(0.5 + i*0.09).toFixed(2)}s" cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="3.5" fill="${color}"/>`;
  }).join('');
  const labelIni = `<text x="${coords[0].x.toFixed(1)}" y="${h-2}" font-size="9" fill="var(--text3)" text-anchor="start" font-family="'DM Mono',monospace">${_wrappedMesKaAbrev(serie[0].mesK)}</text>`;
  const labelFin = `<text x="${ultimo.x.toFixed(1)}" y="${h-2}" font-size="9" fill="var(--text3)" text-anchor="end" font-family="'DM Mono',monospace">${_wrappedMesKaAbrev(serie[serie.length-1].mesK)}</text>`;
  return `<svg aria-hidden="true" class="wrapped-svg-block" viewBox="0 0 ${w} ${h}" width="100%" height="${h}">
    <defs>
      <linearGradient id="wrappedAreaGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <path class="wrapped-area-path" d="${areaD}" fill="url(#wrappedAreaGradient)" stroke="none"/>
    <path class="wrapped-line-path" d="${pathD}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle class="wrapped-dot-pulso" cx="${ultimo.x.toFixed(1)}" cy="${ultimo.y.toFixed(1)}" r="3.5" fill="none" stroke="${color}" stroke-width="1.5"/>
    ${dots}
    ${labelIni}${labelFin}
  </svg>`;
}

/* Dispara la animación de "dibujado" de la línea (stroke-dasharray →
   stroke-dashoffset → 0) dentro de un slide dado. Recibe el slide activo
   en vez de buscar por id global — así el gráfico deja de depender de
   ser el único de la pantalla (ver wrapped.md §7, punto sobre por qué se
   usa clase en vez de id). Si el navegador no soporta getTotalLength()
   en SVG (no debería pasar en un webview moderno, pero por si acaso — y
   jsdom tampoco lo soporta en tests), degrada mostrando la línea ya
   completa sin animar en vez de romper. */
function _wrappedAnimarLinea(slideEl){
  const path = slideEl ? slideEl.querySelector('.wrapped-line-path') : document.querySelector('.wrapped-line-path');
  if(!path || typeof path.getTotalLength !== 'function') return;
  let len;
  try { len = path.getTotalLength(); } catch(e){ return; }
  if(!len) return;
  // (2026-09-15) Esta función no respetaba `prefers-reduced-motion` —
  // a diferencia de `_wrappedAnimarNumeros` y `_wrappedLanzarConfeti`,
  // que sí lo chequean. Con movimiento reducido, la línea se muestra
  // completa de una vez, sin la transición de 1.1s.
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce){
    path.style.strokeDasharray = 'none';
    path.style.strokeDashoffset = '0';
    return;
  }
  path.style.strokeDasharray = String(len);
  path.style.strokeDashoffset = String(len);
  // Forzar reflow antes de animar, si no el navegador puede saltarse
  // directo al estado final sin transición visible.
  path.getBoundingClientRect();
  path.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(.4,0,.2,1)';
  requestAnimationFrame(() => { path.style.strokeDashoffset = '0'; });
}

/* Anima las barras del slide de ranking de categorías (2026-09-15):
   arrancan en 0% (así vienen desde el HTML) y acá se les pone el ancho
   real leído de `data-pct` — mismo patrón que `_wrappedAnimarLinea`
   (arrancar en el estado "vacío" y animar al entrar al slide, respetando
   la transición CSS ya declarada en `.wrapped-bar-fill`). */
function _wrappedAnimarBarras(slideEl){
  if(!slideEl) return;
  slideEl.querySelectorAll('.wrapped-bar-fill').forEach(el => {
    const pct = parseFloat(el.getAttribute('data-pct'));
    if(Number.isFinite(pct)) el.style.width = Math.max(0, Math.min(100, pct)) + '%';
  });
}

/* ─── FORMATO DE NÚMEROS CON SIGNO ─────────────────────────────────────── */
function _wrappedFmtSigned(fmt2, n){
  return (n>=0 ? '+' : '−') + fmt2(Math.abs(n));
}

/* ─── ANIMACIÓN "CONTADOR" de los números grandes de cada slide ──────────
   Mismo efecto que el "roll" del wrapped original de Spotify: el número
   sube desde 0 hasta el valor real con easing, en vez de aparecer ya
   escrito. Respeta prefers-reduced-motion. */
function _wrappedAnimarNumeros(container, fmt2){
  if(!container || !container.querySelectorAll) return;
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const nodos = container.querySelectorAll('.wrapped-bignum[data-value]');
  nodos.forEach(el => {
    const target = parseFloat(el.getAttribute('data-value')) || 0;
    const signed = el.getAttribute('data-signed') === '1';
    const sufijo = el.getAttribute('data-sufijo') || '';
    // `data-sufijo` (ej. "%") es la ÚNICA excepción al formato moneda de
    // `fmt2` — se usa para valores que no son plata (progreso de una
    // meta, %). Con sufijo, el número se redondea plano, sin `$`.
    const formatear = v => sufijo ? (Math.round(v) + sufijo) : (signed ? _wrappedFmtSigned(fmt2, v) : fmt2(v));
    if(reduce || typeof requestAnimationFrame !== 'function'){
      el.textContent = formatear(target);
      return;
    }
    const dur = 850;
    const start = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    function frame(now){
      const p = Math.min(1, (now-start)/dur);
      const eased = 1 - Math.pow(1-p, 3);
      el.textContent = formatear(target*eased);
      if(p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}

/* ─── CONFETI (solo en el slide de cierre) ────────────────────────────────
   Piezas CSS simples (sin canvas, sin librerías) — coherente con "sin
   build tool" del proyecto. Se salta por completo con
   prefers-reduced-motion. */
function _wrappedLanzarConfeti(slideEl){
  if(typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if(!slideEl || !slideEl.querySelector) return;
  let cont = slideEl.querySelector('.wrapped-confetti');
  if(!cont){
    cont = document.createElement('div');
    cont.className = 'wrapped-confetti';
    slideEl.appendChild(cont);
  }
  cont.innerHTML = '';
  const colores = ['var(--accent)','var(--amber)','var(--blue)','var(--red)','var(--purple)'];
  for(let i=0; i<18; i++){
    const pieza = document.createElement('i');
    pieza.style.left = (Math.random()*100).toFixed(1) + '%';
    pieza.style.background = colores[i % colores.length];
    pieza.style.animationDelay = (Math.random()*0.35).toFixed(2) + 's';
    pieza.style.transform = 'rotate(' + Math.floor(Math.random()*360) + 'deg)';
    cont.appendChild(pieza);
  }
}

/* ─── ESTILOS (inyectados una sola vez en <head>) ─────────────────────────
   Usa exclusivamente las variables CSS ya definidas en :root por la app
   (--bg, --bg2, --bg3, --border2, --text, --text2, --text3, --accent,
   --amber, --blue, --red, --purple, --radius, --radius-sm) y las mismas
   fuentes ('DM Sans' / 'DM Mono') — nada de paleta o tipografía nueva. */
/* Pase de diseño (2026-09-14): blobs de fondo, hint de navegación,
   botón de reinicio rápido, pill decorativa y tarjetas "moment" para las
   listas de frases sueltas (comparaciones, descubrimientos, suscrip-
   ciones) — inspirado en un mockup de referencia (`my-money-wrapped.html`,
   no versionado en el repo). Ninguno de estos cambios toca `_wrappedBuildSlides`
   más allá de dos slides-puente puramente decorativos (ver
   `_wrappedCopyPuente`) — sigue sin haber ninguna cifra nueva ni ningún
   desglose tipo "Top categorías" (eso sigue siendo terreno exclusivo de
   Análisis financiero, ver wrapped.md §1). Deliberadamente fuera de este
   pase: la función de "compartir como imagen" del mockup (canvas +
   descarga) — no pedida, y es una pieza de producto aparte (permisos de
   descarga, generación de imagen) que amerita su propia discusión. */
function _wrappedInyectarEstilos(){
  if(document.getElementById('wrapped-story-styles')) return;
  const style = document.createElement('style');
  style.id = 'wrapped-story-styles';
  style.textContent = `
#wrapped-overlay{position:fixed;inset:0;z-index:2000;background:var(--bg);display:flex;flex-direction:column;font-family:'DM Sans',sans-serif;color:var(--text);overflow:hidden;--wrapped-mood:var(--accent);-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}
.wrapped-bg-blob{position:absolute;border-radius:50%;filter:blur(64px);pointer-events:none;z-index:0;transition:background .9s ease;}
.wrapped-bg-blob.b1{width:70vmax;height:70vmax;top:-28vmax;right:-24vmax;background:var(--wrapped-mood);opacity:.16;}
.wrapped-bg-blob.b2{width:60vmax;height:60vmax;bottom:-30vmax;left:-20vmax;background:var(--wrapped-mood);opacity:.09;}
#wrapped-progress{position:relative;z-index:1;display:flex;gap:5px;padding:calc(env(safe-area-inset-top,0px) + 14px) 14px 0;flex-shrink:0;}
.wrapped-seg{flex:1;height:3px;background:var(--border2);border-radius:3px;overflow:hidden;}
.wrapped-seg>i{display:block;height:100%;width:0%;background:var(--accent);border-radius:3px;}
.wrapped-seg.done>i{width:100%;}
#wrapped-topbar{position:relative;z-index:1;display:flex;justify-content:space-between;align-items:center;padding:10px 14px 2px;flex-shrink:0;}
.wrapped-brand{font-size:11px;font-family:'DM Mono',monospace;letter-spacing:1px;text-transform:uppercase;color:var(--text3);}
.wrapped-topbar-right{display:flex;align-items:center;gap:8px;}
#wrapped-close,#wrapped-restart{width:32px;height:32px;border-radius:10px;background:var(--bg3);border:1px solid var(--border2);color:var(--text2);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;line-height:1;}
#wrapped-restart{font-size:16px;}
#wrapped-slides{position:relative;z-index:1;flex:1;overflow:hidden;}
.wrapped-slide{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:20px 26px 46px;opacity:0;visibility:hidden;transform:translateY(10px);transition:opacity .35s ease,transform .4s ease;}
.wrapped-slide.active{opacity:1;visibility:visible;transform:translateY(0);z-index:1;}
.wrapped-slide-inner{max-width:340px;width:100%;text-align:center;}
.wrapped-tag{display:inline-flex;align-items:center;gap:6px;font-family:'DM Mono',monospace;font-size:11px;padding:5px 12px;border-radius:999px;background:var(--bg2);border:1px solid var(--border2);color:var(--text2);margin-bottom:14px;}
.wrapped-eyebrow{font-family:'DM Mono',monospace;font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:var(--text3);margin-bottom:10px;}
.wrapped-headline{font-size:21px;font-weight:700;line-height:1.3;margin:0 0 6px;color:var(--text);}
.wrapped-headline b{color:var(--wrapped-mood);transition:color .6s ease;}
.wrapped-cierre-poema{font-size:13.5px;color:var(--text2);line-height:1.75;margin:14px 0 0;}
.wrapped-sub{font-size:13px;color:var(--text2);line-height:1.55;margin:6px 0 0;}
.wrapped-bignum{font-family:'DM Mono',monospace;font-weight:700;font-size:clamp(30px,10vw,42px);letter-spacing:-.5px;margin:8px 0 2px;}
.wrapped-chart-card{background:var(--bg2);border:1px solid var(--border2);border-radius:var(--radius);padding:16px 12px 10px;margin-bottom:16px;}
.wrapped-mes-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;width:100%;margin-top:12px;text-align:left;}
.wrapped-mes-cell{background:var(--bg2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:10px 11px;}
.wrapped-mes-cell-top{display:flex;align-items:center;gap:6px;margin-bottom:5px;}
.wrapped-mes-dot-color{width:7px;height:7px;border-radius:50%;flex-shrink:0;}
.wrapped-mes-dot-ok{background:var(--accent);}
.wrapped-mes-dot-mal{background:var(--red);}
.wrapped-mes-dot-cero{background:var(--text3);}
.wrapped-svg-block{display:block;overflow:visible;}
.wrapped-hit{cursor:pointer;}
.wrapped-sub.wrapped-sub-sep{margin-top:14px;}
.wrapped-icono-sep{margin-right:8px;}
.wrapped-c-text{color:var(--text);}
.wrapped-mes-nombre{font-family:'DM Mono',monospace;font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;}
.wrapped-mes-linea{font-size:12px;color:var(--text2);line-height:1.4;}
.wrapped-bars{width:100%;margin-top:14px;display:flex;flex-direction:column;gap:10px;text-align:left;}
.wrapped-bar-row{display:flex;align-items:center;gap:8px;}
.wrapped-bar-label{width:88px;flex-shrink:0;font-size:12px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.wrapped-bar-track{flex:1;height:8px;border-radius:999px;background:var(--bg2);border:1px solid var(--border2);overflow:hidden;}
.wrapped-bar-fill{height:100%;border-radius:999px;background:var(--wrapped-mood);width:0%;transition:width 1s cubic-bezier(.16,1,.3,1);}
.wrapped-bar-pct{width:42px;flex-shrink:0;text-align:right;font-family:'DM Mono',monospace;font-size:12px;color:var(--text3);}
.wrapped-stat-row{display:flex;gap:8px;width:100%;margin-top:14px;}
.wrapped-stat{flex:1;background:var(--bg2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:10px 6px;text-align:center;}
.wrapped-stat-v{font-family:'DM Mono',monospace;font-weight:700;font-size:15px;color:var(--text);}
.wrapped-stat-l{font-size:10px;color:var(--text3);margin-top:3px;text-transform:uppercase;letter-spacing:.4px;}
.wrapped-cta-row{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:22px;}
.wrapped-cta{display:inline-flex;align-items:center;gap:6px;background:var(--wrapped-mood);color:#0a0a0a;border:none;border-radius:999px;font-family:'DM Sans',sans-serif;font-weight:700;font-size:14px;padding:12px 22px;cursor:pointer;transition:background .6s ease;}
.wrapped-cta.ghost{background:transparent;color:var(--text);border:1px solid var(--border2);}
.wrapped-slide-inner-wide{max-width:380px;}
.wrapped-mes-detalle{width:100%;text-align:left;margin-top:14px;padding-top:10px;border-top:1px solid var(--border2);}
.wrapped-mes-head{font-family:'DM Mono',monospace;font-size:12px;color:var(--text3);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;}
.wrapped-mes-fila{display:flex;justify-content:space-between;font-size:13px;padding:4px 0;}
.wrapped-mes-fila span{color:var(--text2);}
.wrapped-mes-compara{font-size:12px;color:var(--text3);margin-top:8px;line-height:1.5;}
.wrapped-mes-label.activo{fill:var(--text);font-weight:700;}
.wrapped-dot-ingreso{fill:var(--accent);}
.wrapped-dot-gasto{fill:var(--red);}
/* (2026-09-15) Antes faltaba esta regla por completo: cada circle
   con clase wrapped-dot traía un animation-delay inline pero ningún
   animation/@keyframes que lo usara — los puntos no animaban nada,
   aparecían todos de una. Ahora sí hacen un "pop" escalonado al entrar. */
.wrapped-dot{opacity:0;transform-box:fill-box;transform-origin:center;animation:wrappedDotPop .5s cubic-bezier(.34,1.56,.64,1) forwards;}
.wrapped-area-path{opacity:0;animation:wrappedAreaIn 1.2s ease .15s forwards;}
.wrapped-dot-pulso{transform-box:fill-box;transform-origin:center;opacity:0;animation:wrappedPulso 1.8s ease-out 1.5s infinite;}
@keyframes wrappedDotPop{0%{opacity:0;transform:scale(0);}60%{opacity:1;transform:scale(1.35);}100%{opacity:1;transform:scale(1);}}
@keyframes wrappedAreaIn{to{opacity:1;}}
@keyframes wrappedPulso{0%{transform:scale(1);opacity:.6;}100%{transform:scale(2.6);opacity:0;}}
.wrapped-frases{width:100%;text-align:left;margin-top:6px;}
.wrapped-moment{display:flex;align-items:flex-start;gap:10px;background:var(--bg2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:11px 13px;margin-bottom:8px;}
.wrapped-moment:last-child{margin-bottom:0;}
.wrapped-moment-dot{display:block;width:6px;height:6px;margin-top:6px;border-radius:50%;background:var(--accent);flex-shrink:0;}
.wrapped-moment span{font-size:13px;color:var(--text2);line-height:1.5;}
#wrapped-hint{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 12px);z-index:1;text-align:center;font-family:'DM Mono',monospace;font-size:11px;color:var(--text3);opacity:.7;pointer-events:none;transition:opacity .5s ease;}
#wrapped-hint.wrapped-oculto{opacity:0;}
.wrapped-pill-list{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin-top:14px;}
.wrapped-pill{font-size:11.5px;padding:6px 12px;border-radius:999px;background:var(--bg2);border:1px solid var(--border2);color:var(--text2);}
.wrapped-pill.secundario{color:var(--text3);}
.wrapped-records-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;width:100%;margin-top:10px;}
.wrapped-record{background:var(--bg2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:12px 10px;text-align:left;}
.wrapped-record-l{font-size:11px;color:var(--text3);margin-bottom:4px;}
.wrapped-record-v{font-family:'DM Mono',monospace;font-weight:700;font-size:15px;color:var(--text);}
.wrapped-confetti{position:absolute;inset:0;overflow:hidden;pointer-events:none;}
.wrapped-confetti i{position:absolute;top:-10%;width:7px;height:12px;border-radius:2px;opacity:.9;animation:wrappedConfettiFall 1.5s ease-in forwards;}
@keyframes wrappedConfettiFall{to{transform:translateY(115vh) rotate(280deg);opacity:.15;}}
@media (prefers-reduced-motion: reduce){.wrapped-slide{transition:none;}.wrapped-confetti{display:none;}.wrapped-dot{opacity:1;animation:none;}.wrapped-area-path{opacity:1;animation:none;}.wrapped-dot-pulso{display:none;}}
/* Pantallas de escritorio (2026-09-15): sube tipografía y ancho SOLO
   cuando hay pantalla ancha Y mouse real (hover:hover + pointer:fine)
   — así un celular/tablet en horizontal, que también puede tener
   min-width alto, no cae acá y sigue viendo el layout mobile de
   siempre, que es la prioridad. */
@media (min-width:700px) and (hover:hover) and (pointer:fine){
  .wrapped-slide-inner{max-width:460px;}
  .wrapped-slide-inner-wide{max-width:560px;}
  .wrapped-eyebrow{font-size:13px;}
  .wrapped-headline{font-size:27px;}
  .wrapped-sub{font-size:15.5px;}
  .wrapped-cierre-poema{font-size:16px;}
  .wrapped-bignum{font-size:clamp(42px,6vw,64px);}
  .wrapped-bar-label{font-size:13px;}
  .wrapped-bar-pct{font-size:13px;}
  .wrapped-stat-v{font-size:18px;}
  .wrapped-stat-l{font-size:11px;}
  .wrapped-moment span{font-size:14.5px;}
  .wrapped-mes-nombre{font-size:12px;}
  .wrapped-mes-linea{font-size:13px;}
}
/* ─── PANEL DE DEBUG VISUAL (2026-09-15) ──────────────────────────────────
   Solo se inyecta al DOM cuando ?debug=1/#debug está presente (ver
   renderWrapped) — nunca le llega a un usuario normal, mismo criterio
   que ya regía el console.warn de _wrappedLogDebug. Reutiliza
   únicamente variables CSS ya definidas por la app (--bg2, --border2,
   --text2, --accent, --amber, --red) — sin paleta nueva, mismo criterio
   que el resto del módulo (ver wrapped.md §7undecies). */
#wrapped-debug-toggle{position:absolute;bottom:14px;right:14px;z-index:2100;width:34px;height:34px;border-radius:50%;background:var(--bg2);border:1px solid var(--border2);color:var(--text2);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:15px;}
#wrapped-debug-panel{position:absolute;inset:0;z-index:2200;background:var(--bg);display:none;flex-direction:column;font-family:'DM Sans',sans-serif;color:var(--text);}
#wrapped-debug-panel.wrapped-abierto{display:flex;}
#wrapped-debug-head{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--border2);flex-shrink:0;}
#wrapped-debug-head span{font-weight:700;font-size:14px;}
#wrapped-debug-head button{background:transparent;border:none;color:var(--text2);display:flex;align-items:center;justify-content:center;cursor:pointer;}
#wrapped-debug-body .wrapped-debug-warn i,#wrapped-debug-body .wrapped-debug-ok i,#wrapped-debug-body .wrapped-debug-sel i,#wrapped-debug-body .wrapped-debug-top i,#wrapped-debug-body .wrapped-debug-unsel i{margin-right:4px;}
#wrapped-debug-body{overflow-y:auto;padding:12px 16px 28px;}
#wrapped-debug-body h4{margin:16px 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--text3);}
#wrapped-debug-body table{width:100%;border-collapse:collapse;font-size:12.5px;}
#wrapped-debug-body td,#wrapped-debug-body th{padding:4px 6px;text-align:left;border-bottom:1px solid var(--border);}
#wrapped-debug-body .wrapped-debug-warn{color:var(--amber);font-size:12.5px;margin-bottom:4px;}
#wrapped-debug-body .wrapped-debug-ok{color:var(--accent);font-size:12.5px;}
#wrapped-debug-body .wrapped-debug-sel{color:var(--accent);font-weight:700;}
#wrapped-debug-body .wrapped-debug-unsel{color:var(--text3);}
#wrapped-debug-body .wrapped-debug-top{color:var(--amber);}
`;
  document.head.appendChild(style);
}

/* ─── ARMADO DE CADA SLIDE ────────────────────────────────────────────── */
// El color del número grande llega como `var(--x)` desde cada slide; se traduce a una clase (la CSP sin 'unsafe-inline'
// bloquearía un atributo de estilo). `_moodRegex` (en _wrappedBuildSlides) lee esas mismas clases para el fondo del slide. Las clases c-* viven en styles.css; wrapped-c-text, en el CSS de este archivo.
function _wrappedColorClase(color){
  const mapa = { 'var(--accent)':'c-green', 'var(--red)':'c-red', 'var(--amber)':'c-amber', 'var(--purple)':'c-purple', 'var(--blue)':'c-blue', 'var(--text)':'wrapped-c-text' };
  if(!mapa[color] && typeof console !== 'undefined') console.warn('[wrapped] color sin clase:', color);
  return mapa[color] || '';
}
function _wrappedSlideBignum(eyebrow, headline, value, color, opts){
  opts = opts || {};
  // Robustez: si `value` llegara indefinido/NaN (dato corrupto, campo
  // faltante en un registro viejo) el slide igual debe poder pintarse —
  // nunca con `NaN` visible en el atributo ni en el conteo animado.
  const valorSeguro = Number.isFinite(value) ? value : 0;
  // `opts.ocultarValor` (2026-09-15): reusa la MISMA clase `.saldo-hidden`
  // que ya existe en `styles.css` para "Ocultar saldos" (blur + bloquea
  // selección/click) — no se inventa un mecanismo de ocultamiento nuevo.
  // Solo tapa visualmente el número; el valor real sigue en el DOM
  // (`data-value`) porque así funciona ya el resto de la app con esa
  // misma clase — no es una fuga nueva, es el mismo comportamiento ya
  // aceptado en Inicio/Análisis/Tarjetas.
  const claseOculto = opts.ocultarValor ? ' saldo-hidden' : '';
  return `<div class="wrapped-slide-inner">
    <div class="wrapped-eyebrow">${eyebrow}</div>
    ${headline ? `<div class="wrapped-headline">${headline}</div>` : ''}
    <div class="wrapped-bignum ${_wrappedColorClase(color)}${claseOculto}" data-value="${valorSeguro}"${opts.signed?' data-signed="1"':''}${opts.sufijo?` data-sufijo="${opts.sufijo}"`:''}>0</div>
    ${opts.sub ? `<div class="wrapped-sub">${opts.sub}</div>` : ''}
  </div>`;
}

/* Corte "primera mitad / segunda mitad" del año transcurrido — extraído
   de `_wrappedCambioDeHabitos` para que `_wrappedFasesAnio` (abajo) use
   exactamente el mismo corte de fechas, en vez de reimplementarlo. */
function _wrappedCorteMitadAnio(anioK, mesMax){
  const mitad = Math.floor((mesMax+1) / 2);
  const mesKDeCorte = Fecha.mesKey(anioK, mitad+1); // primer mesK de la segunda mitad
  return {
    enPrimera: fecha => typeof fecha === 'string' && fecha.slice(0,4) === anioK && fecha.slice(0,7) < mesKDeCorte,
    enSegunda: fecha => typeof fecha === 'string' && fecha.slice(0,4) === anioK && fecha.slice(0,7) >= mesKDeCorte
  };
}

/* Compara la categoría líder (por monto) de la primera mitad del año
   contra la segunda — es la única comparación tipo "empezaste haciendo X,
   terminaste haciendo Y" que se agregó en esta pasada. Se calcula con
   seguridad a partir de un solo año de historia porque no depende de
   ningún umbral estadístico de anomalía (a diferencia de detectar "el día
   que rompió tu patrón" o una tendencia mes a mes — eso se dejó afuera a
   propósito, ver wrapped.md §7: con poco historial, ese tipo de detección
   corre mucho riesgo de señalar como "raro" algo que en realidad es
   normal para este usuario, y una falsa alarma en un resumen anual es
   peor que no tener esa historia). Reutiliza `_wrappedTopCategoriaDe`
   (misma agrupación por categoría que el período completo) para no
   duplicar esa lógica. Requiere al menos 6 meses transcurridos del año. */
function _wrappedCambioDeHabitos(S, anioK, mesMax){
  if(mesMax < 5) return null; // menos de 6 meses: no hay dos mitades que valga la pena comparar

  const gastosVar = S.gastosVar || [];
  const pagosFijos = Periodo.pagosFijos(S);
  const esGastoNoReal = typeof _esGastoVarNoReal === 'function' ? _esGastoVarNoReal : (()=>false);

  const { enPrimera, enSegunda } = _wrappedCorteMitadAnio(anioK, mesMax);

  const itemsPrimera = [...gastosVar.filter(g => enPrimera(g.fecha) && !esGastoNoReal(g)), ...pagosFijos.filter(p => enPrimera(p.mes + '-01'))];
  const itemsSegunda = [...gastosVar.filter(g => enSegunda(g.fecha) && !esGastoNoReal(g)), ...pagosFijos.filter(p => enSegunda(p.mes + '-01'))];

  const totalPrimera = itemsPrimera.reduce((s,g)=>s+(g.monto||0),0);
  const totalSegunda = itemsSegunda.reduce((s,g)=>s+(g.monto||0),0);

  const topPrimera = _wrappedTopCategoriaDe(itemsPrimera, totalPrimera);
  const topSegunda = _wrappedTopCategoriaDe(itemsSegunda, totalSegunda);

  if(!topPrimera || !topSegunda || topPrimera.cat === topSegunda.cat) return null;
  // Solo cuenta como "cambio de hábitos" si la categoría fue realmente
  // dominante en cada mitad — si ambas mitades estaban parejas entre
  // varias categorías sin que ninguna destaque, no es un cambio real, es
  // ruido, y mostrarlo como si fuera una historia sería engañoso.
  if((topPrimera.catShare||0) < 0.15 || (topSegunda.catShare||0) < 0.15) return null;

  return { catPrimera: topPrimera.cat, catSegunda: topSegunda.cat };
}

/* ─── FASES DEL AÑO (2026-09-13) ───────────────────────────────────────
   Detecta si el AHORRO (Alcancía) o el PRÉSTAMO A OTROS (Prestado · Me
   deben) se concentró de forma marcada en una mitad del año — la misma
   idea de "dos etapas" que `_wrappedCambioDeHabitos` ya aplica a
   categorías de gasto, extendida a estas dos señales.

   Umbral DELIBERADAMENTE relativo (70/30 de concentración entre
   mitades), nunca un monto fijo en pesos — mismo criterio que el
   `catShare >= 0.15` de `_wrappedCambioDeHabitos` y que el z-score de
   `_wrappedGastoMasRandom`: un umbral en pesos no tiene el mismo
   significado para dos usuarios distintos, uno relativo al propio año sí.
   Prioriza ahorro sobre préstamo si ambos califican (es la señal más
   "sobre el usuario mismo", préstamo depende también de que otras
   personas pidieran). Devuelve `null` si ninguna señal es lo bastante
   clara — no fuerza una narrativa de "fases" en un año parejo (§33 del
   pedido original). */
function _wrappedCambioFuerte(primera, segunda){
  // Ambas mitades necesitan actividad real (>0) para que esto sea un
  // CAMBIO de comportamiento y no una cuenta que simplemente no existía
  // en la primera mitad (ej. Alcancía activada a mitad de año) — eso no
  // es una fase, es que el dato todavía no existía. Verificado con un
  // backup real de una cuenta creada en septiembre: sin esta guarda,
  // "el único depósito del año cayó en la segunda mitad" se leía como
  // "aumentaste tu ahorro", un falso positivo (ver wrapped.md §7sexies).
  if(primera <= 0 || segunda <= 0) return null;
  const total = primera + segunda;
  const shareSegunda = segunda / total;
  if(shareSegunda >= UMBRALES.wrapped.cambioFuerte) return { direccion: 'crecio', shareSegunda };
  if(shareSegunda <= 1 - UMBRALES.wrapped.cambioFuerte) return { direccion: 'cayo', shareSegunda };
  return null;
}
function _wrappedFasesAnio(S, anioK, mesMax){
  if(mesMax < 5) return null; // mismo mínimo que _wrappedCambioDeHabitos

  const { enPrimera, enSegunda } = _wrappedCorteMitadAnio(anioK, mesMax);

  const alcMovs = (S.alcancia && Array.isArray(S.alcancia.movimientos)) ? S.alcancia.movimientos : [];
  const ahorroPrimera = alcMovs.filter(m => m && enPrimera(m.fecha)).reduce((s,m)=>s+(m.monto||0),0);
  const ahorroSegunda = alcMovs.filter(m => m && enSegunda(m.fecha)).reduce((s,m)=>s+(m.monto||0),0);
  const cambioAhorro = _wrappedCambioFuerte(ahorroPrimera, ahorroSegunda);
  if(cambioAhorro){
    return { tipo:'ahorro', direccion: cambioAhorro.direccion };
  }

  const deudores = Deudas.lista('favor');
  const sumaPrestamos = (filtro) => deudores.reduce((s,d) =>
    s + (d.movimientos||[]).filter(m => m && m.tipo==='prestamo' && filtro(m.fecha)).reduce((a,m)=>a+(m.monto||0),0), 0);
  const prestPrimera = sumaPrestamos(enPrimera);
  const prestSegunda = sumaPrestamos(enSegunda);
  const cambioPrestamo = _wrappedCambioFuerte(prestPrimera, prestSegunda);
  if(cambioPrestamo){
    return { tipo:'prestamo', direccion: cambioPrestamo.direccion };
  }

  return null;
}
function _wrappedCopyFases(f){
  if(f.tipo === 'ahorro'){
    return f.direccion === 'crecio' ? _wrappedBankPick('fases-ahorroSubio', [
      'Tu año tuvo dos etapas: empezaste ahorrando poco y en la segunda mitad le metiste mucho más a la alcancía.',
      'Tu año tuvo un antes y un después: el ahorro se disparó en la segunda mitad.',
      'Algo cambió a mitad de año: empezaste a guardar mucho más que antes.',
    ]) : _wrappedBankPick('fases-ahorroBajo', [
      'Tu año tuvo dos etapas: arrancaste ahorrando fuerte y en la segunda mitad bajaste el ritmo.',
      'Tu año tuvo un antes y un después: el ahorro se frenó en la segunda mitad.',
      'Algo cambió a mitad de año: el ritmo de ahorro bajó bastante después.',
    ]);
  }
  return f.direccion === 'crecio' ? _wrappedBankPick('fases-prestamoSubio', [
    'Tu año tuvo dos etapas: empezaste tranquilo y en la segunda mitad te volviste banco de varias personas.',
    'Tu año tuvo un antes y un después: prestar más se volvió costumbre en la segunda mitad.',
    'La segunda mitad del año te tuvo prestando plata bastante más seguido.',
  ]) : _wrappedBankPick('fases-prestamoBajo', [
    'Tu año tuvo dos etapas: prestaste bastante al principio y en la segunda mitad frenaste.',
    'Tu año tuvo un antes y un después: prestaste menos en la segunda mitad.',
    'Prestaste fuerte al principio del año y después bajaste el ritmo.',
  ]);
}

/* ─── "SI TU AÑO FUERA UNA PELÍCULA" (2026-09-13) ──────────────────────
   Puramente decorativo — no calcula NADA nuevo, solo le pone una frase a
   señales que este archivo ya calculó para otros slides (fases, cambio
   de hábitos, racha, patrimonio). Reglas deterministas en orden de más
   específico a más genérico, mismo criterio que `_wrappedPersonalidad`.
   Nunca inventa un evento que no esté respaldado por esas señales —
   el fallback genérico es deliberadamente aburrido en vez de forzar un
   dato que no existe (§33 del pedido original). */
function _wrappedSiTuAnioFuera(ctx){
  const { fasesAnio, cambioHabitos, racha, patrimonio } = ctx;
  if(fasesAnio && fasesAnio.tipo === 'ahorro' && fasesAnio.direccion === 'crecio'){
    return _wrappedBankPick('pelicula-ahorroSubio', [
      'Sería una de crecimiento, con un giro a mitad de año: el momento en que le agarraste el gusto a ahorrar.',
      'Sería de esas donde el personaje cambia a mitad de historia — acá, el momento en que empezaste a ahorrar en serio.',
    ]);
  }
  if(fasesAnio && fasesAnio.tipo === 'prestamo' && fasesAnio.direccion === 'crecio'){
    return _wrappedBankPick('pelicula-prestamoSubio', [
      'Sería una donde el protagonista termina manejando más plata ajena de la que esperaba al principio.',
      'Sería de las que arrancan con un favor pequeño y terminan con el protagonista manejando la plata de medio barrio.',
    ]);
  }
  if(cambioHabitos){
    return _wrappedBankPick('pelicula-cambioHabitos', [
      `Tendría un giro de guion a mitad de año: empezó siendo de ${escHtml(cambioHabitos.catPrimera)} y terminó siendo de ${escHtml(cambioHabitos.catSegunda)}.`,
      `El giro de la trama: arrancó siendo de ${escHtml(cambioHabitos.catPrimera)} y terminó siendo de ${escHtml(cambioHabitos.catSegunda)}.`,
    ], cambioHabitos.catPrimera + cambioHabitos.catSegunda);
  }
  if(racha >= 4){
    return _wrappedBankPick('pelicula-racha', [
      'Sería sobre disciplina silenciosa — el personaje que no falla ni un capítulo.',
      'Sería de ritmo constante, sin sobresaltos — el tipo de historia que gana por perseverancia.',
    ]);
  }
  if(patrimonio && Number.isFinite(patrimonio.diff) && patrimonio.diff > 0){
    return _wrappedBankPick('pelicula-patrimonioSubio', [
      'De las que terminan mejor de lo que empezaron, sin necesitar un clímax dramático para lograrlo.',
      'Sin gran clímax, pero con un final mejor que el comienzo — esas también son buenas historias.',
    ]);
  }
  return _wrappedBankPick('pelicula-generica', [
    'De las que no tienen gran clímax, pero tampoco fueron aburridas.',
    'Sin giros grandes, pero con suficiente para no aburrir.',
  ]);
}

/* ═══════════════════════════════════════════════════════════════════════
   DOMINIOS "DE TERCEROS" (Encargos, Prestado, Mesada, Spotify, Plata
   Comprometida) — decisión de diseño 2026-09-13, ver el comentario de
   cabecera del archivo y wrapped.md §7ter. Cada función de acá abajo lee
   directo la estructura real de su módulo dueño y nunca guarda nada
   nuevo — mismo principio que el resto del archivo. Todas devuelven
   `null` (o un objeto con totales en 0) si el módulo no tiene datos ese
   año, para que `_wrappedBuildSlides` pueda saltarse el slide entero sin
   casos especiales.
   ═══════════════════════════════════════════════════════════════════════ */

/* Nombre de una persona: preferimos el sistema unificado de Personas
   (`getPersonaNombre`, ver personas.md §2 — "el nombre mostrado siempre
   se resuelve preferentemente desde la persona vinculada") y caemos al
   nombre crudo que cada módulo ya guarda si Personas no cargó o el
   registro no tiene `personaId` ("sin perfil", ver personas.md §2/§6).
   Escapa siempre — un nombre de persona es dato del usuario. */
function _wrappedNombrePersona(personaId, nombreCrudo){
  let nombre = nombreCrudo || 'Alguien';
  if(personaId && typeof getPersonaNombre === 'function'){
    const resuelto = getPersonaNombre(personaId);
    if(resuelto) nombre = resuelto;
  }
  return escHtml(nombre);
}

/* ─── ENCARGOS ─────────────────────────────────────────────────────────
   "Cuánta plata ajena te encargaron cuidar este año" — suma de
   movimientos tipo 'entrada' (ver encargos.md §4: es lo único que
   determina el signo) con fecha en el período, sobre todos los
   encargos, sin importar si siguen activos hoy. No usamos `encargoSaldo`
   (saldo ACTUAL de un encargo) porque acá la pregunta es "cuánto entró
   este año", no "cuánto queda hoy" — son cálculos distintos a propósito. */
function _wrappedCalcularEncargos(S, tipo, mesK, anioK){
  const encargos = S.encargos || [];
  if(!Array.isArray(encargos) || !encargos.length) return null;

  let totalEncargado = 0;
  let topEncargo = null; // el que más recibió este período
  const personasSet = new Set();

  encargos.forEach(enc => {
    const movs = Array.isArray(enc.movimientos) ? enc.movimientos : [];
    let totalEsteEncargo = 0;
    movs.forEach(m => {
      if(m && m.tipo === 'entrada' && _wrappedEnRango(m.fecha, tipo, mesK, anioK)){
        totalEsteEncargo += (m.monto||0);
      }
    });
    if(totalEsteEncargo > 0){
      totalEncargado += totalEsteEncargo;
      personasSet.add(enc.personaId || enc.nombre || enc.id);
      if(!topEncargo || totalEsteEncargo > topEncargo.monto){
        topEncargo = { nombre: enc.nombre, personaId: enc.personaId || null, monto: totalEsteEncargo };
      }
    }
  });

  if(totalEncargado <= 0) return null;
  return { totalEncargado, nPersonas: personasSet.size, topEncargo };
}

/* ─── PRESTADO — Me deben (S.deudores) ────────────────────────────────
   Cuánto prestaste este período (movimientos 'prestamo', dinero que
   sale de una cuenta tuya, ver prestado.md §2.2) y cuánto te devolvieron
   ('abono'/'pago-completo'). El deudor "del año" se elige por cuánto le
   prestaste en el período — no por su deuda pendiente total, que puede
   venir de años anteriores y no sería un dato de "este año". */
function _wrappedCalcularPrestado(S, tipo, mesK, anioK){
  const deudores = Deudas.lista('favor');
  if(!Array.isArray(deudores) || !deudores.length) return null;

  let totalPrestado = 0, totalDevuelto = 0;
  let topDeudor = null;

  deudores.forEach(d => {
    const movs = Array.isArray(d.movimientos) ? d.movimientos : [];
    let prestadoAEsta = 0, nPrestamosAEsta = 0;
    movs.forEach(m => {
      if(!m || !_wrappedEnRango(m.fecha, tipo, mesK, anioK)) return;
      if(m.tipo === 'prestamo'){ totalPrestado += (m.monto||0); prestadoAEsta += (m.monto||0); nPrestamosAEsta++; }
      // Un perdón de deuda ("¿Se lo regalas?", m._perdon) es un 'pago-completo' que NO
      // devolvió plata: no cuenta como devuelto (ya cuenta como gasto real, ver gastos.md).
      else if((m.tipo === 'abono' || m.tipo === 'pago-completo') && !m._perdon){ totalDevuelto += (m.monto||0); }
    });
    if(prestadoAEsta > 0 && (!topDeudor || prestadoAEsta > topDeudor.monto)){
      topDeudor = { nombre: d.nombre, personaId: d.personaId || null, monto: prestadoAEsta, n: nPrestamosAEsta };
    }
  });

  if(totalPrestado <= 0 && totalDevuelto <= 0) return null;
  return { totalPrestado, totalDevuelto, topDeudor };
}

/* ─── PRESTADO — Yo debo (S.misDeudas) ────────────────────────────────
   Espejo del anterior: cuánto te prestaron a ti este período
   ('recibido') y cuánto pagaste de vuelta ('pago') — ver prestado.md
   §3.2. */
function _wrappedCalcularMisDeudas(S, tipo, mesK, anioK){
  const misDeudas = Deudas.lista('contra');
  if(!Array.isArray(misDeudas) || !misDeudas.length) return null;

  let totalRecibido = 0, totalPagado = 0;

  misDeudas.forEach(d => {
    const movs = Array.isArray(d.movimientos) ? d.movimientos : [];
    movs.forEach(m => {
      if(!m || !_wrappedEnRango(m.fecha, tipo, mesK, anioK)) return;
      if(m.tipo === 'recibido') totalRecibido += (m.monto||0);
      else if(m.tipo === 'pago' && !m._perdon) totalPagado += (m.monto||0); // un perdón no es plata pagada
    });
  });

  if(totalRecibido <= 0 && totalPagado <= 0) return null;
  return { totalRecibido, totalPagado };
}

/* ─── MESADA ───────────────────────────────────────────────────────────
   Total recibido de papá + mamá este año. Simplificación reconocida: el
   campo `monto` de cada pago es el TOTAL recibido a la fecha para ese
   mes (ver mesada.md §4 — incluye abonos posteriores del pendiente), y
   se filtra por la `fecha` de ese registro (la del último abono si lo
   hubo). Un mes cuya deuda se saldó ya entrado el año siguiente movería
   ese monto al año del abono, no al del mes que representa — mismo tipo
   de aproximación que ya reconoce `_wrappedCalcularPeriodo` para el
   resto de la app, no una fuente de verdad nueva. No usa `getMontoPadre`
   (esa es la cuota vigente hoy, no lo históricamente recibido).

   OJO — esto es DELIBERADAMENTE distinto de `_wrappedMesadaMes` (arriba,
   usada dentro de `_wrappedCalcularPeriodo` para el balance interno de
   "mejor/peor mes"): esa otra función busca el pago por su CLAVE de mes
   ("a qué mes representa este pago", igual que `analisis.js`), esta
   busca por su `fecha` real ("cuándo entró la plata"). Son dos
   preguntas distintas — "cuánto mesada te tocó este año" vs. "cuánto
   entró de mesada en este mes calendario para el balance" — no una
   duplicación evitable. */
function _wrappedCalcularMesada(S, tipo, mesK, anioK){
  const mesadas = S.mesadas;
  if(!mesadas || typeof mesadas !== 'object') return null;

  let total = 0;
  const porPadre = {};
  ['papa','mama'].forEach(parent => {
    const pagos = (mesadas[parent] && mesadas[parent].pagos) || {};
    let totalParent = 0;
    Object.values(pagos).forEach(v => {
      if(v && _wrappedEnRango(v.fecha, tipo, mesK, anioK)) totalParent += (v.monto||0);
    });
    if(totalParent > 0){ total += totalParent; porPadre[parent] = totalParent; }
  });

  if(total <= 0) return null;
  return { total, porPadre };
}

/* ─── SPOTIFY ──────────────────────────────────────────────────────────
   Cobrado − pagado del período, sobre `(S.spotify||{}).historial` (ver
   spotify.md §4). Simplificación reconocida y anotada a propósito: la
   "Ganancia acumulada" real del módulo (spotify.md §7) suma además
   `cuotaAdmin × ciclos pagados`, calculada inline dentro de
   `spotify.js` sin una función central reexportada para reusar acá —
   por eso este número puede no coincidir exactamente con el de la
   pantalla de Spotify. Es un "cobrado menos pagado del año" honesto, no
   la ganancia oficial del módulo. */
function _wrappedCalcularSpotify(S, tipo, mesK, anioK){
  const hist = (S.spotify||{}).historial;
  if(!Array.isArray(hist) || !hist.length) return null;

  let cobrado = 0, pagado = 0;
  hist.forEach(h => {
    if(!h || !_wrappedEnRango(h.fecha, tipo, mesK, anioK)) return;
    if(h.tipo === 'cobro') cobrado += (h.monto||0);
    else if(h.tipo === 'pago') pagado += (h.monto||0);
  });

  if(cobrado <= 0 && pagado <= 0) return null;
  return { cobrado, pagado, balance: cobrado - pagado };
}

/* ─── PLATA COMPROMETIDA ──────────────────────────────────────────────
   Plata que estabas esperando y de verdad llegó este período —
   `S.plataComprometida[]` (ver plata-comprometida.md §4) filtrado por
   `recibido:true` y `fechaRecibido` en el período — nunca por
   `fechaLlegada`, que es solo la fecha ESTIMADA. */
function _wrappedCalcularComprometida(S, tipo, mesK, anioK){
  const items = S.plataComprometida;
  if(!Array.isArray(items) || !items.length) return null;

  let total = 0, topItem = null;
  items.forEach(it => {
    if(it && it.recibido === true && _wrappedEnRango(it.fechaRecibido, tipo, mesK, anioK)){
      total += (it.montoTotal||0);
      if(!topItem || (it.montoTotal||0) > topItem.monto){
        topItem = { desc: it.desc || 'Plata comprometida', monto: it.montoTotal||0 };
      }
    }
  });

  if(total <= 0) return null;
  return { total, topItem };
}

/* ─── TARJETAS DE CRÉDITO — Intereses cobrados ────────────────────────
   `S.tarjetasCredito[].compras[]` con `_esCargoEspecial:true` y
   `_motivoCargo:'interes'` son cargos que el BANCO impone (ver
   `tarjetas_credito.js`, sección "Cargo especial"), no una compra tuya —
   se filtran por `fecha` en el período, igual que cualquier otro dominio
   de §7ter. Deliberadamente NO se toca `tc.deuda` (saldo actual — puede
   venir de años anteriores) ni `.pagos[]`/compras normales (eso ya vive,
   con otro lente, en gastos/categorías si esas compras tienen su gasto
   variable espejo — sumarlo acá otra vez sería contar la misma plata dos
   veces bajo otra etiqueta). Los intereses sí son plata nueva que no
   aparece en ningún otro slide: el banco te la cobró aparte, encima del
   consumo real. */
function _wrappedCalcularInteresesTC(S, tipo, mesK, anioK){
  const tarjetas = S.tarjetasCredito;
  if(!Array.isArray(tarjetas) || !tarjetas.length) return null;

  let totalInteres = 0, nCargos = 0;
  let topTarjeta = null; // la que más intereses generó en el período

  tarjetas.forEach(tc => {
    let interesEstaTarjeta = 0;
    (tc.compras||[]).forEach(c => {
      if(!c || c.eliminado) return;
      if(!(c._esCargoEspecial && c._motivoCargo === 'interes')) return;
      if(!_wrappedEnRango(c.fecha, tipo, mesK, anioK)) return;
      totalInteres += (c.monto||0);
      interesEstaTarjeta += (c.monto||0);
      nCargos++;
    });
    if(interesEstaTarjeta > 0 && (!topTarjeta || interesEstaTarjeta > topTarjeta.monto)){
      topTarjeta = { nombre: tc.nombre || tc.banco || null, monto: interesEstaTarjeta };
    }
  });

  if(totalInteres <= 0) return null;
  return { totalInteres, nCargos, topTarjeta };
}

/* ─── TARJETAS DE CRÉDITO — Comisiones cobradas (2026-09-15) ──────────────
   Mismo patrón EXACTO que `_wrappedCalcularInteresesTC` de arriba, pero
   filtrando `_motivoCargo === 'comision'` en vez de `'interes'` —
   `tarjetas_credito.js` (`TC_MOTIVOS_CARGO`) distingue tres motivos de
   cargo especial (interés, comisión, "otro"); hasta esta sesión Wrapped
   solo leía el primero. Se agrega comisión como candidato APARTE (no
   sumado al mismo total de intereses) porque el copy de intereses
   ("plata que el banco se llevó por esperar a que pagaras") describe algo
   específico de la deuda que no aplica a una comisión — mezclar los dos
   conceptos bajo una sola cifra sería honesto en el número pero deshonesto
   en el texto. Deliberadamente NO se agrega el tercer motivo, `'otro'`:
   es un cajón de sastre a propósito genérico en el propio
   `tarjetas_credito.js` ("Otro cargo del banco") — sin saber qué fue
   realmente, cualquier frase que este módulo le pusiera encima sería
   inventada, y §3 prohíbe justamente eso (nunca forzar un insight sin una
   señal real y concreta detrás). */
function _wrappedCalcularComisionesTC(S, tipo, mesK, anioK){
  const tarjetas = S.tarjetasCredito;
  if(!Array.isArray(tarjetas) || !tarjetas.length) return null;

  let totalComision = 0, nCargos = 0;
  let topTarjeta = null; // la que más comisiones generó en el período

  tarjetas.forEach(tc => {
    let comisionEstaTarjeta = 0;
    (tc.compras||[]).forEach(c => {
      if(!c || c.eliminado) return;
      if(!(c._esCargoEspecial && c._motivoCargo === 'comision')) return;
      if(!_wrappedEnRango(c.fecha, tipo, mesK, anioK)) return;
      totalComision += (c.monto||0);
      comisionEstaTarjeta += (c.monto||0);
      nCargos++;
    });
    if(comisionEstaTarjeta > 0 && (!topTarjeta || comisionEstaTarjeta > topTarjeta.monto)){
      topTarjeta = { nombre: tc.nombre || tc.banco || null, monto: comisionEstaTarjeta };
    }
  });

  if(totalComision <= 0) return null;
  return { totalComision, nCargos, topTarjeta };
}

/* ─── META DE AHORRO DE CAJITA ─────────────────────────────────────────
   Reutiliza `calcMetaProgreso(c)`, YA centralizada en `cuentas.js` (nunca
   se recalcula `pct`/`esperadoHoy`/`diferencia` acá — regla de §3). Como
   esa función depende de toda la cadena de cálculo de Cuentas (`calcC`,
   `_saldoEncargosEnCajita`, tasas por tramos), se llama envuelta en
   try/catch: si algo de esa cadena no cargó todavía o cambia de forma,
   Wrapped simplemente no muestra este slide en vez de romper toda la
   historia por un módulo ajeno. Elige la meta con MAYOR progreso (`pct`),
   no la de mayor objetivo en pesos — es "la más cerca de tu logro este
   año", no "la más ambiciosa". */
function _wrappedMetaCajita(S){
  if(typeof calcMetaProgreso !== 'function') return null;
  const cajitas = _wrappedListaCajitas(S);
  let mejor = null;
  cajitas.forEach(c => {
    if(!c || !c.meta) return;
    let prog = null;
    try { prog = calcMetaProgreso(c); } catch(e){ prog = null; }
    if(!prog || !Number.isFinite(prog.pct)) return;
    if(!mejor || prog.pct > mejor.prog.pct){
      mejor = { nombre: c.nombre || 'Tu meta', prog };
    }
  });
  return mejor;
}
function _wrappedCopyMeta(m){
  const p = m.prog;
  if(p.pct >= 100) return _wrappedBankPick('meta-cumplida', [
    '¡La cumpliste! Y con saldo suficiente para mostrarlo.',
    'Meta cumplida. Sin peros.',
    'Lo lograste — y no por poco.',
  ]);
  if(p.diferencia > 0) return _wrappedBankPick('meta-adelantado', [
    'Vas adelantado a tu propio plan.',
    'Vas más rápido de lo que te propusiste.',
    'Ibas para adelante y le sacaste ventaja a tu propio calendario.',
  ]);
  if(p.diferencia < 0) return _wrappedBankPick('meta-atrasado', [
    'Un poco atrasado del ritmo esperado, pero sigue en pie.',
    'Vas un poco más lento de lo planeado, pero la meta sigue viva.',
    'Se retrasó un poco el plan, pero la meta no se abandonó.',
  ]);
  return _wrappedBankPick('meta-alRitmo', [
    'Justo en el ritmo que te propusiste.',
    'Vas exactamente como lo planeaste.',
    'El plan y la realidad van de la mano, sin desvíos.',
  ]);
}

/* ═══════════════════════════════════════════════════════════════════════
   SEGUNDA TANDA (2026-09-13) — Personalidad financiera, Gasto más random,
   Tus protagonistas. Reabre 2 de las 3 decisiones descartadas en
   wrapped.md §7 (personalidad financiera y, en un slide futuro, share
   cards) — decisión de producto explícita del usuario, documentada en
   wrapped.md §7cuater. La vista mensual sigue sin implementarse (backlog
   aparte, no en esta pasada).
   ═══════════════════════════════════════════════════════════════════════ */

/* Lista de cajitas: viven directo en `S.cajitas[]` (cuentas.md §4). */
function _wrappedListaCajitas(S){
  return Array.isArray(S.cajitas) ? S.cajitas : [];
}

/* ─── PÁRRAFO DE CIERRE ("poema"), 2026-09-14 ──────────────────────────
   Acompaña a `_wrappedCopyCierre` (el titular grande) con un segundo
   párrafo más largo y emocional, inspirado en el cierre del mockup de
   referencia ("No fue perfecto. Hubo meses buenos..."). Mismo criterio
   que el resto del sistema de copy: elige entre señales YA calculadas
   (patrimonio, racha, fasesAnio, personalidad) — nunca inventa ni
   calcula una cifra nueva, y nunca menciona ingresos/gastos/tasa de
   ahorro en crudo (wrapped.md §3). Se prueba en el mismo orden de
   prioridad que `_wrappedCopyCierre` para que ambos párrafos cuenten una
   historia coherente en vez de contradecirse (ej.: que el titular hable
   de una racha fuerte y el párrafo de abajo hable de una caída de
   patrimonio sería un cierre que se pisa a sí mismo). */
function _wrappedCopyCierrePoema(ctx){
  const { anioK, patrimonio, racha, fasesAnio, personalidad } = ctx;

  if(patrimonio && patrimonio.pct !== null && patrimonio.pct >= 50){
    return _wrappedBankPick('poema-patrimonioFuerte', [
      'No fue un año cualquiera. Hubo meses de sembrar y meses de cosechar, decisiones chicas que se sumaron sin que las notaras — y al final, un salto que sí se nota. Eso no pasa solo, pasa porque lo sostuviste.',
      'Hubo constancia detrás de este número, aunque no siempre se sintiera así en el día a día. Cada decisión pequeña fue construyendo algo más grande de lo que parecía en el momento.',
    ], anioK);
  }
  if(racha >= 4){
    return _wrappedBankPick('poema-racha', [
      'No fue perfecto, pero fue constante — y la constancia, con el tiempo, pesa más que la perfección. Cada vez que decidiste guardar en lugar de gastar, sin darte cuenta, armaste un hábito.',
      'Hubo meses fáciles y meses en los que seguramente costó más. Aun así, seguiste apareciendo — y eso, repetido tantas veces, ya no es casualidad.',
    ], anioK + racha);
  }
  if(patrimonio && patrimonio.pct !== null && patrimonio.pct <= -25){
    return _wrappedBankPick('poema-patrimonioCayo', [
      'No fue un año fácil, y no hace falta disimularlo. Hubo gastos que no esperabas y decisiones que tocó tomar rápido. Pero seguiste registrando, seguiste mirando de frente lo que pasaba con tu plata — y eso también cuenta como avanzar.',
      'Hubo meses pesados, de esos que uno preferiría no repetir. Aun así, llegaste hasta acá con los ojos abiertos sobre tus propios números, que ya es más de lo que hace la mayoría.',
    ], anioK);
  }
  if(fasesAnio){
    return _wrappedBankPick('poema-fases', [
      'Este año no fue igual de principio a fin, y está bien que no lo fuera. Hubo una primera mitad y una segunda mitad distintas, como si en el medio hubieras aprendido algo sobre cómo manejar tu plata. Los años así, los que cambian de forma, suelen ser los que más enseñan.',
      'Empezaste el año de una manera y lo terminaste pensando distinto tu plata. Ese giro, aunque no se note en un solo número, es de las cosas que más vale la pena repasar.',
    ], anioK);
  }
  if(personalidad){
    return _wrappedBankPick('poema-personalidad', [
      `Un año con su propio estilo: el de ${personalidad.tipo}. No hubo una sola decisión grande que lo definiera, sino muchas chicas, repetidas, que terminaron formando un patrón reconocible.`,
      `Si tu plata tuviera una forma de ser este año, sería la de ${personalidad.tipo}. Ni perfecta ni dramática — simplemente tú, movimiento a movimiento.`,
    ], anioK + personalidad.tipo);
  }
  return _wrappedBankPick('poema-generico', [
    'No fue perfecto. Hubo meses buenos y meses tranquilos, algún gasto inesperado y alguna decisión de la que te sentiste orgulloso. Sobre todo, hubo continuidad: seguiste registrando, seguiste mirando. Eso, más que cualquier número, es lo que queda.',
    'Fue un año de movimientos chicos que, vistos juntos, cuentan algo más grande. No hace falta que haya sido espectacular para que haya valido la pena repasarlo.',
  ], anioK);
}


/* ─── PERSONALIDAD FINANCIERA ──────────────────────────────────────────
   Clasificación LÚDICA (nunca un puntaje financiero serio, ver el propio
   pedido del usuario §10) elegida por reglas deterministas sobre datos
   que YA se calculan en otro lado de este archivo — nunca un cálculo
   nuevo por su cuenta, mismo principio de §3. Se prueba en orden de más
   específico/raro a más genérico y se queda con el primer match: un CDT
   es un dato inequívoco (`_wrappedCalcularPeriodo` ignora esto porque no
   es gasto/ingreso), mientras que "equilibrista" es el fallback más
   débil (cualquier año sin nada más raro cae ahí). Si NINGUNA regla
   aplica con datos suficientes, devuelve `null` — nunca fuerza una
   personalidad de relleno (regla del propio pedido, §33 "no forzar
   insights"). */
/* Cada candidato conserva EXACTAMENTE la misma condición y el mismo
   banco de frases que la versión anterior (de un solo resultado) — lo
   único nuevo es que ahora se evalúan TODOS en vez de cortar en el
   primer match, para poder ofrecer un "rasgo secundario" real (pase de
   diseño 2026-09-14, inspirado en el mockup de referencia). `evidencia`
   es una frase corta y puramente factual (no narrativa como `frase`) que
   se muestra como chip debajo — mismos datos ya calculados arriba,
   nunca un número nuevo. El orden de la lista sigue siendo la prioridad
   de "más específico/raro" a "más genérico" de siempre: si dos
   candidatos aplican, el primero de la lista es el rasgo principal. */
function _wrappedPersonalidad(S, anioK){
  const cajitas = _wrappedListaCajitas(S);
  const cuentasActivasN = (S.cuentas || []).filter(c => c && !c.archivada && c.tipo !== 'ahorro');
  const deudores = Deudas.lista('favor');
  const prestado = _wrappedCalcularPrestado(S, 'anio', null, anioK);
  const periodo = _wrappedCalcularPeriodo(S, 'anio', null, anioK);
  let racha = 0;
  if(typeof window !== 'undefined' && typeof window._alcRachaAhorro === 'function' && S.alcancia && S.alcancia.historial){
    racha = window._alcRachaAhorro(S.alcancia.historial);
  }
  const catsDistintas = new Set((S.gastosVar||[]).map(g => g.cat).filter(Boolean)).size;
  const tieneCdt = cajitas.some(c => Array.isArray(c.cdts) && c.cdts.length > 0);

  const candidatos = [];

  if(tieneCdt){
    candidatos.push({ tipo:'El Inversionista', evidencia:'tienes al menos un CDT activo', frase: _wrappedBankPick('personalidad-inversionista', [
      'No solo guardaste plata — la pusiste a producir.',
      'Tu plata no se quedó quieta: la pusiste a rendir.',
    ]) });
  }
  if(prestado && prestado.totalPrestado > 0 && deudores.length >= 3){
    candidatos.push({ tipo:'El Banquero', evidencia:`fuiste banco de ${deudores.length} personas`, frase: _wrappedBankPick('personalidad-banquero', [
      `Este año también fuiste banco de ${deudores.length} personas.`,
      `${deudores.length} personas contaron contigo como su banco personal este año.`,
    ], deudores.length) });
  }
  if(racha >= 4){
    candidatos.push({ tipo:'El Acumulador', evidencia:`${racha} alcancías seguidas sin fallar`, frase: _wrappedBankPick('personalidad-acumulador', [
      `${racha} alcancías seguidas sin fallar — eso no es suerte.`,
      `${racha} veces seguidas mejorando tu ahorro. Eso ya es un patrón.`,
    ], racha) });
  }
  if((cajitas.length + cuentasActivasN.length) >= 6){
    candidatos.push({ tipo:'El Multicuenta', evidencia:`${cajitas.length + cuentasActivasN.length} cuentas y cajitas activas`, frase: _wrappedBankPick('personalidad-multicuenta', [
      'Tu plata vive repartida en muchos lugares distintos.',
      'Tienes más cuentas que la mayoría — y a todas les llevas la cuenta.',
    ]) });
  }
  if(catsDistintas >= 6){
    candidatos.push({ tipo:'El Organizador', evidencia:`${catsDistintas} categorías de gasto distintas`, frase: _wrappedBankPick('personalidad-organizador', [
      `Repartiste tus gastos entre ${catsDistintas} categorías distintas.`,
      `${catsDistintas} categorías distintas — a tu plata no le falta orden.`,
    ], catsDistintas) });
  }
  if(Number.isFinite(periodo.balance) && periodo.totalIngresos > 0 && Math.abs(periodo.balance)/periodo.totalIngresos < 0.15){
    candidatos.push({ tipo:'El Equilibrista', evidencia:'ingresos y gastos casi empatados', frase: _wrappedBankPick('personalidad-equilibrista', [
      'Lo que entró y lo que salió estuvieron muy parejos.',
      'Ingresos y gastos casi calcados este año — un balance envidiable.',
    ]) });
  }

  if(!candidatos.length) return null; // no forzar una personalidad si ninguna señal es clara

  const top = candidatos[0];
  // El rasgo secundario también es un match real, con su propia evidencia
  // real — nunca un segundo puesto inventado para rellenar el slide
  // (misma regla de "no forzar" que ya aplicaba al resultado único).
  const secundario = candidatos.length > 1 ? candidatos[1] : null;
  // `_candidatos` (2026-09-15): la lista completa, en el mismo orden de
  // prioridad de siempre — agregada solo para que el panel de debug
  // visual (`_wrappedDebugPanelHtml`) pueda mostrar qué otros arquetipos
  // también aplicaron y no se usaron, sin recalcular nada. Prefijo `_`
  // porque ningún llamador productivo (el slide de personalidad) debe
  // depender de este campo — solo lee `tipo`/`frase`/`evidencia`/`secundario`,
  // igual que antes de este cambio.
  return { tipo: top.tipo, frase: top.frase, evidencia: top.evidencia, secundario, _candidatos: candidatos };
}

/* ─── GASTO MÁS RANDOM ─────────────────────────────────────────────────
   Distinto de "Tu gasto más grande" (que ya existe y usa `_wrappedCalcularPeriodo`):
   ese es el mayor en pesos; este es el más INESPERADO — una descripción
   que no se repitió ni una vez más en el período (`frecuencia === 1`) y
   que además se aleja bastante del gasto típico del usuario (z-score de
   su propio promedio y desviación, nunca un umbral fijo en pesos —
   mismo criterio "en relación al propio usuario" que ya usa
   `_wrappedCopyGasto`). Reutiliza el MISMO filtro de gasto real que
   `_wrappedCalcularPeriodo` (nunca un filtro propio, ver §3) recorriendo
   `S.gastosVar` con `_esGastoVarNoReal()`. Nunca elige el mismo gasto que
   ya ganó "el más grande" — sería repetir el mismo dato con otro marco. */
function _wrappedGastoMasRandom(S, tipo, mesK, anioK, gastoMasGrande){
  const gastosVar = S.gastosVar || [];
  const esGastoNoReal = typeof _esGastoVarNoReal === 'function' ? _esGastoVarNoReal : (()=>false);
  const periodo = gastosVar.filter(g => _wrappedEnRango(g.fecha, tipo, mesK, anioK) && !esGastoNoReal(g));
  if(periodo.length < 5) return null; // muy poca base para que un "z-score" signifique algo

  const montos = periodo.map(g => g.monto||0);
  const mean = montos.reduce((a,b)=>a+b,0) / montos.length;
  const variance = montos.reduce((a,b)=>a+(b-mean)*(b-mean),0) / montos.length;
  const std = Math.sqrt(variance);
  if(std <= 0) return null;

  const frecuencia = {};
  periodo.forEach(g => {
    const k = (g.desc||'').trim().toLowerCase();
    frecuencia[k] = (frecuencia[k]||0) + 1;
  });

  let candidato = null, mejorZ = 0;
  periodo.forEach(g => {
    if(gastoMasGrande && g.desc === gastoMasGrande.desc && g.monto === gastoMasGrande.monto) return; // no repetir el mismo slide
    const k = (g.desc||'').trim().toLowerCase();
    if(frecuencia[k] !== 1) return; // solo pasó una vez
    const z = Math.abs(((g.monto||0) - mean) / std);
    if(z > mejorZ){ mejorZ = z; candidato = g; }
  });

  if(!candidato || mejorZ < 0.8) return null; // nada realmente fuera de patrón
  return { desc: candidato.desc || 'Ese gasto', monto: candidato.monto||0, cat: candidato.cat||null, z: mejorZ };
}

/* ─── TUS PROTAGONISTAS ────────────────────────────────────────────────
   Con quién tuviste más actividad financiera en el período, sumando
   movimientos de TODOS los módulos que involucran personas (Encargos,
   Prestado, Spotify) — nunca solo uno. Cuenta MOVIMIENTOS (interacción),
   no plata — es una pregunta distinta de "quién te encargó más" o "a
   quién le prestaste más" (esas ya las responden sus propios slides de
   §7ter). Agrupa por `personaId` cuando existe; si no, por nombre crudo
   — mismo criterio de "sin perfil" de personas.md §2/§6. */
function _wrappedProtagonistas(S, tipo, mesK, anioK){
  const conteo = {}; // key -> {nombre, personaId, n}
  const sumar = (key, nombre, personaId, n) => {
    if(!key) return;
    if(!conteo[key]) conteo[key] = { nombre, personaId, n: 0 };
    conteo[key].n += n;
  };

  (S.encargos||[]).forEach(enc => {
    const n = (enc.movimientos||[]).filter(m => m && _wrappedEnRango(m.fecha, tipo, mesK, anioK)).length;
    if(n>0) sumar(enc.personaId||enc.nombre, enc.nombre, enc.personaId||null, n);
  });
  Deudas.lista('favor').forEach(d => {
    const n = (d.movimientos||[]).filter(m => m && _wrappedEnRango(m.fecha, tipo, mesK, anioK)).length;
    if(n>0) sumar(d.personaId||d.nombre, d.nombre, d.personaId||null, n);
  });
  Deudas.lista('contra').forEach(d => {
    const n = (d.movimientos||[]).filter(m => m && _wrappedEnRango(m.fecha, tipo, mesK, anioK)).length;
    if(n>0) sumar(d.personaId||d.nombre, d.nombre, d.personaId||null, n);
  });
  ((S.spotify||{}).historial||[]).forEach(h => {
    if(h && h.tipo==='cobro' && h.spId && _wrappedEnRango(h.fecha, tipo, mesK, anioK)){
      const sp = ((S.spotify||{}).personas||[]).find(p => p.id === h.spId);
      const nombre = sp ? sp.nombre : h.nombre;
      const personaId = sp ? sp.personaId : null;
      sumar(personaId||nombre, nombre, personaId||null, 1);
    }
  });

  const lista = Object.values(conteo).sort((a,b) => b.n - a.n);
  if(!lista.length) return null;
  return { top: lista[0], total: lista.length };
}

/* ═══════════════════════════════════════════════════════════════════════
   TERCERA TANDA (2026-09-14) — Gráfico mensual Ingresos/Gastos interactivo,
   comparaciones curiosas, suscripciones personales, recuperación de
   préstamo más rápida, "cosas que no sabías", "lo más extremo del año" y
   "tu año en una frase". Traído a pedido explícito del usuario desde un
   prototipo standalone (my-money-wrapped.html) que no comparte código con
   este módulo.

   OJO CON §1/§3 DE wrapped.md: el gráfico mensual de acá abajo SÍ pinta
   ingresos y gastos reales mes a mes — una excepción puntual y consciente
   a "Wrapped nunca muestra ingresos/gastos en crudo", pedida
   explícitamente por el usuario después de ver el chart equivalente del
   prototipo. Documentada acá y en wrapped.md §7, no es una
   reinterpretación silenciosa de la regla. El resto de esta tanda (récords,
   comparaciones, descubrimientos) SÍ respeta la regla original: solo
   valores puntuales (un gasto, un préstamo, un mes) o conteos, nunca el
   ingreso/gasto/balance agregado de todo el año — por eso, por ejemplo,
   "Lo más extremo del año" no incluye "ahorro neto" (sería literalmente
   el balance del año completo) aunque el prototipo original sí lo tenía. */

/* ─── GRÁFICO MENSUAL INGRESOS/GASTOS (interactivo) ────────────────────
   Reutiliza `_wrappedCalcularPeriodo` mes a mes — mismo patrón de loop
   que ya usan `_wrappedHistoriasMensuales`/`_wrappedMejorPeorMesAnio` —
   nunca reimplementa el cálculo de ingresos/gastos por su cuenta. */
function _wrappedSerieMensualIngresoGasto(S, anioK, mesMax){
  const meses = [];
  for(let m=0; m<=mesMax; m++){
    const mesK = Fecha.mesKey(anioK, m+1);
    const stats = _wrappedCalcularPeriodo(S, 'mes', mesK, anioK);
    if(stats.totalIngresos > 0 || stats.totalGastos > 0){
      meses.push({ mesK, ingresos: stats.totalIngresos, gastos: stats.totalGastos, balance: stats.balance });
    }
  }
  return meses.length >= 2 ? meses : null;
}

/* Dos líneas (ingresos/gastos) + una zona invisible tappable por mes
   (`data-wrapped-mesidx`, ver `_wrappedSetupNav`) + un punto por mes en
   cada línea. A diferencia de `_wrappedGraficoAnimadoSvg` (patrimonio, se
   anima "dibujándose" con dasharray), este no se dibuja: revela sus
   puntos con un delay escalonado (ver `_wrappedSetupGraficoMensual`) y
   arranca seleccionado en el último mes. */
function _wrappedGraficoMensualSvg(meses){
  const w = 300, h = 140, padX = 10, padY = 16, padLabel = 14;
  const maxV = Math.max(1, ...meses.map(m => Math.max(m.ingresos, m.gastos)));
  const stepX = meses.length > 1 ? (w - padX*2) / (meses.length - 1) : 0;
  const xOf = i => padX + i*stepX;
  const yOf = v => (h - padY - padLabel) - (v/maxV) * (h - padY*2 - padLabel);
  const pathDe = key => meses.map((m,i) => (i===0?'M':'L') + xOf(i).toFixed(1) + ',' + yOf(m[key]).toFixed(1)).join(' ');
  const dotsDe = (key, clase) => meses.map((m,i) => `<circle class="wrapped-mes-dot ${clase}" data-idx="${i}" cx="${xOf(i).toFixed(1)}" cy="${yOf(m[key]).toFixed(1)}" r="3.5"/>`).join('');
  const labels = meses.map((m,i) => `<text class="wrapped-mes-label" data-idx="${i}" x="${xOf(i).toFixed(1)}" y="${h-2}" font-size="9" text-anchor="middle" font-family="'DM Mono',monospace" fill="var(--text3)">${_wrappedMesKaAbrev(m.mesK)}</text>`).join('');
  const hitzones = meses.map((m,i) => `<rect data-wrapped-mesidx="${i}" x="${(xOf(i)-(stepX||w)/2).toFixed(1)}" y="0" width="${(stepX||w).toFixed(1)}" height="${h}" fill="transparent" class="wrapped-hit"/>`).join('');
  return `<svg aria-hidden="true" class="wrapped-mensual-svg wrapped-svg-block" viewBox="0 0 ${w} ${h}" width="100%" height="${h}">
    <path d="${pathDe('ingresos')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="${pathDe('gastos')}" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <g>${dotsDe('ingresos','wrapped-dot-ingreso')}${dotsDe('gastos','wrapped-dot-gasto')}</g>
    <g>${labels}</g>
    <g>${hitzones}</g>
  </svg>`;
}

function _wrappedMesDetalleHtml(meses, idx, fmt2){
  const m = meses[idx];
  const prev = meses[idx-1];
  let comparacion;
  if(prev){
    const diff = m.gastos - prev.gastos;
    const pctDiff = prev.gastos ? Math.abs(Math.round((diff/prev.gastos)*100)) : 0;
    comparacion = pctDiff >= 5
      ? `Gastaste un ${pctDiff}% ${diff>0?'más':'menos'} que en ${_wrappedMesKaNombre(prev.mesK)}.`
      : `Gastaste casi lo mismo que en ${_wrappedMesKaNombre(prev.mesK)}.`;
  } else {
    comparacion = 'Tu primer mes con datos este año.';
  }
  const colorBalance = m.balance >= 0 ? 'c-green' : 'c-red';
  return `<div class="wrapped-mes-head">${_wrappedMesKaNombre(m.mesK)}</div>
    <div class="wrapped-mes-fila"><span>Ingresos</span><b class="c-green">${fmt2(m.ingresos)}</b></div>
    <div class="wrapped-mes-fila"><span>Gastos</span><b class="c-red">${fmt2(m.gastos)}</b></div>
    <div class="wrapped-mes-fila"><span>Balance</span><b class="${colorBalance}">${_wrappedFmtSigned(fmt2, m.balance)}</b></div>
    <div class="wrapped-mes-compara">${comparacion}</div>`;
}

/* Estado del gráfico mensual activo — un único global que se reemplaza
   por completo en cada apertura de la pantalla (mismo patrón que
   `_wrappedNav`), porque el click delegado de `_wrappedSetupNav` necesita
   acceso a los datos del mes tocado sin tener que rearmar el HTML. */
let _wrappedMesChart = null;

function _wrappedSeleccionarMes(slideEl, idx){
  if(!_wrappedMesChart || !slideEl) return;
  const { meses, fmt2 } = _wrappedMesChart;
  if(idx < 0 || idx >= meses.length) return;
  slideEl.querySelectorAll('.wrapped-mes-label').forEach(t => t.classList.toggle('activo', parseInt(t.getAttribute('data-idx'),10) === idx));
  slideEl.querySelectorAll('.wrapped-mes-dot').forEach(c => c.setAttribute('r', parseInt(c.getAttribute('data-idx'),10) === idx ? '5.5' : '3.5'));
  const detalle = slideEl.querySelector('.wrapped-mes-detalle');
  if(detalle) detalle.innerHTML = _wrappedMesDetalleHtml(meses, idx, fmt2);
}

/* Se dispara al entrar al slide del gráfico mensual (ver `_wrappedGoTo`):
   revela los puntos de cada mes con un delay escalonado (mismo espíritu
   de "revelación" que el resto de Wrapped) y deja seleccionado el último
   mes por default. Respeta prefers-reduced-motion mostrando todo de una. */
function _wrappedSetupGraficoMensual(slideEl){
  if(!_wrappedMesChart || !slideEl) return;
  const { meses } = _wrappedMesChart;
  const dots = slideEl.querySelectorAll('.wrapped-mes-dot');
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  dots.forEach(d => { d.style.opacity = '0'; });
  if(reduce || typeof setTimeout !== 'function'){
    dots.forEach(d => { d.style.opacity = '1'; });
    _wrappedSeleccionarMes(slideEl, meses.length - 1);
    return;
  }
  meses.forEach((_, i) => {
    setTimeout(() => {
      slideEl.querySelectorAll(`.wrapped-mes-dot[data-idx="${i}"]`).forEach(d => { d.style.transition = 'opacity .25s ease'; d.style.opacity = '1'; });
    }, i * (700 / Math.max(meses.length,1)));
  });
  setTimeout(() => _wrappedSeleccionarMes(slideEl, meses.length - 1), 750);
}

/* Lista simple de frases sueltas — reusada por comparaciones, suscripciones
   y descubrimientos (todas son "una lista de datos curiosos en prosa",
   nunca una tabla de cifras). */
function _wrappedFrasesHtml(frases){
  return `<div class="wrapped-frases">${frases.map(f => `<div class="wrapped-moment"><i class="wrapped-moment-dot"></i><span>${f}</span></div>`).join('')}</div>`;
}

/* ─── COMPARACIONES QUE SE ENTIENDEN MEJOR ASÍ ─────────────────────────
   Ninguna cifra nueva: relaciona números que este archivo ya calcula en
   otro lado (gasto más grande vs. gasto promedio, ambos de `s`; el mismo
   `(S.spotify||{}).costo` que usa `spotify.js`; los depósitos de Alcancía del
   período que ya sabe contar `_wrappedCalcularPeriodo`) — nunca un
   cálculo propio, mismo principio de §3. Necesita al menos 2
   comparaciones reales para armar el slide — una sola suelta no amerita
   su propio slide. */
function _wrappedAlcanciaDepositosPeriodo(S, tipo, mesK, anioK){
  const a = S.alcancia;
  if(!a) return 0;
  let n = 0;
  if(!a._destapada){
    n += (a.movimientos||[]).filter(m => m && _wrappedEnRango(m.fecha, tipo, mesK, anioK)).length;
  }
  (a.historial||[]).forEach(h => { if(h && _wrappedEnRango(h.fechaFin, tipo, mesK, anioK)) n += (h.depositos||0); });
  return n;
}
function _wrappedComparaciones(S, tipo, mesK, anioK, s){
  const frases = [];
  let intensidadMax = 0;

  const { gastosVarPeriodo } = _wrappedItemsRealesPeriodo(S, tipo, mesK, anioK);
  const transporte = gastosVarPeriodo.filter(g => g.cat === 'Transporte').reduce((a,g)=>a+(g.monto||0),0);
  const spotifyCosto = (S.spotify||{}).costo || 0;
  if(transporte > 0 && spotifyCosto > 0){
    const veces = transporte / spotifyCosto;
    if(veces >= 0.3){
      frases.push(`Tu gasto en transporte equivalió a ${veces.toFixed(1)} meses de tu Spotify compartido.`);
      intensidadMax = Math.max(intensidadMax, Math.min(4, veces));
    }
  }

  if(s.gastoMasGrande && s.avgGasto > 0){
    const veces = s.gastoMasGrande.monto / s.avgGasto;
    if(veces >= 2){
      frases.push(`Tu gasto más grande fue ${veces.toFixed(1)} veces más grande que tu gasto promedio.`);
      intensidadMax = Math.max(intensidadMax, Math.min(4, veces/2));
    }
  }

  if(s.alcanciaPeriodo > 0){
    const depositos = _wrappedAlcanciaDepositosPeriodo(S, tipo, mesK, anioK);
    if(depositos > 0){
      frases.push(`Tu alcancía guardó plata en ${depositos} depósito${depositos===1?'':'s'} silenciosos.`);
      intensidadMax = Math.max(intensidadMax, 1);
    }
  }

  return frases.length >= 2 ? { frases, intensidadMax } : null;
}

/* ─── SUSCRIPCIONES Y GASTOS RECURRENTES ───────────────────────────────
   Spotify ya tiene su propio slide de ganancia/pérdida (dominios "de
   terceros" arriba) — este es un ángulo distinto: "cuánto te cuesta cada
   mes solo por existir". SIMPLIFICACIÓN RECONOCIDA: usa la cuota VIGENTE
   HOY de cada gasto fijo categoría "Suscripciones" (`S.gastosFijos`), no
   un total histórico pagado durante el año — no hay en este archivo forma
   segura de reconstruir esa suma sin conocer la forma interna exacta de
   `S.pagosGastosFijos` más allá de lo ya documentado (un mapa). Mismo tipo de simplificación honesta que ya reconoce este
   archivo para la ganancia de Spotify (ver comentario de
   `_wrappedCalcularSpotify`). */
function _wrappedSuscripciones(S){
  const fijos = Array.isArray(S.gastosFijos) ? S.gastosFijos : [];
  const personales = fijos
    .filter(f => f && f.cat === 'Suscripciones')
    .map(f => ({ desc: f.nombre || 'Suscripción', monto: f.monto || 0 }))
    .filter(p => p.monto > 0);

  const spotifyActivo = Array.isArray((S.spotify||{}).personas) && (S.spotify||{}).personas.length > 0;
  if(!personales.length && !spotifyActivo) return null;

  return {
    personales,
    spotify: spotifyActivo ? { personas: (S.spotify||{}).personas.length, costoMensual: (S.spotify||{}).costo || 0 } : null
  };
}

/* ─── RECUPERACIÓN MÁS RÁPIDA DE UN PRÉSTAMO ───────────────────────────
   Solo considera el caso simple —un deudor con exactamente un préstamo y
   un pago que lo cubre por completo—: con varios ciclos de
   préstamo/abono mezclados, "primero a último movimiento" daría un
   número de días engañoso, así que esos deudores simplemente no
   participan de este dato en vez de mostrar algo probablemente
   incorrecto. Filtra a préstamos otorgados dentro del año — un préstamo
   de un año anterior devuelto rápido este año no es "un dato de este
   año". */
function _wrappedRecuperacionMasRapida(S, anioK){
  const deudores = Deudas.lista('favor');
  let mejor = null;
  deudores.forEach(d => {
    const movs = (Array.isArray(d.movimientos) ? d.movimientos : [])
      .filter(m => m && typeof m.fecha === 'string')
      .slice()
      .sort((a,b) => a.fecha.localeCompare(b.fecha));
    if(movs.length !== 2) return;
    const [primero, segundo] = movs;
    if(primero.tipo !== 'prestamo') return;
    if(!(segundo.tipo === 'abono' || segundo.tipo === 'pago-completo')) return;
    if(segundo._perdon) return; // perdonada ≠ recuperada: no es una devolución rápida
    if((segundo.monto||0) < (primero.monto||0)) return;
    if(primero.fecha.slice(0,4) !== anioK) return;
    const dias = Fecha.diasEntre(primero.fecha, segundo.fecha);
    if(!Number.isFinite(dias) || dias < 0) return;
    if(!mejor || dias < mejor.dias){
      mejor = { dias, nombre: d.nombre, personaId: d.personaId || null, monto: primero.monto||0 };
    }
  });
  return mejor;
}

/* ─── "COSAS QUE PROBABLEMENTE NO SABÍAS" ──────────────────────────────
   Sobras curiosas que no ameritan su propio slide dedicado. Necesita al
   menos 2 para armarse. El día más activo cuenta movimientos de todos los
   dominios que ya filtra el resto del archivo por fecha (gasto real,
   movimientos de cuentas sin aperturas, préstamos, Alcancía) — nunca una
   fuente nueva. La comparación "prestaste más de lo que te entró" A
   PROPÓSITO nunca muestra el ingreso total del año en pantalla
   (`s.totalIngresos` es de uso interno únicamente, ver §3) — solo lo usa
   para decidir si la frase (sin cifra) aplica. */
function _wrappedDescubrimientos(S, anioK, s, prestadoAnio){
  const leftovers = [];
  const { gastosVarPeriodo } = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);

  const conteoDias = {};
  const bump = fecha => { if(typeof fecha === 'string' && fecha.slice(0,4) === anioK) conteoDias[fecha] = (conteoDias[fecha]||0) + 1; };
  gastosVarPeriodo.forEach(g => bump(g.fecha));
  (S.movimientos||[]).forEach(m => { if(m && m.tipo !== 'apertura') bump(m.fecha); });
  Deudas.lista('favor').forEach(d => (d.movimientos||[]).forEach(m => m && bump(m.fecha)));
  Deudas.lista('contra').forEach(d => (d.movimientos||[]).forEach(m => m && bump(m.fecha)));
  if(S.alcancia && Array.isArray(S.alcancia.movimientos)) S.alcancia.movimientos.forEach(m => m && bump(m.fecha));
  const diasOrdenados = Object.entries(conteoDias).sort((a,b) => b[1]-a[1]);
  if(diasOrdenados.length && diasOrdenados[0][1] >= 3){
    const [fechaTop, n] = diasOrdenados[0];
    const dia = parseInt(fechaTop.slice(8,10),10);
    const mesTxt = _MES_NOMBRE[parseInt(fechaTop.slice(5,7),10)-1] || '';
    leftovers.push(`Tu día más movido fue el ${dia} de ${mesTxt}, con ${n} movimientos.`);
  }

  const conNota = gastosVarPeriodo.find(g => g.nota && String(g.nota).trim().length > 3);
  if(conNota){
    leftovers.push(`Hasta tus notas cuentan historias: sobre "${escHtml(conNota.desc||'ese gasto')}" dejaste escrito "${escHtml(String(conNota.nota).trim())}".`);
  }

  if(prestadoAnio && prestadoAnio.totalPrestado > 0 && s.totalIngresos > 0 && prestadoAnio.totalPrestado > s.totalIngresos){
    leftovers.push('Prestaste más plata de la que te entró en ingresos este año — generoso, aunque el bolsillo lo haya sentido.');
  }

  return leftovers.length >= 2 ? leftovers : null;
}

/* ─── "LO MÁS EXTREMO DEL AÑO" ─────────────────────────────────────────
   Grid de récords puntuales — nunca agregados del año completo. A
   PROPÓSITO no incluye "ahorro neto" (a diferencia del prototipo del que
   se trajo esta idea): sería literalmente el `balance` de todo el año,
   exactamente lo que §3 prohíbe mostrar. Cada campo de acá es un extremo
   puntual (el gasto más grande, el mes más caro) o un conteo, igual que
   el resto de "datos curiosos" de este módulo. */
function _wrappedRecordsAnio(S, anioK, s, prestadoAnio, serieMensual){
  let mayorIngreso = null;
  _wrappedEntradasIngreso(S).forEach(m => {
    if(_wrappedEnRango(m.fecha,'anio',null,anioK) && (m.monto||0) > (mayorIngreso?mayorIngreso.monto:0)){
      mayorIngreso = { monto: m.monto||0 };
    }
  });

  let mayorPrestamo = null;
  Deudas.lista('favor').forEach(d => (d.movimientos||[]).forEach(m => {
    if(m && m.tipo==='prestamo' && _wrappedEnRango(m.fecha,'anio',null,anioK) && (m.monto||0) > (mayorPrestamo?mayorPrestamo.monto:0)){
      mayorPrestamo = { monto: m.monto||0 };
    }
  }));

  let mesMasCaro = null;
  if(serieMensual){
    serieMensual.forEach(m => { if(!mesMasCaro || m.gastos > mesMasCaro.gastos) mesMasCaro = m; });
  }

  const { gastosVarPeriodo } = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);
  let totalMovs = gastosVarPeriodo.length + (S.movimientos||[]).length;
  Deudas.lista('favor').forEach(d => totalMovs += (d.movimientos||[]).length);
  Deudas.lista('contra').forEach(d => totalMovs += (d.movimientos||[]).length);

  const registros = [
    { l:'Mayor gasto', v: s.gastoMasGrande ? s.gastoMasGrande.monto : null, fmt:'money' },
    { l:'Mayor ingreso', v: mayorIngreso ? mayorIngreso.monto : null, fmt:'money' },
    { l:'Mayor préstamo', v: mayorPrestamo ? mayorPrestamo.monto : null, fmt:'money' },
    { l:'Mes más caro', v: mesMasCaro ? _wrappedMesKaAbrev(mesMasCaro.mesK) : null, fmt:'text' },
    { l:'Ahorro neto', v: s.balance, fmt:'money' },
    { l:'Movimientos totales', v: totalMovs || null, fmt:'text' }
  ];
  return registros.some(r => r.v !== null) ? registros : null;
}

/* Cuenta identidades distintas involucradas en dominios "de terceros" —
   deudores, "yo debo", integrantes de Spotify, encargantes — usando
   `personaId` cuando existe y el nombre crudo como fallback, para no
   contar dos veces a la misma persona vinculada al sistema unificado. */
function _wrappedPersonasInvolucradas(S){
  const set = new Set();
  const add = (personaId, nombre) => { if(personaId) set.add('p:'+personaId); else if(nombre) set.add('n:'+String(nombre).toLowerCase()); };
  Deudas.lista('favor').forEach(d => add(d.personaId, d.nombre));
  Deudas.lista('contra').forEach(d => add(d.personaId, d.nombre));
  ((S.spotify||{}).personas||[]).forEach(p => add(p.personaId, p.nombre));
  (S.encargos||[]).forEach(e => add(e.personaId, e.nombre));
  return set.size;
}

/* ─── "TU AÑO EN NÚMEROS" ──────────────────────────────────────────────
   A diferencia de todo lo demás en este archivo, este slide SÍ muestra
   los agregados completos del año (ingresos, gastos, ahorro neto, dinero
   movido) — decisión explícita del usuario (2026-09-14) para que el
   módulo quede igual al prototipo del que se trajo esta idea, ver
   wrapped.md §1/§3/§7decies para el detalle de qué regla se relajó y
   por qué. */
function _wrappedPeriodoEnNumeros(S, anioK, s, prestadoAnio, serieMensual){
  const { gastosVarPeriodo } = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);
  const categorias = new Set(gastosVarPeriodo.map(g => g.cat).filter(Boolean)).size;
  let totalMovs = gastosVarPeriodo.length + (S.movimientos||[]).length;
  Deudas.lista('favor').forEach(d => totalMovs += (d.movimientos||[]).length);
  Deudas.lista('contra').forEach(d => totalMovs += (d.movimientos||[]).length);
  return [
    { l:'Dinero movido', v: s.totalIngresos + s.totalGastos, fmt:'money' },
    { l:'Ingresos', v: s.totalIngresos, fmt:'money' },
    { l:'Gastos', v: s.totalGastos, fmt:'money' },
    { l:'Ahorro neto', v: s.balance, fmt:'money' },
    { l:'Prestado', v: prestadoAnio ? prestadoAnio.totalPrestado : 0, fmt:'money' },
    { l:'Personas', v: _wrappedPersonasInvolucradas(S), fmt:'text' },
    { l:'Categorías', v: categorias, fmt:'text' },
    { l:'Meses activos', v: serieMensual ? serieMensual.length : 0, fmt:'text' },
    { l:'Movimientos', v: totalMovs, fmt:'text' }
  ];
}
function _wrappedRecordsHtml(registros, fmt2){
  const filas = registros.map(r => `<div class="wrapped-record"><div class="wrapped-record-l">${r.l}</div><div class="wrapped-record-v">${r.v===null?SIN_DATO:(r.fmt==='money'?fmt2(r.v):escHtml(String(r.v)))}</div></div>`).join('');
  return `<div class="wrapped-records-grid">${filas}</div>`;
}

/* ─── "TU AÑO EN UNA FRASE" ─────────────────────────────────────────────
   Puramente decorativo, mismo criterio que `_wrappedSiTuAnioFuera`: no
   calcula nada nuevo, solo junta frases candidatas según señales que
   este archivo ya calculó en otro lado. `tasaAhorroInterna` se usa
   SOLO para elegir la frase, nunca se pinta (mismo criterio de §3 que ya
   aplica `balance`/`promedio` en el resto del archivo). Semilla
   determinística (año + cantidad de opciones que aplicaron) para que no
   cambie de frase si se re-renderiza la misma historia. */
function _wrappedFraseDelAnio(ctx){
  const { anioK, esBanquero, tasaAhorroInterna, fasesAnio, prestadoDistintoDeRecuperacion } = ctx;
  const opciones = [];
  if(esBanquero && tasaAhorroInterna > 0.25) opciones.push('Un año de prestar, recuperar y aun así seguir ahorrando.');
  if(esBanquero) opciones.push('Un año donde tu dinero también salió a trabajar para otros.');
  if(tasaAhorroInterna > 0.3) opciones.push('Un año de aprender a guardar dinero sin dejar de disfrutarlo.');
  if(fasesAnio) opciones.push('Un año que no fue igual de principio a fin.');
  if(esBanquero && prestadoDistintoDeRecuperacion) opciones.push('Ahorraste, prestaste, gastaste y, contra todo pronóstico, llegaste al final.');
  opciones.push('Un año de organizar más que de gastar.');

  // Reutiliza el mismo banco de frases del resto del módulo (ver
  // cabecera de sección de `_wrappedBankPick`) en vez de su propio hash
  // local — misma semilla determinista basada en datos reales, en vez
  // de solo `anioK + opciones.length` (que antes podía coincidir entre
  // años distintos con la misma cantidad de opciones aplicables).
  return _wrappedBankPick('fraseDelAnio', opciones, opciones.length);
}

/* ─── ARMADO DE LA LISTA DE SLIDES DEL AÑO ────────────────────────────────
   Solo incluye un slide por cada dato curioso que realmente exista —
   mismas condiciones que ya usaba la versión de una sola pantalla, ahora

   cada una es su propia revelación en vez de una tarjeta más en la
   lista. */
/* ─── MOTOR DE SCORING DE INSIGHTS (2026-09-13) ────────────────────────
   Reabre §6/§32 del brief original: "no mostrar 50 insights aleatorios...
   crear un sistema de scoring... así el Wrapped se siente curado." Antes
   de esto, CADA dominio de terceros + CADA "descubrimiento" (gasto
   random, protagonistas, meta, cambio de hábitos, fases) se mostraba
   incondicionalmente si existía — un usuario con los 6 módulos de
   terceros activos + los 5 descubrimientos podía terminar con 11 slides
   extra, exactamente el "aluvión sin curar" que el brief pedía evitar.

   Solo entran al pool de scoring los datos que PUEDEN acumularse sin
   límite según cuántos módulos tenga activos el usuario (dominios de
   terceros + descubrimientos). El "esqueleto" narrativo — intro,
   patrimonio, categoría del año, vista mensual, mejor/peor mes, gasto
   más grande, alcancía, racha, personalidad, "si tu año fuera", cierre —
   NO entra al pool: son como máximo 1 de cada uno, nunca se acumulan, y
   recortarlos por puntaje debilitaría la promesa central de Wrapped en
   vez de curarla.

   El puntaje es la SUMA de señales que el propio candidato ya sabe sobre
   sí mismo (nunca un cálculo nuevo — cada bandera sale de datos que su
   propia función `_wrappedCalcular*`/`_wrappedFases*` ya devolvió):
   - `esRecord` (+3): es un extremo real, no un promedio (récord, o ya
     pasó su propio filtro estadístico — ej. `_wrappedGastoMasRandom` ya
     exige z-score, así que CUALQUIER resultado suyo es por definición un
     record local).
   - `esCambioComportamiento` (+3): es una fase/cambio de hábito, no un
     dato estático — más "historia", no solo una cifra.
   - `involucraMeta` (+2): tiene una meta de por medio (más personal que
     un movimiento suelto).
   - `involucraPersona` (+1): nombra a alguien — mismo criterio suave de
     `wrapped.md §7ter` sobre por qué el protagonista se elige por
     actividad, no al azar.
   - `intensidad` (0 a 4, capado): qué tan lejos de "lo normal" está este
     dato para ESTE usuario — reutiliza valores relativos que cada
     función ya calculó (el `z` de `_wrappedGastoMasRandom`, el `pct` de
     una meta, la cantidad de personas involucradas), NUNCA un monto fijo
     en pesos, mismo criterio de todo el archivo. */
function _wrappedScoreInsight(c){
  let score = 0;
  if(c.esRecord) score += 3;
  if(c.esCambioComportamiento) score += 3;
  if(c.involucraMeta) score += 2;
  if(c.involucraPersona) score += 1;
  if(Number.isFinite(c.intensidad)) score += Math.max(0, Math.min(4, c.intensidad));
  return score;
}
/* Cuántos slides del pool de insights se muestran como máximo — el resto
   simplemente no se cuenta esta vez (nunca se pierden datos reales de
   `S`, solo no todos caben en UNA historia de un año sin sentirse
   inflada). Un número, no una fracción de todos los candidatos posibles,
   porque el objetivo es un tamaño de historia consistente entre un
   usuario con 2 módulos activos y uno con los 11 — mismo espíritu que
   Spotify Wrapped, que no crece sin límite aunque hayas escuchado más
   artistas. */
const WRAPPED_MAX_INSIGHTS_POOL = 8;

/* Lee el estado de "Ocultar saldos" (saldos-ocultos.js) directo de
   su localStorage ya documentado (`mf-saldos-ocultos`) — Wrapped no
   tiene forma de leer la variable interna de ese módulo (no está
   expuesta como `window._algo`, a diferencia de `_alcRachaAhorro`), así
   que usa la misma llave pública que ya persiste el toggle.
   Confirmado contra `saldos-ocultos.js`:
   `toggleSaldos()` guarda literalmente `'1'`/`'0'` (no `'true'`/`'false'`,
   que era mi supuesto sin verificar de la pasada anterior — corregido
   acá). El fallback ante cualquier error sigue siendo "no ocultar"
   (mejor mostrar de más que reventar el slide). */
function _wrappedSaldosOcultos(){
  try {
    if(typeof localStorage === 'undefined') return false;
    return localStorage.getItem('mf-saldos-ocultos') === '1';
  } catch(e){ return false; }
}

function _wrappedBuildSlides(S, fmt2, anioOpt){
  // Año que toca mostrar: decidido por js/core/wrapped-gate.js (núcleo
  // eager, siempre cargado antes que este módulo lazy) — resuelve la
  // decisión que había quedado abierta en wrapped.md §7decies. Antes
  // (opción 3 de esa sección) siempre era el año en curso, en vivo; ahora
  // (opción 2) es el año recién cerrado, y solo se llega hasta acá durante
  // la ventana de enero (ver el guard en window.renderWrapped más abajo).
  // Fallback al año en curso SOLO si wrapped-gate.js no llegó a cargar —
  // no debería pasar nunca en producción (carga antes que lazy-loader.js
  // en index.html), pero un dato faltante acá no debe romper el render.
  const anioK = anioOpt ? String(anioOpt) : (typeof window._wrappedAnioObjetivo === 'function'
    ? window._wrappedAnioObjetivo()
    : _wrappedHoy().slice(0,4));
  // ¿Hay datos suficientes? Si no, un mensaje honesto en vez de 17 diapositivas casi vacías (criterio en wrapped-gate.js; si ese archivo
  // no cargó —no pasa en producción— se asume que sí hay, como siempre).
  const datosAnio = typeof window._wrappedDatosAnio === 'function' ? window._wrappedDatosAnio(anioK, S) : { tier: 'suficiente' };
  if(datosAnio.tier !== 'suficiente') return _wrappedSlidesInsuficiente(datosAnio, anioK);
  const { anioActual, mesActualIdx } = _wrappedAnioYMesActual();
  const mesMax = (anioK === anioActual) ? mesActualIdx : 11;
  const s = _wrappedCalcularPeriodo(S, 'anio', null, anioK);
  const patrimonio = _wrappedPatrimonioAnio(S, anioK);
  const serie = _wrappedSerieMensualAnio(S, anioK);
  const { mejor, peor, promedio, empateMejor, empatePeor } = _wrappedMejorPeorMesAnio(S, anioK);
  const cambioHabitos = _wrappedCambioDeHabitos(S, anioK, mesMax);
  const fasesAnio = _wrappedFasesAnio(S, anioK, mesMax);
  const historiasMensuales = _wrappedHistoriasMensuales(S, anioK, mesMax);
  const graficoSvg = _wrappedGraficoAnimadoSvg(serie);
  const serieMensualIngresoGasto = _wrappedSerieMensualIngresoGasto(S, anioK, mesMax);

  // Arranca el banco de frases con una semilla determinista para esta
  // apertura (ver cabecera de sección de `_wrappedBankPick`) — reutiliza
  // `s.totalIngresos`/`s.totalGastos` (ya calculados solo para uso
  // interno, §3) y el patrimonio del año, nunca un cálculo nuevo.
  _wrappedIniciarBanco(anioK + '|' + s.totalIngresos + '|' + s.totalGastos + '|' + (patrimonio && Number.isFinite(patrimonio.diff) ? patrimonio.diff : 0));

  let racha = 0;
  if(typeof window !== 'undefined' && typeof window._alcRachaAhorro === 'function' && S.alcancia && S.alcancia.historial){
    racha = window._alcRachaAhorro(S.alcancia.historial);
  }

  // Dominios "de terceros" — ver comentario de cabecera del archivo y
  // wrapped.md §7ter. Cada uno es independiente; si un módulo no cargó
  // datos ese año, su función devuelve null y el slide simplemente no
  // se arma (mismo patrón que topCategoria/gastoMasGrande arriba).
  const encargosAnio    = _wrappedCalcularEncargos(S, 'anio', null, anioK);
  const prestadoAnio    = _wrappedCalcularPrestado(S, 'anio', null, anioK);
  const misDeudasAnio   = _wrappedCalcularMisDeudas(S, 'anio', null, anioK);
  const mesadaAnio      = _wrappedCalcularMesada(S, 'anio', null, anioK);
  const spotifyAnio     = _wrappedCalcularSpotify(S, 'anio', null, anioK);
  const comprometidaAnio = _wrappedCalcularComprometida(S, 'anio', null, anioK);
  // Tarjetas de Crédito (2026-09-15) — nuevo dominio, agregado después de
  // revisar `tarjetas_credito.js` a pedido del usuario. Deliberadamente
  // acotado a los INTERESES cobrados en el período (`_esCargoEspecial &&
  // _motivoCargo==='interes'`), no a la deuda actual (`tc.deuda`, que
  // puede venir de antes — mismo motivo por el que Préstamos tampoco
  // muestra "pendiente") ni a `calcDeudaAjenaDeTarjeta`/`calcDeudaTcPropia`
  // (viven en otro módulo no incluido acá; recalcularlas de memoria acá
  // violaría la regla de §3 de no reimplementar un cálculo centralizado
  // que no se puede ver/reexportar). Los intereses sí son un dato
  // 100% puntual del período, igual que el resto de §7ter.
  const interesesTC = _wrappedCalcularInteresesTC(S, 'anio', null, anioK);
  // Comisiones (2026-09-15, misma sesión): mismo dato de origen
  // (S.tarjetasCredito), motivo distinto — ver `_wrappedCalcularComisionesTC`
  // para el razonamiento completo de por qué es un candidato aparte y por
  // qué el tercer motivo ("otro cargo del banco") se dejó afuera.
  const comisionesTC = _wrappedCalcularComisionesTC(S, 'anio', null, anioK);

  // Segunda tanda (2026-09-13): personalidad, gasto random, protagonistas.
  const personalidad   = _wrappedPersonalidad(S, anioK);
  const gastoRandom    = _wrappedGastoMasRandom(S, 'anio', null, anioK, s.gastoMasGrande);
  const protagonistas  = _wrappedProtagonistas(S, 'anio', null, anioK);
  const metaCajita     = _wrappedMetaCajita(S);

  // Tercera tanda (2026-09-14) — ver comentario de cabecera de esa sección.
  const comparaciones   = _wrappedComparaciones(S, 'anio', null, anioK, s);
  const suscripciones   = _wrappedSuscripciones(S);
  const recuperacion    = _wrappedRecuperacionMasRapida(S, anioK);
  const descubrimientos = _wrappedDescubrimientos(S, anioK, s, prestadoAnio);
  const recordsAnio     = _wrappedRecordsAnio(S, anioK, s, prestadoAnio, serieMensualIngresoGasto);
  // Uso puramente interno para elegir la frase del año — nunca se pinta en
  // pantalla (mismo criterio que `balance`/`promedio` en el resto del
  // archivo, ver §3).
  const tasaAhorroInterna = s.totalIngresos > 0 ? s.balance / s.totalIngresos : 0;
  const fraseAnio = _wrappedFraseDelAnio({
    anioK,
    esBanquero: !!(prestadoAnio && prestadoAnio.totalPrestado > 0),
    tasaAhorroInterna,
    fasesAnio,
    prestadoDistintoDeRecuperacion: !!(prestadoAnio && prestadoAnio.topDeudor && recuperacion && prestadoAnio.topDeudor.nombre !== recuperacion.nombre)
  });

  const slides = [];

  // Fecha exacta de inicio/fin de datos del año (pase de diseño
  // 2026-09-14, ver `_wrappedRangoFechasAnio`) — degrada a la línea
  // genérica de siempre si el año todavía no tiene ni un solo dato real.
  const rangoFechas = _wrappedRangoFechasAnio(S, anioK);
  const introSub = rangoFechas
    ? `Movimiento por movimiento, desde el ${_wrappedFmtFechaLarga(rangoFechas.inicio)} hasta el ${_wrappedFmtFechaLarga(rangoFechas.fin)}.`
    : 'Lo repasamos un dato a la vez.';

  // «Balance honesto»: un año con patrimonio negativo al cierre, patrimonio cayendo con gastos sobre ingresos, o gastos sin ningún ingreso
  // registrado no se abre con fiesta. Mismos datos, otra portada y sin confeti; los números y las demás diapositivas no cambian.
  const dificil = _wrappedAnioDificil(patrimonio, s);
  slides.push({
    id: 'intro',
    mood: dificil ? 'accent' : 'purple',
    html: dificil
      ? `<div class="wrapped-slide-inner">
      <div class="wrapped-eyebrow">Tu balance ${anioK}</div>
      <div class="wrapped-headline">${dificil === 'sin-ingresos' ? 'Este año faltan ingresos en tus registros.' : 'Un año exigente, contado sin maquillaje.'}</div>
      <div class="wrapped-sub">${dificil === 'sin-ingresos' ? 'Registraste gastos pero ningún ingreso, así que el balance no está completo. Aun así, esto es lo que se ve.' : 'Lo importante de un año así es saber dónde estás parado. Esto es lo que pasó.'} ${introSub}</div>
    </div>`
      : `<div class="wrapped-slide-inner">
      <div class="wrapped-tag"><i class="fa-solid fa-tag"></i> Wrapped ${anioK}</div>
      <div class="wrapped-eyebrow">Tu resumen ${anioK}</div>
      <div class="wrapped-headline">${_wrappedCopyIntro()}</div>
      <div class="wrapped-sub">${introSub}</div>
    </div>`
  });

  // Slide "actividad" (2026-09-15): cuánta plata se movió en total y en
  // cuántos registros — es la apertura tipo "escuchaste 40.000 minutos"
  // de Spotify Wrapped: una cifra de volumen/actividad, no de resultado.
  // OJO CON LA REGLA DE §3: esto suma ingresos + gastos reales del año en
  // un solo número. No es lo mismo que mostrar `totalIngresos`/`totalGastos`
  // por separado (eso sí queda prohibido, porque de ahí se puede derivar
  // el balance y la tasa de ahorro) — un total combinado de "plata movida"
  // no permite reconstruir ninguno de los dos por separado. Aun así es una
  // decisión de producto nueva, no una consecuencia obvia de una regla ya
  // escrita — vale la pena confirmarla explícitamente si se documenta en
  // wrapped.md.
  if(s.totalIngresos > 0 || s.totalGastos > 0){
    const totalMovido = s.totalIngresos + s.totalGastos;
    const totalRegistros = (s.nGastos||0) + (s.nIngresos||0);
    slides.push({
      id: 'actividad',
      html: _wrappedSlideBignum('Para empezar', _wrappedBankPick('actividad-headline', [
        'Tu plata tuvo una vida bastante ocupada.',
        'Esto es todo lo que se movió este año.',
        'Así de activa estuvo tu plata este año.',
      ]), totalMovido, 'var(--text)', {
        sub: totalRegistros > 0
          ? `movidos en total entre ingresos y gastos, repartidos en ${totalRegistros} movimiento${totalRegistros===1?'':'s'} registrado${totalRegistros===1?'':'s'}.`
          : 'movidos en total entre ingresos y gastos este año.'
      })
    });
  }

  if(graficoSvg){
    let bignum = '', sub = '';
    if(patrimonio && Number.isFinite(patrimonio.diff)){
      bignum = `<div class="wrapped-bignum ${patrimonio.diff >= 0 ? 'c-green' : 'c-red'}" data-value="${patrimonio.diff}" data-signed="1">0</div>`;
      sub = `<div class="wrapped-sub">${_wrappedCopyPatrimonio(patrimonio, { balance: s.balance, gastoMasGrande: s.gastoMasGrande })}</div>`;
    }
    slides.push({
      id: 'patrimonio',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Tu patrimonio en ${anioK}</div>
        <div class="wrapped-chart-card">${graficoSvg}</div>
        ${bignum}${sub}
      </div>`
    });
  }

  if(s.topCategoria){
    slides.push({ id:'categoria', html: _wrappedSlideBignum('Tu categoría del año', escHtml(s.topCategoria.cat), s.topCategoria.monto, 'var(--purple)', {
      sub: _wrappedCopyCategoria(s.topCategoria)
    }) });

    // Slide nuevo (2026-09-15): ranking de TODAS las categorías, no solo
    // la ganadora — reusa `_wrappedItemsRealesPeriodo` (ya centralizado,
    // ver comentario ahí) para no recalcular el filtro de "gasto real",
    // y `_wrappedRankingCategorias` para no reimplementar el agrupado
    // que ya hace `_wrappedTopCategoriaDe`. Se salta si hay menos de 2
    // categorías (con una sola, ya lo dijo todo el slide de arriba).
    const itemsAnio = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);
    const rankingCats = _wrappedRankingCategorias(
      [...itemsAnio.gastosVarPeriodo, ...itemsAnio.pagosFijosPeriodo],
      s.totalGastos,
      7
    );
    if(rankingCats.length >= 2){
      const filas = rankingCats.map(c => `
        <div class="wrapped-bar-row">
          <div class="wrapped-bar-label">${escHtml(c.cat)}</div>
          <div class="wrapped-bar-track"><div class="wrapped-bar-fill" data-pct="${c.pct.toFixed(1)}"></div></div>
          <div class="wrapped-bar-pct">${c.pct.toFixed(1)}%</div>
        </div>`).join('');
      slides.push({
        id: 'categorias-ranking',
        mood: 'purple',
        html: `<div class="wrapped-slide-inner wrapped-slide-inner-wide">
          <div class="wrapped-eyebrow">${_wrappedBankPick('categoriasRanking-eyebrow', [
            'Así se repartió tu año',
            'Categoría por categoría',
            'Todo lo que se llevó tu plata',
          ])}</div>
          <div class="wrapped-headline"><b>${escHtml(rankingCats[0].cat)}</b> se llevó la mayor parte.</div>
          <div class="wrapped-bars">${filas}</div>
        </div>`
      });
    }
  }

  if(historiasMensuales){
    // Antes era una lista de una columna con scroll interno (fea dentro
    // de una historia tipo "reveal" — obligaba a scrollear DENTRO de un
    // slide, algo que ningún otro slide de este archivo hace). Ahora es
    // una cuadrícula de 2 columnas sin scroll: nombre corto de mes +
    // punto de color según el balance + la misma frase de siempre.
    const celdas = historiasMensuales.map(m => {
      const claseDot = m.balance > 0 ? 'wrapped-mes-dot-ok' : (m.balance < 0 ? 'wrapped-mes-dot-mal' : 'wrapped-mes-dot-cero');
      return `<div class="wrapped-mes-cell">
        <div class="wrapped-mes-cell-top"><span class="wrapped-mes-dot-color ${claseDot}"></span><span class="wrapped-mes-nombre">${_wrappedMesKaAbrev(m.mesK)}</span></div>
        <div class="wrapped-mes-linea">${m.linea}</div>
      </div>`;
    }).join('');
    slides.push({
      id: 'vista-mensual',
      mood: 'accent',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Este año, mes a mes</div>
        <div class="wrapped-mes-grid">${celdas}</div>
      </div>`
    });
  }

  if(serieMensualIngresoGasto){
    _wrappedMesChart = { meses: serieMensualIngresoGasto, fmt2 };
    slides.push({
      id: 'grafico-mensual',
      mood: 'accent',
      html: `<div class="wrapped-slide-inner wrapped-slide-inner-wide">
        <div class="wrapped-eyebrow">Mes a mes</div>
        <div class="wrapped-headline">Así se movió tu plata.</div>
        <div class="wrapped-chart-card">${_wrappedGraficoMensualSvg(serieMensualIngresoGasto)}</div>
        <div class="wrapped-mes-detalle">${_wrappedMesDetalleHtml(serieMensualIngresoGasto, serieMensualIngresoGasto.length-1, fmt2)}</div>
      </div>`
    });
  } else {
    _wrappedMesChart = null;
  }

  if(mejor){
    slides.push({ id:'mejor', html: _wrappedSlideBignum('Tu mejor mes', _wrappedMesKaNombre(mejor.mesK), mejor.balance, 'var(--accent)', {
      sub: _wrappedCopyMejorMes(mejor, promedio, empateMejor, fmt2)
    }) });
  }
  if(peor && (!mejor || peor.mesK !== mejor.mesK)){
    slides.push({ id:'peor', html: _wrappedSlideBignum('Tu mes más difícil', _wrappedMesKaNombre(peor.mesK), peor.balance, 'var(--red)', {
      sub: _wrappedCopyPeorMes(peor, promedio, empatePeor, fmt2)
    }) });
  }

  if(s.gastoMasGrande){
    slides.push({ id:'gasto', html: _wrappedSlideBignum('Tu gasto más grande', escHtml(s.gastoMasGrande.desc), s.gastoMasGrande.monto, 'var(--blue)', {
      sub: _wrappedCopyGasto(s.gastoMasGrande, s.avgGasto, s.totalGastos)
    }) });
  }

  if(s.alcanciaPeriodo > 0){
    slides.push({ id:'alcancia', html: _wrappedSlideBignum('Guardaste en la Alcancía', '', s.alcanciaPeriodo, 'var(--amber)', {
      ocultarValor: _wrappedSaldosOcultos(),
      sub: _wrappedCopyAlcancia(s.alcanciaPeriodo, s.gastoMasGrande, s.alcanciaCiclos)
    }) });
  }

  if(racha >= 2){
    slides.push({
      id: 'racha',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Racha de ahorro</div>
        <div class="wrapped-bignum c-amber">${racha}</div>
        <div class="wrapped-sub">alcancías seguidas — ${_wrappedCopyRacha(racha)}</div>
      </div>`
    });
  }

  // ─── Pool de insights con scoring (ver comentario arriba de
  // `_wrappedScoreInsight`) — cada candidato trae su HTML ya armado más
  // las banderas para puntuarlo. Se arma la lista completa, se puntúa, se
  // ordena de mayor a menor, y solo entran los primeros
  // `WRAPPED_MAX_INSIGHTS_POOL` a la historia final.
  const candidatosInsights = [];

  if(encargosAnio){
    candidatosInsights.push({
      involucraPersona: true,
      intensidad: Math.min(4, encargosAnio.nPersonas),
      html: _wrappedSlideBignum('Plata que te encargaron cuidar', '', encargosAnio.totalEncargado, 'var(--purple)', {
        sub: _wrappedCopyEncargos(encargosAnio, fmt2)
      })
    });
  }

  if(prestadoAnio && prestadoAnio.totalPrestado > 0){
    candidatosInsights.push({
      involucraPersona: true,
      esRecord: !!prestadoAnio.topDeudor,
      intensidad: prestadoAnio.totalDevuelto > 0 ? 2 : 1,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">${_wrappedBankPick('banco-eyebrow', [
          'Felicitaciones: este periodo también fuiste banco',
          'Resulta que también prestas plata',
          'Tu otro trabajo: entidad financiera informal',
        ])}</div>
        <div class="wrapped-headline">${_wrappedBankPick('banco-headline', [
          'Tuviste una sucursal bancaria funcionando sin que nadie te pagara por eso.',
          'Fuiste banco, cobrador y a veces también el que esperaba pacientemente.',
          'Prestaste plata como quien no quiere la cosa — sin intereses, como buen banco informal.',
        ])}</div>
        <div class="wrapped-stat-row">
          <div class="wrapped-stat"><div class="wrapped-stat-v">${fmt2(prestadoAnio.totalPrestado)}</div><div class="wrapped-stat-l">Prestado</div></div>
          <div class="wrapped-stat"><div class="wrapped-stat-v">${fmt2(prestadoAnio.totalDevuelto)}</div><div class="wrapped-stat-l">Recuperado</div></div>
        </div>
        <div class="wrapped-sub wrapped-sub-sep">${_wrappedCopyPrestado(prestadoAnio, fmt2)}</div>
      </div>`
    });
  }

  if(misDeudasAnio && misDeudasAnio.totalRecibido > 0){
    candidatosInsights.push({
      intensidad: 1,
      html: _wrappedSlideBignum('Te prestaron a ti', '', misDeudasAnio.totalRecibido, 'var(--blue)', {
        sub: _wrappedCopyMisDeudas(misDeudasAnio)
      })
    });
  }

  if(mesadaAnio){
    candidatosInsights.push({
      intensidad: 1, // es un ingreso esperado y recurrente, no una sorpresa
      html: _wrappedSlideBignum('Tu mesada del año', '', mesadaAnio.total, 'var(--accent)', {
        sub: _wrappedCopyMesada(mesadaAnio)
      })
    });
  }

  if(spotifyAnio){
    const color = spotifyAnio.balance >= 0 ? 'var(--accent)' : 'var(--red)';
    candidatosInsights.push({
      involucraPersona: true,
      esRecord: spotifyAnio.balance !== 0,
      intensidad: 2,
      html: _wrappedSlideBignum('Administrar Spotify te dejó', '', spotifyAnio.balance, color, {
        signed: true, sub: _wrappedCopySpotify(spotifyAnio, fmt2)
      })
    });
  }

  if(comprometidaAnio){
    candidatosInsights.push({
      esRecord: true, // ya pasó el filtro de `recibido:true` — es un evento real, no un promedio
      intensidad: 2,
      html: _wrappedSlideBignum('Plata comprometida que llegó', '', comprometidaAnio.total, 'var(--amber)', {
        sub: _wrappedCopyComprometida(comprometidaAnio)
      })
    });
  }

  if(interesesTC){
    candidatosInsights.push({
      esRecord: true, // es un cargo real del banco, no un promedio
      intensidad: 3, // costo puro, sin nada a cambio — pesa más que un gasto normal
      html: _wrappedSlideBignum('El banco te cobró en intereses', '', interesesTC.totalInteres, 'var(--red)', {
        sub: _wrappedCopyInteresesTC(interesesTC)
      })
    });
  }

  if(comisionesTC){
    candidatosInsights.push({
      esRecord: true, // mismo criterio que intereses: cargo real, no un promedio
      // Intensidad más baja que intereses (2 vs 3) a propósito: una
      // comisión (cuota de manejo, cargo puntual) suele ser más chica y
      // más "esperable" que pagar intereses por deuda — no compiten con
      // el mismo peso narrativo aunque ambas sean plata que se fue sin
      // que el usuario "eligiera" nada.
      intensidad: 2,
      html: _wrappedSlideBignum('El banco te cobró en comisiones', '', comisionesTC.totalComision, 'var(--red)', {
        sub: _wrappedCopyComisionesTC(comisionesTC)
      })
    });
  }

  if(metaCajita){
    candidatosInsights.push({
      involucraMeta: true,
      esRecord: metaCajita.prog.pct >= 100,
      intensidad: metaCajita.prog.pct >= 100 ? 4 : 2,
      html: _wrappedSlideBignum(`Tu meta "${escHtml(metaCajita.nombre)}"`, '', metaCajita.prog.pct, 'var(--accent)', {
        sufijo: '%', sub: _wrappedCopyMeta(metaCajita)
      })
    });
  }

  // Frecuencia vs. peso por movimiento (2026-09-15) — mismo espíritu que
  // la cláusula que ya existía dentro de `_wrappedCopyCategoria`
  // (`topPorFrecuencia`), pero como slide propio porque el contraste con
  // "la categoría más concentrada" es un dato curioso completo por sí
  // solo, no una nota al pie de la categoría del año. Solo entra si las
  // dos categorías realmente difieren — si coincidieran no habría
  // contraste que contar (misma regla de "no forzar" del resto del
  // archivo).
  if(s.topCategoria && s.topCategoria.topPorFrecuencia){
    const frecuente = s.topCategoria.topPorFrecuencia; // {cat, count}
    const itemsCat = _wrappedItemsRealesPeriodo(S, 'anio', null, anioK);
    const concentrada = _wrappedCategoriaMasConcentrada([...itemsCat.gastosVarPeriodo, ...itemsCat.pagosFijosPeriodo]);
    if(concentrada && concentrada.cat !== frecuente.cat){
      candidatosInsights.push({
        intensidad: 2,
        html: `<div class="wrapped-slide-inner">
          <div class="wrapped-eyebrow">${_wrappedBankPick('relCategoria-eyebrow', [
            'Un detalle curioso sobre tus categorías',
            'Frecuencia y peso no siempre van juntos',
            'Algo que probablemente no habías notado',
          ])}</div>
          <div class="wrapped-headline">${_wrappedBankPick('relCategoria-headline', [
            'Lo que más se repite no siempre es lo que más pesa.',
            'Una cosa es lo que más usas, otra lo que más cuesta cada vez.',
            'La categoría más presente no fue la más pesada por movimiento.',
          ])}</div>
          ${_wrappedFrasesHtml([
            `<b>${escHtml(frecuente.cat)}</b> fue tu categoría más frecuente, con ${frecuente.count} movimiento${frecuente.count===1?'':'s'}.`,
            `<b>${escHtml(concentrada.cat)}</b> fue la que más pesó por movimiento, en promedio ${fmt2(concentrada.avgPerOcc)} cada vez.`,
          ])}
        </div>`
      });
    }
  }

  if(comparaciones){
    candidatosInsights.push({
      intensidad: comparaciones.intensidadMax,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Números que se entienden mejor así</div>
        <div class="wrapped-headline">Un poco de contexto.</div>
        ${_wrappedFrasesHtml(comparaciones.frases)}
      </div>`
    });
  }

  if(suscripciones){
    const filas = [];
    if(suscripciones.spotify){
      filas.push(`Spotify compartido: ${fmt2(suscripciones.spotify.costoMensual)} al mes entre ${suscripciones.spotify.personas} persona${suscripciones.spotify.personas===1?'':'s'}.`);
    }
    suscripciones.personales.forEach(p => filas.push(`${escHtml(p.desc)}: ${fmt2(p.monto)} al mes.`));
    candidatosInsights.push({
      intensidad: 1,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Tus gastos que aparecen cada mes sin pedir permiso</div>
        <div class="wrapped-headline">${_wrappedBankPick('suscripciones-headline', [
          'Estos gastos aparecen solos, mes tras mes.',
          'Suscripciones y recurrentes: la plata que sale en piloto automático.',
          'Nadie te pregunta si quieres pagar esto — simplemente pasa cada mes.',
        ])}</div>
        ${_wrappedFrasesHtml(filas)}
      </div>`
    });
  }

  if(recuperacion){
    candidatosInsights.push({
      involucraPersona: true,
      esRecord: true,
      intensidad: Math.max(0, Math.min(4, (30 - recuperacion.dias) / 6)),
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">El regreso triunfal</div>
        <div class="wrapped-headline">${_wrappedNombrePersona(recuperacion.personaId, recuperacion.nombre)}</div>
        <div class="wrapped-bignum c-green">${recuperacion.dias}</div>
        <div class="wrapped-sub">día${recuperacion.dias===1?'':'s'} para devolverte por completo lo que le prestaste.</div>
      </div>`
    });
  }

  if(descubrimientos){
    candidatosInsights.push({
      intensidad: 1,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Cosas que probablemente no sabías</div>
        <div class="wrapped-headline">Un poco de trivia sobre tu año.</div>
        ${_wrappedFrasesHtml(descubrimientos)}
      </div>`
    });
  }

  if(recordsAnio){
    candidatosInsights.push({
      esRecord: true,
      intensidad: 3,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Lo más extremo</div>
        <div class="wrapped-headline">Lo más extremo del período.</div>
        ${_wrappedRecordsHtml(recordsAnio, fmt2)}
      </div>`
    });
  }

  if(gastoRandom){
    candidatosInsights.push({
      esRecord: true, // ya pasó el propio filtro de z-score de `_wrappedGastoMasRandom`
      intensidad: gastoRandom.z, // reutiliza el mismo z ya calculado, nunca uno nuevo
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Premio al gasto más inesperado</div>
        <div class="wrapped-headline"><i class="fa-solid fa-star wrapped-icono-sep c-purple"></i>${escHtml(gastoRandom.desc)}</div>
        <div class="wrapped-bignum c-purple" data-value="${gastoRandom.monto}">0</div>
        <div class="wrapped-sub">No esperábamos verte por acá este año.</div>
      </div>`
    });
  }

  if(protagonistas && protagonistas.top && protagonistas.top.n >= 3){
    const nombre = _wrappedNombrePersona(protagonistas.top.personaId, protagonistas.top.nombre);
    candidatosInsights.push({
      involucraPersona: true,
      intensidad: Math.min(4, protagonistas.top.n / 5),
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Tu protagonista del año</div>
        <div class="wrapped-headline">${nombre}</div>
        <div class="wrapped-sub">${protagonistas.top.n} movimientos juntos entre préstamos, encargos o Spotify${protagonistas.total>1?` — de ${protagonistas.total} personas con las que tuviste actividad`:''}.</div>
      </div>`
    });
  }

  if(cambioHabitos){
    candidatosInsights.push({
      esCambioComportamiento: true,
      intensidad: 3,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Cambiaste de hábitos a mitad de año</div>
        <div class="wrapped-headline">De <b>${escHtml(cambioHabitos.catPrimera)}</b> a <b>${escHtml(cambioHabitos.catSegunda)}</b></div>
        <div class="wrapped-sub">tu categoría más fuerte pasó de una a otra entre la primera y la segunda mitad del año.</div>
      </div>`
    });
  }

  if(fasesAnio){
    candidatosInsights.push({
      esCambioComportamiento: true,
      intensidad: 3,
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Tu año tuvo dos etapas</div>
        <div class="wrapped-sub">${_wrappedCopyFases(fasesAnio)}</div>
      </div>`
    });
  }

  // `candidatosPuntuados` (2026-09-15): antes este cálculo vivía inline y
  // se cortaba directo con `.slice`, descartando para siempre los
  // candidatos que no entraron. Separarlo en dos pasos no cambia qué
  // insights se eligen (`insightsElegidos` sigue siendo exactamente el
  // mismo corte de siempre) — solo permite que el panel de debug visual
  // (`_wrappedDebugPanelHtml`) pueda mostrar también los descartados y
  // por qué puntaje se quedaron afuera.
  const candidatosPuntuados = candidatosInsights
    .map(c => ({ ...c, score: _wrappedScoreInsight(c) }))
    .sort((a,b) => b.score - a.score); // sort estable: empates conservan el orden en que se agregaron arriba
  const insightsElegidos = candidatosPuntuados.slice(0, WRAPPED_MAX_INSIGHTS_POOL);

  // Puente narrativo (2026-09-14): una micro-pausa de texto, sin ningún
  // dato nuevo, entre el bloque de "datos ancla" (patrimonio, categoría,
  // mejor/peor mes, gasto más grande) y el pool de insights variables —
  // le da ritmo de "capítulo" a la historia en vez de saltar de golpe.
  // Puramente decorativo: no cambia qué se calcula, solo cómo se siente
  // la transición (mismo espíritu que `_wrappedSiTuAnioFuera`).
  if(insightsElegidos.length){
    slides.push({
      id: 'puente-insights',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-headline">${_wrappedCopyPuente('insights')}</div>
      </div>`
    });
  }

  insightsElegidos.forEach((c, i) => slides.push({ id: 'insight-' + i, html: c.html }));

  if(personalidad){
    slides.push({
      id: 'puente-personalidad',
      mood: 'amber',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-headline">${_wrappedCopyPuente('personalidad')}</div>
      </div>`
    });
    const chipsPersonalidad = [
      personalidad.evidencia ? `<span class="wrapped-pill">${escHtml(personalidad.evidencia)}</span>` : '',
      personalidad.secundario ? `<span class="wrapped-pill secundario">Rasgo secundario: ${escHtml(personalidad.secundario.tipo)}</span>` : ''
    ].join('');
    slides.push({
      id: 'personalidad',
      mood: 'amber',
      html: `<div class="wrapped-slide-inner">
        <div class="wrapped-eyebrow">Tu personalidad financiera</div>
        <div class="wrapped-headline">${escHtml(personalidad.tipo.toUpperCase())}</div>
        <div class="wrapped-sub">${escHtml(personalidad.frase)}</div>
        ${chipsPersonalidad ? `<div class="wrapped-pill-list">${chipsPersonalidad}</div>` : ''}
      </div>`
    });
  }

  const huboAlgo = slides.length > 1; // más que solo el intro

  if(!huboAlgo){
    // Había registros suficientes pero ninguna diapositiva de datos pudo armarse: se cuenta como «poco», con la misma voz.
    return _wrappedSlidesInsuficiente(Object.assign({}, datosAnio, { tier: 'poco' }), anioK);
  }

  const lineaCierre = _wrappedCopyCierre({ anioK, patrimonio, racha, s, gastoMasGrande: s.gastoMasGrande });

  slides.push({
    id: 'frase-anio',
    mood: 'purple',
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-eyebrow">Tu ${anioK} en una frase</div>
      <div class="wrapped-headline">"${fraseAnio}"</div>
    </div>`
  });

  slides.push({
    id: 'periodo-en-numeros',
    mood: 'accent',
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-eyebrow">Tu ${anioK} en números</div>
      <div class="wrapped-headline">El resumen rápido.</div>
      ${_wrappedRecordsHtml(_wrappedPeriodoEnNumeros(S, anioK, s, prestadoAnio, serieMensualIngresoGasto), fmt2)}
    </div>`
  });

  // "Si tu año fuera una película" siempre tiene ALGO que decir (hasta su
  // fallback es una frase honesta, no una inventada) — por eso se agrega
  // DESPUÉS de la guarda `huboAlgo`: si no hubo ningún dato real este año,
  // no debe ser esta frase decorativa la que rompa el estado vacío de
  // "Todavía no hay mucho que contar".
  slides.push({
    id: 'si-tu-anio-fuera',
    mood: 'purple',
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-eyebrow">Si tu año financiero fuera una película...</div>
      <div class="wrapped-sub">${_wrappedSiTuAnioFuera({ fasesAnio, cambioHabitos, racha, patrimonio })}</div>
    </div>`
  });

  // Párrafo de cierre más largo y emocional (pase de diseño 2026-09-14,
  // inspirado en el mockup de referencia) — se arma con `_wrappedCopyCierrePoema`,
  // que solo elige texto entre señales YA calculadas arriba (racha,
  // fasesAnio, patrimonio, personalidad) exactamente igual que
  // `_wrappedCopyCierre`; no reemplaza a `lineaCierre` (que sigue siendo
  // el titular grande), lo acompaña como segundo párrafo más largo.
  const poemaCierre = _wrappedCopyCierrePoema({ anioK, patrimonio, racha, fasesAnio, personalidad });

  slides.push({
    id: 'cierre',
    mood: 'purple',
    confetti: !dificil,
    html: `<div class="wrapped-slide-inner">
      <div class="wrapped-tag"><i class="fa-solid fa-tag"></i> Wrapped ${anioK}</div>
      <div class="wrapped-eyebrow">Eso fue ${anioK}</div>
      <div class="wrapped-headline">${lineaCierre}</div>
      <div class="wrapped-cierre-poema">${poemaCierre}</div>
      <div class="wrapped-cta-row">
        ${_WRAPPED_BTN_GUARDAR}
        <button type="button" class="wrapped-cta" data-wrapped-action="replay">Ver de nuevo</button>
        <button type="button" class="wrapped-cta ghost" data-wrapped-action="cerrar">Cerrar</button>
      </div>
    </div>`
  });

  // Mood/acento por slide para los que todavía no tienen uno explícito
  // (mejor/peor mes, gasto más grande, alcancía, categoría, patrimonio,
  // racha, y todos los "insights" de terceros armados con
  // `_wrappedSlideBignum`): en vez de tocar cada `slides.push(...)` de
  // arriba a mano, se reutiliza el MISMO color que esa función ya eligió
  // para pintar el número grande (la clase `c-purple`, etc.) —
  // así el acento de fondo siempre combina con el número del propio
  // slide, sin definir una segunda vez qué color le corresponde a cada
  // dato. Si un slide no trae ningún color inline (los puramente de
  // texto, que ya recibieron su `mood` explícito arriba), cae a
  // `--accent`, el mismo default neutro de siempre.
  const _MOOD_DE_CLASE = { 'c-purple':'purple', 'c-blue':'blue', 'c-amber':'amber', 'c-red':'red', 'c-green':'accent' };
  const _moodRegex = /(?:^|[\s"])(c-purple|c-blue|c-amber|c-red|c-green)(?=[\s"])/;
  slides.forEach(sl => {
    if(sl.mood) return;
    const m = _moodRegex.exec(sl.html);
    sl.mood = m ? _MOOD_DE_CLASE[m[1]] : 'accent';
  });

  // Snapshot para el panel de debug visual (2026-09-15, ver
  // `_wrappedDebugPanelHtml`) — nunca se lee si `?debug=1`/`#debug` no
  // está presente (`renderWrapped` ni siquiera llama a
  // `_wrappedDebugPanelHtml` en ese caso). Propiedad extra sobre el
  // array, no un campo nuevo en `S`: sigue sin haber ningún estado
  // persistido (§3) — vive y muere con esta única llamada a
  // `_wrappedBuildSlides`. Solo guarda metadatos de SELECCIÓN (puntaje,
  // qué tema, si entró o no) y evidencia ya factual que ya existía —
  // nunca ingresos/gastos/tasaAhorro en crudo (§3).
  slides._wrappedDebugInfo = {
    candidatosInsights: candidatosPuntuados.map((c, i) => ({
      // Label solo para lectura humana en el panel — se extrae del mismo
      // `wrapped-eyebrow` que ya se pinta en el slide (nunca un texto
      // nuevo); si por lo que sea no matchea, cae a un id genérico.
      label: (/<div class="wrapped-eyebrow">(.*?)<\/div>/.exec(c.html || '') || [null, 'insight-' + i])[1],
      score: c.score,
      elegido: i < WRAPPED_MAX_INSIGHTS_POOL,
      esRecord: !!c.esRecord,
      esCambioComportamiento: !!c.esCambioComportamiento,
      involucraMeta: !!c.involucraMeta,
      involucraPersona: !!c.involucraPersona,
      intensidad: c.intensidad || 0
    })),
    personalidad: personalidad ? {
      elegido: personalidad.tipo,
      secundario: personalidad.secundario ? personalidad.secundario.tipo : null,
      candidatos: (personalidad._candidatos || []).map(c => ({ tipo: c.tipo, evidencia: c.evidencia }))
    } : null,
    totalSlides: slides.length
  };

  return slides;
}

/* ─── MOTOR DE NAVEGACIÓN (tap, swipe, flechas) ───────────────────────────
   Un único estado de módulo (`_wrappedNav`) que se reemplaza por completo
   en cada apertura de la pantalla — evita acumular listeners de teclado
   "colgados" entre una apertura y otra (ver _wrappedLimpiarNav). */
let _wrappedNav = null;

function _wrappedLimpiarNav(){
  if(_wrappedNav && _wrappedNav.onKeydown){
    document.removeEventListener('keydown', _wrappedNav.onKeydown);
  }
  _wrappedNav = null;
}

function _wrappedGoTo(i){
  if(!_wrappedNav) return;
  const { slidesEls, segEls, fmt2, overlay } = _wrappedNav;
  if(i < 0 || i >= slidesEls.length) return;
  const anterior = slidesEls[_wrappedNav.current];
  if(anterior) anterior.classList.remove('active');
  _wrappedNav.current = i;
  const el = slidesEls[i];
  el.classList.add('active');
  // Mood/acento por slide (pase de diseño 2026-09-14, inspirado en el
  // mockup de referencia): reutiliza las mismas variables de color que
  // ya existen en toda la app (--accent/--purple/--blue/--amber/--red,
  // ver styles.css) — nunca una paleta nueva. `data-mood` se arma en
  // `_wrappedBuildSlides`; si un slide no trae mood, cae a `--accent`.
  if(overlay){
    const mood = el.getAttribute('data-mood') || 'accent';
    overlay.style.setProperty('--wrapped-mood', 'var(--' + mood + ')');
  }
  segEls.forEach((seg, idx) => {
    seg.classList.toggle('done', idx < i);
    const barra = seg.querySelector('i');
    if(barra) barra.style.width = (idx <= i) ? '100%' : '0%';
  });
  _wrappedAnimarNumeros(el, fmt2);
  if(el.querySelector('.wrapped-line-path')){
    requestAnimationFrame(() => requestAnimationFrame(() => _wrappedAnimarLinea(el)));
  }
  if(el.querySelector('.wrapped-mensual-svg')){
    _wrappedSetupGraficoMensual(el);
  }
  if(el.querySelector('.wrapped-bar-fill')){
    requestAnimationFrame(() => requestAnimationFrame(() => _wrappedAnimarBarras(el)));
  }
  if(el.getAttribute('data-confetti') === '1'){
    _wrappedLanzarConfeti(el);
  }
}

function _wrappedCerrar(){
  _wrappedLimpiarNav();
  // El overlay se monta en document.body (no dentro de #screen-wrapped,
  // ver wrapped.md §7bis), así que hay que sacarlo del DOM a mano al
  // cerrar — showScreen('config') solo oculta pantallas .screen, no toca
  // nada fuera de ese árbol.
  //
  // 'config' ya no es una suposición: Wrapped se abre ahora desde
  // Configuración → Herramientas → "Tu resumen" (antes vivía en el menú
  // "Más", ver CHANGELOG.md#wrapped), así que volver a 'config' es
  // exactamente la pantalla de la que se entró — mismo patrón que ya usa
  // Actividad reciente para volver a Configuración.
  //
  // Esto reemplaza el intento anterior, showScreen('mas'): 'mas' nunca
  // fue un id de .screen real (el menú "Más" es el overlay #mas-menu, no
  // una pantalla), así que getElementById('screen-mas') devolvía null y
  // showScreen() reventaba justo después de sacarle 'active' a todas las
  // .screen, dejando la app sin ninguna pantalla visible — la "página
  // negra" que se veía al cerrar.
  const overlay = document.getElementById('wrapped-overlay');
  if(overlay) overlay.remove();
  if(typeof showScreen === 'function') showScreen('config');
}

/* El overlay es `position:fixed`, y por spec un elemento fixed siempre
   tiene `offsetParent === null` — no sirve para detectar visibilidad acá.
   En su lugar se camina la cadena de ancestros buscando `display:none`
   (la forma real en que la app oculta una pantalla inactiva). */
function _wrappedVisible(el){
  if(!el || !el.isConnected) return false;
  if(typeof window === 'undefined' || !window.getComputedStyle) return true;
  let nodo = el;
  while(nodo){
    if(window.getComputedStyle(nodo).display === 'none') return false;
    nodo = nodo.parentElement;
  }
  return true;
}

// Botón «Guardar este Wrapped»: guarda el año que se está viendo y deja el botón en «Guardado».
function _wrappedAlGuardar(boton, contexto){
  try{
    _wrappedGuardar(window.S || {}, contexto.anioK, contexto.slides);
  }catch(e){
    console.warn('[wrapped] No se pudo guardar el Wrapped:', e);
    if(typeof toast === 'function') toast('No se pudo guardar el Wrapped.', 'err', 4000);
    return;
  }
  const marca = document.createElement('div');
  marca.innerHTML = _WRAPPED_BTN_GUARDADO;
  boton.replaceWith(marca.firstChild);
  if(typeof toast === 'function') toast('Wrapped guardado. Lo encuentras en Configuración, en la sección Mis Wrapped.', 'ok', 4000);
}

function _wrappedSetupNav(overlay, fmt2, contexto){
  _wrappedLimpiarNav();

  const slidesEls = Array.prototype.slice.call(overlay.querySelectorAll('.wrapped-slide'));
  const segEls    = Array.prototype.slice.call(overlay.querySelectorAll('.wrapped-seg'));
  const contSlides = overlay.querySelector('#wrapped-slides');
  const closeBtn   = overlay.querySelector('#wrapped-close');
  const restartBtn = overlay.querySelector('#wrapped-restart');
  const hintEl     = overlay.querySelector('#wrapped-hint');

  _wrappedNav = { slidesEls, segEls, fmt2, overlay, current: 0, onKeydown: null };

  // El hint de navegación solo tiene sentido antes de que el usuario
  // entienda cómo se mueve la historia — se apaga con la primera
  // interacción real (tap para avanzar/retroceder, swipe o flecha) y no
  // vuelve a aparecer en esta misma apertura.
  function ocultarHint(){ if(hintEl) hintEl.classList.add('wrapped-oculto'); }

  function siguiente(){ ocultarHint(); _wrappedGoTo(_wrappedNav.current + 1); }
  function anterior(){ ocultarHint(); _wrappedGoTo(_wrappedNav.current - 1); }

  // Un solo listener de click decide: si el tap fue sobre algo
  // interactivo (los botones de "Ver de nuevo" / "Cerrar" del slide de
  // cierre) lo deja pasar; si no, navega según la mitad de la pantalla
  // donde ocurrió el tap — mismo patrón de "zonas muertas" que usa la
  // navegación tipo stories.
  contSlides.addEventListener('click', function(e){
    // Un tap sobre una zona de mes del gráfico interactivo (ver
    // `_wrappedGraficoMensualSvg`) selecciona ese mes en vez de navegar de
    // slide — se resuelve ANTES que la lista de "interactivo" de abajo
    // porque el hitzone es un <rect> dentro del SVG, no un elemento de
    // formulario.
    const mesHit = e.target.closest && e.target.closest('[data-wrapped-mesidx]');
    if(mesHit){
      const slideEl = mesHit.closest('.wrapped-slide');
      _wrappedSeleccionarMes(slideEl, parseInt(mesHit.getAttribute('data-wrapped-mesidx'),10));
      return;
    }
    const interactivo = e.target.closest && e.target.closest('button, a, input, select, textarea');
    if(interactivo){
      const accion = interactivo.getAttribute('data-wrapped-action');
      if(accion === 'replay') _wrappedGoTo(0);
      else if(accion === 'cerrar') _wrappedCerrar();
      else if(accion === 'guardar') _wrappedAlGuardar(interactivo, contexto);
      return;
    }
    const rect = contSlides.getBoundingClientRect();
    const x = e.clientX - rect.left;
    if(x < rect.width * 0.34) anterior();
    else siguiente();
  });

  let touchX = null, touchY = null;
  contSlides.addEventListener('touchstart', function(e){
    touchX = e.touches[0].clientX;
    touchY = e.touches[0].clientY;
  }, { passive: true });
  contSlides.addEventListener('touchend', function(e){
    if(touchX === null) return;
    const dx = e.changedTouches[0].clientX - touchX;
    const dy = e.changedTouches[0].clientY - touchY;
    // Convención estándar de "stories": el swipe horizontal cambia de
    // historia; el eje vertical se deja libre para no sentirse raro.
    if(Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy)){
      dx < 0 ? siguiente() : anterior();
    }
    touchX = null; touchY = null;
  }, { passive: true });

  if(closeBtn) closeBtn.addEventListener('click', _wrappedCerrar);
  // Reinicio rápido desde cualquier punto de la historia — antes solo
  // existía el botón "Ver de nuevo" del slide de cierre, que obligaba a
  // llegar hasta el final para volver a ver algo desde el principio.
  if(restartBtn) restartBtn.addEventListener('click', function(){ ocultarHint(); _wrappedGoTo(0); });

  // Flechas de teclado — solo reaccionan si la pantalla de Wrapped sigue
  // realmente visible (evita que un listener "colgado", si el usuario
  // salió de esta pantalla sin pasar por el botón Cerrar, siga
  // interceptando flechas en el resto de la app) y si el foco no está en
  // un campo de texto.
  const onKeydown = function(e){
    if(!_wrappedVisible(overlay)) return;
    const activo = document.activeElement;
    if(activo && /^(INPUT|TEXTAREA|SELECT)$/.test(activo.tagName)) return;
    if(e.key === 'ArrowRight'){ siguiente(); }
    else if(e.key === 'ArrowLeft'){ anterior(); }
  };
  document.addEventListener('keydown', onKeydown);
  _wrappedNav.onKeydown = onKeydown;
}

/* ─── ENTRADA PRINCIPAL ────────────────────────────────────────────────── */
window.renderWrapped = function(anioOpt){
  // Año a mostrar: el pedido (`renderWrapped(2026)`), el que dejó _wrappedAbrir (wrapped-gate.js, se consume) o el recién cerrado.
  const objetivo = typeof window._wrappedAnioObjetivo === 'function' ? window._wrappedAnioObjetivo() : _wrappedHoy().slice(0,4);
  const anioK = String(anioOpt || window._wrappedAnioVista || objetivo);
  window._wrappedAnioVista = undefined;

  const S = window.S || {};
  const guardado = S.wrappedAnios && S.wrappedAnios[anioK];

  // GENERAR solo se puede para el año recién cerrado y durante la ventana de enero; VER uno guardado, siempre. Fuera de eso, quien llega por
  // otro camino (deep link viejo, showScreen('wrapped') a mano desde la consola) vuelve a Configuración — ver wrapped.md §7decies.
  const generable = anioK === objetivo && !(typeof window._wrappedDisponible === 'function' && !window._wrappedDisponible());
  if(!guardado && !generable){
    if(typeof toast === 'function') toast('Tu resumen del año vuelve en enero.', 'info', 4000);
    if(typeof showScreen === 'function') showScreen('config');
    return;
  }

  // Marca "ya lo vio" para este año objetivo — así el banner de aviso
  // (wrapped-gate.js) no insiste si el usuario ya entró por su cuenta
  // desde el menú. Flag de UI en localStorage, no un dato financiero
  // nuevo en S (mismo criterio de siempre, ver cabecera del archivo §3).
  if(anioK === objetivo){
    try{ localStorage.setItem('mf_wrapped_visto_' + objetivo, '1'); }catch(_){}
  }

  const fmt2 = fmt; // se inyecta en las funciones de copy (_wrappedCopy*) para que sigan siendo puras

  _wrappedLogDebug(S);
  _wrappedInyectarEstilos();

  // Mostrar. Dentro de la ventana de enero SIEMPRE se calcula: si el año ya estaba guardado y el cálculo sigue dando un Wrapped real, el
  // guardado se reemplaza (entra lo añadido tarde); si ya no hay datos suficientes se conserva el guardado. Fuera de la ventana, el guardado
  // se muestra tal cual, sin recalcular nada. Abrir NUNCA guarda por sí solo: eso es el botón «Guardar» de la última diapositiva.
  let slides;
  if(generable){
    const frescas = _wrappedBuildSlides(S, fmt2, anioK);
    const esMensaje = frescas.some(sl => sl.id === 'insuf-titular');
    if(guardado && esMensaje){
      slides = _wrappedSlidesDeSnapshot(guardado);
    } else {
      if(guardado){
        try{ _wrappedGuardar(S, anioK, frescas); }catch(e){ console.warn('[wrapped] No se pudo actualizar el Wrapped de ' + anioK + ':', e); }
      }
      slides = guardado ? _wrappedMarcarGuardado(frescas) : frescas;
    }
  } else {
    slides = _wrappedSlidesDeSnapshot(guardado); // el recuerdo tal como se guardó: no se recalcula nada
  }

  const progresoHtml = slides.map(() => `<div class="wrapped-seg"><i></i></div>`).join('');
  const slidesHtml = slides.map(sl => `<div class="wrapped-slide" data-mood="${sl.mood || 'accent'}"${sl.confetti ? ' data-confetti="1"' : ''}>${sl.html}</div>`).join('');

  // Panel de debug visual (2026-09-15) — solo se arma y se inyecta cuando
  // la URL trae `?debug=1`/`#debug` (ver `_wrappedDebugPanelHtml`); en
  // cualquier otro caso `debugHtml` queda vacío y no se agrega nada al
  // DOM ni se paga el costo de armar las tablas.
  const debugOn = _wrappedDebugOn() && !!slides._wrappedDebugInfo; // el panel de debug necesita los datos del armado: un guardado no los tiene
  const debugHtml = debugOn
    ? `<button type="button" id="wrapped-debug-toggle" aria-label="Panel de debug" title="Panel de debug">
         <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
       </button>
       <div id="wrapped-debug-panel">
         <div id="wrapped-debug-head"><span>Debug — Wrapped</span><button type="button" id="wrapped-debug-close">
           <svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
         </button></div>
         <div id="wrapped-debug-body">${_wrappedDebugPanelHtml(S, slides._wrappedDebugInfo)}</div>
       </div>`
    : '';

  // Se monta directo en document.body (no dentro de #wrapped-body /
  // #screen-wrapped) — ver wrapped.md §7bis: .screen.active tiene un
  // transform:translateY(0) permanente (animation-fill-mode:both en
  // styles.css), y cualquier transform en un ancestro convierte a este
  // overlay position:fixed en algo posicionado contra ESE ancestro en
  // vez del viewport. Mismo patrón que #toast-container.
  const overlayPrevio = document.getElementById('wrapped-overlay');
  if(overlayPrevio) overlayPrevio.remove();

  const overlay = document.createElement('div');
  overlay.id = 'wrapped-overlay';
  overlay.innerHTML = `<div class="wrapped-bg-blob b1"></div>
    <div class="wrapped-bg-blob b2"></div>
    <div id="wrapped-progress">${progresoHtml}</div>
    <div id="wrapped-topbar">
      <span class="wrapped-brand">Tu resumen</span>
      <div class="wrapped-topbar-right">
        <button type="button" id="wrapped-restart" aria-label="Volver al inicio" title="Volver al inicio"><i class="fa-solid fa-arrow-rotate-left"></i></button>
        <button type="button" id="wrapped-close" aria-label="Cerrar" title="Cerrar">
          <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
        </button>
      </div>
    </div>
    <div id="wrapped-slides">${slidesHtml}</div>
    <div id="wrapped-hint">Toca, desliza o usa las flechas para avanzar</div>
    ${debugHtml}`;
  document.body.appendChild(overlay);

  if(debugOn){
    const toggle = overlay.querySelector('#wrapped-debug-toggle');
    const panel = overlay.querySelector('#wrapped-debug-panel');
    const closeBtn = overlay.querySelector('#wrapped-debug-close');
    // stopPropagation: el overlay entero tiene un click delegado para
    // avanzar/retroceder de historia (ver `_wrappedSetupNav`) — sin esto,
    // tocar el botón de debug o cerrar el panel también dispararía "siguiente".
    if(toggle) toggle.addEventListener('click', function(e){ e.stopPropagation(); panel.classList.toggle('wrapped-abierto'); });
    if(closeBtn) closeBtn.addEventListener('click', function(e){ e.stopPropagation(); panel.classList.remove('wrapped-abierto'); });
    if(panel) panel.addEventListener('click', function(e){ e.stopPropagation(); });
  }

  _wrappedSetupNav(overlay, fmt2, { anioK, slides });
  _wrappedGoTo(0);
};

/* Sin Events.registerAll: la navegación de esta pantalla se maneja por
   completo dentro de este archivo (ver _wrappedSetupNav) — no hay
   data-action delegados al dispatcher central de eventos porque la
   interacción (tap por zona, swipe, flechas) es específica de un
   carrusel de historias, no un formulario ni una lista de botones. */

/* Exportadas solo para poder testear los cálculos y el armado de slides
   de forma aislada — no se usan desde ningún otro archivo. */
// Sonda de la huella (js/core/huella.js): lo que Wrapped calcula del ÚNICO año que la app puede mostrar — el recién cerrado, año actual − 1
// (_wrappedVentana en wrapped-gate.js, que es la fuente; sin él se calcula igual desde hoy()). Cubre totales, mejor/peor mes, gasto más
// grande y categoría líder (dentro de _wrappedCalcularPeriodo) y cada dominio de terceros (encargos, préstamos, mesada, Spotify, comprometida,
// intereses y comisiones de tarjeta). Los años anteriores no se ven en ninguna pantalla, así que no se exige conservarlos: la política de
// corte (Cierre.corteMasReciente, ≥ 24 meses, siempre ≤ dic de año − 2) deja intacto este año por construcción y la sonda lo comprueba.
// Corre aislada: las funciones reciben la copia como `S`. docs/cierre-de-periodos.md.
registrarSonda('wrapped',function(st){
  const out={};
  const anioObjetivo=typeof window._wrappedAnioObjetivo==='function'?window._wrappedAnioObjetivo():String(parseInt(hoy().slice(0,4),10)-1);
  [anioObjetivo].forEach(anioK=>{
    out[anioK]={
      periodo:_wrappedCalcularPeriodo(st,'anio',null,anioK),
      mejorPeor:_wrappedMejorPeorMesAnio(st,anioK),
      encargos:_wrappedCalcularEncargos(st,'anio',null,anioK),
      prestado:_wrappedCalcularPrestado(st,'anio',null,anioK),
      misDeudas:_wrappedCalcularMisDeudas(st,'anio',null,anioK),
      mesada:_wrappedCalcularMesada(st,'anio',null,anioK),
      spotify:_wrappedCalcularSpotify(st,'anio',null,anioK),
      comprometida:_wrappedCalcularComprometida(st,'anio',null,anioK),
      interesesTC:_wrappedCalcularInteresesTC(st,'anio',null,anioK),
      comisionesTC:_wrappedCalcularComisionesTC(st,'anio',null,anioK),
      protagonistas:_wrappedProtagonistas(st,'anio',null,anioK),
      recuperacion:_wrappedRecuperacionMasRapida(st,anioK)
    };
  });
  return out;
});

window._wrappedInternals = {
  WRAPPED_BANCO_INSUFICIENTE,
  WRAPPED_SNAPSHOT_VERSION,
  _wrappedSlidesInsuficiente,
  _wrappedSnapshotDe,
  _wrappedGuardar,
  _wrappedMarcarGuardado,
  _wrappedSlidesDeSnapshot,
  _wrappedSinMascara,
  _wrappedConMascara,
  _wrappedBankPick,
  _wrappedIniciarBanco,
  _wrappedHashStr,
  _wrappedSeededRandom,
  _wrappedCalcularPeriodo,
  _wrappedInicioRachaReal,
  _wrappedMejorPeorMesAnio,
  _wrappedPatrimonioAnio,
  _wrappedAnioDificil,
  _wrappedSerieMensualAnio,
  _wrappedGraficoAnimadoSvg,
  _wrappedMesKaNombre,
  _wrappedBuildSlides,
  _wrappedFmtSigned,
  _wrappedCopyIntro,
  _wrappedCopyPuente,
  _wrappedCopyPatrimonio,
  _wrappedCopyCategoria,
  _wrappedCopyMejorMes,
  _wrappedCopyPeorMes,
  _wrappedCopyAlcancia,
  _wrappedCopyRacha,
  _wrappedCopyCierre,
  _wrappedCopyCierrePoema,
  _wrappedCopyGasto,
  _wrappedTopCategoriaDe,
  _wrappedCambioDeHabitos,
  _wrappedAnioYMesActual,
  _wrappedEnRango,
  _wrappedValidarDatos,
  _wrappedDebugOn,
  _wrappedDebugPanelHtml,
  _wrappedCalcularEncargos,
  _wrappedCalcularPrestado,
  _wrappedCalcularMisDeudas,
  _wrappedCalcularMesada,
  _wrappedCalcularSpotify,
  _wrappedCalcularComprometida,
  _wrappedCalcularInteresesTC,
  _wrappedCopyInteresesTC,
  _wrappedCalcularComisionesTC,
  _wrappedCopyComisionesTC,
  _wrappedNombrePersona,
  _wrappedMesadaMes,
  _wrappedIngresosFijosMes,
  _wrappedCuotaAnioFallback,
  _wrappedListaCajitas,
  _wrappedPersonalidad,
  _wrappedGastoMasRandom,
  _wrappedProtagonistas,
  _wrappedMetaCajita,
  _wrappedCopyMeta,
  _wrappedCorteMitadAnio,
  _wrappedCambioFuerte,
  _wrappedFasesAnio,
  _wrappedCopyFases,
  _wrappedSiTuAnioFuera,
  _wrappedHistoriasMensuales,
  _wrappedLineaMes,
  _wrappedScoreInsight,
  _wrappedItemsRealesPeriodo,
  _wrappedSerieMensualIngresoGasto,
  _wrappedGraficoMensualSvg,
  _wrappedMesDetalleHtml,
  _wrappedComparaciones,
  _wrappedAlcanciaDepositosPeriodo,
  _wrappedSuscripciones,
  _wrappedRecuperacionMasRapida,
  _wrappedDescubrimientos,
  _wrappedRecordsAnio,
  _wrappedPersonasInvolucradas,
  _wrappedPeriodoEnNumeros,
  _wrappedFraseDelAnio
};

})();

Ui.pantalla('wrapped', () => { if (typeof renderWrapped === 'function') renderWrapped(); }, { key: 'wrapped-render' });
